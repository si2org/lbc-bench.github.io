`timescale 1ns/1ps

module gcd_3_ip_tb;

   // Parameters
   localparam WIDTH = 6;
   localparam SIGNED_EN = 1; // Set to 1 to enable signed inputs

   // Clock and reset
   logic clk;
   logic rst;

   // Inputs to DUT
   logic signed [WIDTH-1:0] A;
   logic signed [WIDTH-1:0] B;
   logic signed [WIDTH-1:0] C;
   logic go;

   integer i;
  
   // Outputs from DUT
   logic signed [WIDTH-1:0] OUT;
   logic done;

   // Instantiate DUT
   gcd_3_ip #(
      .WIDTH(WIDTH),
      .SIGNED_EN(SIGNED_EN)
   ) dut (
      .clk (clk),
      .rst (rst),
      .A   (A),
      .B   (B),
      .C   (C),
      .go  (go),
      .OUT (OUT),
      .done(done)
   );

   initial begin
      $dumpfile("test.vcd");
      $dumpvars(0, dut);
   end

   // Clock generation
   initial begin
      clk = 0;
      forever #5 clk = ~clk;  
   end

   // Function to compute GCD
   function automatic integer gcd(input integer x, input integer y);
      begin
         x = (x < 0) ? -x : x; 
         y = (y < 0) ? -y : y;
         while (y != 0) begin
            integer t;
            t = y;
            y = x % y;
            x = t;
         end
         gcd = x;
      end
   endfunction

   function automatic integer compute_gcd(input integer x, input integer y, input integer z);
      integer temp_gcd_1;
      begin
         temp_gcd_1 = gcd(x, y);
         compute_gcd = gcd(temp_gcd_1, z);
      end
   endfunction

   // Task to perform a test case
   task automatic test_case(
      input integer a_in,
      input integer b_in,
      input integer c_in
   );
      integer expected_gcd;
      integer start_time, end_time, latency;
      begin
         @(negedge clk);
         A <= a_in;
         B <= b_in;
         C <= c_in;
         go <= 1;
         @(posedge clk);
         @(posedge clk);
         go <= 0;

         start_time = $time;

         wait (done == 1);

         end_time = $time;

         latency = (end_time - start_time) / 10; 

         @(posedge clk);
         go <= 0;

         expected_gcd = compute_gcd(a_in, b_in, c_in);

         expected_gcd = expected_gcd & ((1 << WIDTH) - 1);

         if (OUT !== expected_gcd) begin
            $display("Test FAILED for inputs A=%0d, B=%0d, C=%0d: Expected GCD=%0d, Got=%0d at time %0t", a_in, b_in, c_in, expected_gcd, OUT, $time);
         end else begin
            $display("Test PASSED for inputs A=%0d, B=%0d, C=%0d: GCD=%0d, Latency=%0d cycles", a_in, b_in, c_in, OUT, latency);
         end
      end
   endtask

   // Test sequence
   initial begin
      // Initialize signals
      rst = 1;
      A = 0;
      B = 0;
      C = 0;
      go = 0;

      #20;
      rst = 0;

      // Test case 1: A=0, B=0, C=0
      test_case(0, 0, 0);

      // Test case 2: A=-1, B=0, C=0
      test_case(-1, 0, 0);

      // Test case 3: A=0, B=-1, C=0
      test_case(0, -1, 0);

      // Test case 4: A=0, B=0, C=-1
      test_case(0, 0, -1);

      // Test case 5: A=-1, B=-1, C=-1
      test_case(-1, -1, -1);

      // Test case 6: A=31, B=-31, C=31
      test_case(31, -31, 31);

      // Test case 7: A=-15, B=10, C=5
      test_case(-15, 10, 5);

      // Test case 8: A=31, B=0, C=-15
      test_case(31, 0, -15);

      // Test case 9: A=-18, B=24, C=-30
      test_case(-18, 24, -30);
	  
      // Test case 10: A=18, B=24, C=30
      test_case(18, 24, 30);

      for (i = 0; i < 10; i = i + 1) begin
         integer a_rand, b_rand, c_rand;
         integer min_val, max_val;
         if (SIGNED_EN == 1) begin
            min_val = -(1 << (WIDTH-1));
            max_val = (1 << (WIDTH-1)) - 1;
            a_rand = ($random % (max_val - min_val + 1)) + min_val;
            b_rand = ($random % (max_val - min_val + 1)) + min_val;
            c_rand = ($random % (max_val - min_val + 1)) + min_val;
         end else begin
            min_val = 0;
            max_val = (1 << WIDTH) - 1;
            a_rand = $urandom_range(min_val, max_val);
            b_rand = $urandom_range(min_val, max_val);
            c_rand = $urandom_range(min_val, max_val);
         end
         test_case(a_rand, b_rand, c_rand);
      end

      @(negedge clk);
      A <= -15;
      B <= 10;
      C <= -5;
      go <= 1;
      @(posedge clk);
      go <= 0;

      #20;

      rst <= 1;
      #10;
      rst <= 0;

      if (done) begin
         $display("Error: 'done' asserted after reset during operation at time %0t", $time);
      end else begin
         $display("Reset during operation handled correctly at time %0t", $time);
      end

      test_case(20, -15, 10);

      #100;
      $display("All tests completed.");
      $finish;
   end

endmodule