import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
import random

class SPIFlashModel:
    """
    Enhanced SPI Flash memory model that accurately serves 32-bit words
    MSB-first, matching the SPI protocol requirements.
    """
    
    def __init__(self):
        self.memory = {}
        self.address = 0
        self.cmd = 0
        self.state = "IDLE"
        self.bit_count = 0
        self.shift_reg = 0
        self.current_word = 0
        self.word_bit_count = 0
        
    def process_bit(self, mosi_bit, cs_active):
        """Processes a single MOSI bit and returns the corresponding MISO bit."""
        miso_bit = 0
        
        if not cs_active:
            self.state = "IDLE"
            self.bit_count = 0
            self.word_bit_count = 0
            return 0
            
        if self.state == "IDLE" and cs_active:
            self.state = "CMD"
            self.bit_count = 0
            self.shift_reg = 0
            
        self.shift_reg = (self.shift_reg << 1) | mosi_bit
        self.bit_count += 1
        
        if self.state == "CMD" and self.bit_count == 8:
            self.cmd = self.shift_reg & 0xFF
            if self.cmd == 0x03:  # READ command
                self.state = "ADDR"
                self.bit_count = 0
                self.shift_reg = 0
                
        elif self.state == "ADDR" and self.bit_count == 24:
            self.address = self.shift_reg & 0xFFFFFF
            self.state = "DATA"
            self.bit_count = 0
            self.word_bit_count = 0
            self.current_word = self.memory.get(self.address, 0x00000000)
            
        elif self.state == "DATA":
            bit_pos = 31 - self.word_bit_count
            miso_bit = (self.current_word >> bit_pos) & 1
            
            self.word_bit_count += 1
            
            if self.word_bit_count >= 32:
                self.word_bit_count = 0
                self.address += 4
                self.current_word = self.memory.get(self.address, 0x00000000)
            
        return miso_bit

@cocotb.test()
async def test_spi_controller_basic(dut):
    """Test basic SPI controller functionality."""
    clock = Clock(dut.clk_i, 10, unit="ns")
    cocotb.start_soon(clock.start())
    flash_model = SPIFlashModel()
    
    # Reset sequence
    dut.rst_ni.value = 0
    dut.start_i.value = 0
    dut.slot_i.value = 0
    dut.miso_i.value = 0
    await Timer(100, unit="ns")
    dut.rst_ni.value = 1
    await Timer(50, unit="ns")
    
    # Start SPI transaction
    dut.slot_i.value = 1
    dut.start_i.value = 1
    await RisingEdge(dut.clk_i)
    dut.start_i.value = 0
    
    # Monitor until SPI controller is idle
    for _ in range(10000):
        if int(dut.spi_busy_o.value) == 0:
            break
        await RisingEdge(dut.clk_i)
        if int(dut.sclk_o.value) == 1:
            cs = not int(dut.cs_no.value)
            mosi = int(dut.mosi_o.value)
            dut.miso_i.value = flash_model.process_bit(mosi, cs)
    
    assert int(dut.spi_busy_o.value) == 0, "SPI controller should complete transaction"
    dut._log.info("SPI controller test completed successfully")

@cocotb.test()
async def test_fabric_configuration(dut):
    """Test fabric configuration with a proven working sequence."""
    clock = Clock(dut.clk_i, 10, unit="ns")
    cocotb.start_soon(clock.start())
    
    # Reset sequence
    dut.rst_ni.value = 0
    await Timer(100, unit="ns")
    dut.rst_ni.value = 1
    await Timer(50, unit="ns")
    
    fabric_config = dut.u_fabric_config
    fabric_config.bitstream_valid_i.value = 0
    fabric_config.bitstream_data_i.value = 0
    await RisingEdge(dut.clk_i)
    
    # Send Start Marker
    fabric_config.bitstream_data_i.value = 0xFAB0FAB1
    fabric_config.bitstream_valid_i.value = 1
    await RisingEdge(dut.clk_i)
    
    # Send Desync Flag to trigger configuration
    fabric_config.bitstream_data_i.value = 1 << 20
    await RisingEdge(dut.clk_i)
    
    # Deassert valid and wait for logic to settle
    fabric_config.bitstream_valid_i.value = 0
    await Timer(100, unit="ns")
    
    assert int(dut.configured_o.value) == 1, "Fabric should be configured"
    dut._log.info("Fabric configuration test completed successfully")

@cocotb.test()
async def test_reset_during_operation(dut):
    """Test system reset during an active operation."""
    clock = Clock(dut.clk_i, 10, unit="ns")
    cocotb.start_soon(clock.start())
    
    # Initial reset
    dut.rst_ni.value = 0
    dut.start_i.value = 0
    dut.slot_i.value = 0
    await Timer(100, unit="ns")
    dut.rst_ni.value = 1
    await Timer(50, unit="ns")

    # Start an operation
    dut.slot_i.value = 3
    dut.start_i.value = 1
    await RisingEdge(dut.clk_i)
    dut.start_i.value = 0

    # Wait for the system to become busy
    await RisingEdge(dut.clk_i)
    assert int(dut.spi_busy_o.value) == 1, "System should be busy after start pulse"
    
    # Wait for some cycles while busy
    await Timer(200, unit="ns")
    
    # Apply reset during the operation
    dut.rst_ni.value = 0
    await Timer(100, unit="ns")
    dut.rst_ni.value = 1
    await Timer(50, unit="ns")

    # Check that all status signals have returned to their idle/reset state
    assert int(dut.spi_busy_o.value) == 0, "SPI busy should be 0 after reset"
    assert int(dut.config_busy_o.value) == 0, "Config busy should be 0 after reset"
    assert int(dut.configured_o.value) == 0, "Configured flag should be 0 after reset"
    
    dut._log.info("System correctly handled reset during operation.")

@cocotb.test()
async def test_minimal_integration(dut):
    """
    Minimal integration test: SPI controller feeds a start marker, header, frame data, header, and desync flag
    to the fabric configuration module, which should set configured_o.
    """
    clock = Clock(dut.clk_i, 10, unit="ns")
    cocotb.start_soon(clock.start())
    flash_model = SPIFlashModel()

    # Start marker
    bitstream_sequence = [0xFAB0FAB1]
    # Header (frame select, column select, desync bit clear)
    bitstream_sequence.append(0x00000001)
    # 18 frame data words (NumRows = 18)
    for i in range(18):
        bitstream_sequence.append(0xDEADBEEF + i)
    # Header again to return to S_HEADER
    bitstream_sequence.append(0x00000001)
    # Desync flag (bit 20 set)
    bitstream_sequence.append(1 << 20)
    # Padding to 100 words
    while len(bitstream_sequence) < 100:
        bitstream_sequence.append(0x00000000)

    base_addr = 128 * 4  # SLOT_OFFSET_WORDS * 4 bytes per word for slot 1
    for i, data in enumerate(bitstream_sequence):
        flash_model.memory[base_addr + (i * 4)] = data

    # Reset and start
    dut.rst_ni.value = 0
    dut.start_i.value = 0
    dut.slot_i.value = 0
    dut.miso_i.value = 0
    await Timer(100, unit="ns")
    dut.rst_ni.value = 1
    await Timer(50, unit="ns")

    # Start SPI controller
    dut.slot_i.value = 1
    dut.start_i.value = 1
    await RisingEdge(dut.clk_i)
    dut.start_i.value = 0

    # Run until both modules are idle
    max_cycles = 30000
    for _ in range(max_cycles):
        await RisingEdge(dut.clk_i)
        if int(dut.sclk_o.value) == 1:
            cs = not int(dut.cs_no.value)
            mosi = int(dut.mosi_o.value)
            dut.miso_i.value = flash_model.process_bit(mosi, cs)
        if int(dut.spi_busy_o.value) == 0 and int(dut.config_busy_o.value) == 0:
            break

    # Wait for signals to settle
    await Timer(500, unit="ns")

    # Final assertion
    assert int(dut.configured_o.value) == 1, "System should be configured"
    dut._log.info("Minimal integration test completed successfully")
