import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, ClockCycles

DATA_WIDTH = 8
S_COUNT = 4

@cocotb.test()
async def test_single_input(dut):
    """Test Case 1: Send one frame on input 0"""
    await initialize_dut(dut)
    check_task = cocotb.start_soon(check_output(dut, expected_data=[0xAB]))
    await send_frame(dut, port=0, data_list=[0xAB])
    await check_task


@cocotb.test()
async def test_switch_select_mid_frame(dut):
    """Test Case 2: Try to switch select mid-frame (should not take effect mid-frame)"""
    await initialize_dut(dut)
    check_task = cocotb.start_soon(check_output(dut, expected_data=[0xDE, 0xAD]))
    dut.select.value = 2
    dut.enable.value = 1
    await drive_input(dut, port=2, byte=0xDE, tlast=0)
    dut.select.value = 1
    await drive_input(dut, port=2, byte=0xAD, tlast=1)
    await check_task


@cocotb.test()
async def test_select_invalid_input(dut):
    """Test Case 3: select port with no valid data"""
    await initialize_dut(dut)

    dut.enable.value = 1
    dut.select.value = 1  # port 1 is selected but no valid
    await ClockCycles(dut.clk, 10)  # Wait to confirm no data appears
    assert dut.m_axis_tvalid.value == 0, "Expected no valid output when selected port has no data"
    dut._log.info("PASS: No output as selected port had no valid input")


# ===============================
# Utility Functions
# ===============================

async def initialize_dut(dut):
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    dut.rst.value = 1
    dut.enable.value = 0
    dut.select.value = 0
    dut.m_axis_tready.value = 1

    dut.s_axis_tvalid.value = 0
    dut.s_axis_tlast.value = 0
    dut.s_axis_tdata.value = 0
    dut.s_axis_tuser.value = 0

    for _ in range(5):
        await RisingEdge(dut.clk)
    dut.rst.value = 0
    await RisingEdge(dut.clk)


async def send_frame(dut, port, data_list):
    """Send an AXI Stream frame on the given input port"""
    dut.select.value = port
    dut.enable.value = 1

    for i, val in enumerate(data_list):
        is_last = int(i == len(data_list) - 1)
        await drive_input(dut, port=port, byte=val, tlast=is_last)

    await ClockCycles(dut.clk, 2)


async def drive_input(dut, port, byte, tlast):
    data_val = int(dut.s_axis_tdata.value)
    data_val &= ~(0xFF << (port * 8))
    data_val |= (byte & 0xFF) << (port * 8)
    dut.s_axis_tdata.value = data_val

    dut.s_axis_tvalid.value = int(dut.s_axis_tvalid.value) | (1 << port)
    dut.s_axis_tlast.value = int(dut.s_axis_tlast.value) | (tlast << port)
    dut.s_axis_tuser.value = int(dut.s_axis_tuser.value) | (0 << port)

    await RisingEdge(dut.clk)
    while not ((int(dut.s_axis_tready.value) >> port) & 1):
        await RisingEdge(dut.clk)

    # Clear signals before the final clock so the mux sees exactly one output cycle per beat
    dut.s_axis_tvalid.value = int(dut.s_axis_tvalid.value) & ~(1 << port)
    dut.s_axis_tlast.value = int(dut.s_axis_tlast.value) & ~(1 << port)
    await RisingEdge(dut.clk)


async def check_output(dut, expected_data):
    """Monitor output and compare against expected data"""
    received = []

    for expected in expected_data:
        while not dut.m_axis_tvalid.value:
            await RisingEdge(dut.clk)

        if dut.m_axis_tvalid.value and dut.m_axis_tready.value:
            byte = int(dut.m_axis_tdata.value)
            received.append(byte)
            dut._log.info(f"Received byte: 0x{byte:02X}")
            await RisingEdge(dut.clk)

    assert received == expected_data, f"Expected {expected_data}, got {received}"
