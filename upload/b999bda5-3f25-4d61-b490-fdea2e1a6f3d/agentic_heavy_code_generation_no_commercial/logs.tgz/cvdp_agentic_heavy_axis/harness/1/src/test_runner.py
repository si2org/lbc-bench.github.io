import os
from cocotb_tools.runner import get_runner
import pytest
import math

verilog_sources = os.getenv("VERILOG_SOURCES").split()
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = bool(os.getenv("WAVE"))

def runner(S_COUNT: int = 0, M_COUNT: int = 0,DATA_WIDTH: int = 0, ID_ENABLE: int = 0,S_ID_WIDTH: int = 0,M_DEST_WIDTH: int = 0, USER_ENABLE: int = 0,USER_WIDTH: int = 0,M_BASE: int = 0, M_TOP: int = 0,UPDATE_TID: int = 0,S_REG_TYPE: int = 0,M_REG_TYPE: int = 0,ARB_TYPE_ROUND_ROBIN :int = 0,ARB_LSB_HIGH_PRIORITY: int = 0):
    m_id_width  = math.ceil(math.log2(S_COUNT))
    s_des_width  = math.ceil(math.log2(M_COUNT))
    m_connect =  (1 << (S_COUNT * M_COUNT)) - 1
    keep_enable = (DATA_WIDTH>8)
    keep_width = int((DATA_WIDTH+7)/8)
    parameter = {"DATA_WIDTH":DATA_WIDTH,"M_COUNT": M_COUNT,"S_COUNT": S_COUNT, "ID_ENABLE": ID_ENABLE, "S_ID_WIDTH": S_ID_WIDTH, "M_DEST_WIDTH": M_DEST_WIDTH,"USER_ENABLE": USER_ENABLE,"USER_WIDTH":USER_WIDTH,"M_BASE": M_BASE,"M_TOP":M_TOP,"M_CONNECT": m_connect,"UPDATE_TID":UPDATE_TID,"S_REG_TYPE":S_REG_TYPE,"M_REG_TYPE":M_REG_TYPE,"ARB_TYPE_ROUND_ROBIN":ARB_TYPE_ROUND_ROBIN,"ARB_LSB_HIGH_PRIORITY":ARB_LSB_HIGH_PRIORITY,"KEEP_ENABLE": keep_enable, "KEEP_WIDTH": keep_width,"M_ID_WIDTH": S_ID_WIDTH + m_id_width, "S_DEST_WIDTH": M_DEST_WIDTH + s_des_width}
    runner = get_runner(sim)
    runner.build(
        sources=verilog_sources,
        hdl_toplevel=toplevel,
        # Arguments
        parameters=parameter,
        always=True,
        clean=True,
        verbose=True,
        timescale=("1ns", "1ns"),
        log_file="sim.log")
    runner.test(hdl_toplevel=toplevel, test_module=module, waves=wave)

@pytest.mark.parametrize("S_COUNT ", [4])
@pytest.mark.parametrize("M_COUNT ", [4])
@pytest.mark.parametrize("DATA_WIDTH ", [8])
@pytest.mark.parametrize("ID_ENABLE ", [1])
@pytest.mark.parametrize("S_ID_WIDTH ", [8])
@pytest.mark.parametrize("M_DEST_WIDTH ", [1])
@pytest.mark.parametrize("USER_ENABLE ", [1])
@pytest.mark.parametrize("USER_WIDTH", [1])
#@pytest.mark.parametrize("M_BASE", [(0 << 0) | (2 << 3) | (4 << 6) | (6 << 9)])  # 0xD10 = 3344
#@pytest.mark.parametrize("M_TOP", [(0 << 0) | (2 << 3) | (4 << 6) | (6 << 9)])
@pytest.mark.parametrize("M_BASE", [(0 << 0) | (1 << 3) | (2 << 6) | (3 << 9)])
@pytest.mark.parametrize("M_TOP",  [(0 << 0) | (1 << 3) | (2 << 6) | (3 << 9)])
@pytest.mark.parametrize("UPDATE_TID ", [0])
@pytest.mark.parametrize("S_REG_TYPE  ", [0])
@pytest.mark.parametrize("M_REG_TYPE  ", [2])
@pytest.mark.parametrize("ARB_TYPE_ROUND_ROBIN ", [1])
@pytest.mark.parametrize("ARB_LSB_HIGH_PRIORITY  ", [1])
def test_axis_switch(S_COUNT,M_COUNT,DATA_WIDTH,ID_ENABLE,S_ID_WIDTH,M_DEST_WIDTH,USER_ENABLE,USER_WIDTH,M_BASE,M_TOP,UPDATE_TID,S_REG_TYPE,M_REG_TYPE,ARB_TYPE_ROUND_ROBIN,ARB_LSB_HIGH_PRIORITY):
        runner(S_COUNT = S_COUNT,M_COUNT = M_COUNT,DATA_WIDTH = DATA_WIDTH,ID_ENABLE = ID_ENABLE,S_ID_WIDTH = S_ID_WIDTH,M_DEST_WIDTH = M_DEST_WIDTH,USER_ENABLE = USER_ENABLE,USER_WIDTH = USER_WIDTH,M_BASE = M_BASE,M_TOP = M_TOP,UPDATE_TID = UPDATE_TID,S_REG_TYPE = S_REG_TYPE,M_REG_TYPE = M_REG_TYPE,ARB_TYPE_ROUND_ROBIN = ARB_TYPE_ROUND_ROBIN,ARB_LSB_HIGH_PRIORITY = ARB_LSB_HIGH_PRIORITY)
