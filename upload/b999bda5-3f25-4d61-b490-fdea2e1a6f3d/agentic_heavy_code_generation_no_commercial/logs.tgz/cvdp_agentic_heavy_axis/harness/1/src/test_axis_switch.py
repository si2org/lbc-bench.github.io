import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer

# DUT parameters
S_COUNT = 4
M_COUNT = 4
DATA_WIDTH = 8
ID_WIDTH = 8
DEST_WIDTH = 3


def set_signal_slice(signal, sid, width, value):
    """Update only the slice of the signal corresponding to a given sid."""
    full_width = S_COUNT * width
    try:
        current_val = int(signal.value)
    except (ValueError, TypeError):
        current_val = 0
    mask = ((1 << width) - 1) << (sid * width)
    value_shifted = (value & ((1 << width) - 1)) << (sid * width)
    signal.value = (current_val & ~mask) | value_shifted


def set_bit(signal, index, value):
    """Set a single bit in a BitVector signal safely."""
    try:
        current = int(signal.value)
    except (ValueError, TypeError):
        current = 0
    if value:
        current |= (1 << index)
    else:
        current &= ~(1 << index)
    signal.value = current


def clear_input_signals(dut):
    dut.s_axis_tdata.value = 0
    dut.s_axis_tid.value = 0
    dut.s_axis_tdest.value = 0
    dut.s_axis_tvalid.value = 0
    dut.s_axis_tlast.value = 0
    dut.s_axis_tuser.value = 0
    dut.s_axis_tkeep.value = 0


async def send_frame(dut, sid, data, tid, dest):
    """Drive a single AXI-Stream frame from source `sid` with debug logging."""
    encoded_tdest = (dest) 

    set_signal_slice(dut.s_axis_tdata, sid, DATA_WIDTH, data)
    set_signal_slice(dut.s_axis_tid, sid, ID_WIDTH, tid)
    set_signal_slice(dut.s_axis_tdest, sid, DEST_WIDTH, encoded_tdest)
    set_bit(dut.s_axis_tvalid, sid, 1)
    set_bit(dut.s_axis_tlast, sid, 1)

    decoded_port = (encoded_tdest >> 1) & 0b11
    dut._log.info(f"[SID={sid}] TDATA=0x{data:02X}, TDEST=0x{encoded_tdest:03b}, TDEST[2:1]={decoded_port} → m_axis[{decoded_port}]")

    for _ in range(20):
        try:
            ready_vector = int(dut.s_axis_tready.value)
        except ValueError:
            ready_vector = 0
        if ready_vector & (1 << sid):
            await RisingEdge(dut.clk)
            break
        await RisingEdge(dut.clk)
    else:
        dut._log.warning(f"[SID={sid}] Skipped: tready not asserted")
        set_bit(dut.s_axis_tvalid, sid, 0)
        set_bit(dut.s_axis_tlast, sid, 0)
        return

    set_bit(dut.s_axis_tvalid, sid, 0)
    set_bit(dut.s_axis_tlast, sid, 0)
    set_bit(dut.s_axis_tready, sid, 0)
    set_signal_slice(dut.s_axis_tdata, sid, DATA_WIDTH, 0)
    set_signal_slice(dut.s_axis_tid, sid, ID_WIDTH, 0)
    set_signal_slice(dut.s_axis_tdest, sid, DEST_WIDTH, 0) 

    '''dut.s_axis_tvalid.value = 0
    dut.s_axis_tlast.value = 0
    dut.s_axis_tready.value = 0
    dut.s_axis_tdata.vaue = 0
    dut.s_axis_tid.value = 0
    dut.s_axis_tdest.value = 0'''

    try:
        m_valid = int(dut.m_axis_tvalid.value)
        m_data = int(dut.m_axis_tdata.value)
        m_dest  = int(dut.m_axis_tdest.value)
        dut._log.info(f"    [Output State] m_axis_tvalid=0b{m_valid:04b}, m_axis_tdata=0x{m_data:08X}, m_axis_tdest=0x{m_dest:X}")
    except Exception:
        dut._log.warning("    [Output State] Could not read m_axis_tvalid/tdata")


@cocotb.test()
async def test_axis_switch(dut):
    """AXI4-Stream switch test with tdest[2:1] routing and debug logs."""
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    # Reset DUT
    dut.rst.value = 1
    await Timer(100, unit="ns")
    dut.rst.value = 0
    await Timer(100, unit="ns")

    clear_input_signals(dut)

    if int(dut.m_axis_tvalid.value) != 0:
        dest_value = int(dut.m_axis_tdest.value)
        dut._log.info(f"[DEBUG] m_axis_tdest value = 0x{dest_value:X}")
    else:
        dut._log.warning("[DEBUG] m_axis_tdest is not valid yet — skipping print")

    # Set tkeep to enable all bytes
    tkeep_width = (DATA_WIDTH // 8) * S_COUNT
    #dut.s_axis_tkeep.value = (1 << tkeep_width) - 1

    # Set all outputs ready
    dut.m_axis_tready.value = (1 << M_COUNT) - 1

    # TEST 1: 0123 → 0123 (direct map)
    dut._log.info("Test 1: 0123 → 0123")
    await send_frame(dut, 0, 0x01, 0, 0)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 1:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 1
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data) & 0xFF
    m_byte = (m_data) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 0 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 0 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte" 
    await Timer(20, unit="ns")


    await send_frame(dut, 1, 0x11, 1, 1)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0X{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 2:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 2
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    assert dut_s_axis_tdata == m_axis_tdata,f" data routing is done as expected"  
    await Timer(20, unit="ns")

    while int(dut.s_axis_tready.value) != 0:
        await RisingEdge(dut.clk)

    await send_frame(dut, 2, 0x22, 2, 2)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0X{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 4:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 4
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    assert dut_s_axis_tdata == m_axis_tdata,f" data routing is done as expected" 
    await Timer(20, unit="ns")

    while int(dut.s_axis_tready.value) != 0:
        await RisingEdge(dut.clk)

    await send_frame(dut, 3, 0x33, 3, 3)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0X{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 8:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 8
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    #assert dut_s_axis_tdata == m_axis_tdata,f" data routing is done as expected" 
    await Timer(100, unit="ns")

    # Reset DUT
    dut.rst.value = 1
    await Timer(100, unit="ns")
    dut.rst.value = 0
    await Timer(100, unit="ns")

    clear_input_signals(dut)
    await Timer(20, unit="ns")

    # TEST 2: 0123 → 3210 (reverse)
    dut._log.info("Test 2: 0123 → 3210")
    await send_frame(dut, 0, 0xA0, 0, 3)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 1:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 8
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data) & 0xFF
    m_byte = (m_data) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 0 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 0 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 1, 0xA1, 1, 2)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 2:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 4
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)

    s_byte = (s_data >> 8) & 0xFF

    m_byte = (m_data >> 16) & 0xFF

    # Log and compare
    dut._log.info(f"s_axis_tdata (port 1 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 2 byte) = 0x{m_byte:02x}")

    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 2, 0xA2, 2, 1)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 4:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 2
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data >> 16) & 0xFF
    m_byte = (m_data >> 8) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 2 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 1 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")
    
    await send_frame(dut, 3, 0xA3, 3, 0)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 8:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 1
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data >> 24) & 0xFF
    m_byte = (m_data) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 3 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 0 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(100, unit="ns")

    # TEST 3: 0000 → 3210 (reverse)
    dut._log.info("Test 3: 0000 → 3210")
    await send_frame(dut, 0, 0xB0, 0, 3)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 1:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tlast.value == 15
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data) & 0xFF
    m_byte = (m_data >> 24) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 0 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 3 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 0, 0xB1, 1, 2)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 1:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tlast.value == 15
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data) & 0xFF
    m_byte = (m_data>>16) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 0 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 2 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 0, 0xB2, 2, 1)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 1:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tlast.value == 15
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data) & 0xFF
    m_byte = (m_data >> 8) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 0 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 1 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 0, 0xB3, 3, 0)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 1:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 15
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data) & 0xFF
    m_byte = (m_data ) & 0xFF
    dut._log.info(f"s_axis_tdata (port 0 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 0 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(100, unit="ns")

     # Reset DUT
    dut.rst.value = 1
    await Timer(100, unit="ns")
    dut.rst.value = 0
    await Timer(100, unit="ns")

    clear_input_signals(dut)
    await Timer(20, unit="ns")

    # TEST 4: 0123 → 0000 (all zeros)
    dut._log.info("Test 4: 0123 → 0000")
    await send_frame(dut, 0, 0xC0, 0, 0)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 1:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 1
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data) & 0xFF
    m_byte = (m_data) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 0 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 0 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 1, 0xC1, 1, 0)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 2:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 1
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data >> 8) & 0xFF
    m_byte = (m_data) & 0xFF
    dut._log.info(f"s_axis_tdata (port 1 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 0 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 2, 0xC2, 2, 0)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 4:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 1
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data >> 16) & 0xFF
    m_byte = (m_data) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 2 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 0 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 3, 0xC3, 3, 0)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 8:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 1
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data >> 24) & 0xFF
    m_byte = (m_data) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 3 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 0 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(100, unit="ns")

    # Reset DUT
    dut.rst.value = 1
    await Timer(100, unit="ns")
    dut.rst.value = 0
    await Timer(100, unit="ns")

    clear_input_signals(dut)
    await Timer(20, unit="ns")

    # TEST 5: 0123 → 0145 (no destination port)
    dut._log.info("Test 5: 0123 → 0156")
    await send_frame(dut, 0, 0xD0, 0, 0)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 1:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 1
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data) & 0xFF
    m_byte = (m_data) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 0 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 0 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 1, 0xD1, 1, 1)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    if dut.s_axis_tready.value == 2:
        await RisingEdge(dut.clk)
        assert dut.m_axis_tvalid.value == 2
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data >> 8) & 0xFF
    m_byte = (m_data >> 8) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 1 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 1 byte) = 0x{m_byte:02x}")
    assert s_byte == m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 2, 0xD2, 2, 5)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data >> 16) & 0xFF
    m_byte = (m_data ) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 2 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 5 byte not declared) = 0x{m_byte:02x}")
    assert s_byte != m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(20, unit="ns")

    await send_frame(dut, 3, 0xD3, 3, 6)
    dut_s_axis_tdata = int(dut.s_axis_tdata.value)
    dut._log.info(f"    [Output] s_axis_tdata = 0x{dut_s_axis_tdata:08x}")
    m_axis_tdata = int(dut.m_axis_tdata.value)
    dut._log.info(f"    [Output] m_axis_tdata = 0X{m_axis_tdata:08x}")
    s_data = int(dut.s_axis_tdata.value)
    m_data = int(dut.m_axis_tdata.value)
    s_byte = (s_data >> 24) & 0xFF
    m_byte = (m_data ) & 0xFF
    # Log and compare
    dut._log.info(f"s_axis_tdata (port 3 byte) = 0x{s_byte:02x}")
    dut._log.info(f"m_axis_tdata (port 6 byte not declared) = 0x{m_byte:02x}")
    assert s_byte != m_byte, "Data routing mismatch: input byte does not match output byte"
    await Timer(100, unit="ns")



    dut._log.info("Test completed successfully.")

    