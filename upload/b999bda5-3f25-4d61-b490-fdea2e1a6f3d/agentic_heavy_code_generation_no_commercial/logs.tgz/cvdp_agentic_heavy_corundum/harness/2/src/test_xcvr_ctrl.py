import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, FallingEdge, Timer
import logging

class TB:
    def __init__(self, dut):
        self.dut = dut
        self.log = logging.getLogger("cocotb.tb")
        self.log.setLevel(logging.DEBUG)

        # Set default values
        self.dut.reconfig_rst.value = 0
        self.dut.pll_locked_in.value = 0
        self.dut.xcvr_reconfig_readdata.setimmediatevalue(0)
        self.dut.xcvr_reconfig_waitrequest.setimmediatevalue(1)

    async def reset(self):
        self.dut.reconfig_rst.value = 1
        await Timer(100, unit="ns")
        self.dut.reconfig_rst.value = 0
        self.log.info("Reset released")

    async def wait_n_cycles(self, n):
        for _ in range(n):
            await RisingEdge(self.dut.reconfig_clk)

@cocotb.test()
async def test_xcvr_ctrl_basic(dut):
    tb = TB(dut)
    cocotb.start_soon(Clock(dut.reconfig_clk, 10, unit="ns").start())

    await tb.reset()
    dut.pll_locked_in.value = 1
    await tb.wait_n_cycles(2)
    #tb.log.info("PLL locked set to 1")

    for i in range(20):
        addr = int(dut.xcvr_reconfig_address.value)
        wr = int(dut.xcvr_reconfig_write.value)
        rd = int(dut.xcvr_reconfig_read.value)
        wdata = int(dut.xcvr_reconfig_writedata.value)
        #tb.log.info(f"[{i:02}] addr={addr:05x} wr={wr} rd={rd} wdata={wdata:02x}")

        # Add assertions
        assert addr == 0, f"Unexpected address at cycle {i}: {addr:#05x}"
        assert wr == 0, f"Unexpected write at cycle {i}"
        assert rd == 0, f"Unexpected read at cycle {i}"
        assert wdata == 0, f"Unexpected write data at cycle {i}"

        await tb.wait_n_cycles(1)

@cocotb.test()
async def test_xcvr_ctrl_reset_behavior(dut):
    tb = TB(dut)
    cocotb.start_soon(Clock(dut.reconfig_clk, 10, unit="ns").start())

    dut.pll_locked_in.value = 1
    await tb.reset()
    tb.log.info("Reset released while PLL locked")

    for i in range(5):
        addr = int(dut.xcvr_reconfig_address.value)
        wr = int(dut.xcvr_reconfig_write.value)
        rd = int(dut.xcvr_reconfig_read.value)
        #tb.log.info(f"[{i}] addr={addr:05x} wr={wr} rd={rd}")

        assert addr == 0, f"Cycle {i}: Unexpected address {addr:#05x}"
        assert wr == 0, f"Cycle {i}: Unexpected write {wr}"
        assert rd == 0, f"Cycle {i}: Unexpected read {rd}"

        await tb.wait_n_cycles(1)

@cocotb.test()
async def test_xcvr_ctrl_waitrequest_handling(dut):
    tb = TB(dut)
    cocotb.start_soon(Clock(dut.reconfig_clk, 10, unit="ns").start())

    await tb.reset()
    dut.pll_locked_in.value = 1
    tb.log.info("PLL locked set")

    for i in range(20):
        # Alternate waitrequest every cycle
        dut.xcvr_reconfig_waitrequest.value = i % 2  # 1, 0, 1, 0...

        await tb.wait_n_cycles(1)

        actual = int(dut.xcvr_reconfig_waitrequest.value)
        addr = int(dut.xcvr_reconfig_address.value)
        #tb.log.info(f"[{i}] waitrequest={actual} addr={addr:05x}")

        assert actual == (i % 2), f"Cycle {i}: waitrequest expected {(i % 2)}, got {actual}"
        assert addr == 0, f"Cycle {i}: Unexpected address {addr:#05x}"

@cocotb.test()
async def test_xcvr_ctrl_read_write_signals(dut):
    tb = TB(dut)

    # Start reconfig clock
    cocotb.start_soon(Clock(dut.reconfig_clk, 10, unit="ns").start())

    # Apply reset
    await tb.reset()

    # Apply initial input stimulus
    dut.xcvr_reconfig_waitrequest.value = 0  # Avalon-MM target is ready
    dut.pll_locked_in.value = 1              # PLL lock triggers reconfig FSM
    tb.log.info("Inputs set: pll_locked_in=1, xcvr_reconfig_waitrequest=0")

    wr_seen = False
    rd_seen = False

    for i in range(100):
        wr = int(dut.xcvr_reconfig_write.value)
        rd = int(dut.xcvr_reconfig_read.value)
        addr = int(dut.xcvr_reconfig_address.value)
        wdata = int(dut.xcvr_reconfig_writedata.value)
        reconfig_clk = int(dut.reconfig_clk.value)
        if wr:
            wr_seen = True
        if rd:
            rd_seen = True

        await tb.wait_n_cycles(1)

    if wr_seen or rd_seen:
        tb.log.info("PASS: Write or read operation detected.")


