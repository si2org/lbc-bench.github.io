import cocotb
from cocotb.triggers import Timer, RisingEdge
from cocotb.clock import Clock

async def run_clock(dut, period_ns=10):
    """Start a clock on dut.clk with given period (default 10ns)"""
    cocotb.start_soon(Clock(dut.clk, period_ns, unit="ns", period_high=(period_ns+1)//2 if period_ns%2 else period_ns//2).start())
    await Timer(1)  # let clock settle

async def reset_dut(dut):
    # Drive reset and valid at top-level
    dut.rstn.value = 0
    dut.valid.value = 0

    # If not driven from top level, also manually reset internal signals
    dut.conv1_buf_inst.line_buffer_controller_inst.row_complete.value = 0

    await Timer(20, unit="ns")
    dut.rstn.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)


@cocotb.test()
async def test_reset_behavior(dut):
    """Test if signals reset correctly after rstn"""
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset_dut(dut)

    ctrl = dut.conv1_buf_inst.line_buffer_controller_inst
    PAD = int(ctrl.PAD.value)

    assert ctrl.col_ptr.value == PAD, "col_ptr should reset to PAD"
    assert ctrl.init_col_ptr.value == PAD, "init_col_ptr should reset to PAD"
    assert ctrl.global_col_ptr.value == 0, "global_col_ptr should reset to 0"
    assert ctrl.right_pad_valid.value == 0, "right_pad_valid should reset to 0"


@cocotb.test()
async def test_left_pad_mask_progression(dut):
    """Test left_pad_mask during initial input phase"""
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset_dut(dut)

    ctrl = dut.conv1_buf_inst.line_buffer_controller_inst
    PAD = int(ctrl.PAD.value)
    KER_SIZE = int(ctrl.KER_SIZE.value)

    for cycle in range(KER_SIZE + 2):
        dut.valid.value = 1
        await RisingEdge(dut.clk)
        mask = int(ctrl.left_pad_mask.value)
        print(f"[{cycle}] left_pad_mask = {mask:0{KER_SIZE}b}")

@cocotb.test()
async def test_right_pad_phase(dut):
    """Test right padding after a full row input"""

    await run_clock(dut, 5)
    await reset_dut(dut)

    ctrl = dut.conv1_buf_inst.line_buffer_controller_inst

    KER_SIZE = int(ctrl.KER_SIZE.value)
    INPUT_X_DIM = int(ctrl.INPUT_X_DIM.value)
    PAD = int(ctrl.PAD.value)
    pad_trigger_ptr = INPUT_X_DIM - PAD - 1  # e.g., 223

    dut.valid.value = 1
    dut.conv1_buf_inst.line_buffer_controller_inst.row_complete.value = 0

    pad_phase_started = False
    ctrl_valid_started = False
    MAX_CYCLES = 1000

    for cycle in range(MAX_CYCLES):
        await RisingEdge(dut.clk)

        gptr = int(ctrl.global_col_ptr.value)
        ctrl_valid = int(ctrl.valid.value)
        dut_valid = int(dut.valid.value)
        pad_done = int(ctrl.padrow_complete.value)

        print(f"[{cycle}] dut.valid={dut_valid} ctrl.valid={ctrl_valid} global_col_ptr={gptr}, "
              f"padrow_complete={pad_done}, right_pad_en={int(ctrl.right_pad_en.value)}")

        if ctrl_valid:
            ctrl_valid_started = True

        if ctrl_valid_started and gptr >= pad_trigger_ptr:
            pad_phase_started = True
            break

    dut.valid.value = 0  # Stop after reaching threshold

    assert pad_phase_started, f"Never reached right pad threshold global_col_ptr={pad_trigger_ptr}"

@cocotb.test()
async def test_padrow_complete_reset(dut):
    """Test if counters reset after row_complete and padrow_complete"""
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset_dut(dut)

    ctrl = dut.conv1_buf_inst.line_buffer_controller_inst
    PAD = int(ctrl.PAD.value)

    # Provide some input first
    for _ in range(4):
        dut.valid.value = 1
        await RisingEdge(dut.clk)

    # Trigger row_complete
    dut.conv1_buf_inst.line_buffer_controller_inst.row_complete.value = 1
    await RisingEdge(dut.clk)
    dut.conv1_buf_inst.line_buffer_controller_inst.row_complete.value = 0
    await RisingEdge(dut.clk)

    # Check if reset occurred
    assert ctrl.col_ptr.value == PAD, "col_ptr should reset to PAD after row_complete"
    assert ctrl.init_col_ptr.value == PAD, "init_col_ptr should reset to PAD after row_complete"
    assert ctrl.global_col_ptr.value == 0, "global_col_ptr should reset to 0 after row_complete"
