import cocotb
from cocotb.clock    import Clock
from cocotb.triggers import RisingEdge

CLK_PERIOD_NS = 10   # 100 MHz sim clock

async def reset_dut(dut, cycles=5):
    dut.rst_in.value = 1
    for _ in range(cycles):
        await RisingEdge(dut.clk_in)
    dut.rst_in.value = 0
    await RisingEdge(dut.clk_in)


async def one_pulse(sig, clk):
    sig.value = 1
    await RisingEdge(clk)
    sig.value = 0


def is_resolved(val):
    """True if signal has no X/Z bits."""
    return val.is_resolvable


async def toggle_period_cycles(dut, max_cycles=50_000):
    """
    Count clock cycles between two consecutive changes of noise_out.
    Returns the count or None if no toggle seen inside max_cycles.
    """
    prev = None
    for i in range(max_cycles):
        await RisingEdge(dut.clk_in)
        if not is_resolved(dut.noise_out.value):
            continue
        cur = int(dut.noise_out.value)
        if prev is None:
            prev = cur
            continue
        if cur != prev:
            return i  # cycles between toggles
    return None

@cocotb.test()
async def test_power_on_reset(dut):
    cocotb.start_soon(Clock(dut.clk_in, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    dut.apu_cycle_pulse_in.value = 1
    await reset_dut(dut)

    assert dut.noise_out.value == 0
    assert dut.active_out.value == 0


@cocotb.test()
async def test_length_counter_halt_bit(dut):
    cocotb.start_soon(Clock(dut.clk_in, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    dut.apu_cycle_pulse_in.value = 1
    await reset_dut(dut)
    dut.en_in.value = 1

    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b11, 0x20, 1
    await RisingEdge(dut.clk_in)
    dut.wr_in.value = 0

    # Set HALT via $400C bit 5
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b00, 0b0010_0000, 1
    await RisingEdge(dut.clk_in)
    dut.wr_in.value = 0

    for _ in range(40):
        await one_pulse(dut.lc_pulse_in, dut.clk_in)
        await RisingEdge(dut.clk_in)

    assert dut.active_out.value == 1

@cocotb.test()
async def test_envelope_constant_volume(dut):
    cocotb.start_soon(Clock(dut.clk_in, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    dut.apu_cycle_pulse_in.value = 1
    await reset_dut(dut)
    dut.en_in.value = 1

    # Length + CONST volume 0x9
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b11, 0xF0, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b00, 0b0001_1001, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0

    # Fastest timer
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b10, 0x00, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0

    for _ in range(400):
        await RisingEdge(dut.clk_in)
        if is_resolved(dut.noise_out.value) and int(dut.noise_out.value):
            assert dut.noise_out.value == 0x9
            return
    assert False, "never saw non-zero noise_out"

@cocotb.test()
async def test_silence_when_inactive(dut):
    cocotb.start_soon(Clock(dut.clk_in, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    dut.apu_cycle_pulse_in.value = 1
    await reset_dut(dut)

    for _ in range(400):
        await RisingEdge(dut.clk_in)
        if is_resolved(dut.noise_out.value):
            assert int(dut.noise_out.value) == 0
        assert dut.active_out.value == 0

@cocotb.test()
async def test_output_gate_by_lfsr(dut):
    cocotb.start_soon(Clock(dut.clk_in, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    dut.apu_cycle_pulse_in.value = 1
    await reset_dut(dut)
    dut.en_in.value = 1

    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b11, 0xF0, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b00, 0b0001_0111, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b10, 0x00, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0

    zeros = sevens = 0
    for _ in range(600):
        await RisingEdge(dut.clk_in)
        if not is_resolved(dut.noise_out.value):
            continue
        v = int(dut.noise_out.value)
        if v == 0: zeros += 1
        elif v == 7: sevens += 1
    assert zeros and sevens

@cocotb.test()
async def test_register_write_mid_cycle(dut):
    cocotb.start_soon(Clock(dut.clk_in, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    dut.apu_cycle_pulse_in.value = 1
    await reset_dut(dut)
    dut.en_in.value = 1

    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b11, 0xF0, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b00, 0b0001_1000, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0

    # Start slow (index 4)
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b10, 0x40, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0
    slow_cycles = await toggle_period_cycles(dut, max_cycles=5000)

    # Immediate write to fast (index 0) on same clk as reload
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b10, 0x00, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0
    fast_cycles = await toggle_period_cycles(dut, max_cycles=3000)

    assert slow_cycles and fast_cycles and fast_cycles < slow_cycles // 2


@cocotb.test()
async def test_length_counter_load_and_expire(dut):
    """
    Load the shortest length (index 0 → 0x0A), pulse lc_pulse_in until
    active_out de-asserts.  We convert active_out to int() so the while
    loop terminates correctly.
    """
    cocotb.start_soon(Clock(dut.clk_in, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    dut.apu_cycle_pulse_in.value = 1
    await reset_dut(dut)
    dut.en_in.value = 1

    # $400F — length index 0 (bits 7-3 = 00000)
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b11, 0x00, 1
    await RisingEdge(dut.clk_in)
    dut.wr_in.value = 0
    await RisingEdge(dut.clk_in)

    dut._log.info(f"[LC] after load: q_length={int(dut.length_counter.q_length.value):02X}")

    tick = 0
    while int(dut.active_out.value):
        await one_pulse(dut.lc_pulse_in, dut.clk_in)
        await RisingEdge(dut.clk_in)
        tick += 1
        dut._log.info(f"[LC] pulse {tick:02d}  q_length="
                      f"{int(dut.length_counter.q_length.value):02X}")
        assert tick < 60, "length counter still non-zero after 60 pulses!"

    dut._log.info(f"[LC] inactive after {tick} pulses (expected ≤10)")
    assert not int(dut.active_out.value)

@cocotb.test()
async def test_envelope_decay_loop(dut):
    """
    With loop flag set, const=0, period=0 (fastest), envelope should
    ramp 15→0, reload to 15, and repeat.  We sample internal env_out.
    """
    cocotb.start_soon(Clock(dut.clk_in, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    dut.apu_cycle_pulse_in.value = 1
    await reset_dut(dut)
    dut.en_in.value = 1

    # long length so channel stays active
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b11, 0xA0, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0

    # $400C: loop=1 (bit5), const=0 (bit4), period=0 (bits3-0)
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b00, 0b0010_0000, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0

    # restart envelope via $400F write (any data) – env_restart goes high
    dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b11, 0x00, 1
    await RisingEdge(dut.clk_in); dut.wr_in.value = 0

    values = []
    for eg in range(64):                        # 64 env-gen ticks
        await one_pulse(dut.eg_pulse_in, dut.clk_in)
        await RisingEdge(dut.clk_in)
        v = int(dut.envelope_generator.env_out.value)
        values.append(v)
        if eg % 8 == 0:
            dut._log.info(f"[ENV] tick {eg:02d}  env_out={v}")

    assert 15 in values and 0 in values, "env_out never hit both 15 and 0"
    assert values.count(15) >= 2,           "loop flag didn’t wrap to 15 twice"


@cocotb.test()
async def test_timer_periods(dut):
    cocotb.start_soon(Clock(dut.clk_in, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    dut.apu_cycle_pulse_in.value = 1            # keep divider enabled
    await reset_dut(dut)

    async def distance(idx):
        # Program $400E with index in lower nibble
        dut.a_in.value, dut.d_in.value, dut.wr_in.value = 0b10, idx & 0x0F, 1
        await RisingEdge(dut.clk_in)
        dut.wr_in.value = 0

        # ── Wait for first resolved HIGH ───────────────────────────────
        cycles = 0
        while (
            not (dut.timer_pulse.value.is_resolvable and int(dut.timer_pulse.value) == 1)
            and cycles < 2000
        ):
            await RisingEdge(dut.clk_in)
            cycles += 1
        assert cycles < 2000, f"timer_pulse never went HIGH for index {idx}"
        # FALLING edge -– ensure we start timing from LOW-to-next-HIGH gap
        while dut.timer_pulse.value.is_resolvable and int(dut.timer_pulse.value) == 1:
            await RisingEdge(dut.clk_in)

        # ── Measure LOW duration until next HIGH ──────────────────────
        gap = 0
        while (
            not (dut.timer_pulse.value.is_resolvable and int(dut.timer_pulse.value) == 1)
            and gap < 2000
        ):
            await RisingEdge(dut.clk_in)
            gap += 1
        assert gap < 2000, f"second timer_pulse HIGH not seen for index {idx}"

        dut._log.info(f"[TMR] index {idx:01X} gap = {gap} clk cycles")
        return gap

    gap_fast = await distance(0x0)   # period 2  → effective ~3-4 cycles
    gap_slow = await distance(0x4)   # period 32 → much larger

    # Accept any ratio ≥4× to stay implementation-agnostic
    ratio = gap_slow / max(1, gap_fast)
    dut._log.info(f"[TMR] slow/fast ratio = {ratio:.2f}")
    assert ratio >= 4.0, "timer periods too close – expected ≥4× difference"
