import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock


async def setup_dut(dut):
    """Initialize clock, reset, and default values for all inputs."""
    cocotb.start_soon(Clock(dut.clk_in, 10, unit="ns").start())
    dut.rst_in.value = 1

    # Initialize all inputs
    dut.sel_in.value = 0
    dut.ncs_in.value = 1
    dut.r_nw_in.value = 1
    dut.cpu_d_in.value = 0
    dut.vram_a_in.value = 0
    dut.vram_d_in.value = 0
    dut.pram_d_in.value = 0
    dut.vblank_in.value = 0
    dut.spr_ram_d_in.value = 0
    dut.spr_overflow_in.value = 0
    dut.spr_pri_col_in.value = 0

    await RisingEdge(dut.clk_in)
    await RisingEdge(dut.clk_in)
    dut.rst_in.value = 0
    await RisingEdge(dut.clk_in)


@cocotb.test()
async def test_reset_behavior(dut):
    """Test if all registers reset correctly"""
    await setup_dut(dut)

    assert dut.fv_out.value == 0
    assert dut.ht_out.value == 0
    assert dut.vt_out.value == 0
    assert dut.v_out.value == 0
    assert dut.h_out.value == 0
    assert dut.bg_en_out.value == 0
    assert dut.spr_en_out.value == 0


@cocotb.test()
async def test_write_2001_register(dut):
    """Write to 0x2001 (sel_in=1), verify display control bits"""
    await setup_dut(dut)

    dut.sel_in.value = 1
    dut.r_nw_in.value = 0
    dut.cpu_d_in.value = 0b00011110
    await RisingEdge(dut.clk_in)
    dut.ncs_in.value = 0
    await RisingEdge(dut.clk_in)
    dut.ncs_in.value = 1
    await RisingEdge(dut.clk_in)

    assert dut.spr_en_out.value == 1
    assert dut.bg_en_out.value == 1
    assert dut.spr_ls_clip_out.value == 0
    assert dut.bg_ls_clip_out.value == 0


@cocotb.test()
async def test_read_2002_and_vblank_flag(dut):
    """Simulate vblank and read from 0x2002"""
    await setup_dut(dut)

    dut.vblank_in.value = 1
    await RisingEdge(dut.clk_in)

    dut.sel_in.value = 2
    dut.r_nw_in.value = 1
    dut.ncs_in.value = 0
    await RisingEdge(dut.clk_in)
    dut.ncs_in.value = 1
    await RisingEdge(dut.clk_in)

    assert dut.vblank_out.value == 0  # cleared after read


@cocotb.test()
async def test_scroll_register_2005(dut):
    """Test two writes to 0x2005 (scroll register)"""
    await setup_dut(dut)

    dut.sel_in.value = 5
    dut.r_nw_in.value = 0

    # First write
    dut.cpu_d_in.value = 0b11010100
    dut.ncs_in.value = 0
    await RisingEdge(dut.clk_in)
    dut.ncs_in.value = 1
    await RisingEdge(dut.clk_in)

    # Second write
    dut.cpu_d_in.value = 0b01111011
    dut.ncs_in.value = 0
    await RisingEdge(dut.clk_in)
    dut.ncs_in.value = 1
    await RisingEdge(dut.clk_in)

    assert dut.fh_out.value == 0b100
    assert dut.ht_out.value == 0b11010
    assert dut.fv_out.value == 0b011
    assert dut.vt_out.value == 0b01111


@cocotb.test()
async def test_increment_vram_addr_on_2007_write(dut):
    """Write to 0x2007 (VRAM or Palette), check memory write control"""
    await setup_dut(dut)

    # Case 1: Palette write
    dut.sel_in.value = 7
    dut.r_nw_in.value = 0
    dut.cpu_d_in.value = 0xAA
    dut.vram_a_in.value = 0x3F00

    # Step through clean falling edge of ncs_in
    dut.ncs_in.value = 1
    await RisingEdge(dut.clk_in)
    await Timer(1, unit="ns")  # Let inputs settle
    dut.ncs_in.value = 0
    await Timer(1, unit="ns")  # This is when pram_wr_out goes high!

    assert dut.pram_wr_out.value == 1, "Palette write failed at address 0x3F00"
    assert dut.vram_wr_out.value == 0
    assert dut.vram_d_out.value == 0xAA
    assert dut.inc_addr_out.value == 1

    # Restore ncs_in and test normal VRAM write
    dut.ncs_in.value = 1
    await RisingEdge(dut.clk_in)

    # Case 2: VRAM write
    dut.cpu_d_in.value = 0xBB
    dut.vram_a_in.value = 0x2000
    await Timer(1, unit="ns")
    dut.ncs_in.value = 0
    await Timer(1, unit="ns")

    assert dut.vram_wr_out.value == 1, "VRAM write failed at address 0x2000"
    assert dut.pram_wr_out.value == 0
    assert dut.vram_d_out.value == 0xBB
    assert dut.inc_addr_out.value == 1

@cocotb.test()
async def test_write_read_2000_register(dut):
    """Write to 0x2000 and verify all corresponding control signals"""
    await setup_dut(dut)

    dut.sel_in.value = 0
    dut.r_nw_in.value = 0
    dut.cpu_d_in.value = 0b10000101  # spr_h=0 now
    await RisingEdge(dut.clk_in)
    dut.ncs_in.value = 0
    await RisingEdge(dut.clk_in)
    dut.ncs_in.value = 1
    await RisingEdge(dut.clk_in)

    assert dut.nvbl_en_out.value == 1, "nvbl_en should be 1"
    assert dut.spr_h_out.value == 0, "spr_h should be 0"
    assert dut.s_out.value == 0, "s should be 0"
    assert dut.spr_pt_sel_out.value == 0, "spr_pt_sel should be 0"
    assert dut.inc_addr_amt_out.value == 1, "addr_incr should be 1"
    assert dut.v_out.value == 0, "v should be 0"
    assert dut.h_out.value == 1, "h should be 1"

@cocotb.test()
async def test_sprite_ram_auto_increment(dut):
    """Test auto-increment of sprite RAM address after 0x2004 write"""
    await setup_dut(dut)

    # Write sprite RAM address (0x20) via 0x2003
    dut.sel_in.value = 3
    dut.r_nw_in.value = 0
    dut.cpu_d_in.value = 0x20
    dut.ncs_in.value = 0
    await RisingEdge(dut.clk_in)
    dut.ncs_in.value = 1
    await RisingEdge(dut.clk_in)

    # Write sprite data via 0x2004
    dut.sel_in.value = 4
    dut.cpu_d_in.value = 0xAB
    dut.r_nw_in.value = 0
    dut.ncs_in.value = 0
    await RisingEdge(dut.clk_in)  # This is the falling edge detection
    dut.ncs_in.value = 1

    # spr_ram_wr_out is combinational - must check *immediately*
    assert dut.spr_ram_wr_out.value == 1, "Expected sprite RAM write enable"
    assert dut.spr_ram_d_out.value == 0xAB, "Expected sprite RAM data"

    # Wait one clock to see spr_ram_a_out updated
    await RisingEdge(dut.clk_in)
    assert dut.spr_ram_a_out.value == 0x21, f"Expected spr_ram_a_out to increment to 0x21, got {dut.spr_ram_a_out.value}"
