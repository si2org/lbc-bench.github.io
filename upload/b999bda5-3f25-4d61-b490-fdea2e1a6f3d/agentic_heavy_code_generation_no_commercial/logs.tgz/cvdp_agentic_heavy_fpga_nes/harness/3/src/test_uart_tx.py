import cocotb
from cocotb.clock    import Clock
from cocotb.triggers import RisingEdge, First, Timer
import random

CLK_PERIOD_NS = 10  # 100 MHz

async def drive_clocks(dut):
    cocotb.start_soon(Clock(dut.clk, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2).start())
    await RisingEdge(dut.clk)
    while True:
        # oversampled baud tick every clock
        dut.baud_clk_tick.value = 1
        await RisingEdge(dut.clk)

async def reset_dut(dut):
    dut.reset.value = 1
    for _ in range(5):
        await RisingEdge(dut.clk)
    dut.reset.value = 0
    await RisingEdge(dut.clk)

def expected_frame(byte, data_bits, parity_mode, stop_bits):
    bits = [0]  # start bit
    # data LSB→MSB
    for i in range(data_bits):
        bits.append((byte >> i) & 1)
    # parity
    if parity_mode == 1:      # odd
        bits.append((bin(byte).count("1") % 2) ^ 1)
    elif parity_mode == 2:    # even
        bits.append(bin(byte).count("1") % 2)
    # stop bits
    bits += [1] * stop_bits
    return bits

# -----------------------------------------------------------------------------
# Sample each bit in the center of its period
# -----------------------------------------------------------------------------
async def sample_frame(dut, n_bits):
    obs = []
    oversample = int(dut.BAUD_CLK_OVERSAMPLE_RATE.value)
    half_cycle = oversample // 2

    # align to first tick edge
    await RisingEdge(dut.clk)

    for i in range(n_bits):
        # wait half-period
        for _ in range(half_cycle):
            await RisingEdge(dut.clk)
        val = int(dut.tx.value)
        obs.append(val)
        dut._log.info(f"  Sampled bit[{i}] = {val}")
        # finish bit period
        for _ in range(oversample - half_cycle):
            await RisingEdge(dut.clk)

    return obs

# -----------------------------------------------------------------------------
# Send a byte, wait for done, compare bits
# -----------------------------------------------------------------------------
async def send_and_check(dut, byte):
    data_bits   = int(dut.DATA_BITS.value)
    parity_mode = int(dut.PARITY_MODE.value)
    stop_bits   = int(dut.STOP_BITS.value)
    oversample  = int(dut.BAUD_CLK_OVERSAMPLE_RATE.value)

    exp = expected_frame(byte, data_bits, parity_mode, stop_bits)
    n   = len(exp)

    # start sampling in parallel
    samp = cocotb.start_soon(sample_frame(dut, n))

    # pulse tx_start
    dut.tx_data .value = byte
    dut.tx_start.value = 1
    await RisingEdge(dut.clk)
    dut.tx_start.value = 0
    dut._log.info(f"→ Sending 0x{byte:02X}, expect {exp}")

    # wait for tx_done_tick or timeout
    max_ns = (n * oversample + 4) * CLK_PERIOD_NS
    done   = RisingEdge(dut.tx_done_tick)
    to     = Timer(max_ns, unit="ns")
    evt    = await First(done, to)
    assert evt is done, f"Timeout {max_ns} ns waiting for tx_done_tick for 0x{byte:02X}"

    obs = await samp
    dut._log.info(f"  Observed {obs}")
    assert obs == exp, (
        f"Bit mismatch for 0x{byte:02X}\n"
        f"  Expected: {exp}\n"
        f"  Observed: {obs}"
    )
    dut._log.info(f"✔ Frame 0x{byte:02X} OK")

    # one-bit idle before next
    for _ in range(oversample):
        await RisingEdge(dut.clk)

# -----------------------------------------------------------------------------
# 10 Tests
# -----------------------------------------------------------------------------
@cocotb.test()
async def test_idle(dut):
    """1) Idle: tx must stay high."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    for _ in range(3):
        await RisingEdge(dut.clk)
    assert int(dut.tx.value) == 1, "Idle: tx should be high"
    dut._log.info("✔ idle OK")

@cocotb.test()
async def test_send_00(dut):
    """2) Send 0x00."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    await send_and_check(dut, 0x00)

@cocotb.test()
async def test_send_FF(dut):
    """3) Send 0xFF."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    await send_and_check(dut, 0xFF)

@cocotb.test()
async def test_send_5A(dut):
    """4) Send 0x5A."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    await send_and_check(dut, 0x5A)

@cocotb.test()
async def test_send_A5(dut):
    """5) Send 0xA5."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    await send_and_check(dut, 0xA5)

@cocotb.test()
async def test_pattern_3C(dut):
    """6) Send 0x3C."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    await send_and_check(dut, 0x3C)

@cocotb.test()
async def test_back_to_back(dut):
    """7) Back-to-back: 0x55 then 0xAA."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    await send_and_check(dut, 0x55)
    await send_and_check(dut, 0xAA)

@cocotb.test()
async def test_random_sequence(dut):
    """8) 5 random bytes sequentially."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    for _ in range(5):
        await send_and_check(dut, random.randint(0, 0xFF))

@cocotb.test()
async def test_tx_start_glitch(dut):
    """9) Single-cycle tx_start glitch must not start."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    dut.tx_data .value = 0x77
    dut.tx_start.value = 1
    await RisingEdge(dut.clk)
    dut.tx_start.value = 0
    dut._log.info("→ glitch")
    # wait 2 bit‐periods
    for _ in range(2 * int(dut.BAUD_CLK_OVERSAMPLE_RATE.value)): 
        await RisingEdge(dut.clk)
    assert int(dut.tx_done_tick.value) == 0, "Glitch unexpectedly sent"
    dut._log.info("✔ glitch ignored")

@cocotb.test()
async def test_partial_frame_timeout(dut):
    """10) Only half-frame → no tx_done_tick."""
    cocotb.start_soon(drive_clocks(dut))
    await reset_dut(dut)
    data_bits  = int(dut.DATA_BITS.value)
    oversample = int(dut.BAUD_CLK_OVERSAMPLE_RATE.value)  

    dut.tx_data .value = 0xCC
    dut.tx_start.value = 1
    await RisingEdge(dut.clk)
    dut.tx_start.value = 0
    dut._log.info("→ half-frame")

    half_cycles = (1 + data_bits // 2) * oversample
    for _ in range(half_cycles + 2):
        await RisingEdge(dut.clk)

    assert int(dut.tx_done_tick.value) == 0, "Partial prematurely done" 
    dut._log.info("✔ partial still in progress")
