import os
from pathlib import Path
from cocotb_tools.runner import get_runner
import pytest

# Fetch environment variables for simulation setup
verilog_sources = os.getenv("VERILOG_SOURCES").split()
toplevel_lang   = os.getenv("TOPLEVEL_LANG", "verilog")
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL", "uart_tx")
module          = os.getenv("MODULE", "test_uart_tx")
wave            = os.getenv("WAVE", "1")

# -------------------------------------------------------------------
# Added: default parameter overrides for the UART transmitter
# -------------------------------------------------------------------
parameters = {
    "DATA_BITS":                8,
    "STOP_BITS":                1,
    "PARITY_MODE":              1,   # 0-NONE, 1-ODD, 2-EVEN
    "BAUD_CLK_OVERSAMPLE_RATE": 16
}

def runner():
    """Runs the simulation for the uart_tx design."""
    simulation_runner = get_runner(sim)

    simulation_runner.build(
        sources      = verilog_sources,
        hdl_toplevel = toplevel,
        always       = True,
        clean        = True,
        waves        = (wave == "1"),
        verbose      = True,
        timescale    = ("1ns", "1ns"),
        log_file     = "build.log",
        parameters   = parameters      # ← new line
    )

    simulation_runner.test(
        hdl_toplevel = toplevel,
        test_module  = module,
        waves        = (wave == "1")
    )

# Pytest entry point
@pytest.mark.simulation
def test_uart_tx():
    """Pytest function to execute the uart_tx testbench."""
    print("Running uart tx testbench...")
    runner()
