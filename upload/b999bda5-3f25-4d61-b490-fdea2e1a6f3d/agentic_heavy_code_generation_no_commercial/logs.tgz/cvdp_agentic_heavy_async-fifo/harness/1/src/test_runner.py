import os
from pathlib import Path
from cocotb_tools.runner import get_runner
import pytest

# Fetch environment variables for simulation setup
verilog_sources = os.getenv("VERILOG_SOURCES").split()
toplevel_lang = os.getenv("TOPLEVEL_LANG", "verilog")
sim = os.getenv("SIM", "icarus")
toplevel = os.getenv("TOPLEVEL", "async_fifo")
module = os.getenv("MODULE", "test_async_fifo")
wave = os.getenv("WAVE", "1")

# Optional: override parameters using environment or defaults
DSIZE = os.getenv("DSIZE", "8")
ASIZE = os.getenv("ASIZE", "4")
AWFULLSIZE = os.getenv("AWFULLSIZE", "1")
AREMPTYSIZE = os.getenv("AREMPTYSIZE", "1")
FALLTHROUGH = os.getenv("FALLTHROUGH", '"TRUE"')  # Keep quotes for string params

# Function to configure and run the simulation
def runner():
    """Runs the simulation for the async_fifo."""

    # Get the simulation runner
    simulation_runner = get_runner(sim)

    # Parameter override dictionary
    parameters = {
        "DSIZE": DSIZE,
        "ASIZE": ASIZE,
        "AWFULLSIZE": AWFULLSIZE,
        "AREMPTYSIZE": AREMPTYSIZE,
      #  "FALLTHROUGH": FALLTHROUGH,
    }

    # Build the simulation environment
    simulation_runner.build(
        sources=verilog_sources,
        hdl_toplevel=toplevel,
        always=True,
        clean=True,
        waves=(wave == "1"),
        verbose=True,
        timescale=("1ns", "1ns"),
        parameters=parameters,
        log_file="build.log"
    )

    # Run the testbench
    simulation_runner.test(
        hdl_toplevel=toplevel,
        test_module=module,
        waves=(wave == "1")
    )

# Pytest function to run the simulation
def test_async_fifo():
    """Pytest function to execute the async_fifo testbench."""
    print("Running async_fifo testbench...")
    runner()
