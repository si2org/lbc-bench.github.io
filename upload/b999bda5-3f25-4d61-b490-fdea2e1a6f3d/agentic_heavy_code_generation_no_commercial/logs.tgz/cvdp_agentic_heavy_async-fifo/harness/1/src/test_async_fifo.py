import cocotb
from cocotb.triggers import RisingEdge, ClockCycles, Timer
from cocotb.clock import Clock
import random

DSIZE = 8
ASIZE = 4
DEPTH = 1 << ASIZE
MAX_WAIT_CYCLES = 10  # Retry limit to avoid infinite loops

async def reset_fifo(dut):
    dut._log.info("[RESET] Asserting reset signals...")
    dut.wrst_n.value = 0
    dut.rrst_n.value = 0
    dut.winc.value = 0
    dut.rinc.value = 0
    await ClockCycles(dut.wclk, 5)
    await ClockCycles(dut.rclk, 5)
    dut.wrst_n.value = 1
    dut.rrst_n.value = 1
    await ClockCycles(dut.wclk, 2)
    await ClockCycles(dut.rclk, 2)
    dut._log.info("[RESET] Deasserted reset signals.")

@cocotb.test()
async def test_basic_write_read(dut):
    """Basic test: Write and read values with interleaved read."""
    cocotb.start_soon(Clock(dut.wclk, 10, unit="ns").start())
    cocotb.start_soon(Clock(dut.rclk, 12, unit="ns").start())
    await reset_fifo(dut)

    test_data = [random.randint(0, 255) for _ in range(5)]
    dut._log.info(f"[TEST] Writing data: {test_data}")

    read_data = []

    for val in test_data:
        # Attempt to write
        dut.wdata.value = val
        dut.winc.value = 1
        wait = 0
        while (not dut.wfull.value.is_resolvable or dut.wfull.value) and wait < MAX_WAIT_CYCLES:
            dut._log.warning(f"[WAIT] FIFO full. Retry {wait + 1}/{MAX_WAIT_CYCLES}")
            await RisingEdge(dut.wclk)
            wait += 1
        if dut.wfull.value.is_resolvable and dut.wfull.value:
            dut._log.error("FIFO stuck in full state. Skipping write.")
            continue
        await RisingEdge(dut.wclk)
        dut.winc.value = 0

        # Read immediately after write
        dut.rinc.value = 1
        wait = 0
        while (not dut.rempty.value.is_resolvable or dut.rempty.value) and wait < MAX_WAIT_CYCLES:
            dut._log.warning(f"[WAIT] FIFO empty. Retry {wait + 1}/{MAX_WAIT_CYCLES}")
            await RisingEdge(dut.rclk)
            wait += 1
        assert dut.rempty.value.is_resolvable and not int(dut.rempty.value), "FIFO stuck in empty state"
        assert dut.rdata.value.is_resolvable, "rdata is X: possible pointer/gray-code bug"
        rval = int(dut.rdata.value)  # read BEFORE consuming edge
        read_data.append(rval)
        dut._log.info(f"[READ] Value: {rval}")
        await RisingEdge(dut.rclk)  # consume
        dut.rinc.value = 0

    assert read_data == test_data[:len(read_data)], f"Mismatch: Expected {test_data}, got {read_data}"



@cocotb.test()
async def test_fifo_full_flag(dut):
    """Fill FIFO and verify wfull is asserted."""
    cocotb.start_soon(Clock(dut.wclk, 10, unit="ns").start())
    cocotb.start_soon(Clock(dut.rclk, 10, unit="ns").start())
    await reset_fifo(dut)

    dut.winc.value = 1
    for i in range(DEPTH):
        dut.wdata.value = i
        await RisingEdge(dut.wclk)

    await RisingEdge(dut.wclk)
    dut.winc.value = 0

    assert dut.wfull.value == 1, "wfull not asserted after FIFO fill"
    dut._log.info("[CHECK] wfull correctly asserted at capacity.")


@cocotb.test()
async def test_fifo_empty_flag(dut):
    """Check rempty after reset (no writes)."""
    cocotb.start_soon(Clock(dut.wclk, 10, unit="ns").start())
    cocotb.start_soon(Clock(dut.rclk, 10, unit="ns").start())
    await reset_fifo(dut)

    await RisingEdge(dut.rclk)
    assert dut.rempty.value == 1, "rempty not asserted after reset"
    dut._log.info("[CHECK] rempty correctly asserted after reset.")


@cocotb.test()
async def test_randomized_write_read(dut):
    """Random data burst write/read stress test."""
    cocotb.start_soon(Clock(dut.wclk, 10, unit="ns").start())
    cocotb.start_soon(Clock(dut.rclk, 13, unit="ns", period_high=7).start())
    await reset_fifo(dut)

    write_data = [random.randint(0, 255) for _ in range(DEPTH // 2)]
    read_data = []

    for val in write_data:
        wait = 0
        while (not dut.wfull.value.is_resolvable or int(dut.wfull.value)) and wait < MAX_WAIT_CYCLES:
            dut.winc.value = 0
            await RisingEdge(dut.wclk)
            wait += 1
        assert dut.wfull.value.is_resolvable and not int(dut.wfull.value), "FIFO stayed full during randomized write"
        dut.wdata.value = val
        dut.winc.value = 1
        await RisingEdge(dut.wclk)
        dut.winc.value = 0
        await Timer(1, unit="ns")

    await ClockCycles(dut.rclk, 6)

    for exp in write_data:
        wait = 0
        while (not dut.rempty.value.is_resolvable or int(dut.rempty.value)) and wait < MAX_WAIT_CYCLES:
            dut.rinc.value = 0
            await RisingEdge(dut.rclk)
            wait += 1
        assert dut.rempty.value.is_resolvable and not int(dut.rempty.value), "FIFO stayed empty during randomized read"
        assert dut.rdata.value.is_resolvable, "rdata is X during randomized read"
        got = int(dut.rdata.value)
        read_data.append(got)
        assert got == exp, f"Randomized read mismatch: expected {exp}, got {got}"
        dut.rinc.value = 1
        await RisingEdge(dut.rclk)
        dut.rinc.value = 0
        await Timer(1, unit="ns")

    assert read_data == write_data, f"Data mismatch: wrote {write_data}, read {read_data}"
    dut._log.info("[PASS] Randomized stress test succeeded.")

@cocotb.test()
async def test_awfull_threshold(dut):
    """Check 'awfull' signal 1 slot before 'wfull'."""
    cocotb.start_soon(Clock(dut.wclk, 10, unit="ns").start())
    cocotb.start_soon(Clock(dut.rclk, 10, unit="ns").start())
    await reset_fifo(dut)

    dut.winc.value = 1
    for i in range(DEPTH - 1):  # Fill all but one
        dut.wdata.value = i
        await RisingEdge(dut.wclk)

        if i == DEPTH - 2:
            await Timer(1, unit="ns")  # Let combinational logic settle
            assert dut.awfull.value == 1, "awfull should be asserted when 1 slot left"
            dut._log.info("[CHECK] awfull correctly asserted.")

    dut.winc.value = 0

@cocotb.test()
async def test_arempty_threshold(dut):
    """Check 'arempty' signal when one unread item left."""
    cocotb.start_soon(Clock(dut.wclk, 10, unit="ns").start())
    cocotb.start_soon(Clock(dut.rclk, 10, unit="ns").start())
    await reset_fifo(dut)

    # Write two values
    for val in [1, 2]:
        dut.wdata.value = val
        dut.winc.value = 1
        await RisingEdge(dut.wclk)
    dut.winc.value = 0

    # Wait for write-to-read sync
    await ClockCycles(dut.rclk, 4)

    # Read one value
    dut.rinc.value = 1
    await RisingEdge(dut.rclk)
    dut.rinc.value = 0

    # Wait for arempty to reflect status
    await ClockCycles(dut.rclk, 3)

    assert dut.arempty.value == 1, "arempty should be high with 1 item left"
    dut._log.info("[CHECK] arempty correctly asserted.")

@cocotb.test()
async def test_cross_clock_domain_burst(dut):
    """Stress test: Async burst writes and reads with skewed clocks."""
    cocotb.start_soon(Clock(dut.wclk, 8, unit="ns").start())   # Faster write
    cocotb.start_soon(Clock(dut.rclk, 20, unit="ns").start())  # Slower read
    await reset_fifo(dut)

    write_vals = list(range(10))
    read_vals = []

    # Burst write 10 values
    for val in write_vals:
        dut.wdata.value = val
        dut.winc.value = 1
        await RisingEdge(dut.wclk)

    dut.winc.value = 0
    await ClockCycles(dut.rclk, 6)  # allow pointer sync

    # Controlled read with timeout
    MAX_RETRIES = 100
    retries = 0
    while len(read_vals) < len(write_vals) and retries < MAX_RETRIES:
        if dut.rempty.value.is_resolvable and not int(dut.rempty.value):
            dut.rinc.value = 1
            await RisingEdge(dut.rclk)
            if not dut.rdata.value.is_resolvable:
                dut.rinc.value = 0
                await RisingEdge(dut.rclk)
                continue
            rval = int(dut.rdata.value)
            read_vals.append(rval)
            dut._log.info(f"[READ] {rval}")
        else:
            dut.rinc.value = 0
            await RisingEdge(dut.rclk)
        retries += 1

    dut.rinc.value = 0
    assert read_vals == write_vals[:len(read_vals)], f"Expected {write_vals}, got {read_vals}"
    dut._log.info("[PASS] Cross-clock burst test successful.")


@cocotb.test()
async def test_async_fifo_basic(dut):
    """Final verified test for async_fifo: logs wdata, rdata, rempty, rptr issues"""

    clk_period = 10  # ns
    log = dut._log

    log.info("🔧 Starting async_fifo testbench")

    # Start clocks
    cocotb.start_soon(Clock(dut.wclk, clk_period, unit="ns", period_high=(clk_period+1)//2 if clk_period%2 else clk_period//2).start())
    cocotb.start_soon(Clock(dut.rclk, clk_period, unit="ns", period_high=(clk_period+1)//2 if clk_period%2 else clk_period//2).start())

    # Reset both sides
    dut.wrst_n.value = 0
    dut.rrst_n.value = 0
    dut.winc.value = 0
    dut.rinc.value = 0
    dut.wdata.value = 0

    await Timer(4 * clk_period, unit="ns")
    dut.wrst_n.value = 1
    dut.rrst_n.value = 1
    log.info("✅ Reset released")

    await Timer(4 * clk_period, unit="ns")

    # Step 1: Write values
    write_data = [0x11, 0x22, 0x33, 0x44]
    log.info(f"📤 Writing: {[f'{v:#04x}' for v in write_data]}")
    for i, val in enumerate(write_data):
        dut.wdata.value = val
        dut.winc.value = 1
        await RisingEdge(dut.wclk)
        dut.winc.value = 0
        await RisingEdge(dut.wclk)
        log.info(f"📝 Wrote {val:#04x} at wclk cycle {i}")

    # Step 2: Wait for rempty to go low
    log.info("⏳ Waiting for rempty=0...")
    while not (dut.rempty.value.is_resolvable and int(dut.rempty.value) == 0):
        await RisingEdge(dut.rclk)
    log.info("📥 FIFO ready to read")

    # Step 3: Read only 3 values (0x22, 0x33, 0x44)
    read_values = []
    expected_data = write_data[1:]  # skip 0x11
    for i in range(len(expected_data)):
        dut.rinc.value = 1
        await RisingEdge(dut.rclk)
        dut.rinc.value = 0
        await RisingEdge(dut.rclk)

        val = dut.rdata.value
        rempty = int(dut.rempty.value)
        ready = val.is_resolvable
        log.info(f"📡 [Cycle {i}] rinc=1 | rempty={rempty} | rdata={val} | ready={ready}")

        if not ready:
            log.error(f"❌ rdata is undefined at read index {i}")
            break

        intval = int(val)
        read_values.append(intval)
        log.info(f"✅ Captured rdata: {intval:#04x} at index {i}")

    # Step 4: Validate only last 3 values
    log.info("🔍 Verifying last 3 values (expected drop of first)")
    for i, (exp, act) in enumerate(zip(expected_data, read_values)):
        log.info(f"🔎 Index {i}: Expected {exp:#04x}, Got {act:#04x}")
        assert exp == act, f"Mismatch at index {i}: expected {exp:#04x}, got {act:#04x}"

    assert len(read_values) == len(expected_data), (
        f"Expected {len(expected_data)} reads, got {len(read_values)}"
    )

    log.info("✅ FIFO data matches expected output. Test PASSED.")
