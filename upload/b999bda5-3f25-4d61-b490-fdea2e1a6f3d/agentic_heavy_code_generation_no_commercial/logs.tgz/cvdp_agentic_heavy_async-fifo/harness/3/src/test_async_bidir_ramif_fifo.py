import cocotb
from cocotb.triggers import RisingEdge, ClockCycles, Timer
from cocotb.clock import Clock
import random

CLK_PERIOD = 10  # ns

async def reset_side(dut, prefix):
    getattr(dut, f"{prefix}_rst_n").value = 0
    await ClockCycles(getattr(dut, f"{prefix}_clk"), 5)
    getattr(dut, f"{prefix}_rst_n").value = 1
    await ClockCycles(getattr(dut, f"{prefix}_clk"), 2)

@cocotb.test()
async def test_clk_and_reset_toggle(dut):
    """Ensure clocks are toggling and reset signals are correctly set/deasserted."""
    cocotb.start_soon(Clock(dut.a_clk, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())
    cocotb.start_soon(Clock(dut.b_clk, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())

    dut.a_winc.value = 0
    dut.b_winc.value = 0
    dut.a_wdata.value = 0
    dut.b_wdata.value = 0

    await reset_side(dut, "a")
    await reset_side(dut, "b")
    await ClockCycles(dut.a_clk, 3)
    await ClockCycles(dut.b_clk, 3)

    dut._log.info("✅ Clocks and resets toggled cleanly.")

@cocotb.test()
async def test_a_side_can_drive_ram_wdata(dut):
    """Write from A side and confirm o_ram_a_wdata matches."""
    cocotb.start_soon(Clock(dut.a_clk, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())
    await reset_side(dut, "a")

    dut.a_dir.value = 1
    await ClockCycles(dut.a_clk, 2)

    test_val = random.randint(1, 255)
    dut.a_wdata.value = test_val
    dut.a_winc.value = 1
    await RisingEdge(dut.a_clk)
    dut.a_winc.value = 0
    await RisingEdge(dut.a_clk)

    observed = int(dut.o_ram_a_wdata.value)
    dut._log.info(f"A wrote {test_val:#04x}, observed {observed:#04x} on o_ram_a_wdata.")
    assert observed == test_val, f"Expected {test_val:#04x}, got {observed:#04x}"

@cocotb.test()
async def test_b_side_can_drive_ram_wdata(dut):
    """Write from B side and confirm o_ram_b_wdata matches."""
    cocotb.start_soon(Clock(dut.b_clk, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())
    await reset_side(dut, "b")

    dut.b_dir.value = 1
    await ClockCycles(dut.b_clk, 2)

    test_val = random.randint(1, 255)
    dut.b_wdata.value = test_val
    dut.b_winc.value = 1
    await RisingEdge(dut.b_clk)
    dut.b_winc.value = 0
    await RisingEdge(dut.b_clk)

    observed = int(dut.o_ram_b_wdata.value)
    dut._log.info(f"B wrote {test_val:#04x}, observed {observed:#04x} on o_ram_b_wdata.")
    assert observed == test_val, f"Expected {test_val:#04x}, got {observed:#04x}"

@cocotb.test()
async def test_ram_interface_assignments(dut):
    """Confirm that o_ram_a_addr and o_ram_b_addr are always driven (not Z/X)."""
    cocotb.start_soon(Clock(dut.a_clk, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())
    cocotb.start_soon(Clock(dut.b_clk, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())

    await reset_side(dut, "a")
    await reset_side(dut, "b")
    await ClockCycles(dut.a_clk, 4)
    await ClockCycles(dut.b_clk, 4)

    addr_a = dut.o_ram_a_addr.value
    addr_b = dut.o_ram_b_addr.value

    dut._log.info(f"RAM A addr: {addr_a}, RAM B addr: {addr_b}")

    assert addr_a.is_resolvable, "RAM A address is not resolvable"
    assert addr_b.is_resolvable, "RAM B address is not resolvable"

@cocotb.test()
async def test_a_side_single_write_strobe(dut):
    """Check that A-side triggers o_ram_a_winc properly on a valid write pulse."""
    cocotb.start_soon(Clock(dut.a_clk, 10, unit="ns").start())
    await ClockCycles(dut.a_clk, 2)
    dut.a_rst_n.value = 0
    await ClockCycles(dut.a_clk, 2)
    dut.a_rst_n.value = 1
    await ClockCycles(dut.a_clk, 2)

    dut.a_dir.value = 1
    dut.a_wdata.value = 0x5A
    dut.a_winc.value = 1
    await RisingEdge(dut.a_clk)
    dut.a_winc.value = 0
    await RisingEdge(dut.a_clk)

    val = int(dut.o_ram_a_winc.value)
    dut._log.info(f"A-side o_ram_a_winc = {val}")
    assert val in (0, 1)

@cocotb.test()
async def test_b_side_write_and_addr_valid(dut):
    """Confirm B-side write strobe and address is resolvable."""
    cocotb.start_soon(Clock(dut.b_clk, 10, unit="ns").start())
    await ClockCycles(dut.b_clk, 2)
    dut.b_rst_n.value = 0
    await ClockCycles(dut.b_clk, 2)
    dut.b_rst_n.value = 1
    await ClockCycles(dut.b_clk, 2)

    dut.b_dir.value = 1
    dut.b_wdata.value = 0xA5
    dut.b_winc.value = 1
    await RisingEdge(dut.b_clk)
    dut.b_winc.value = 0
    await RisingEdge(dut.b_clk)

    assert dut.o_ram_b_addr.value.is_resolvable, "B-side addr not resolvable"
    dut._log.info(f"B-side o_ram_b_addr: {dut.o_ram_b_addr.value}")

@cocotb.test()
async def test_direction_flip_and_rinc(dut):
    """Flip direction from write to read and observe read strobes."""
    cocotb.start_soon(Clock(dut.a_clk, 10, unit="ns").start())
    cocotb.start_soon(Clock(dut.b_clk, 10, unit="ns").start())
    for side in ("a", "b"):
        getattr(dut, f"{side}_rst_n").value = 0
    await ClockCycles(dut.a_clk, 3)
    for side in ("a", "b"):
        getattr(dut, f"{side}_rst_n").value = 1
    await ClockCycles(dut.a_clk, 2)

    dut.a_dir.value = 1
    dut.b_dir.value = 1
    dut.a_wdata.value = 0xC3
    dut.b_wdata.value = 0x3C
    dut.a_winc.value = 1
    dut.b_winc.value = 1
    await RisingEdge(dut.a_clk)
    await RisingEdge(dut.b_clk)
    dut.a_winc.value = 0
    dut.b_winc.value = 0

    # Change direction to read
    dut.a_dir.value = 0
    dut.b_dir.value = 0
    dut.a_rinc.value = 1
    dut.b_rinc.value = 1
    await RisingEdge(dut.a_clk)
    await RisingEdge(dut.b_clk)
    dut.a_rinc.value = 0
    dut.b_rinc.value = 0

    dut._log.info(f"A-side o_ram_a_rinc = {dut.o_ram_a_rinc.value}")
    dut._log.info(f"B-side o_ram_b_rinc = {dut.o_ram_b_rinc.value}")
    assert int(dut.o_ram_a_rinc.value) in (0, 1)
    assert int(dut.o_ram_b_rinc.value) in (0, 1)


@cocotb.test()
async def test_a_rdata_source(dut):
    """Verify a_rdata uses i_ram_a_rdata (not i_ram_b_rdata) — combinational mux bug."""
    cocotb.start_soon(Clock(dut.a_clk, CLK_PERIOD, unit="ns").start())
    cocotb.start_soon(Clock(dut.b_clk, CLK_PERIOD, unit="ns").start())

    await reset_side(dut, "a")
    await reset_side(dut, "b")

    # Drive distinct sentinel values so the bug is unambiguous
    dut.i_ram_a_rdata.value = 0xAA
    dut.i_ram_b_rdata.value = 0x55

    await Timer(1, unit="ns")  # combinational settling

    rdata = int(dut.a_rdata.value)
    dut._log.info(f"i_ram_a_rdata=0xAA, i_ram_b_rdata=0x55 => a_rdata=0x{rdata:02X}")
    assert rdata == 0xAA, (
        f"a_rdata=0x{rdata:02X}: expected 0xAA (i_ram_a_rdata); "
        f"bug assigns a_rdata = i_ram_b_rdata which gives 0x55"
    )
