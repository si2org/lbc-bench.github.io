import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer, FallingEdge
import harness_library as hrs_lb
import random

def set_inputs(dut, model, in_prot=0, in_sIP=0, in_dIP=0, in_sPort=0, in_dPort=0,
               in_len=0, in_pktID=0, in_flits=0, in_tcp_flags=0,
               in_pkt_flags=0, in_pkt_queue_id=0, in_hash=0, in_padding=0,
               in_meta_valid=0, out_meta_ready=0, nb_fallback_queues=0, enable_rr=0):
    dut.in_prot.value            = in_prot
    dut.in_sIP.value             = in_sIP
    dut.in_dIP.value             = in_dIP
    dut.in_sPort.value           = in_sPort
    dut.in_dPort.value           = in_dPort
    dut.in_len.value             = in_len
    dut.in_pktID.value           = in_pktID
    dut.in_flits.value           = in_flits
    dut.in_tcp_flags.value       = in_tcp_flags
    dut.in_pkt_flags.value       = in_pkt_flags
    dut.in_pkt_queue_id.value    = in_pkt_queue_id
    dut.in_hash.value            = in_hash
    dut.in_padding.value         = in_padding
    dut.in_meta_valid.value      = in_meta_valid
    dut.out_meta_ready.value     = out_meta_ready
    dut.nb_fallback_queues.value = nb_fallback_queues
    dut.enable_rr.value          = enable_rr

    model.update(in_prot, in_sIP, in_dIP, in_sPort, in_dPort, in_len, in_pktID, in_flits, in_tcp_flags, in_pkt_flags, in_pkt_queue_id, in_hash, in_padding, out_meta_ready, nb_fallback_queues, enable_rr, in_meta_valid)

def compare_values(dut, model, debug=0):
    dut_prot         = int(dut.out_prot.value)
    dut_sIP          = int(dut.out_sIP.value)
    dut_dIP          = int(dut.out_dIP.value)
    dut_sPort        = int(dut.out_sPort.value)
    dut_dPort        = int(dut.out_dPort.value)
    dut_len          = int(dut.out_len.value)
    dut_pktID        = int(dut.out_pktID.value)
    dut_flits        = int(dut.out_flits.value)
    dut_tcp_flags    = int(dut.out_tcp_flags.value)
    dut_pkt_flags    = int(dut.out_pkt_flags.value)
    dut_pkt_queue_id = int(dut.out_pkt_queue_id.value)
    dut_hash         = int(dut.out_hash.value)
    dut_padding      = int(dut.out_padding.value)
    dut_meta_valid   = int(dut.out_meta_valid.value)
    dut_meta_ready   = int(dut.in_meta_ready.value)

    model_prot         = model.prot
    model_sIP          = model.sIP
    model_dIP          = model.dIP
    model_sPort        = model.sPort
    model_dPort        = model.dPort
    model_len          = model.len
    model_pktID        = model.pktID
    model_flits        = model.flits
    model_tcp_flags    = model.tcp_flags
    model_pkt_flags    = model.pkt_flags
    model_pkt_queue_id = model.pkt_queue_id
    model_hash         = model.hash
    model_padding      = model.padding
    model_meta_valid   = model.out_meta_valid
    model_meta_ready   = model.in_meta_ready

    if debug == 1:
        print("\nOUTPUTS")
        print(f"DUT prot  = {hex(dut_prot)} \nMODEL prot  = {hex(model_prot)}")
        print(f"DUT sIP  = {hex(dut_sIP)} \nMODEL prot  = {hex(model_sIP)}")
        print(f"DUT dIP  = {hex(dut_dIP)} \nMODEL prot  = {hex(model_dIP)}")
        print(f"DUT sPort  = {hex(dut_sPort)} \nMODEL prot  = {hex(model_sPort)}")
        print(f"DUT dPort  = {hex(dut_dPort)} \nMODEL prot  = {hex(model_dPort)}")
        print(f"DUT len  = {hex(dut_len)} \nMODEL prot  = {hex(model_len)}")
        print(f"DUT pktID  = {hex(dut_pktID)} \nMODEL prot  = {hex(model_pktID)}")
        print(f"DUT flits  = {hex(dut_flits)} \nMODEL prot  = {hex(model_flits)}")
        print(f"DUT tcp_flags  = {hex(dut_tcp_flags)} \nMODEL prot  = {hex(model_tcp_flags)}")
        print(f"DUT pkt_flags  = {hex(dut_pkt_flags)} \nMODEL prot  = {hex(model_pkt_flags)}")
        print(f"DUT pkt_queue_id  = {hex(dut_pkt_queue_id)} \nMODEL prot  = {hex(model_pkt_queue_id)}")
        print(f"DUT hash  = {hex(dut_hash)} \nMODEL prot  = {hex(model_hash)}")
        print(f"DUT padding  = {hex(dut_padding)} \nMODEL prot  = {hex(model_padding)}")
        print(f"DUT out_meta_valid  = {hex(dut_meta_valid)} \nMODEL prot  = {hex(model_meta_valid)}")
        print(f"DUT in_meta_ready  = {hex(dut_meta_ready)} \nMODEL prot  = {hex(model_meta_ready)}")
    
    assert dut_prot         == model_prot,         f"[ERROR] DUT o_data does not match model o_data: {hex(dut_prot)} != {hex(model_prot)}"
    assert dut_sIP          == model_sIP,          f"[ERROR] DUT sIP does not match model sIP: {hex(dut_sIP)} != {hex(model_sIP)}"
    assert dut_dIP          == model_dIP,          f"[ERROR] DUT dIP does not match model dIP: {hex(dut_dIP)} != {hex(model_dIP)}"
    assert dut_sPort        == model_sPort,        f"[ERROR] DUT sPort does not match model sPort: {hex(dut_sPort)} != {hex(model_sPort)}"
    assert dut_dPort        == model_dPort,        f"[ERROR] DUT dPort does not match model dPort: {hex(dut_dPort)} != {hex(model_dPort)}"
    assert dut_len          == model_len,          f"[ERROR] DUT len does not match model len: {hex(dut_len)} != {hex(model_len)}"
    assert dut_pktID        == model_pktID,        f"[ERROR] DUT pktID does not match model pktID: {hex(dut_pktID)} != {hex(model_pktID)}"
    assert dut_flits        == model_flits,        f"[ERROR] DUT flits does not match model flits: {hex(dut_flits)} != {hex(model_flits)}"
    assert dut_tcp_flags    == model_tcp_flags,    f"[ERROR] DUT tcp_flags does not match model tcp_flags: {hex(dut_tcp_flags)} != {hex(model_tcp_flags)}"
    assert dut_pkt_flags    == model_pkt_flags,    f"[ERROR] DUT pkt_flags does not match model pkt_flags: {hex(dut_pkt_flags)} != {hex(model_pkt_flags)}"
    assert dut_pkt_queue_id == model_pkt_queue_id, f"[ERROR] DUT pkt_queue_id does not match model pkt_queue_id: {hex(dut_pkt_queue_id)} != {hex(model_pkt_queue_id)}"
    assert dut_hash         == model_hash,         f"[ERROR] DUT hash does not match model hash: {hex(dut_hash)} != {hex(model_hash)}"
    assert dut_padding      == model_padding,      f"[ERROR] DUT padding does not match model padding: {hex(dut_padding)} != {hex(model_padding)}"
    assert dut_meta_valid   == model_meta_valid,   f"[ERROR] DUT out_meta_valid does not match model out_meta_valid: {hex(dut_meta_valid)} != {hex(model_meta_valid)}"
    assert dut_meta_ready   == model_meta_ready,   f"[ERROR] DUT in_meta_ready does not match model in_meta_ready: {hex(dut_meta_ready)} != {hex(model_meta_ready)}"

@cocotb.test()
async def test_flow_director(dut):
    random.seed(1)
    """Test the flow_director module with edge cases and random data."""
    cocotb.start_soon(Clock(dut.clk, 10, unit='ns').start())

    model = hrs_lb.flow_director()

    resets = 4
    runs = 1000
    
    await hrs_lb.dut_init(dut)

    for i in range(resets):
        # Reset DUT
        # Set all inputs to 0
        model.reset()
        set_inputs(dut, model)
        await FallingEdge(dut.clk)
        dut.rst.value = 1
        await FallingEdge(dut.clk)
        dut.rst.value = 0

        compare_values(dut, model)

        for j in range(runs):
            if (j+1)%500 == 0:
                print(f'\n------ Reset {i}, run {j+1} ------')
            
            # Test with pkt_queue_id != '1
            set_inputs(dut, model, in_prot=random.randint(0,2**8-1), in_sIP=random.randint(0,2**32-1), in_dIP=random.randint(0,2**32-1), in_sPort=random.randint(0,2**16-1), in_dPort=random.randint(0,2**16-1),
                       in_len=random.randint(0,2**16-1), in_pktID=random.randint(0,2**10-1), in_flits=random.randint(0,2**5-1), in_tcp_flags=random.randint(0,2**9-1),
                       in_pkt_flags=random.randint(0,2**3-1), in_pkt_queue_id=random.randint(0,2**32-2), in_hash=random.randint(0,2**32-1), in_padding=random.randint(0,2**45-1),
                       in_meta_valid=random.randint(0,1), out_meta_ready=random.randint(0,1), nb_fallback_queues=random.randint(0,2**32-1), enable_rr=random.randint(0,1))
            
            await FallingEdge(dut.clk)
            compare_values(dut, model)

            # Test with pkt_queue_id == '1 and nb_fallback_queues != 0
            set_inputs(dut, model, in_prot=random.randint(0,2**8-1), in_sIP=random.randint(0,2**32-1), in_dIP=random.randint(0,2**32-1), in_sPort=random.randint(0,2**16-1), in_dPort=random.randint(0,2**16-1),
                       in_len=random.randint(0,2**16-1), in_pktID=random.randint(0,2**10-1), in_flits=random.randint(0,2**5-1), in_tcp_flags=random.randint(0,2**9-1),
                       in_pkt_flags=random.randint(0,2**3-1), in_pkt_queue_id=2**32-1, in_hash=random.randint(0,2**32-1), in_padding=random.randint(0,2**45-1),
                       in_meta_valid=random.randint(0,1), out_meta_ready=random.randint(0,1), nb_fallback_queues=random.randint(1,2**32-1), enable_rr=random.randint(0,1))
            
            await FallingEdge(dut.clk)
            compare_values(dut, model)

            # Test with pkt_queue_id == '1 and nb_fallback_queues == 0
            set_inputs(dut, model, in_prot=random.randint(0,2**8-1), in_sIP=random.randint(0,2**32-1), in_dIP=random.randint(0,2**32-1), in_sPort=random.randint(0,2**16-1), in_dPort=random.randint(0,2**16-1),
                       in_len=random.randint(0,2**16-1), in_pktID=random.randint(0,2**10-1), in_flits=random.randint(0,2**5-1), in_tcp_flags=random.randint(0,2**9-1),
                       in_pkt_flags=random.randint(0,2**3-1), in_pkt_queue_id=2**32-1, in_hash=random.randint(0,2**32-1), in_padding=random.randint(0,2**45-1),
                       in_meta_valid=random.randint(0,1), out_meta_ready=random.randint(0,1), nb_fallback_queues=0, enable_rr=random.randint(0,1))
            
            await FallingEdge(dut.clk)
            compare_values(dut, model)

            # Full random test
            set_inputs(dut, model, in_prot=random.randint(0,2**8-1), in_sIP=random.randint(0,2**32-1), in_dIP=random.randint(0,2**32-1), in_sPort=random.randint(0,2**16-1), in_dPort=random.randint(0,2**16-1),
                       in_len=random.randint(0,2**16-1), in_pktID=random.randint(0,2**10-1), in_flits=random.randint(0,2**5-1), in_tcp_flags=random.randint(0,2**9-1),
                       in_pkt_flags=random.randint(0,2**3-1), in_pkt_queue_id=random.randint(0,2**32-1), in_hash=random.randint(0,2**32-1), in_padding=random.randint(0,2**45-1),
                       in_meta_valid=random.randint(0,1), out_meta_ready=random.randint(0,1), nb_fallback_queues=random.randint(0,2**32-1), enable_rr=random.randint(0,1))
            
            await FallingEdge(dut.clk)
            compare_values(dut, model)

