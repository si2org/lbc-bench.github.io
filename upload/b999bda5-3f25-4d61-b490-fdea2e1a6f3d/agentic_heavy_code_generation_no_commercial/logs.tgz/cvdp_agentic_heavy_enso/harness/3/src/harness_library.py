import cocotb
from cocotb.triggers import FallingEdge, RisingEdge, Timer
from collections import deque

async def dut_init(dut):
    # iterate all the input signals and initialize with 0
    for signal in dut:
        try:
            signal.value = 0
        except Exception:
            pass

class flow_director:
    def __init__(self):
        self.reset()

    def reset(self):
        self.pkt_flags      = 0
        self.in_meta_ready  = 0
        self.out_meta_valid = 0
        self.prot           = 0
        self.sIP            = 0
        self.dIP            = 0
        self.sPort          = 0
        self.dPort          = 0
        self.len            = 0
        self.pktID          = 0
        self.flits          = 0
        self.tcp_flags      = 0
        self.pkt_queue_id   = 0
        self.hash           = 0
        self.padding        = 0

        self.next_rr_queue  = 0
    
    def update(self, prot, sIP, dIP, sPort, dPort, len, pktID, flits, tcp_flags, pkt_flags, pkt_queue_id, hash, padding, out_meta_ready, nb_fallback_qs, en_rr, in_meta_valid):
        self.prot           = prot
        self.sIP            = sIP
        self.dIP            = dIP
        self.sPort          = sPort
        self.dPort          = dPort
        self.len            = len
        self.pktID          = pktID
        self.flits          = flits
        self.tcp_flags      = tcp_flags
        self.hash           = hash
        self.padding        = padding
        self.in_meta_ready  = out_meta_ready
        self.out_meta_valid = in_meta_valid
        self.pkt_queue_id   = pkt_queue_id

        self.pkt_flags = 2

        fallback_q_mask = nb_fallback_qs - 1

        if en_rr == 1:
            self.next_rr_queue = (self.next_rr_queue + 1) & fallback_q_mask

        if pkt_queue_id == (2**32 - 1):
            if nb_fallback_qs == 0:
                self.pkt_flags = 1
            elif en_rr == 1:
                self.pkt_queue_id = self.next_rr_queue
            else:
                self.pkt_queue_id = hash & fallback_q_mask
