module wrapper(
    input logic clk,
    input logic rst,

    // Input.
    input  logic [7:0]  in_prot,
    input  logic [31:0] in_sIP,
    input  logic [31:0] in_dIP,
    input  logic [15:0] in_sPort,
    input  logic [15:0] in_dPort,
    input  logic [15:0] in_len,
    input  logic [9:0]  in_pktID,
    input  logic [4:0]  in_flits,
    input  logic [8:0]  in_tcp_flags,
    input  logic [2:0]  in_pkt_flags,
    input  logic [31:0] in_pkt_queue_id,
    input  logic [31:0] in_hash,
    input  logic [44:0] in_padding,
    input  logic        in_meta_valid,
    output logic        in_meta_ready,

    // Output.
    output logic [7:0]  out_prot,
    output logic [31:0] out_sIP,
    output logic [31:0] out_dIP,
    output logic [15:0] out_sPort,
    output logic [15:0] out_dPort,
    output logic [15:0] out_len,
    output logic [9:0]  out_pktID,
    output logic [4:0]  out_flits,
    output logic [8:0]  out_tcp_flags,
    output logic [2:0]  out_pkt_flags,
    output logic [31:0] out_pkt_queue_id,
    output logic [31:0] out_hash,
    output logic [44:0] out_padding,
    output logic        out_meta_valid,
    input  logic        out_meta_ready,

    input logic [31:0] nb_fallback_queues,
    input logic enable_rr
);

// Interface signals
metadata_t   in_meta_data;
metadata_t   out_meta_data;

always_comb begin
    in_meta_data.prot          = in_prot;
    in_meta_data.tuple.sIP     = in_sIP;
    in_meta_data.tuple.dIP     = in_dIP;
    in_meta_data.tuple.sPort   = in_sPort;
    in_meta_data.tuple.dPort   = in_dPort;
    in_meta_data.len           = in_len;
    in_meta_data.pktID         = in_pktID;
    in_meta_data.flits         = in_flits;
    in_meta_data.tcp_flags     = in_tcp_flags;
    in_meta_data.pkt_flags     = in_pkt_flags;
    in_meta_data.pkt_queue_id  = in_pkt_queue_id;
    in_meta_data.hash          = in_hash;
    in_meta_data.padding       = in_padding;

    out_prot         = out_meta_data.prot;
    out_sIP          = out_meta_data.tuple.sIP;
    out_dIP          = out_meta_data.tuple.dIP;
    out_sPort        = out_meta_data.tuple.sPort;
    out_dPort        = out_meta_data.tuple.dPort;
    out_len          = out_meta_data.len;
    out_pktID        = out_meta_data.pktID;
    out_flits        = out_meta_data.flits;
    out_tcp_flags    = out_meta_data.tcp_flags;
    out_pkt_flags    = out_meta_data.pkt_flags;
    out_pkt_queue_id = out_meta_data.pkt_queue_id;
    out_hash         = out_meta_data.hash;
    out_padding      = out_meta_data.padding;
end

flow_director uu_flow_director(
    .clk               (clk               ),
    .rst               (rst               ),
    .in_meta_data      (in_meta_data      ),
    .in_meta_valid     (in_meta_valid     ),
    .in_meta_ready     (in_meta_ready     ),
    .out_meta_data     (out_meta_data     ),
    .out_meta_valid    (out_meta_valid    ),
    .out_meta_ready    (out_meta_ready    ),
    .nb_fallback_queues(nb_fallback_queues),
    .enable_rr         (enable_rr         )
);

endmodule : wrapper
