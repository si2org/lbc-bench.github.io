module wrapper(
    input  logic        clk,
    input  logic        rst,
    input  logic        stall,
    input  logic [31:0] initval,
    input  logic [31:0] sIP,
    input  logic [31:0] dIP,
    input  logic [15:0] sPort,
    input  logic [15:0] dPort,
    input  logic        tuple_in_valid,
    output logic        hashed_valid,
    output logic [31:0] hashed
);

// Interface signals
tuple_t tuple_in;

always_comb begin
    tuple_in.sIP   = sIP;
    tuple_in.dIP   = dIP;
    tuple_in.sPort = sPort;
    tuple_in.dPort = dPort;
end

hash_func uu_hash_func(
    .clk           (clk           ),
    .rst           (rst           ),
    .stall         (stall         ),
    .tuple_in      (tuple_in      ),
    .initval       (initval       ),
    .tuple_in_valid(tuple_in_valid),
    .hashed        (hashed        ),
    .hashed_valid  (hashed_valid  )
);

endmodule : wrapper
