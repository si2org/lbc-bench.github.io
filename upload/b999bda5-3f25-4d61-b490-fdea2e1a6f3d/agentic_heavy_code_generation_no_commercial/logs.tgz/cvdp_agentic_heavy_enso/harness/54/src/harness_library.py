import cocotb
from cocotb.triggers import FallingEdge, RisingEdge, Timer
from collections import deque

async def dut_init(dut):
    # iterate all the input signals and initialize with 0
    for signal in dut:
        try:
            signal.value = 0
        except Exception:
            pass

class hash_func:
    def __init__(self):
        self.reset()

    def mix_with_breakpoint(self, b: int, a: int, bp: int, width: int = 32) -> int:
        """
        Compute (b ^ a) - concat(a[bp-1:0], a[width-1:bp]) with wrap-around to `width` bits.

        Args:
        b:      integer (e.g. b5), will be masked to `width` bits
        a:      integer (e.g. a5), will be masked to `width` bits
        bp:     breakpoint index (0 < bp < width)
        width:  total bit-width (default 32)

        Returns:
        result of the SV expression, as an int in [0..2**width-1].
        """
        # masks
        ALL  = (1 << width) - 1
        LOW  = (1 << bp)    - 1

        # enforce width
        b &= ALL
        a &= ALL

        # split a into low[bp-1:0] and high[width-1:bp]
        low  = a & LOW
        high = a >> bp

        # concat back: low in the top bits, high in the bottom
        concat = ((low << (width - bp)) | high) & ALL

        # compute and wrap-around
        return ((b ^ a) - concat) & ALL        

    def reset(self):
        # Outputs
        self.hashed_valid = 0
        self.hashed = 0
        
        # Internal regs
        self.a  = 0
        self.a1 = 0
        self.a2 = 0
        self.a3 = 0
        self.a4 = 0
        self.a5 = 0

        self.b  = 0
        self.b1 = 0
        self.b2 = 0
        self.b3 = 0
        self.b4 = 0
        self.b5 = 0
        self.b6 = 0

        self.c  = 0
        self.c1 = 0
        self.c2 = 0
        self.c3 = 0
        self.c4 = 0
        self.c5 = 0
        self.c6 = 0

        self.valid  = 0
        self.valid1 = 0
        self.valid2 = 0
        self.valid3 = 0
        self.valid4 = 0
        self.valid5 = 0
        self.valid6 = 0
    
    def update(self, stall, initval, sIP, dIP, sPort, dPort, tuple_in_valid):
        key = (sIP << 64) | (sPort << 48) | (dIP << 16) | dPort

        if not stall:
            # Valid regs
            self.hashed_valid = self.valid6
            self.valid6 = self.valid5
            self.valid5 = self.valid4
            self.valid4 = self.valid3
            self.valid3 = self.valid2
            self.valid2 = self.valid1
            self.valid1 = self.valid
            self.valid  = tuple_in_valid

            # Data processing
            #self.hashed = (self.c6 ^ self.b6) - {self.b6[7:0],self.b6[31:8]}
            self.hashed = self.mix_with_breakpoint(self.c6, self.b6, 8)

            self.c6 = self.c5
            self.b6 = self.mix_with_breakpoint(self.b5, self.a5, 18)
            #self.b6 = (self.b5 ^ self.a5) - {self.a5[17:0],self.a5[31:18]}

            self.c5 = self.c4
            self.b5 = self.b4
            self.a5 = self.mix_with_breakpoint(self.a4, self.c4, 28)
            #self.a5 = (self.a4 ^ self.c4) - {self.c4[27:0],self.c4[31:28]}

            #self.c4 = (self.c3 ^ self.b3) - {self.b3[15:0],self.b3[31:16]}
            self.c4 = self.mix_with_breakpoint(self.c3, self.b3, 16)
            self.b4 = self.b3
            self.a4 = self.a3
            
            self.c3 = self.c2
            self.b3 = self.mix_with_breakpoint(self.b2, self.a2, 7)
            self.a3 = self.a2
            #self.b3 = (self.b2 ^ self.a2) - {self.a2[6:0],self.a2[31:7]}

            self.c2 = self.c1
            self.b2 = self.b1
            self.a2 = self.mix_with_breakpoint(self.a1, self.c1, 21)
            #self.a2 = (self.a1 ^ self.c1) - {self.c1[20:0],self.c1[31:21]}
            
            #self.c1 = (self.c ^ self.b) - {self.b[17:0],self.b[31:18]}
            self.c1 = self.mix_with_breakpoint(self.c, self.b, 18)
            self.b1 = self.b
            self.a1 = self.a

            key_95_64 = (key >> 64) & 0xFFFFFFFF
            key_63_32 = (key >> 32) & 0xFFFFFFFF
            key_31_00 = key & 0xFFFFFFFF
            self.c = (0xdeadbefb + key_95_64 + initval) & 0xFFFFFFFF
            self.b = (0xdeadbefb + key_63_32 + initval) & 0xFFFFFFFF
            self.a = (0xdeadbefb + key_31_00 + initval) & 0xFFFFFFFF
