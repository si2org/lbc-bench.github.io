import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer, FallingEdge
import harness_library as hrs_lb
import random

def set_inputs(dut, model, stall=0, initval=0, sIP=0, dIP=0, sPort=0, dPort=0, tuple_in_valid=0, reset=0):
    dut.stall.value = stall
    dut.initval.value = initval
    dut.sIP.value = sIP
    dut.dIP.value = dIP
    dut.sPort.value = sPort
    dut.dPort.value = dPort
    dut.tuple_in_valid.value = tuple_in_valid

    if reset:
        model.reset()
    else:
        model.update(stall, initval, sIP, dIP, sPort, dPort, tuple_in_valid)

def compare_values(dut, model, debug=0):
    dut_hashed_valid = int(dut.hashed_valid.value)
    dut_hashed = int(dut.hashed.value)
    
    model_hashed_valid = model.hashed_valid
    model_hashed = model.hashed

    assert dut_hashed_valid == model_hashed_valid, f"[ERROR] DUT hashed_valid does not match model hashed_valid: {hex(dut_hashed_valid)} != {hex(model_hashed_valid)}"
    assert dut_hashed       == model_hashed,       f"[ERROR] DUT hashed does not match model hashed: {hex(dut_hashed)} != {hex(model_hashed)}"
    

@cocotb.test()
async def test_hash_func(dut):
    """Test the hash_func module with edge cases and random data."""
    cocotb.start_soon(Clock(dut.clk, 10, unit='ns').start())

    model = hrs_lb.hash_func()

    resets = 4
    runs = 10000
    
    await hrs_lb.dut_init(dut)

    for i in range(resets):
        # Reset DUT
        # Set all inputs to 0
        set_inputs(dut, model, reset=1)
        await FallingEdge(dut.clk)
        dut.rst.value = 1
        await FallingEdge(dut.clk)
        dut.rst.value = 0

        compare_values(dut, model)

        for j in range(runs):
            if j == 0:
                print(f'\n------ Reset {i} ------')
            
            # Full random test
            set_inputs(dut, model, stall=random.randint(0, 1), initval=random.randint(0, 2**32-1), sIP=random.randint(0, 2**32-1),
                       dIP=random.randint(0, 2**32-1), sPort=random.randint(0, 2**16-1), dPort=random.randint(0, 2**16-1),
                       tuple_in_valid=random.randint(0, 1))
            
            await FallingEdge(dut.clk)
            compare_values(dut, model)

