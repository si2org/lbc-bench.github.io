import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer, FallingEdge
import harness_library as hrs_lb
import random

def set_inputs(dut, model, in_pkt_valid=0, out_pkt_ready=0, enable=0, numerator=0, denominator=0, conf_rl_valid=0, reset=0):
    if reset:
        in_pkt_sop   = 0
        in_pkt_eop   = 0
        in_pkt_empty = 0
        pad2         = 0
        config_id    = 0
        signal       = 0
        pad1         = 0
        in_pkt_data  = 0
    else:
        in_pkt_sop   = random.randint(0, 1)
        in_pkt_eop   = random.randint(0, 1)
        in_pkt_empty = random.randint(0, 2**6-1)
        pad2         = random.randint(0, 2**31-1)
        config_id    = random.randint(0, 2**64-1)
        signal       = random.randint(0, 2**64-1)
        pad1         = random.randint(0, 2**320-1)
        in_pkt_data  = random.randint(0, 2**512-1)

    dut.in_pkt_data.value   = in_pkt_data
    dut.in_pkt_valid.value  = in_pkt_valid
    dut.in_pkt_sop.value    = in_pkt_sop
    dut.in_pkt_eop.value    = in_pkt_eop
    dut.in_pkt_empty.value  = in_pkt_empty
    dut.out_pkt_ready.value = out_pkt_ready
    dut.pad1.value          = pad1
    dut.enable.value        = enable
    dut.pad2.value          = pad2
    dut.numerator.value     = numerator
    dut.denominator.value   = denominator
    dut.config_id.value     = config_id
    dut.signal.value        = signal
    dut.conf_rl_valid.value = conf_rl_valid

    model.update(in_pkt_data, in_pkt_valid, in_pkt_sop, in_pkt_eop, in_pkt_empty, out_pkt_ready,
                 pad1, enable, pad2, numerator, denominator, config_id, signal, conf_rl_valid)

def compare_values(dut, model):

    dut_in_pkt_ready  = int(dut.in_pkt_ready.value)
    dut_out_pkt_data  = int(dut.out_pkt_data.value)
    dut_out_pkt_valid = int(dut.out_pkt_valid.value)
    dut_out_pkt_sop   = int(dut.out_pkt_sop.value)
    dut_out_pkt_eop   = int(dut.out_pkt_eop.value)
    dut_out_pkt_empty = int(dut.out_pkt_empty.value)
    dut_conf_rl_ready = int(dut.conf_rl_ready.value)

    model_in_pkt_ready  = model.in_pkt_ready
    model_out_pkt_data  = model.out_pkt_data
    model_out_pkt_valid = model.out_pkt_valid
    model_out_pkt_sop   = model.out_pkt_sop
    model_out_pkt_eop   = model.out_pkt_eop
    model_out_pkt_empty = model.out_pkt_empty
    model_conf_rl_ready = model.conf_rl_ready

    assert dut_in_pkt_ready  == model_in_pkt_ready,  f"[ERROR] DUT in_pkt_ready does not match model in_pkt_ready: {hex(dut_in_pkt_ready)} != {hex(model_in_pkt_ready)}"
    assert dut_out_pkt_data  == model_out_pkt_data,  f"[ERROR] DUT out_pkt_data does not match model out_pkt_data: {hex(dut_out_pkt_data)} != {hex(model_out_pkt_data)}"
    assert dut_out_pkt_valid == model_out_pkt_valid, f"[ERROR] DUT out_pkt_valid does not match model out_pkt_valid: {hex(dut_out_pkt_valid)} != {hex(model_out_pkt_valid)}"
    assert dut_out_pkt_sop   == model_out_pkt_sop,   f"[ERROR] DUT out_pkt_sop does not match model out_pkt_sop: {hex(dut_out_pkt_sop)} != {hex(model_out_pkt_sop)}"
    assert dut_out_pkt_eop   == model_out_pkt_eop,   f"[ERROR] DUT out_pkt_eop does not match model out_pkt_eop: {hex(dut_out_pkt_eop)} != {hex(model_out_pkt_eop)}"
    assert dut_out_pkt_empty == model_out_pkt_empty, f"[ERROR] DUT out_pkt_empty does not match model out_pkt_empty: {hex(dut_out_pkt_empty)} != {hex(model_out_pkt_empty)}"
    assert dut_conf_rl_ready == model_conf_rl_ready, f"[ERROR] DUT conf_rl_ready does not match model conf_rl_ready: {hex(dut_conf_rl_ready)} != {hex(model_conf_rl_ready)}"

@cocotb.test()
async def test_rate_limiter(dut):
    """Test the rate_limiter module with edge cases and random data."""
    cocotb.start_soon(Clock(dut.clk, 10, unit='ns').start())

    model = hrs_lb.rate_limiter()

    resets = 40
    runs = 300
    
    await hrs_lb.dut_init(dut)

    for i in range(resets):
        # Reset DUT
        # Set all inputs to 0
        model.reset()
        set_inputs(dut, model, reset=1)
        await FallingEdge(dut.clk)
        dut.rst.value = 1
        await FallingEdge(dut.clk)
        dut.rst.value = 0
        await FallingEdge(dut.clk)

        compare_values(dut, model)

        if i%5 == 0:
            print(f'\n------ Reset {i} ------')
        for j in range(runs):
            
            # Set conf_rl_valid and enable to a random value and keep them for half of the cycles
            if j == 0 or j >= runs/2:
                conf_rl_valid = random.randint(0,1)
                enable        = random.randint(0,1)

            # Keep numerator and denominator low
            set_inputs(dut, model, in_pkt_valid=random.randint(0, 1), out_pkt_ready=random.randint(0, 1), enable=enable,
                       numerator=random.randint(0, 10), denominator=random.randint(0, 10), conf_rl_valid=conf_rl_valid)
            await FallingEdge(dut.clk)
            compare_values(dut, model)

            