module wrapper (
    input logic clk,
    input logic rst,
    input  logic [511:0] in_pkt_data,
    input  logic         in_pkt_valid,
    input  logic         in_pkt_sop,
    input  logic         in_pkt_eop,
    input  logic [5:0]   in_pkt_empty,
    input  logic         out_pkt_ready,
    input  logic [319:0] pad1,
    input  logic         enable,
    input  logic [30:0]  pad2,
    input  logic [15:0]  numerator,
    input  logic [15:0]  denominator,
    input  logic [63:0]  config_id,
    input  logic [63:0]  signal,
    input  logic         conf_rl_valid,
    output logic         in_pkt_ready,
    output logic [511:0] out_pkt_data,
    output logic         out_pkt_valid,
    output logic         out_pkt_sop,
    output logic         out_pkt_eop,
    output logic [5:0]   out_pkt_empty,
    output logic         conf_rl_ready
);

// Interface signals
rate_limit_config_t conf_rl_data;

always_comb begin
    conf_rl_data.pad1        = pad1;
    conf_rl_data.enable      = enable;
    conf_rl_data.pad2        = pad2;
    conf_rl_data.numerator   = numerator;
    conf_rl_data.denominator = denominator;
    conf_rl_data.config_id   = config_id;
    conf_rl_data.signal      = signal;
end

rate_limiter uu_rate_limiter (
    .clk          (clk          ),
    .rst          (rst          ),
    .in_pkt_data  (in_pkt_data  ),
    .in_pkt_valid (in_pkt_valid ),
    .in_pkt_ready (in_pkt_ready ),
    .in_pkt_sop   (in_pkt_sop   ),
    .in_pkt_eop   (in_pkt_eop   ),
    .in_pkt_empty (in_pkt_empty ),
    .out_pkt_data (out_pkt_data ),
    .out_pkt_valid(out_pkt_valid),
    .out_pkt_ready(out_pkt_ready),
    .out_pkt_sop  (out_pkt_sop  ),
    .out_pkt_eop  (out_pkt_eop  ),
    .out_pkt_empty(out_pkt_empty),
    .conf_rl_data (conf_rl_data ),
    .conf_rl_valid(conf_rl_valid),
    .conf_rl_ready(conf_rl_ready)
);

endmodule : wrapper
