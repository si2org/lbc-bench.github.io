import cocotb
from cocotb.triggers import FallingEdge, RisingEdge, Timer
from collections import deque

async def dut_init(dut):
    # iterate all the input signals and initialize with 0
    for signal in dut:
        if(signal._name == "conf_rl_ready"):
            signal.value = 1
        elif signal._type == "GPI_NET":
            signal.value = 0

class rate_limiter:
    def __init__(self):
        self.reset()
    
    def reset(self):
        # Interface signals
        self.in_pkt_ready = 0
        self.out_pkt_data = 0
        self.out_pkt_valid = 0
        self.out_pkt_sop = 0
        self.out_pkt_eop = 0
        self.out_pkt_empty = 0
        self.conf_rl_ready = 1

        # Intenal signals
        self.rate_limit_enabled = 0
        self.numerator = 0
        self.denominator = 0
        self.period_counter = 0
    
    def extract_bits(self, value, high, low):
        """Extract bits from 'high' to 'low' (inclusive) from a given integer."""
        width = high - low + 1
        mask = (1 << width) - 1
        return (value >> low) & mask

    def update(self, in_pkt_data, in_pkt_valid, in_pkt_sop, in_pkt_eop, in_pkt_empty, out_pkt_ready, pad1, enable, pad2, numerator, denominator, config_id, signal, conf_rl_valid):
        
        self.conf_rl_ready = 1
        self.out_pkt_data = in_pkt_data
        self.out_pkt_sop = in_pkt_sop
        self.out_pkt_eop = in_pkt_eop
        self.out_pkt_empty = in_pkt_empty

        if self.rate_limit_enabled:
            self.period_counter = self.period_counter + 1
            if self.period_counter >= self.denominator:
                self.period_counter = 0

        if conf_rl_valid:
            if enable:
                self.numerator = numerator
                self.denominator = denominator
                if not self.rate_limit_enabled:
                    self.period_counter = 0
            self.rate_limit_enabled = enable
        
        pause = 0

        if self.rate_limit_enabled:
            if self.period_counter >= self.numerator:
                pause = 1

        self.in_pkt_ready = out_pkt_ready & (~pause);
        self.out_pkt_valid = in_pkt_valid & (~pause);

