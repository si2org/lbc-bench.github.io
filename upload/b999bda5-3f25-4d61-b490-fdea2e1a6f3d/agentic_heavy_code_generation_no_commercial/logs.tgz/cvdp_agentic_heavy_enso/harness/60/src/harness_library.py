import cocotb
from cocotb.triggers import FallingEdge, RisingEdge, Timer
from collections import deque

async def dut_init(dut):
    # iterate all the input signals and initialize with 0
    for signal in dut:
        try:
            signal.value = 0
        except Exception:
            pass

class input_comp:
    def __init__(self):
        self.reset()
        self.pkt_buffer_address = 0
        self.pkt_buffer_writedata_sop = 0
        self.pkt_buffer_writedata_eop = 0
        self.pkt_buffer_writedata_empty = 0
        self.pkt_buffer_writedata_data = 0
        self.pkt_data = 0
        self.pkt_empty = 0
        self.pkt_sop = 0
        self.pkt_eop = 0
        self.pkt_valid = 0
        self.meta_valid = 0
        self.emptylist_out_ready = 0
        self.pkt_buffer_address_r = 0
        self.pkt_buffer_write_r = 0
        self.pkt_buffer_writedata_sop_r = 0
        self.pkt_buffer_writedata_eop_r = 0
        self.pkt_buffer_writedata_empty_r = 0
        self.pkt_buffer_writedata_data_r = 0
        self.meta_data_pktID = 0
        self.meta_data_flits = 0

    def reset(self):
        # Outputs
        self.pkt_buffer_write = 0

        # Internal
        self.drop_pkt = 0
        self.flits = 0
    
    def update(self, eth_sop, eth_eop, eth_valid, emptylist_out_valid, eth_data, eth_empty, emptylist_out_data, sequential=1):
        self.emptylist_out_ready = eth_valid & eth_sop

        if sequential:
            if eth_valid and eth_sop:
                self.pkt_data = eth_data
            self.pkt_buffer_address         = self.pkt_buffer_address_r
            self.pkt_buffer_write           = self.pkt_buffer_write_r
            self.pkt_buffer_writedata_sop   = self.pkt_buffer_writedata_sop_r
            self.pkt_buffer_writedata_eop   = self.pkt_buffer_writedata_eop_r
            self.pkt_buffer_writedata_empty = self.pkt_buffer_writedata_empty_r
            self.pkt_buffer_writedata_data  = self.pkt_buffer_writedata_data_r

            self.meta_data_pktID = 0
            self.meta_data_flits = 0

            self.pkt_buffer_write_r = 0
            self.pkt_buffer_writedata_sop_r = eth_sop
            self.pkt_buffer_writedata_eop_r = eth_eop
            self.pkt_buffer_writedata_empty_r = eth_empty
            self.pkt_buffer_writedata_data_r = eth_data
            self.pkt_valid  = 0
            self.meta_valid = 0
            self.pkt_sop = 0
            self.pkt_eop = 0

            if eth_valid:
                if eth_eop & (not self.drop_pkt) & (not (eth_sop and (not emptylist_out_valid))):
                    self.pkt_sop   = 1
                    self.pkt_eop   = 1
                    self.pkt_valid = 1

                    if eth_sop and emptylist_out_valid:
                        self.meta_data_pktID = emptylist_out_data
                    else:
                        self.meta_data_pktID = self.pkt_id
                    
                    if not eth_sop:
                        self.meta_data_flits = self.flits + 1
                    elif emptylist_out_valid:
                        self.meta_data_flits = 1
                    else:
                        self.meta_data_flits = self.flits
                    self.meta_valid      = 1
                
                if eth_sop == 0:
                    if self.pkt_buffer_address_r < 2**15-1:
                        self.pkt_buffer_address_r = self.pkt_buffer_address_r + 1
                    else:
                        self.pkt_buffer_address_r = 0
                    if self.drop_pkt:
                        self.pkt_buffer_write_r = 0
                    else:
                        self.pkt_buffer_write_r = 1
                    
                    if self.flits < 2**5-1:
                        self.flits = self.flits + 1
                    else:
                        self.flits = 0
                elif emptylist_out_valid:
                    self.pkt_buffer_address_r = emptylist_out_data << 5
                    self.pkt_buffer_write_r = 1

                    self.drop_pkt = 0
                    self.pkt_id = emptylist_out_data
                    self.flits = 1
                else:
                    self.drop_pkt = 1





