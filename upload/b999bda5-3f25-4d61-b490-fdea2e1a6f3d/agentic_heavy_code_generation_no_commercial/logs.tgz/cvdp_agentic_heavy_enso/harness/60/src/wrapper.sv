module wrapper(
    input  logic                  clk,
    input  logic                  rst,
    input  logic                  eth_sop,
    input  logic                  eth_eop,
    input  logic                  eth_valid,
    input  logic                  emptylist_out_valid,
    input  logic                  meta_ready,
    input  logic                  pkt_ready,
    input  logic [511:0]          eth_data,
    input  logic [5:0]            eth_empty,
    input  logic [PKT_AWIDTH-1:0] emptylist_out_data,

    output logic [PKTBUF_AWIDTH-1:0] pkt_buffer_address,
    output logic                     pkt_buffer_write,
    output logic                     pkt_buffer_writedata_sop,
    output logic                     pkt_buffer_writedata_eop,
    output logic [5:0]               pkt_buffer_writedata_empty,
    output logic [511:0]             pkt_buffer_writedata_data,
    output logic                     emptylist_out_ready,
    output logic                     pkt_sop,
    output logic                     pkt_eop,
    output logic                     pkt_valid,
    output logic [511:0]             pkt_data,
    output logic [5:0]               pkt_empty,
    output logic                     meta_valid,
    output logic [7:0]               meta_data_prot,
    output logic [31:0]              meta_data_sIP, 
    output logic [31:0]              meta_data_dIP, 
    output logic [15:0]              meta_data_sPort, 
    output logic [15:0]              meta_data_dPort, 
    output logic [15:0]              meta_data_len,  // Payload length.
    output logic [PKT_AWIDTH-1:0]    meta_data_pktID,
    output logic [4:0]               meta_data_flits,  // Total number of flits.
    output logic [8:0]               meta_data_tcp_flags,
    output logic [2:0]               meta_data_pkt_flags,
    output logic [31:0]              meta_data_pkt_queue_id,
    output logic [31:0]              meta_data_hash,
    output logic [PADDING_WIDTH-1:0] meta_data_padding
);

// Interface signals
flit_t     pkt_buffer_writedata;
metadata_t meta_data;

always_comb begin
    pkt_buffer_writedata_sop   = pkt_buffer_writedata.sop;
    pkt_buffer_writedata_eop   = pkt_buffer_writedata.eop;
    pkt_buffer_writedata_empty = pkt_buffer_writedata.empty;
    pkt_buffer_writedata_data  = pkt_buffer_writedata.data;
    meta_data_prot             = meta_data.prot;
    meta_data_sIP              = meta_data.tuple.sIP;
    meta_data_dIP              = meta_data.tuple.dIP;
    meta_data_sPort            = meta_data.tuple.sPort;
    meta_data_dPort            = meta_data.tuple.dPort;
    meta_data_len              = meta_data.len;
    meta_data_pktID            = meta_data.pktID;
    meta_data_flits            = meta_data.flits;
    meta_data_tcp_flags        = meta_data.tcp_flags;
    meta_data_pkt_flags        = meta_data.pkt_flags;
    meta_data_pkt_queue_id     = meta_data.pkt_queue_id;
    meta_data_hash             = meta_data.hash;
    meta_data_padding          = meta_data.padding;
end

input_comp uu_input_comp(
    .clk                 (clk                 ),
    .rst                 (rst                 ),
    .eth_sop             (eth_sop             ),
    .eth_eop             (eth_eop             ),
    .eth_data            (eth_data            ),
    .eth_empty           (eth_empty           ),
    .eth_valid           (eth_valid           ),
    .pkt_buffer_address  (pkt_buffer_address  ),
    .pkt_buffer_write    (pkt_buffer_write    ),
    .pkt_buffer_writedata(pkt_buffer_writedata),
    .emptylist_out_data  (emptylist_out_data  ),
    .emptylist_out_valid (emptylist_out_valid ),
    .emptylist_out_ready (emptylist_out_ready ),
    .pkt_sop             (pkt_sop             ),
    .pkt_eop             (pkt_eop             ),
    .pkt_valid           (pkt_valid           ),
    .pkt_data            (pkt_data            ),
    .pkt_empty           (pkt_empty           ),
    .pkt_ready           (pkt_ready           ),
    .meta_valid          (meta_valid          ),
    .meta_data           (meta_data           ),
    .meta_ready          (meta_ready          )
);

endmodule : wrapper
