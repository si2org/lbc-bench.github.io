import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer, FallingEdge
import harness_library as hrs_lb
import random

def set_inputs(dut, model, eth_sop=0, eth_eop=0, eth_valid=0, emptylist_out_valid=0, meta_ready=0, pkt_ready=0, eth_data=0, eth_empty=0, emptylist_out_data=0, sequential=1):
    dut.eth_sop.value = eth_sop
    dut.eth_eop.value = eth_eop
    dut.eth_valid.value = eth_valid
    dut.emptylist_out_valid.value = emptylist_out_valid
    dut.meta_ready.value = meta_ready
    dut.pkt_ready.value = pkt_ready
    dut.eth_data.value = eth_data
    dut.eth_empty.value = eth_empty
    dut.emptylist_out_data.value = emptylist_out_data

    model.update(eth_sop, eth_eop, eth_valid, emptylist_out_valid, eth_data, eth_empty, emptylist_out_data, sequential)

def compare_values(dut, model):
    dut_pkt_buffer_address = int(dut.pkt_buffer_address.value)
    dut_pkt_buffer_write = int(dut.pkt_buffer_write.value)
    dut_pkt_buffer_writedata_sop = int(dut.pkt_buffer_writedata_sop.value)
    dut_pkt_buffer_writedata_eop = int(dut.pkt_buffer_writedata_eop.value)
    dut_pkt_buffer_writedata_empty = int(dut.pkt_buffer_writedata_empty.value)
    dut_pkt_buffer_writedata_data = int(dut.pkt_buffer_writedata_data.value)
    dut_emptylist_out_ready = int(dut.emptylist_out_ready.value)
    dut_pkt_sop = int(dut.pkt_sop.value)
    dut_pkt_eop = int(dut.pkt_eop.value)
    dut_pkt_valid = int(dut.pkt_valid.value)
    dut_pkt_data = int(dut.pkt_data.value)
    dut_pkt_empty = int(dut.pkt_empty.value)
    dut_meta_valid = int(dut.meta_valid.value)
    dut_meta_data_prot = int(dut.meta_data_prot.value)
    dut_meta_data_sIP = int(dut.meta_data_sIP.value)
    dut_meta_data_dIP = int(dut.meta_data_dIP.value)
    dut_meta_data_sPort = int(dut.meta_data_sPort.value)
    dut_meta_data_dPort = int(dut.meta_data_dPort.value)
    dut_meta_data_len = int(dut.meta_data_len.value)
    dut_meta_data_pktID = int(dut.meta_data_pktID.value)
    dut_meta_data_flits = int(dut.meta_data_flits.value)
    dut_meta_data_tcp_flags = int(dut.meta_data_tcp_flags.value)
    dut_meta_data_pkt_flags = int(dut.meta_data_pkt_flags.value)
    dut_meta_data_pkt_queue_id = int(dut.meta_data_pkt_queue_id.value)
    dut_meta_data_hash = int(dut.meta_data_hash.value)
    dut_meta_data_padding = int(dut.meta_data_padding.value)

    assert dut_pkt_buffer_address == model.pkt_buffer_address, f"[ERROR] DUT pkt_buffer_address does not match model pkt_buffer_address: {hex(dut_pkt_buffer_address)} != {hex(model.pkt_buffer_address)}"
    assert dut_pkt_buffer_writedata_sop == model.pkt_buffer_writedata_sop, f"[ERROR] DUT pkt_buffer_writedata.sop does not match model pkt_buffer_writedata.sop: {hex(dut_pkt_buffer_writedata_sop)} != {hex(model.pkt_buffer_writedata_sop)}"
    assert dut_pkt_buffer_writedata_eop == model.pkt_buffer_writedata_eop, f"[ERROR] DUT pkt_buffer_writedata.eop does not match model pkt_buffer_writedata.eop: {hex(dut_pkt_buffer_writedata_eop)} != {hex(model.pkt_buffer_writedata_eop)}"
    assert dut_pkt_buffer_writedata_empty == model.pkt_buffer_writedata_empty, f"[ERROR] DUT pkt_buffer_writedata.empty does not match model pkt_buffer_writedata.empty: {hex(dut_pkt_buffer_writedata_empty)} != {hex(model.pkt_buffer_writedata_empty)}"
    assert dut_pkt_buffer_writedata_data == model.pkt_buffer_writedata_data, f"[ERROR] DUT pkt_buffer_writedata.data does not match model pkt_buffer_writedata.data: {hex(dut_pkt_buffer_writedata_data)} != {hex(model.pkt_buffer_writedata_data)}"
    assert dut_emptylist_out_ready == model.emptylist_out_ready, f"[ERROR] DUT emptylist_out_ready does not match model emptylist_out_ready: {hex(dut_emptylist_out_ready)} != {hex(model.emptylist_out_ready)}"
    assert dut_pkt_sop == model.pkt_sop, f"[ERROR] DUT pkt_sop does not match model pkt_sop: {hex(dut_pkt_sop)} != {hex(model.pkt_sop)}"
    assert dut_pkt_eop == model.pkt_eop, f"[ERROR] DUT pkt_eop does not match model pkt_eop: {hex(dut_pkt_eop)} != {hex(model.pkt_eop)}"
    assert dut_pkt_valid == model.pkt_valid, f"[ERROR] DUT pkt_valid does not match model pkt_valid: {hex(dut_pkt_valid)} != {hex(model.pkt_valid)}"
    assert dut_pkt_data == model.pkt_data, f"[ERROR] DUT pkt_data does not match model pkt_data: {hex(dut_pkt_data)} != {hex(model.pkt_data)}"
    assert dut_pkt_empty == model.pkt_empty, f"[ERROR] DUT pkt_empty does not match model pkt_empty: {hex(dut_pkt_empty)} != {hex(model.pkt_empty)}"
    assert dut_meta_valid == model.meta_valid, f"[ERROR] DUT meta_valid does not match model meta_valid: {hex(dut_meta_valid)} != {hex(model.meta_valid)}"
    assert dut_pkt_buffer_write == model.pkt_buffer_write, f"[ERROR] DUT pkt_buffer_write does not match model pkt_buffer_write: {hex(dut_pkt_buffer_write)} != {hex(model.pkt_buffer_write)}"
    assert dut_meta_data_pktID == model.meta_data_pktID, f"[ERROR] DUT metadata.pktID does not match model metadata.pktID: {hex(dut_meta_data_pktID)} != {hex(model.meta_data_pktID)}"
    assert dut_meta_data_flits == model.meta_data_flits, f"[ERROR] DUT metadata.flits does not match model metadata.flits: {hex(dut_meta_data_flits)} != {hex(model.meta_data_flits)}"

    assert dut_meta_data_prot == 0, f"[ERROR] DUT metadata.prot does not match model metadata.prot: {hex(dut_meta_data_prot)} != {hex(0)}"
    assert dut_meta_data_sIP == 0, f"[ERROR] DUT metadata.sIP does not match model metadata.sIP: {hex(dut_meta_data_sIP)} != {hex(0)}"
    assert dut_meta_data_dIP == 0, f"[ERROR] DUT metadata.dIP does not match model metadata.dIP: {hex(dut_meta_data_dIP)} != {hex(0)}"
    assert dut_meta_data_sPort == 0, f"[ERROR] DUT metadata.sPort does not match model metadata.sPort: {hex(dut_meta_data_sPort)} != {hex(0)}"
    assert dut_meta_data_dPort == 0, f"[ERROR] DUT metadata.dPort does not match model metadata.dPort: {hex(dut_meta_data_dPort)} != {hex(0)}"
    assert dut_meta_data_len == 0, f"[ERROR] DUT metadata.len does not match model metadata.len: {hex(dut_meta_data_len)} != {hex(0)}"
    assert dut_meta_data_tcp_flags == 0, f"[ERROR] DUT metadata.tcp_flags does not match model metadata.tcp_flags: {hex(dut_meta_data_tcp_flags)} != {hex(0)}"
    assert dut_meta_data_pkt_flags == 0, f"[ERROR] DUT metadata.pkt_flags does not match model metadata.pkt_flags: {hex(dut_meta_data_pkt_flags)} != {hex(0)}"
    assert dut_meta_data_pkt_queue_id == 0, f"[ERROR] DUT metadata.pkt_queue_id does not match model metadata.pkt_queue_id: {hex(dut_meta_data_pkt_queue_id)} != {hex(0)}"
    assert dut_meta_data_hash == 0, f"[ERROR] DUT metadata.hash does not match model metadata.hash: {hex(dut_meta_data_hash)} != {hex(0)}"
    assert dut_meta_data_padding == 0, f"[ERROR] DUT metadata.padding does not match model metadata.padding: {hex(dut_meta_data_padding)} != {hex(0)}"
    

@cocotb.test()
async def test_input_comp(dut):
    """Test the input_comp module with edge cases and random data."""
    cocotb.start_soon(Clock(dut.clk, 10, unit='ns').start())

    model = hrs_lb.input_comp()

    resets = 4
    runs = 2000
    
    await hrs_lb.dut_init(dut)

    for i in range(resets):
        # Reset DUT
        # Set all inputs to 0
        set_inputs(dut, model)
        model.reset()
        await FallingEdge(dut.clk)
        dut.rst.value = 1
        await FallingEdge(dut.clk)
        dut.rst.value = 0

        # Set inputs to random value and wait less than the next clock, so all combinational operations and none of the sequential is performed.
        set_inputs(dut, model, eth_sop=random.randint(0,1), eth_eop=random.randint(0,1), eth_valid=random.randint(0,1),
                   emptylist_out_valid=random.randint(0,1), meta_ready=random.randint(0,1), pkt_ready=random.randint(0,1),
                   eth_data=random.randint(0,2**512-1), eth_empty=random.randint(0,2**6-1), emptylist_out_data=random.randint(0,2**10-1), sequential=0)
        await Timer(1, unit='ns')
        compare_values(dut, model)

        # Set internal register to a known value
        if i == 0:
            set_inputs(dut, model, eth_sop=1, eth_eop=random.randint(0,1), eth_valid=1,
                       emptylist_out_valid=1, meta_ready=random.randint(0,1), pkt_ready=random.randint(0,1),
                       eth_data=random.randint(0,2**512-1), eth_empty=random.randint(0,2**6-1), emptylist_out_data=0)
            await FallingEdge(dut.clk)
            compare_values(dut, model)

        for j in range(runs):
            if j == 0:
                print(f'\n------ Reset {i} ------')
            
            # Full random test
            set_inputs(dut, model, eth_sop=random.randint(0,1), eth_eop=random.randint(0,1), eth_valid=random.randint(0,1),
                       emptylist_out_valid=random.randint(0,1), meta_ready=random.randint(0,1), pkt_ready=random.randint(0,1),
                       eth_data=random.randint(0,2**512-1), eth_empty=random.randint(0,2**6-1), emptylist_out_data=random.randint(0,2**10-1))
            
            await FallingEdge(dut.clk)
            # Set inputs to random value and wait less than the next clock, so all combinational operations and none of the sequential is performed.
            set_inputs(dut, model, eth_sop=random.randint(0,1), eth_eop=random.randint(0,1), eth_valid=random.randint(0,1),
                       emptylist_out_valid=random.randint(0,1), meta_ready=random.randint(0,1), pkt_ready=random.randint(0,1),
                       eth_data=random.randint(0,2**512-1), eth_empty=random.randint(0,2**6-1), emptylist_out_data=random.randint(0,2**10-1), sequential=0)
            await Timer(1, unit='ns')
            compare_values(dut, model)

