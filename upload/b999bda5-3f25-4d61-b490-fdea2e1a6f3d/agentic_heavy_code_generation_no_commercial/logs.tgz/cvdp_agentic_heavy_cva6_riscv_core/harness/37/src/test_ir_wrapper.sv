module test_ir_wrapper 
  import ariane_pkg::*;
#(
  parameter config_pkg::cva6_cfg_t CVA6Cfg = build_config_pkg::build_config(
    cva6_config_pkg::cva6_cfg
  )
) (
    input logic clk_i,
    input logic rst_ni,
    input logic flush_i,
    input logic valid_i,
    output logic serving_unaligned_o,
    input logic [CVA6Cfg.VLEN-1:0] address_i,
    input logic [CVA6Cfg.FETCH_WIDTH-1:0] data_i,
    output logic                          valid1_o,
    output logic                          valid2_o,
    output logic [CVA6Cfg.VLEN-1:0]       addr1_o,
    output logic [CVA6Cfg.VLEN-1:0]       addr2_o,
    output logic [31:0]                   instr1_o,
    output logic [31:0]                   instr2_o
);

    logic [CVA6Cfg.INSTR_PER_FETCH-1:0] valid_o;
    logic [CVA6Cfg.INSTR_PER_FETCH-1:0][CVA6Cfg.VLEN-1:0] addr_o;
    logic [CVA6Cfg.INSTR_PER_FETCH-1:0][31:0] instr_o;
  
  instr_realign #(
    .CVA6Cfg(CVA6Cfg)
  ) dut (
    .clk_i (clk_i),
    .rst_ni (rst_ni),
    .flush_i (flush_i),
    .valid_i (valid_i),
    .serving_unaligned_o (serving_unaligned_o),
    .address_i (address_i),
    .data_i (data_i),
    .valid_o (valid_o),
    .addr_o (addr_o),
    .instr_o (instr_o)
  );

  always_comb
  begin
    valid1_o = valid_o[0];
    valid2_o = valid_o[1];
    addr1_o  = addr_o[0];
    addr2_o  = addr_o[1];
    instr1_o = instr_o[0];
    instr2_o = instr_o[1];
  end

endmodule
