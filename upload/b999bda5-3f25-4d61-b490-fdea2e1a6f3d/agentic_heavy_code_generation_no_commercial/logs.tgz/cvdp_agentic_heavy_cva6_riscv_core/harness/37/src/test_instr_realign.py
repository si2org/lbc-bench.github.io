import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
import harness_library as hrs_lb

# ----------------------------------------
# - Tests
# ----------------------------------------


async def reset_dut(dut):
    dut.rst_ni.value = 0
    await RisingEdge(dut.clk_i)
    await RisingEdge(dut.clk_i)
    dut.rst_ni.value = 1
    await RisingEdge(dut.clk_i)

@cocotb.test()
async def test_compressed_and_full_instr_fetch(dut):
    # Start a 10 ns clock
    cocotb.start_soon(Clock(dut.clk_i, 10, unit="ns").start())

    # Reset
    await reset_dut(dut)

    dut.flush_i.value = 1
    await RisingEdge(dut.clk_i)
    dut.flush_i.value = 0
    await RisingEdge(dut.clk_i)

    # pattern 1: data_i[1:0] = 0b11 => uncompressed
    data1 = 0xA5A5A5A5
    data1 = (data1 & ~0b11) | 0b11
    dut.data_i.value    = data1
    dut.address_i.value = 0x100
    dut.valid_i.value   = 1
    await RisingEdge(dut.clk_i)

    got1 = int(dut.valid1_o.value)
    assert got1 == 1, f"Expected slot0 valid (1) for a full instruction fetch, got {got1}"

    # pattern 2: data_i[1:0] = 0b01 => compressed
    data2 = 0x5A5A5A5A
    data2 = (data2 & ~0b11) | 0b01
    dut.data_i.value    = data2
    dut.valid_i.value   = 1
    await RisingEdge(dut.clk_i)

    got2 = int(dut.valid1_o.value)
    got3 = int(dut.valid2_o.value)
    assert got2 == 1, f"valid1_o should be 1 but got {got2}"
    assert got3 == 1, f"valid2_o should be 1 but got {got3}"

@cocotb.test()
async def test_back_to_back_compressed_instrs(dut):
    # start clock
    cocotb.start_soon(Clock(dut.clk_i, 10, unit="ns").start())
    await RisingEdge(dut.clk_i)

    instr0 = 0x1234  # binary ..0100 -> LSBs 0b00 -> compressed
    instr1 = 0xABCD  # binary ..1101 -> LSBs 0b01 -> compressed

    data = (instr1 << 16) | instr0
    addr = 0x100

    dut.data_i.value    = data
    dut.address_i.value = addr
    dut.valid_i.value   = 1

    await RisingEdge(dut.clk_i)

    got0 = int(dut.valid1_o.value)
    got1 = int(dut.valid2_o.value)

    assert got0 == 1, f"Slot0 valid_o=0, expected 1 for compressed instr0"
    assert got1 == 1, f"Slot1 valid_o=0, expected 1 for compressed instr1"

    # now check that the two 16-bit chunks were delivered correctly
    ro0 = int(dut.instr1_o.value) & 0x0000FFFF
    ro1 = int(dut.instr2_o.value)
    assert ro0 == instr0, f"instr_o[0]=0x{ro0:04X}, expected 0x{instr0:04X}"
    assert ro1 == instr1, f"instr_o[1]=0x{ro1:04X}, expected 0x{instr1:04X}"

    # check the addresses tag each 16-bit instruction correctly:
    ao0 = int(dut.addr1_o.value)
    ao1 = int(dut.addr2_o.value)
    assert ao0 == addr,         f"addr_o[0]=0x{ao0:03X}, expected 0x{addr:03X}"
    assert ao1 == addr + 2,     f"addr_o[1]=0x{ao1:03X}, expected 0x{addr+2:03X}"

