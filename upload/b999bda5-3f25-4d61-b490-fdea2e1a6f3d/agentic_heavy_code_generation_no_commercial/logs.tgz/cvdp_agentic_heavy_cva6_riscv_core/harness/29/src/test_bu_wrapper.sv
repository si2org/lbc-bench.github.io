module test_bu_wrapper 
  import ariane_pkg::*;
#(
  parameter config_pkg::cva6_cfg_t CVA6Cfg = build_config_pkg::build_config(
    cva6_config_pkg::cva6_cfg
  )
) (
  // Clock & Reset
  input  logic                          clk_i,
  input  logic                          rst_ni,
  input  logic                          v_i,
  input  logic                          debug_mode_i,
  input  logic [7:0]                    operation_i,
  input  logic [CVA6Cfg.XLEN-1:0]       operand_a_i,
  input  logic [CVA6Cfg.XLEN-1:0]       imm_i,

  // -----------------------
  // Instruction fields
  // -----------------------
  input  logic [CVA6Cfg.VLEN-1:0]       pc_i,
  input  logic                          is_zcmt_i,
  input  logic                          is_compressed_instr_i,
  input  logic                          branch_valid_i,
  input  logic                          branch_comp_res_i,

  // -----------------------
  // Predictor feedback
  // -----------------------
  input  logic [1:0]                    branch_predict_cf_i, // 0-4
  input  logic [CVA6Cfg.VLEN-1:0]       branch_predict_address_i,

  // -----------------------
  // Outputs to observe
  // -----------------------
  output logic [CVA6Cfg.VLEN-1:0]     branch_result_o,
  output logic [CVA6Cfg.VLEN-1:0]     resolved_branch_target_o,
  output logic [CVA6Cfg.VLEN-1:0]     resolved_branch_pc_o,
  output logic                        resolved_branch_taken_o,
  output logic                        resolved_branch_valid_o,
  output logic                        resolved_branch_mispredict_o,
  output logic [1:0]                  resolved_branch_cf_o,
  output logic                        resolve_branch_o,
  output logic                        branch_exception_valid_o,
  output logic [CVA6Cfg.XLEN-1:0]     branch_exception_cause_o
);
  // ----- Complete Signal List -------

  typedef struct packed {
      fu_t                              fu; // 0-10
      fu_op                             operation; // 8 bit signal
      logic [CVA6Cfg.XLEN-1:0]          operand_a;
      logic [CVA6Cfg.XLEN-1:0]          operand_b;
      logic [CVA6Cfg.XLEN-1:0]          imm;
      logic [CVA6Cfg.TRANS_ID_BITS-1:0] trans_id;
  } fu_data_t;

  typedef struct packed {
      cf_t                     cf;               // type of control flow prediction
      logic [CVA6Cfg.VLEN-1:0] predict_address;  // target address at which to jump, or not
  }branchpredict_sbe_t ;

  typedef struct packed {
      logic                    valid;           // prediction with all its values is valid
      logic [CVA6Cfg.VLEN-1:0] pc;              // PC of predict or mis-predict
      logic [CVA6Cfg.VLEN-1:0] target_address;  // target address at which to jump, or not
      logic                    is_mispredict;   // set if this was a mis-predict
      logic                    is_taken;        // branch is taken
      cf_t                     cf_type;         // 0-4
    }bp_resolve_t;

  typedef struct packed {
      logic [CVA6Cfg.XLEN-1:0] cause;  // cause of exception
      logic [CVA6Cfg.XLEN-1:0] tval;  // additional information of causing exception (e.g.: instruction causing it),
      // address of LD/ST fault
      logic [CVA6Cfg.GPLEN-1:0] tval2;  // additional information when the causing exception in a guest exception
      logic [31:0] tinst;  // transformed instruction information
      logic gva;  // signals when a guest virtual address is written to tval
      logic valid;
  }exception_t;

  // Internal signals
  fu_data_t           fu_data_struct;
  branchpredict_sbe_t branch_predict_struct;
  bp_resolve_t        resolved_branch_struct;
  exception_t         branch_exception_struct;

  always_comb begin
    fu_data_struct.operation = fu_op'(operation_i);
    fu_data_struct.operand_a = operand_a_i;
    fu_data_struct.imm       = imm_i;
  
    fu_data_struct.fu = ALU;
    fu_data_struct.operand_b = 0;
    fu_data_struct.trans_id = 0;

  end

  always_comb begin
    branch_predict_struct.cf              = cf_t'(branch_predict_cf_i);
    branch_predict_struct.predict_address = branch_predict_address_i;
  end

  //===========================================
  // Instantiate 
  //===========================================

  branch_unit #(
    .CVA6Cfg             (CVA6Cfg),
    .bp_resolve_t        (bp_resolve_t),
    .branchpredict_sbe_t (branchpredict_sbe_t),
    .exception_t         (exception_t),
    .fu_data_t           (fu_data_t)
  ) dut (
    .clk_i                      (clk_i),
    .rst_ni                     (rst_ni),
    .v_i                        (v_i),
    .debug_mode_i               (debug_mode_i),
    .fu_data_i                  (fu_data_struct),
    .pc_i                       (pc_i),
    .is_zcmt_i                  (is_zcmt_i),
    .is_compressed_instr_i      (is_compressed_instr_i),
    .branch_valid_i             (branch_valid_i),
    .branch_comp_res_i          (branch_comp_res_i),
    .branch_result_o            (branch_result_o),
    .branch_predict_i           (branch_predict_struct),
    .resolved_branch_o          (resolved_branch_struct),
    .resolve_branch_o           (resolve_branch_o),
    .branch_exception_o         (branch_exception_struct)
  );

  always_comb begin
    resolved_branch_target_o     = resolved_branch_struct.target_address;
    resolved_branch_pc_o         = resolved_branch_struct.pc;
    resolved_branch_taken_o      = resolved_branch_struct.is_taken;
    resolved_branch_valid_o      = resolved_branch_struct.valid;
    resolved_branch_mispredict_o = resolved_branch_struct.is_mispredict;
    resolved_branch_cf_o         = resolved_branch_struct.cf_type;
    branch_exception_valid_o     = branch_exception_struct.valid;
    branch_exception_cause_o     = branch_exception_struct.cause;
  end

endmodule
