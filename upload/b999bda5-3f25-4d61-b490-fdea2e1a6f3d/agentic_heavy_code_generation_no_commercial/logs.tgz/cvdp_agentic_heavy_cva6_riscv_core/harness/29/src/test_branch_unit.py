import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
import harness_library as hrs_lb

# ----------------------------------------
# - Tests
# ----------------------------------------

async def reset_dut(dut):
    dut.rst_ni.value = 0
    await RisingEdge(dut.clk_i)
    await RisingEdge(dut.clk_i)
    dut.rst_ni.value = 1
    await RisingEdge(dut.clk_i)

@cocotb.test()
async def test_compressed_next_pc(dut):
    cocotb.start_soon(Clock(dut.clk_i, 10, unit="ns").start())

    # reset
    await reset_dut(dut)

    dut.v_i.value                   = 0
    dut.debug_mode_i.value          = 0
    dut.operation_i.value           = 0
    dut.operand_a_i.value           = 0
    dut.imm_i.value                 = 0
    dut.is_zcmt_i.value             = 0
    dut.branch_valid_i.value        = 0
    dut.branch_comp_res_i.value     = 0
    dut.branch_predict_cf_i.value   = 0
    dut.branch_predict_address_i.value = 0

    for pc in (0x0000_0000,
               0x0000_0100,
               0x8000_0000):
        dut.pc_i.value               = pc
        dut.is_compressed_instr_i.value = 1

        await RisingEdge(dut.clk_i)
        await RisingEdge(dut.clk_i)

        got = int(dut.branch_result_o.value)
        expected = (pc + 2) & ((1 << len(str(dut.branch_result_o.value))) - 1)
        assert got == expected, (
            f"Compressed next-PC incorrect: "
            f"pc=0x{pc:08X}, got=0x{got:08X}, expected=0x{expected:08X}"
        )

@cocotb.test()
async def test_cf_persists_after_branch(dut):

    cocotb.start_soon(Clock(dut.clk_i, 10, unit="ns").start())

    # simple reset
    dut.rst_ni.value = 0
    await RisingEdge(dut.clk_i)
    dut.rst_ni.value = 1
    await RisingEdge(dut.clk_i)

    dut.v_i.value                      = 0
    dut.debug_mode_i.value             = 0
    dut.operation_i.value              = 0
    dut.operand_a_i.value              = 0
    dut.imm_i.value                    = 0
    dut.pc_i.value                     = 0x100
    dut.is_zcmt_i.value                = 0
    dut.is_compressed_instr_i.value    = 0
    dut.branch_comp_res_i.value        = 1
    dut.branch_predict_address_i.value = 0

    dut.branch_predict_cf_i.value = 1   # Branch
    dut.branch_valid_i.value      = 1
    await RisingEdge(dut.clk_i)
    await RisingEdge(dut.clk_i)

    seen_cf = int(dut.resolved_branch_cf_o.value)
    assert seen_cf == 1, f"Expected cf=1 on the branch cycle, got {seen_cf}"

    dut.branch_valid_i.value = 0
    for i in range(3):
        await RisingEdge(dut.clk_i)
        await RisingEdge(dut.clk_i)
        cf = int(dut.resolved_branch_cf_o.value)
        assert cf == seen_cf, (
            f"Cycle {i}: cf_type changed to {cf} after branch_valid=0 "
            f"(expected {seen_cf})"
        )

@cocotb.test()
async def test_resolve_branch_for_jalr(dut):

    cocotb.start_soon(Clock(dut.clk_i, 10, unit="ns").start())

    # reset
    dut.rst_ni.value = 0
    await RisingEdge(dut.clk_i)
    dut.rst_ni.value = 1
    await RisingEdge(dut.clk_i)

    dut.v_i.value                     = 0
    dut.debug_mode_i.value            = 0
    dut.is_zcmt_i.value               = 0
    dut.is_compressed_instr_i.value   = 0
    dut.branch_valid_i.value          = 1    # indicate a branch
    dut.branch_comp_res_i.value       = 1    # treat as taken
    dut.branch_predict_address_i.value= 0
    dut.branch_predict_cf_i.value     = 0

    base   = 0x1003
    offset = 5
    dut.operand_a_i.value = base
    dut.imm_i.value       = offset

    dut.operation_i.value = 19 # JALR value

    dut.pc_i.value = 0x2000

    await RisingEdge(dut.clk_i)
    await RisingEdge(dut.clk_i)

    got_target     = int(dut.resolved_branch_target_o.value)
    got_pc         = int(dut.resolved_branch_pc_o.value)
    got_valid      = int(dut.resolved_branch_valid_o.value)
    got_mispred    = int(dut.resolved_branch_mispredict_o.value)
    got_cf         = int(dut.resolved_branch_cf_o.value)
    got_resolve    = int(dut.resolve_branch_o.value)

    raw = base + offset
    expected_target = raw & ~1

    assert got_resolve == 1,      f"resolve_branch_o should be 1 for JALR, got {got_resolve}"
    assert got_valid   == 1,      f"resolved_branch_valid_o should be 1, got {got_valid}"
    assert got_target  == expected_target, (
        f"JALR target wrong: expected 0x{expected_target:08X}, got 0x{got_target:08X}"
    )
    assert got_pc == 0x2000,      f"resolved_branch_pc_o should equal pc_i, got 0x{got_pc:08X}"
    assert got_mispred == 1,      f"JALR mispredict should be 1, got {got_mispred}"
    assert got_cf == 3, (
        f"resolved_branch_cf_o should be JumpR ({int(dut.JumpR.value)}), got {got_cf}"
    )