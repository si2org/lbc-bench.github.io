module test_scoreboard_wrapper 
  import ariane_pkg::*;
#(
  parameter config_pkg::cva6_cfg_t CVA6Cfg = build_config_pkg::build_config(
    cva6_config_pkg::cva6_cfg
  )
) (
  // Clock & Reset
  input  logic                                  clk_i,
  input  logic                                  rst_ni,

  // ---------------------------
  // *Issue‐Stage* (NrIssuePorts = 1 assumed)
  // ---------------------------
  // Flat decoded instruction: just a 1‐byte transaction ID
  input  logic [CVA6Cfg.TRANS_ID_BITS-1:0]      decoded_trans_id_i,
  input  logic                                  decoded_valid_i,
  output logic                                  decoded_instr_ack_o_0,
  // Issue‐stage “ready/ack” back to scoreboard
  input  logic                                  issue_ack_i_0,

  // ---------------------------
  // *Write‐Back*
  // ---------------------------
  // We only allow a single writeback channel
  input  logic                                  wt_valid_i,
  input  logic [CVA6Cfg.TRANS_ID_BITS-1:0]      wb_trans_id_i,
  input  logic [CVA6Cfg.XLEN-1:0]                wb_data_i,
  input  logic                                  x_we_i,    // CVXIF write‐enable (unused)
  input  logic [4:0]                            x_rd_i,    // CVXIF rd (unused)

  // ---------------------------
  // *Branch‐Mispredict/Flush*
  // ---------------------------
  input  logic                                  flush_i,
  input  logic                                  br_valid_i,
  input  logic                                  br_mispredict_i,
  input  logic [CVA6Cfg.VLEN-1:0]               br_target_i,

  // ---------------------------
  // *Commit‐Stage*
  // ---------------------------
  output logic [CVA6Cfg.TRANS_ID_BITS-1:0]      commit_trans_id_o,
  output logic                                  commit_drop,
  output logic                                  commit_valid_o,
  input  logic                                  commit_ack_i_0,

  // ---------------------------
  // *“Full” Flag & Issue Stage Outputs*
  // ---------------------------
  output logic                                  sb_full_o,
  output logic [CVA6Cfg.TRANS_ID_BITS-1:0]      issue_trans_id_o,
  output logic [31:0]                           orig_instr_o_0,
  output logic                                  issue_valid_o_0,

  output logic [CVA6Cfg.TRANS_ID_BITS-1:0] rvfi_issue_pointer_o_0,
  output logic [CVA6Cfg.TRANS_ID_BITS-1:0] rvfi_commit_pointer_o_0
);
  // ----- Complete Signal List -------

  typedef struct packed {
      cf_t                     cf;               // type of control flow prediction
      logic [CVA6Cfg.VLEN-1:0] predict_address;  // target address at which to jump, or not
  }branchpredict_sbe_t ;
  typedef struct packed {
      logic                    valid;           // prediction with all its values is valid
      logic [CVA6Cfg.VLEN-1:0] pc;              // PC of predict or mis-predict
      logic [CVA6Cfg.VLEN-1:0] target_address;  // target address at which to jump, or not
      logic                    is_mispredict;   // set if this was a mis-predict
      logic                    is_taken;        // branch is taken
      cf_t                     cf_type;
    }bp_resolve_t;
  typedef struct packed {
      logic [CVA6Cfg.XLEN-1:0] cause;  // cause of exception
      logic [CVA6Cfg.XLEN-1:0] tval;  // additional information of causing exception (e.g.: instruction causing it),
      // address of LD/ST fault
      logic [CVA6Cfg.GPLEN-1:0] tval2;  // additional information when the causing exception in a guest exception
      logic [31:0] tinst;  // transformed instruction information
      logic gva;  // signals when a guest virtual address is written to tval
      logic valid;
  }exception_t;
  
  typedef struct packed {
    logic [CVA6Cfg.VLEN-1:0]      pc;
    logic [CVA6Cfg.TRANS_ID_BITS-1:0] trans_id;
    fu_t                           fu;
    fu_op                          op;
    logic [REG_ADDR_SIZE-1:0]      rs1;
    logic [REG_ADDR_SIZE-1:0]      rs2;
    logic [REG_ADDR_SIZE-1:0]      rd;
    logic [CVA6Cfg.XLEN-1:0]       result;
    logic                          valid;
    logic                          use_imm;
    logic                          use_zimm;
    logic                          use_pc;
    exception_t                    ex;
    branchpredict_sbe_t            bp;
    logic                          is_compressed;
    logic                          is_macro_instr;
    logic                          is_last_macro_instr;
    logic                          is_double_rd_macro_instr;
    logic                          vfp;
    logic                          is_zcmt;
  } scoreboard_entry_t;

  typedef struct packed {
    logic                          valid;
    logic [CVA6Cfg.XLEN-1:0]       data;
    logic                          ex_valid;
    logic [CVA6Cfg.TRANS_ID_BITS-1:0] trans_id;
  } writeback_t;
  typedef struct packed {
      logic [CVA6Cfg.NR_SB_ENTRIES-1:0] still_issued;
      logic [CVA6Cfg.TRANS_ID_BITS-1:0] issue_pointer;
      writeback_t [CVA6Cfg.NrWbPorts-1:0] wb;
      scoreboard_entry_t [CVA6Cfg.NR_SB_ENTRIES-1:0] sbe;
  }forwarding_t;

  typedef logic [(CVA6Cfg.NrRgprPorts == 3 ? CVA6Cfg.XLEN : CVA6Cfg.FLen)-1:0] rs3_len_t;

    logic              [CVA6Cfg.NrCommitPorts-1:0] commit_ack_i;
    scoreboard_entry_t [CVA6Cfg.NrIssuePorts-1:0]       decoded_instr_i;
    logic              [CVA6Cfg.NrIssuePorts-1:0][31:0] orig_instr_i;
    logic              [CVA6Cfg.NrIssuePorts-1:0]       decoded_instr_valid_i;
    logic              [CVA6Cfg.NrIssuePorts-1:0]       issue_ack_i;
    logic              [CVA6Cfg.NrWbPorts-1:0][CVA6Cfg.TRANS_ID_BITS-1:0] trans_id_i;
    logic              [CVA6Cfg.NrWbPorts-1:0][CVA6Cfg.XLEN-1:0] wbdata_i;
    // input exception_t [CVA6Cfg.NrWbPorts-1:0] ex_i,
    // logic              [CVA6Cfg.NrWbPorts-1:0] wt_valid_i;

    scoreboard_entry_t [CVA6Cfg.NrCommitPorts-1:0] commit_instr_o;
    logic              [CVA6Cfg.NrCommitPorts-1:0] commit_drop_o;
    scoreboard_entry_t [CVA6Cfg.NrIssuePorts-1:0]       issue_instr_o;
    logic              [CVA6Cfg.NrIssuePorts-1:0]       decoded_instr_ack_o;
    logic              [CVA6Cfg.NrIssuePorts-1:0][31:0] orig_instr_o;
    logic              [CVA6Cfg.NrIssuePorts-1:0]       issue_instr_valid_o;
    forwarding_t                                        fwd_o;
    logic [ CVA6Cfg.NrIssuePorts-1:0][CVA6Cfg.TRANS_ID_BITS-1:0] rvfi_issue_pointer_o;
    logic [CVA6Cfg.NrCommitPorts-1:0][CVA6Cfg.TRANS_ID_BITS-1:0] rvfi_commit_pointer_o;
  // ------------------------------------------------------------
  // Internally‐driven signals (all tied to zero or defaults)
  // ------------------------------------------------------------
  // For “CVXIF” writeback (unused in these tests)
  logic                                          x_transaction_accepted_i = 0;
  logic                                          x_issue_writeback_i   = 0;

  // No “orig_instr” data needed
  logic [31:0]                                   orig_instr_i_flat = 0;

  // We only expose one “decoded_instr” struct; scoreboard expects an array of size 1


  scoreboard_entry_t decoded_instr_array;

  // Writeback struct (matching scoreboard’s writeback_t)
  
  writeback_t wb_array;

  // “resolved_branch_i” struct (bp_resolve_t)
  bp_resolve_t resolved_branch_struct;



  // -------------------------------------------------------------------
  // Build the single‐entry “decoded_instr_i” array from the flat inputs
  // -------------------------------------------------------------------
  always_comb begin
    // zero all fields except “trans_id” and “valid”
    decoded_instr_array.pc                     = '0;
    decoded_instr_array.trans_id               = decoded_trans_id_i;
    decoded_instr_array.fu                     = ALU;
    decoded_instr_array.op                     = ADD;
    decoded_instr_array.rs1                    = '0;
    decoded_instr_array.rs2                    = '0;
    decoded_instr_array.rd                     = '0;
    decoded_instr_array.result                 = '0;
    decoded_instr_array.valid                  = decoded_valid_i;
    decoded_instr_array.use_imm                = 0;
    decoded_instr_array.use_zimm               = 0;
    decoded_instr_array.use_pc                 = 0;

    // Exception fields = zero
    decoded_instr_array.ex.cause               = '0;
    decoded_instr_array.ex.tval                = '0;
    decoded_instr_array.ex.tval2               = '0;
    decoded_instr_array.ex.tinst               = '0;
    decoded_instr_array.ex.gva                 = 0;
    decoded_instr_array.ex.valid               = 0;

    // Branch-predict fields are driven from the flat ports
    resolved_branch_struct.valid                  = br_valid_i;
    resolved_branch_struct.is_mispredict          = br_mispredict_i;
    resolved_branch_struct.target_address         = br_target_i;
    resolved_branch_struct.pc                     = '0;
    resolved_branch_struct.is_taken               = 0;
    resolved_branch_struct.cf_type                = NoCF;

    decoded_instr_array.bp.cf                  = resolved_branch_struct.cf_type;
    decoded_instr_array.bp.predict_address     = resolved_branch_struct.target_address;

    // All other scoreboard‐entry flags = 0
    decoded_instr_array.is_compressed          = 0;
    decoded_instr_array.is_macro_instr         = 0;
    decoded_instr_array.is_last_macro_instr    = 0;
    decoded_instr_array.is_double_rd_macro_instr = 0;
    decoded_instr_array.vfp                     = 0;
    decoded_instr_array.is_zcmt                 = 0;

    decoded_instr_ack_o_0 = decoded_instr_ack_o[0];
    orig_instr_o_0 = orig_instr_o[0];
    commit_ack_i[0] = commit_ack_i_0;
    commit_ack_i[1] = '0;
    decoded_instr_i[0] = decoded_instr_array;
    orig_instr_i[0] = orig_instr_i_flat;
    decoded_instr_valid_i[0] = decoded_valid_i;

    issue_ack_i[0] = issue_ack_i_0;

    rvfi_issue_pointer_o_0 = rvfi_issue_pointer_o[0];
    rvfi_commit_pointer_o_0 = rvfi_commit_pointer_o[0];
  end


  // ---------------------------------------------------------
  // Build the “writeback” array from flat inputs
  // ---------------------------------------------------------
  always_comb begin
    wb_array.valid     = wt_valid_i;
    wb_array.data      = wb_data_i;
    wb_array.ex_valid  = 0;             // no exception in simple tests
    wb_array.trans_id  = wb_trans_id_i;

    trans_id_i[0] = wb_trans_id_i;
    trans_id_i[1] = '0;
    wbdata_i[0]   = wb_data_i;
    wbdata_i[1]   = '0;
  end

  // ---------------------------------------------------------
  // Build “issue_instr_o[0]” → expose just the trans_id
  // ---------------------------------------------------------
  assign issue_trans_id_o   = issue_instr_o[0].trans_id;
  assign issue_valid_o_0      = issue_instr_valid_o[0];

  // ---------------------------------------------------------
  // Commit outputs: expose only trans_id and drop‐flag/valid
  // ---------------------------------------------------------
  logic [CVA6Cfg.TRANS_ID_BITS-1:0] commit_trans_id_loc;
  assign commit_trans_id_loc = commit_instr_o[0].trans_id;
  assign commit_trans_id_o   = commit_trans_id_loc;
  assign commit_drop         = commit_drop_o[0];  // already a 1-bit
  assign commit_valid_o      = commit_instr_o[0].valid;

  // ---------------------------------------------------------
  // Resolved-branch struct passed to scoreboard
  // ---------------------------------------------------------
  // already built above (named resolved_branch_struct)

  // ---------------------------------------------------------
  // Reduced scoreboard‐instantiation ports
  // ---------------------------------------------------------
  scoreboard #(
    .CVA6Cfg       (CVA6Cfg),
    .bp_resolve_t  (bp_resolve_t),
    .exception_t   (exception_t),
    .scoreboard_entry_t(scoreboard_entry_t),
    .forwarding_t  (forwarding_t),
    .writeback_t   (writeback_t),
    .rs3_len_t     (rs3_len_t)
  ) uut (
    // Clock / Reset
    .clk_i                      (clk_i),
    .rst_ni                     (rst_ni),

    // Full flag
    .sb_full_o                  (sb_full_o),

    // Flush & unissued‐instr flush
    .flush_unissued_instr_i     (1'b0),
    .flush_i                    (flush_i),

    // CVXIF writeback (tied to default)
    .x_transaction_accepted_i   (x_transaction_accepted_i),
    .x_issue_writeback_i        (x_issue_writeback_i),
    .x_id_i                      ('0),

    // Commit ports (1 port)
    .commit_instr_o             (commit_instr_o),
    .commit_drop_o              (commit_drop_o),
    .commit_ack_i               (commit_ack_i ),

    // ID Stage (Issue input)
    .decoded_instr_i            (decoded_instr_i),
    .orig_instr_i               (orig_instr_i   ),
    .decoded_instr_valid_i      (decoded_instr_valid_i),
    .decoded_instr_ack_o        ( decoded_instr_ack_o ),

    // Issue Stage (Issue output)
    .issue_instr_o              (issue_instr_o),
    .orig_instr_o               (orig_instr_o),
    .issue_instr_valid_o        (issue_instr_valid_o),
    .issue_ack_i                (issue_ack_i ),
    .fwd_o                      (fwd_o),

    // EX Stage writeback
    .resolved_branch_i          (resolved_branch_struct),
    .trans_id_i                 (trans_id_i),
    .wbdata_i                   (wbdata_i  ),
    .ex_i                       ('0),
    .wt_valid_i                 ({ wt_valid_i }),
    .x_we_i                     (x_we_i),
    .x_rd_i                     (x_rd_i),

    // RVFI interface
    .rvfi_issue_pointer_o       (rvfi_issue_pointer_o  ),
    .rvfi_commit_pointer_o      (rvfi_commit_pointer_o  )
  );

endmodule
