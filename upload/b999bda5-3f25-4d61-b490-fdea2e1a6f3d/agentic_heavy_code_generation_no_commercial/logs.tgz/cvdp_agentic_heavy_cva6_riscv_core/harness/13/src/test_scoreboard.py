import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
import harness_library as hrs_lb

# ----------------------------------------
# - Tests
# ----------------------------------------

async def reset_dut(dut):
    dut.rst_ni.value = 0
    await RisingEdge(dut.clk_i)
    await RisingEdge(dut.clk_i)
    dut.rst_ni.value = 1
    await RisingEdge(dut.clk_i)


@cocotb.test()
async def test_commit_pointer(dut):
    """Commit-pointer off-by-one"""
    cocotb.start_soon(Clock(dut.clk_i, 10, units="ns").start())
    await hrs_lb.dut_init(dut)
    await reset_dut(dut)

    # Cycle 1: decode — present instruction to scoreboard (issue_ack still low)
    dut.decoded_trans_id_i.value    = 3
    dut.decoded_valid_i.value       = 1
    await RisingEdge(dut.clk_i)

    # Cycle 2: issue_ack — keep decoded_valid=1 so issue_instr_valid_o=1 when issue_ack fires
    # SVA: issue_ack_i[i] |-> issue_instr_valid_o[i] = decoded_valid & ~issue_full = 1
    dut.issue_ack_i_0.value         = 1
    await RisingEdge(dut.clk_i)
    dut.decoded_valid_i.value       = 0
    dut.issue_ack_i_0.value         = 0

    # Writeback: set sbe.valid=1 so commit assertion passes with golden RTL
    dut.wt_valid_i.value            = 1
    dut.wb_trans_id_i.value         = 0  # instruction was issued to slot 0 (issue_pointer_q=0)
    dut.wb_data_i.value             = 0
    await RisingEdge(dut.clk_i)
    dut.wt_valid_i.value            = 0
    await RisingEdge(dut.clk_i)    # let writeback register into mem_q

    # Commit
    dut.commit_ack_i_0.value        = 1
    await RisingEdge(dut.clk_i)
    dut.commit_ack_i_0.value        = 0
    await RisingEdge(dut.clk_i)

    ptr = int(dut.rvfi_commit_pointer_o_0.value)
    assert ptr == 1, f"Commit pointer advanced by {ptr} (should be 1)"

@cocotb.test()
async def test_write_back(dut):
    """Stale WB update"""
    cocotb.start_soon(Clock(dut.clk_i, 10, units="ns").start())
    await hrs_lb.dut_init(dut)
    await reset_dut(dut)

    # Cycle 1: decode
    dut.decoded_trans_id_i.value    = 1
    dut.decoded_valid_i.value       = 1
    dut.x_we_i.value                = 0
    dut.x_rd_i.value                = 0
    await RisingEdge(dut.clk_i)

    # Cycle 2: issue_ack with decoded_valid still high
    dut.issue_ack_i_0.value         = 1
    await RisingEdge(dut.clk_i)
    dut.decoded_valid_i.value       = 0
    dut.issue_ack_i_0.value         = 0

    # Writeback: set sbe.valid=1 for slot 0 (instruction issued to slot 0)
    dut.wt_valid_i.value            = 1
    dut.wb_trans_id_i.value         = 0
    dut.wb_data_i.value             = 0x1234
    await RisingEdge(dut.clk_i)
    dut.wt_valid_i.value            = 0
    await RisingEdge(dut.clk_i)    # let writeback register into mem_q

    dut.commit_ack_i_0.value        = 1
    await RisingEdge(dut.clk_i)
    dut.commit_ack_i_0.value        = 0
    await RisingEdge(dut.clk_i)

    committed_id = int(dut.commit_trans_id_o.value)
    assert committed_id == 1, f"Write-back ID lost: got {committed_id}, expected 1"
