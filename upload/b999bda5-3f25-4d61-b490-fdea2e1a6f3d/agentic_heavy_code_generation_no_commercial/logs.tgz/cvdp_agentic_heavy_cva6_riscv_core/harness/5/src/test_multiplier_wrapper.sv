module test_multiplier_wrapper
  import ariane_pkg::*;
#(
  parameter config_pkg::cva6_cfg_t CVA6Cfg = build_config_pkg::build_config(cva6_config_pkg::cva6_cfg)
) (
    input  logic                             clk_i,
    input  logic                             rst_ni,
    input  logic [CVA6Cfg.TRANS_ID_BITS-1:0] trans_id_i,
    input  logic                             mult_valid_i,
    input  fu_op                             operation_i,
    input  logic [         CVA6Cfg.XLEN-1:0] operand_a_i,
    input  logic [         CVA6Cfg.XLEN-1:0] operand_b_i,
    output logic [         CVA6Cfg.XLEN-1:0] result_o,
    output logic                             mult_valid_o,
    output logic [CVA6Cfg.TRANS_ID_BITS-1:0] mult_trans_id_o
);

 multiplier # (
    .CVA6Cfg(CVA6Cfg)
 ) dut (
    .*
 );

endmodule