import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
import harness_library as hrs_lb

# ----------------------------------------
# - Tests
# ----------------------------------------

CLMUL, CLMULH, CLMULR = 155, 156, 157

# helper to reverse bits
def _rev(x: int, width: int) -> int:
    r = 0
    for i in range(width):
        if (x >> i) & 1:
            r |= 1 << (width - 1 - i)
    return r

def ref_clmul(a: int, b: int, width: int) -> int:
    mask = (1 << width) - 1
    res = 0
    for i in range(width):
        if (b >> i) & 1:
            res ^= (a << i) & mask
    return res


def ref_clmulr(a: int, b: int, width: int) -> int:
    """
    Reference for CLMULR
    """
    rev_a = _rev(a, width)
    rev_b = _rev(b, width)
    low = ref_clmul(rev_a, rev_b, width)
    return _rev(low, width)


def ref_clmulh(a: int, b: int, width: int) -> int:
    """
    Reference for CLMULH
    """
    rev_a = _rev(a, width)
    rev_b = _rev(b, width)
    low = ref_clmul(rev_a, rev_b, width)
    rev_low = _rev(low, width)
    return rev_low >> 1


async def reset_dut(dut):
    dut.rst_ni.value = 0
    await RisingEdge(dut.clk_i)
    await RisingEdge(dut.clk_i)
    dut.rst_ni.value = 1
    await RisingEdge(dut.clk_i)


@cocotb.test()
async def test_clmul(dut):
    """Test CLMUL (carry-less low half)"""
    cocotb.start_soon(Clock(dut.clk_i, 10, unit='ns').start())
    await reset_dut(dut)

    width = len(str(dut.operand_a_i.value))
    tests = [
        (0x12345678, 0x87654321),
        (0xF0F0F0F0, 0x0F0F0F0F),
    ]

    for a, b in tests:
        dut.trans_id_i.value   = 0
        dut.mult_valid_i.value = 1
        dut.operation_i.value  = CLMUL
        dut.operand_a_i.value  = a
        dut.operand_b_i.value  = b

        await RisingEdge(dut.clk_i)
        await RisingEdge(dut.clk_i)

        expected = ref_clmul(a, b, width)
        got = int(dut.result_o.value)
        assert got == expected, f"CLMUL mismatch: a=0x{a:X}, b=0x{b:X}, expected=0x{expected:X}, got=0x{got:X}"

@cocotb.test()
async def test_clmulh(dut):
    cocotb.start_soon(Clock(dut.clk_i, 10, unit='ns').start())
    await reset_dut(dut)

    width = len(str(dut.operand_a_i.value))
    tests = [
        (0xF0F0F0F0, 0x0F0F0F0F),
        (0x12345678, 0x87654321),
    ]

    for a, b in tests:
        dut.trans_id_i.value   = 0
        dut.mult_valid_i.value = 1
        dut.operation_i.value  = CLMULH
        dut.operand_a_i.value  = a
        dut.operand_b_i.value  = b

        await RisingEdge(dut.clk_i)
        await RisingEdge(dut.clk_i)

        expected = ref_clmulh(a, b, width)
        got = int(dut.result_o.value)
        assert got == expected, f"CLMULH mismatch: a=0x{a:X}, b=0x{b:X}, expected=0x{expected:X}, got=0x{got:X}"


@cocotb.test()
async def test_clmulr(dut):
    cocotb.start_soon(Clock(dut.clk_i, 10, unit='ns').start())
    await reset_dut(dut)

    width = len(str(dut.operand_a_i.value))
    tests = [
        (0xF0F0F0F0, 0x0F0F0F0F),
        (0x00000001, 0x80000000),
    ]

    for a, b in tests:
        dut.trans_id_i.value   = 0
        dut.mult_valid_i.value = 1
        dut.operation_i.value  = CLMULR
        dut.operand_a_i.value  = a
        dut.operand_b_i.value  = b

        await RisingEdge(dut.clk_i)
        await RisingEdge(dut.clk_i)

        expected = ref_clmulr(a, b, width)
        got = int(dut.result_o.value)
        assert got == expected, f"CLMULR mismatch: a=0x{a:X}, b=0x{b:X}, expected=0x{expected:X}, got=0x{got:X}"
