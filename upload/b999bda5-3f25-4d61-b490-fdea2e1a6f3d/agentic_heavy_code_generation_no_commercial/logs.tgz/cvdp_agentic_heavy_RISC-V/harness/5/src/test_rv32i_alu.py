# test_rv32i_alu.py
#
# Four focused test-cases:
#   • test_add_sub_arith
#   • test_logic_ops
#   • test_shift_ops
#   • test_compare_ops
#
# Together they exercise every one-hot bit in i_alu and confirm o_y
# matches a software-reference model.  Each sub-test randomises 100
# vectors per opcode for quick yet meaningful coverage.

import random
import cocotb
from cocotb.clock    import Clock
from cocotb.triggers import RisingEdge, ReadOnly, Timer

# --------------------------------------------------------------------
#  One-hot ALU bit positions (must match rv32i_header.vh)
# --------------------------------------------------------------------
IDX = dict(
    ADD  = 0, SUB  = 1,
    SLT  = 2, SLTU = 3,
    XOR  = 4, OR   = 5, AND  = 6,
    SLL  = 7, SRL  = 8, SRA  = 9,
    EQ   = 10, NEQ = 11,
    GE   = 12, GEU = 13,
)

def alu_vec(name):
    """Convert opcode string to one-hot vector for i_alu."""
    return 1 << IDX[name]

# --------------------------------------------------------------------
#  Helpers
# --------------------------------------------------------------------
def u32(x):  return x & 0xFFFF_FFFF
def s32(x):  return x if x < 0x8000_0000 else x - 0x1_0000_0000

def ref(op, a, b):
    """Golden reference for every ALU operation."""
    if op == "ADD":  return u32(a + b)
    if op == "SUB":  return u32(a - b)
    if op == "XOR":  return a ^ b
    if op == "OR":   return a | b
    if op == "AND":  return a & b
    if op == "SLL":  return u32(a << (b & 0x1F))
    if op == "SRL":  return a >> (b & 0x1F)
    if op == "SRA":  return u32(s32(a) >> (b & 0x1F))
    if op == "SLT":  return 1 if s32(a) <  s32(b) else 0
    if op == "SLTU": return 1 if a < b else 0
    if op == "EQ":   return 1 if a == b else 0
    if op == "NEQ":  return 1 if a != b else 0
    if op == "GE":   return 1 if s32(a) >= s32(b) else 0
    if op == "GEU":  return 1 if a >= b else 0
    raise ValueError(op)

async def reset(dut):
    dut.i_rst_n.value = 0
    await RisingEdge(dut.i_clk)
    await RisingEdge(dut.i_clk)
    dut.i_rst_n.value = 1
    await RisingEdge(dut.i_clk)

async def drive_and_check(dut, op_names, vectors=100):
    """Shared routine: randomise operands, drive ALU, check o_y."""
    rand = random.Random(0x55AA + hash(tuple(op_names)))
    dut.i_ce.value          = 1
    dut.i_stall.value       = 0
    dut.i_force_stall.value = 0
    dut.i_flush.value       = 0
    dut.i_opcode.value      = 0  # keeps operand-selection simple

    for name in op_names:
        code = alu_vec(name)
        for _ in range(vectors):
            a = rand.getrandbits(32)
            b = rand.getrandbits(32)

            dut.i_rs1.value = a
            dut.i_rs2.value = b
            dut.i_imm.value = b     # ALU picks imm when opcode_rtype=0
            dut.i_rs1_addr.value = 1
            dut.i_rd_addr.value  = 2
            dut.i_alu.value = code

            await RisingEdge(dut.i_clk)   # compute
            await RisingEdge(dut.i_clk)   # registered o_y

            y_hw = int(dut.o_y.value)
            y_sw = ref(name, a, b)
            assert y_hw == y_sw, (
                f"{name} failed: a={hex(a)} b={hex(b)} "
                f"got {hex(y_hw)} ≠ {hex(y_sw)}"
            )

# --------------------------------------------------------------------
#  Individual feature tests
# --------------------------------------------------------------------

@cocotb.test()
async def test_add_sub_arith(dut):
    """ADD / SUB sanity over random operand pairs."""
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset(dut)
    await drive_and_check(dut, ["ADD", "SUB"])

@cocotb.test()
async def test_logic_ops(dut):
    """XOR / OR / AND randomised functional check."""
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset(dut)
    await drive_and_check(dut, ["XOR", "OR", "AND"])

@cocotb.test()
async def test_shift_ops(dut):
    """Left-, logical-right-, and arithmetic-right-shifts with varied shift amounts."""
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset(dut)
    await drive_and_check(dut, ["SLL", "SRL", "SRA"])

@cocotb.test()
async def test_compare_ops(dut):
    """Signed/unsigned min-max, equality, inequality comparisons."""
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset(dut)
    await drive_and_check(dut, ["SLT", "SLTU", "EQ", "NEQ", "GE", "GEU"])

# One-hot bit for ADD (matches rv32i_header.vh)
ALU_ADD = 1 << 0     # idx 0 is ADD in the reference design


# ------------------------------------------------------------
#  Boilerplate helpers
# ------------------------------------------------------------
async def reset_dut(dut):
    dut.i_rst_n.value = 0
    await RisingEdge(dut.i_clk)
    await RisingEdge(dut.i_clk)
    dut.i_rst_n.value = 1
    await RisingEdge(dut.i_clk)

def drive_operands(dut, a, b):
    """Set operands and select ADD."""
    dut.i_rs1.value   = a
    dut.i_rs2.value   = b
    dut.i_imm.value   = b        # ALU picks imm when opcode_rtype = 0
    dut.i_rs1_addr.value = 3
    dut.i_rd_addr.value  = 5
    dut.i_alu.value   = ALU_ADD
    dut.i_opcode.value = 0       # keep datapath simple


async def capture_o_y(dut):
    """Wait two clocks (pipeline latency) and return o_y."""
    await RisingEdge(dut.i_clk)  # compute
    await RisingEdge(dut.i_clk)  # o_y registered
    return int(dut.o_y.value)


# ------------------------------------------------------------
#  1) Clock-enable gating
# ------------------------------------------------------------
@cocotb.test()
async def test_ce_hold(dut):
    """o_y must NOT change while i_ce is de-asserted."""
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset_dut(dut)

    # Initial transaction with CE=1
    dut.i_ce.value, dut.i_stall.value, dut.i_force_stall.value = 1, 0, 0
    drive_operands(dut, 0x11111111, 0x22222222)
    y_initial = await capture_o_y(dut)

    # Toggle CE low; drive DIFFERENT operands
    dut.i_ce.value = 0
    drive_operands(dut, 0xAAAA_AAAA, 0x5555_5555)
    y_hold = await capture_o_y(dut)

    assert y_hold == y_initial, "o_y updated even though i_ce = 0"


# ------------------------------------------------------------
# 2) Pipeline stall gating
# ------------------------------------------------------------
@cocotb.test()
async def test_stall_hold(dut):
    """o_y must hold while upstream asserts i_stall=1."""
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset_dut(dut)

    dut.i_ce.value, dut.i_stall.value = 1, 0
    drive_operands(dut, 0x1234_5678, 0xFEDC_BA98)
    y_ref = await capture_o_y(dut)

    # Apply ordinary stall
    dut.i_stall.value = 1
    drive_operands(dut, 0x0BAD_C0DE, 0xDEAD_BEEF)
    y_stalled = await capture_o_y(dut)

    assert y_stalled == y_ref, "o_y changed during i_stall"


# ------------------------------------------------------------
# 3) Force-stall gating
# ------------------------------------------------------------
@cocotb.test()
async def test_force_stall(dut):
    """o_y must hold while i_force_stall=1 (even if i_stall=0)."""
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset_dut(dut)

    dut.i_ce.value, dut.i_force_stall.value = 1, 0
    drive_operands(dut, 0x0F0F_0F0F, 0x1010_1010)
    y_ref = await capture_o_y(dut)

    # Apply force-stall (pipeline back-pressure)
    dut.i_force_stall.value = 1
    drive_operands(dut, 0xAAAA_0000, 0x5555_0000)
    y_force = await capture_o_y(dut)

    assert y_force == y_ref, "o_y changed during i_force_stall"

# test_flush_only.py
import cocotb
from cocotb.clock    import Clock
from cocotb.triggers import RisingEdge, NextTimeStep, ReadOnly

ALU_ADD = 1 << 0   # one‑hot bit for ADD


# --------------------------------------------------------------------
#  Helpers
# --------------------------------------------------------------------
async def reset(dut):
    dut.i_rst_n.value = 0
    await RisingEdge(dut.i_clk)
    await RisingEdge(dut.i_clk)
    dut.i_rst_n.value = 1
    await RisingEdge(dut.i_clk)

def drive_add_operands(dut, a=1, b=1):
    dut.i_alu.value      = ALU_ADD
    dut.i_opcode.value   = 0         # keeps datapath simple
    dut.i_rs1.value      = a
    dut.i_rs2.value      = b
    dut.i_imm.value      = b
    dut.i_rs1_addr.value = 3
    dut.i_rd_addr.value  = 5


# --------------------------------------------------------------------
#  Flush handshake test
# --------------------------------------------------------------------
@cocotb.test()
async def flush_clock_enable(dut):
    """
    Expectations derived from rtl/rv32i_alu.v:

      1. While i_flush == 1, o_ce must be LOW.
      2. After i_flush returns to 0 (i_ce held HIGH) o_ce must
         return HIGH within 10 cycles.
      3. Thereafter o_ce mirrors i_ce.
    """
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset(dut)

    # ------------------- default drive -------------------
    dut.i_ce.value          = 1
    dut.i_stall.value       = 0
    dut.i_force_stall.value = 0
    dut.i_flush.value       = 0
    drive_add_operands(dut)

    await RisingEdge(dut.i_clk)      # let pipeline prime

    # ------------------- assert flush -------------------
    dut.i_flush.value = 1            # drive BEFORE edge
    await RisingEdge(dut.i_clk)      # cycle where flush is active
    await ReadOnly()
    assert dut.o_ce.value == 0, "o_ce not low during flush pulse"

    # ------------------- de‑assert flush ----------------
    await NextTimeStep()             # leave read‑only phase
    dut.i_flush.value = 0            # flush released

    # Wait up to 10 cycles for o_ce to come back HIGH
    for _ in range(10):
        await RisingEdge(dut.i_clk)
        await ReadOnly()
        if dut.o_ce.value == 1:
            break
    else:
        raise AssertionError("o_ce failed to resume within 10 cycles")

    # ---------------- verify o_ce tracks i_ce -----------
    await NextTimeStep()
    dut.i_ce.value = 0               # drop CE
    await RisingEdge(dut.i_clk)
    await ReadOnly()
    assert dut.o_ce.value == 0, "o_ce failed to follow i_ce low"

    await NextTimeStep()
    dut.i_ce.value = 1               # raise CE again
    await RisingEdge(dut.i_clk)
    await ReadOnly()
    assert dut.o_ce.value == 1, "o_ce failed to follow i_ce high"
