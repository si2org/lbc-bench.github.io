# test_rv32i_csr.py  – REVISED
#
# Works on the clean rv32i_csr.v and still fails on the intentionally-buggy
# version we created earlier.

import cocotb
from cocotb.clock    import Clock
from cocotb.triggers import RisingEdge, Timer

# ---------------------------------------------------------------------
#  Handy constants (mirror rv32i_header.vh)
# ---------------------------------------------------------------------
OPCODE_SYSTEM   = 1 << 9            # one-hot SYSTEM bit
FUNCT3_CSRRWI   = 0b101
FUNCT3_CSRRS    = 0b010
FUNCT3_CSRRCI   = 0b111

MSTATUS = 0x300
MIE     = 0x304
MCAUSE  = 0x342


# ---------------------------------------------------------------------
#  Utility helpers
# ---------------------------------------------------------------------
async def csr_transaction(dut, funct3, csr_idx, imm=0, rs1=0):
    """Issue a 1-cycle CSR op and capture o_csr_out two cycles later."""
    dut.i_opcode.value    = OPCODE_SYSTEM
    dut.i_funct3.value    = funct3
    dut.i_csr_index.value = csr_idx
    dut.i_imm.value       = imm
    dut.i_rs1.value       = rs1

    await RisingEdge(dut.i_clk)      # apply
    await RisingEdge(dut.i_clk)      # result ready
    result = int(dut.o_csr_out.value)

    # De-assert to avoid back-to-back ops
    dut.i_opcode.value = 0
    dut.i_funct3.value = 0
    await RisingEdge(dut.i_clk)
    return result


async def reset_dut(dut):
    """Power-on reset (two cycles low, then release)."""
    dut.i_rst_n.value = 0
    dut.i_ce.value    = 1
    dut.i_stall.value = 0

    # Zero the rest
    for sig in (
        'i_external_interrupt', 'i_software_interrupt', 'i_timer_interrupt',
        'i_is_inst_illegal', 'i_is_ecall', 'i_is_ebreak', 'i_is_mret',
        'writeback_change_pc', 'i_opcode', 'i_funct3', 'i_csr_index',
        'i_imm', 'i_rs1', 'i_y'
    ):
        getattr(dut, sig).value = 0

    dut.i_pc.value = 0

    # Hold reset
    await RisingEdge(dut.i_clk)
    await RisingEdge(dut.i_clk)
    dut.i_rst_n.value = 1
    await RisingEdge(dut.i_clk)
    await RisingEdge(dut.i_clk)


# ---------------------------------------------------------------------
#  TEST-1  – MEPC must equal the faulting PC
# ---------------------------------------------------------------------
@cocotb.test()
async def test_trap_pc_capture(dut):
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset_dut(dut)

    fault_pc = 0x100
    dut.i_pc.value            = fault_pc
    dut.i_is_inst_illegal.value = 1    # raise exception
    await RisingEdge(dut.i_clk)
    dut.i_is_inst_illegal.value = 0    # one-cycle pulse

    # Wait for trap handshake
    for _ in range(20):
        await RisingEdge(dut.i_clk)
        if dut.o_go_to_trap_q.value:
            break
    assert dut.o_go_to_trap_q.value, "Trap never asserted"

    # *** wait one extra edge so o_return_address gets the new MEPC ***
    await RisingEdge(dut.i_clk)
    captured_pc = int(dut.o_return_address.value)
    assert captured_pc == fault_pc, (
        f"BUG-1 detected: MEPC={hex(captured_pc)} should be {hex(fault_pc)}"
    )


# ---------------------------------------------------------------------
#  TEST-2  – External IRQ priority over timer
# ---------------------------------------------------------------------
@cocotb.test()
async def test_interrupt_priority(dut):
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset_dut(dut)

    # Enable global + individual interrupt bits
    await csr_transaction(dut, FUNCT3_CSRRWI, MSTATUS, imm=0x8)         # set MIE
    await csr_transaction(dut, FUNCT3_CSRRWI, MIE, imm=(1<<11)|(1<<7)|(1<<3))

    # Raise external and timer together
    dut.i_external_interrupt.value = 1
    dut.i_timer_interrupt.value    = 1
    dut.i_pc.value = 0x200

    # Wait for trap entry
    for _ in range(40):
        await RisingEdge(dut.i_clk)
        if dut.o_go_to_trap_q.value:
            break
    assert dut.o_go_to_trap_q.value, "Interrupt trap not taken"

    # Give the CSR logic a couple of free cycles before reading
    await RisingEdge(dut.i_clk)
    await RisingEdge(dut.i_clk)

    mcause = await csr_transaction(dut, FUNCT3_CSRRS, MCAUSE, rs1=0)
    expected = 0x8000000B            # external interrupt
    assert mcause == expected, (
        f"BUG-2 detected: MCAUSE={hex(mcause)} expected {hex(expected)}"
    )


# ---------------------------------------------------------------------
#  TEST-3  – CSRRCI must clear bits
# ---------------------------------------------------------------------
@cocotb.test()
async def test_csr_write_protect(dut):
    cocotb.start_soon(Clock(dut.i_clk, 10, unit="ns").start())
    await reset_dut(dut)

    init_mask = (1<<11)|(1<<7)|(1<<3)
    await csr_transaction(dut, FUNCT3_CSRRWI, MIE, imm=init_mask)

    mie_val = await csr_transaction(dut, FUNCT3_CSRRS, MIE, rs1=0)
    assert (mie_val & init_mask) == init_mask, "Initial MIE write failed"

    clear_mask = (1<<11)                 # clear external-IRQ enable
    await csr_transaction(dut, FUNCT3_CSRRCI, MIE, imm=clear_mask)
    mie_val2 = await csr_transaction(dut, FUNCT3_CSRRS, MIE, rs1=0)
    assert (mie_val2 & clear_mask) == 0, (
        "BUG-3 detected: CSRRCI did not clear bit 11 in MIE"
    )
