module async_fifo_tb;

    initial begin
    $dumpfile("async_fifo_tb.vcd");
    $dumpvars(0, async_fifo_tb);
    end
   //--------------------------------------------------------------------------
   //  Parameters – feel free to tune these for deeper or wider FIFOs.
   //--------------------------------------------------------------------------
   localparam int P_DATA_WIDTH = 32;
   localparam int P_ADDR_WIDTH =  4;      // depth = 2**P_ADDR_WIDTH (16)

   //--------------------------------------------------------------------------
   //  Clocks (fully asynchronous)
   //--------------------------------------------------------------------------
   real WR_CLK_PERIOD =  200;             //  
   real RD_CLK_PERIOD = 360;             // 

   logic i_wr_clk  = 0;
   logic i_rd_clk  = 0;

   initial forever #(WR_CLK_PERIOD/2) i_wr_clk = ~i_wr_clk;
   initial forever #(RD_CLK_PERIOD/2) i_rd_clk = ~i_rd_clk;

   //--------------------------------------------------------------------------
   //  Resets & I/O stimuli
   //--------------------------------------------------------------------------
   logic                     i_wr_rst_n;
   logic                     i_rd_rst_n;

   logic                     i_wr_en;
   logic                     i_rd_en;
   logic [P_DATA_WIDTH-1:0]  i_wr_data;

   wire                      o_fifo_full_dut;
   wire                      o_fifo_empty_dut;
   wire [P_DATA_WIDTH-1:0]   o_rd_data_dut;

   wire                      o_fifo_full_ref;
   wire                      o_fifo_empty_ref;
   wire [P_DATA_WIDTH-1:0]   o_rd_data_ref;

   //--------------------------------------------------------------------------
   //  Device‑Under‑Test 
   //--------------------------------------------------------------------------
   async_fifo #(
      .p_data_width (P_DATA_WIDTH),
      .p_addr_width (P_ADDR_WIDTH)
   ) dut (
      .i_wr_clk    (i_wr_clk),
      .i_wr_rst_n  (i_wr_rst_n),
      .i_wr_en     (i_wr_en),
      .i_wr_data   (i_wr_data),
      .o_fifo_full (o_fifo_full_dut),
      .i_rd_clk    (i_rd_clk),
      .i_rd_rst_n  (i_rd_rst_n),
      .i_rd_en     (i_rd_en),
      .o_rd_data   (o_rd_data_dut),
      .o_fifo_empty(o_fifo_empty_dut)
   );

   //--------------------------------------------------------------------------
   //  Golden reference model (100 % correct) – module names are suffixed “_ref”
   //--------------------------------------------------------------------------
   async_fifo_ref #(
      .p_data_width (P_DATA_WIDTH),
      .p_addr_width (P_ADDR_WIDTH)
   ) ref_fifo (
      .i_wr_clk    (i_wr_clk),
      .i_wr_rst_n  (i_wr_rst_n),
      .i_wr_en     (i_wr_en),
      .i_wr_data   (i_wr_data),
      .o_fifo_full (o_fifo_full_ref),
      .i_rd_clk    (i_rd_clk),
      .i_rd_rst_n  (i_rd_rst_n),
      .i_rd_en     (i_rd_en),
      .o_rd_data   (o_rd_data_ref),
      .o_fifo_empty(o_fifo_empty_ref)
   );

   //--------------------------------------------------------------------------
   //  Error counter & helper task
   //--------------------------------------------------------------------------
   int unsigned err_cnt = 0;

   task automatic check (bit condition, string msg);
      if (!condition) begin
         $error("%0t  %s", $time, msg);
         err_cnt++;
      end
   endtask

   //--------------------------------------------------------------------------
   //  Reset sequence – synchronous to both domains
   //--------------------------------------------------------------------------
   initial begin
      i_wr_en     = 0;
      i_rd_en     = 0;
      i_wr_data   = '0;
      i_wr_rst_n  = 0;
      i_rd_rst_n  = 0;
      repeat (5) @(posedge i_wr_clk);
      repeat (5) @(posedge i_rd_clk);
      i_wr_rst_n  = 1;
      i_rd_rst_n  = 1;
   end

   //--------------------------------------------------------------------------
   //  Stimulus & scoreboard
   //--------------------------------------------------------------------------
   bit [P_DATA_WIDTH-1:0] score_q[$];     // expected read‑back values

   // Write driver & score‑capture
   always @(posedge i_wr_clk) begin
      i_wr_en   <= ($urandom_range(0,9) < 7);      // 70 % chance to attempt write
      i_wr_data <= $urandom();

      if (i_wr_rst_n && i_wr_en && !o_fifo_full_ref)
         score_q.push_back(i_wr_data);
   end

   // Read driver, data comparison (with 1‑cycle latency for synchronous RAM)
   reg [P_DATA_WIDTH-1:0] exp_d /* verilator keep */;
   reg [P_DATA_WIDTH-1:0] tmp /* verilator keep */;
   always @(posedge i_rd_clk) begin
      i_rd_en <= ($urandom_range(0,9) < 7);        // 70 % chance to attempt read

      tmp = 'x;
      if (i_rd_rst_n && i_rd_en && !o_fifo_empty_ref) begin
         check(score_q.size() > 0, "Reference queue under‑flow");
         if (score_q.size() > 0) tmp = score_q.pop_front();
      end
      exp_d <= tmp;                                // delay one cycle

      // ----------------------------------------------------------------
      //  DUT vs REF comparisons (FLAGS & DATA)
      // ----------------------------------------------------------------
      // FULL flag – owned by write clock domain
      check(o_fifo_full_dut === o_fifo_full_ref,
             "FULL flag mismatch (write domain)");
      // EMPTY flag – owned by read clock domain
      check(o_fifo_empty_dut === o_fifo_empty_ref,
             "EMPTY flag mismatch (read domain)");

      // Data compare once valid word expected
      if (exp_d !== 'x) begin
         check(o_rd_data_ref  === exp_d,
                $sformatf("Reference read data incorrect. Exp %h Got %h",
                          exp_d, o_rd_data_ref));
         check(o_rd_data_dut === o_rd_data_ref,
                $sformatf("DUT read data mismatch. Exp %h Got %h",
                          o_rd_data_ref, o_rd_data_dut));
      end
   end

   //--------------------------------------------------------------------------
   //  Finish after fixed time or on too many errors
   //--------------------------------------------------------------------------
   initial begin
   #200000;                      
      if (err_cnt == 0) $display("\n*** TEST PASSED – no mismatches detected ***\n");
      else               $display("\n*** TEST FAILED – %0d errors detected ***\n", err_cnt);
      $finish;
   end

endmodule : async_fifo_tb

/* ===========================================================================
 *  Reference RTL  (golden, 100 % correct)
 *  All module names are uniquely suffixed with _ref so they do NOT clash
 *  with the DUT's sub‑modules.
 * ========================================================================*/
module async_fifo_ref
   #(parameter p_data_width = 32,
     parameter p_addr_width = 16)
   (
    input  wire                     i_wr_clk,
    input  wire                     i_wr_rst_n,
    input  wire                     i_wr_en,
    input  wire [p_data_width-1:0]  i_wr_data,
    output wire                     o_fifo_full,
    input  wire                     i_rd_clk,
    input  wire                     i_rd_rst_n,
    input  wire                     i_rd_en,
    output wire [p_data_width-1:0]  o_rd_data,
    output wire                     o_fifo_empty
   );

   // -------------------------------------------------------------------
   //  Internal pointer & synchroniser signals
   // -------------------------------------------------------------------
   wire [p_addr_width-1:0] w_wr_bin_addr;
   wire [p_addr_width-1:0] w_rd_bin_addr;
   wire [p_addr_width  :0] w_wr_grey_addr;
   wire [p_addr_width  :0] w_rd_grey_addr;
   wire [p_addr_width  :0] w_rd_ptr_sync;
   wire [p_addr_width  :0] w_wr_ptr_sync;

   // -------------------------------------------------------------------
   //  Instantiations – all suffixed _ref
   // -------------------------------------------------------------------
   read_to_write_pointer_sync_ref #(.p_addr_width(p_addr_width)) rd2wr_ref (
      .o_rd_ptr_sync (w_rd_ptr_sync),
      .i_rd_grey_addr(w_rd_grey_addr),
      .i_wr_clk      (i_wr_clk),
      .i_wr_rst_n    (i_wr_rst_n)
   );

   write_to_read_pointer_sync_ref #(.p_addr_width(p_addr_width)) wr2rd_ref (
      .i_rd_clk      (i_rd_clk),
      .i_rd_rst_n    (i_rd_rst_n),
      .i_wr_grey_addr(w_wr_grey_addr),
      .o_wr_ptr_sync (w_wr_ptr_sync)
   );

   wptr_full_ref #(.p_addr_width(p_addr_width)) wptr_ref (
      .i_wr_clk      (i_wr_clk),
      .i_wr_rst_n    (i_wr_rst_n),
      .i_wr_en       (i_wr_en),
      .i_rd_ptr_sync (w_rd_ptr_sync),
      .o_fifo_full   (o_fifo_full),
      .o_wr_bin_addr (w_wr_bin_addr),
      .o_wr_grey_addr(w_wr_grey_addr)
   );

   fifo_memory_ref #(.p_data_width(p_data_width), .p_addr_width(p_addr_width)) mem_ref (
      .i_wr_clk     (i_wr_clk),
      .i_wr_clk_en  (i_wr_en),
      .i_wr_addr    (w_wr_bin_addr),
      .i_wr_data    (i_wr_data),
      .i_wr_full    (o_fifo_full),
      .i_rd_clk     (i_rd_clk),
      .i_rd_clk_en  (i_rd_en),
      .i_rd_addr    (w_rd_bin_addr),
      .o_rd_data    (o_rd_data)
   );

   rptr_empty_ref #(.p_addr_width(p_addr_width)) rptr_ref (
      .i_rd_clk      (i_rd_clk),
      .i_rd_rst_n    (i_rd_rst_n),
      .i_rd_en       (i_rd_en),
      .i_wr_ptr_sync (w_wr_ptr_sync),
      .o_fifo_empty  (o_fifo_empty),
      .o_rd_bin_addr (w_rd_bin_addr),
      .o_rd_grey_addr(w_rd_grey_addr)
   );

endmodule : async_fifo_ref

/* --------------------------------------------------------------------------- */
module fifo_memory_ref
   #(parameter p_data_width = 32,
     parameter p_addr_width = 16)
   (
    input  wire                     i_wr_clk,
    input  wire                     i_wr_clk_en,
    input  wire [p_addr_width-1:0]  i_wr_addr,
    input  wire [p_data_width-1:0]  i_wr_data,
    input  wire                     i_wr_full,
    input  wire                     i_rd_clk,
    input  wire                     i_rd_clk_en,
    input  wire [p_addr_width-1:0]  i_rd_addr,
    output reg  [p_data_width-1:0]  o_rd_data
   );

   localparam int P_DEPTH = 1 << p_addr_width;
   reg [p_data_width-1:0] mem [0:P_DEPTH-1];

   always @(posedge i_wr_clk) begin
      if (i_wr_clk_en && !i_wr_full)
         mem[i_wr_addr] <= i_wr_data;
   end

   always @(posedge i_rd_clk) begin
      if (i_rd_clk_en)
         o_rd_data <= mem[i_rd_addr];
   end
endmodule : fifo_memory_ref

/* --------------------------------------------------------------------------- */
module read_to_write_pointer_sync_ref
   #(parameter p_addr_width = 16)
   (
    input  wire                      i_wr_clk,
    input  wire                      i_wr_rst_n,
    input  wire [p_addr_width:0]     i_rd_grey_addr,
    output reg  [p_addr_width:0]     o_rd_ptr_sync
   );
   reg [p_addr_width:0] rd_ff;
   always @(posedge i_wr_clk or negedge i_wr_rst_n) begin
      if (!i_wr_rst_n) begin
         rd_ff        <= '0;
         o_rd_ptr_sync<= '0;
      end else begin
         rd_ff        <= i_rd_grey_addr;
         o_rd_ptr_sync<= rd_ff;
      end
   end
endmodule : read_to_write_pointer_sync_ref

/* --------------------------------------------------------------------------- */
module write_to_read_pointer_sync_ref
   #(parameter p_addr_width = 16)
   (
    input  wire                      i_rd_clk,
    input  wire                      i_rd_rst_n,
    input  wire [p_addr_width:0]     i_wr_grey_addr,
    output reg  [p_addr_width:0]     o_wr_ptr_sync
   );
   reg [p_addr_width:0] wr_ff;
   always @(posedge i_rd_clk or negedge i_rd_rst_n) begin
      if (!i_rd_rst_n) begin
         wr_ff        <= '0;
         o_wr_ptr_sync<= '0;
      end else begin
         wr_ff        <= i_wr_grey_addr;
         o_wr_ptr_sync<= wr_ff;
      end
   end
endmodule : write_to_read_pointer_sync_ref

/* --------------------------------------------------------------------------- */
module wptr_full_ref
   #(parameter p_addr_width = 16)
   (
    input  wire                     i_wr_clk,
    input  wire                     i_wr_rst_n,
    input  wire                     i_wr_en,
    input  wire [p_addr_width  :0]  i_rd_ptr_sync,
    output reg                      o_fifo_full,
    output wire [p_addr_width-1:0]  o_wr_bin_addr,
    output reg  [p_addr_width  :0]  o_wr_grey_addr
   );
   reg  [p_addr_width:0] wr_bin;
   wire [p_addr_width:0] nxt_bin = wr_bin + (i_wr_en & ~o_fifo_full);
   wire [p_addr_width:0] nxt_grey= (nxt_bin >> 1) ^ nxt_bin;
   wire full_cond = (nxt_grey == {~i_rd_ptr_sync[p_addr_width:p_addr_width-1],
                                  i_rd_ptr_sync[p_addr_width-2:0]});

   always @(posedge i_wr_clk or negedge i_wr_rst_n) begin
      if (!i_wr_rst_n) begin
         wr_bin       <= '0;
         o_wr_grey_addr<= '0;
         o_fifo_full  <= 1'b0;
      end else begin
         wr_bin       <= nxt_bin;
         o_wr_grey_addr<= nxt_grey;
         o_fifo_full  <= full_cond;
      end
   end
   assign o_wr_bin_addr = wr_bin[p_addr_width-1:0];
endmodule : wptr_full_ref

/* --------------------------------------------------------------------------- */
module rptr_empty_ref
   #(parameter p_addr_width = 16)
   (
    input  wire                     i_rd_clk,
    input  wire                     i_rd_rst_n,
    input  wire                     i_rd_en,
    input  wire [p_addr_width  :0]  i_wr_ptr_sync,
    output reg                      o_fifo_empty,
    output wire [p_addr_width-1:0]  o_rd_bin_addr,
    output reg  [p_addr_width  :0]  o_rd_grey_addr
   );
   reg  [p_addr_width:0] rd_bin;
   wire [p_addr_width:0] nxt_bin = rd_bin + (i_rd_en & ~o_fifo_empty);
   wire [p_addr_width:0] nxt_grey= (nxt_bin >> 1) ^ nxt_bin;
   wire empty_cond = (nxt_grey == i_wr_ptr_sync);

   always @(posedge i_rd_clk or negedge i_rd_rst_n) begin
      if (!i_rd_rst_n) begin
         rd_bin       <= '0;
         o_rd_grey_addr<= '0;
         o_fifo_empty <= 1'b1;
      end else begin
         rd_bin       <= nxt_bin;
         o_rd_grey_addr<= nxt_grey;
         o_fifo_empty <= empty_cond;
      end
   end
   assign o_rd_bin_addr = rd_bin[p_addr_width-1:0];
endmodule : rptr_empty_ref
