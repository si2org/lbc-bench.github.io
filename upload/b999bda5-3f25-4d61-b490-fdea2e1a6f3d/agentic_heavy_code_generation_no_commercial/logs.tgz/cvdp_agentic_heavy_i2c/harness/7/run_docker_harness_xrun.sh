#!/bin/bash

# Auto-generated script to run harness Docker container
# Usage: run_docker_harness_xrun.sh [-d] (where -d enables debug mode with bash entrypoint)
set -e

# Parse command line arguments
DEBUG_MODE=false
while getopts 'd' flag; do
  case "${flag}" in
    d) DEBUG_MODE=true ;;
  esac
done

# Use shared bridge network: cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc
NETWORK_CREATED=0

# Check if network exists, create if needed
if ! docker network inspect cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc &>/dev/null; then
  echo "Creating Docker network cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc..."
  docker network create --driver bridge cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc
  NETWORK_CREATED=1
fi

# Function to clean up resources
cleanup() {
  echo "Cleaning up Docker resources..."
  docker compose -f <source-results>/cvdp_agentic_heavy_i2c/harness/7/docker-compose.yml -p cvdp_agentic_heavy_i2c_7_1784862637 kill xrun 2>/dev/null || true
  docker rmi cvdp_agentic_heavy_i2c_7_1784862637-xrun 2>/dev/null || true
  if [ $NETWORK_CREATED -eq 1 ]; then
    echo "Removing Docker network cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc..."
    docker network rm cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc 2>/dev/null || true
  fi
}

# Set up cleanup trap
trap cleanup EXIT

# Run the harness container
echo "Running harness with project name: cvdp_agentic_heavy_i2c_7_1784862637"
# Get current user and group IDs
USER_ID=$(id -u)
GROUP_ID=$(id -g)

if [ "$DEBUG_MODE" = true ]; then
  echo "DEBUG MODE: Starting container with bash entrypoint"
  docker compose -f <source-results>/cvdp_agentic_heavy_i2c/harness/7/docker-compose.yml -p cvdp_agentic_heavy_i2c_7_1784862637 run --rm --user $USER_ID:$GROUP_ID -e HOME=/rundir -e XDG_CACHE_HOME=/rundir/.cache --entrypoint bash -v cvdp_agentic_heavy_i2c_0007_workspace:/code -v "<source-results>/cvdp_agentic_heavy_i2c/harness/7/src:/src" -v "<source-results>/cvdp_agentic_heavy_i2c/harness/7/rundir:/rundir" -v "<home>/for_github/cvdp_benchmark/llm_lib:/pysubj" --rm -w /rundir xrun
else
  docker compose -f <source-results>/cvdp_agentic_heavy_i2c/harness/7/docker-compose.yml -p cvdp_agentic_heavy_i2c_7_1784862637 run --rm --user $USER_ID:$GROUP_ID -e HOME=/rundir -e XDG_CACHE_HOME=/rundir/.cache -v cvdp_agentic_heavy_i2c_0007_workspace:/code -v "<source-results>/cvdp_agentic_heavy_i2c/harness/7/src:/src" -v "<source-results>/cvdp_agentic_heavy_i2c/harness/7/rundir:/rundir" -v "<home>/for_github/cvdp_benchmark/llm_lib:/pysubj" --rm -w /rundir xrun
fi
exit_code=$?

# Exit with the same code as the docker command
exit $exit_code
