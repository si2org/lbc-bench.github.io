module router_register_tb;
  reg        clock;
  reg        resetn;

  // Stimulus signals
  reg        pkt_valid;
  reg  [7:0] data_in;
  reg        fifo_full;
  reg        detect_add;
  reg        lfd_state;
  reg        ld_state;
  reg        laf_state;
  reg        full_state;
  reg        rst_int_reg;

  // DUT outputs
  wire [7:0] dout;
  wire       low_packet_valid;
  wire       parity_done;
  wire       err;

  // Instantiate DUT
  router_register uut (
    .clock            (clock),
    .resetn           (resetn),
    .pkt_valid        (pkt_valid),
    .data_in          (data_in),
    .fifo_full        (fifo_full),
    .detect_add       (detect_add),
    .lfd_state        (lfd_state),
    .ld_state         (ld_state),
    .laf_state        (laf_state),
    .full_state       (full_state),
    .rst_int_reg      (rst_int_reg),
    .dout             (dout),
    .low_packet_valid (low_packet_valid),
    .parity_done      (parity_done),
    .err              (err)
  );

  // Clock generation: 10ns period
  initial begin
    clock = 0;
    forever #5 clock = ~clock;
  end

  // Simple assertion task
  task assert_eq(input [7:0] a, input [7:0] b, input string name);
    if (a !== b) begin
      $error("[%0t] ASSERT FAIL: %s: expected 0x%0h, got 0x%0h", $time, name, b, a);
      $fatal(1);
    end
    else begin
      $display("[%0t] PASS: %s = 0x%0h", $time, name, a);
    end
  endtask

  task assert_bit(input bit a, input bit b, input string name);
    if (a !== b) begin
      $error("[%0t] ASSERT FAIL: %s: expected %0b, got %0b", $time, name, b, a);
      $fatal(1);
    end else begin
      $display("[%0t] PASS: %s = %0b", $time, name, a);
    end
  endtask

  //----------------------------------------------
  // Utility: capture current dout as seed value
  //----------------------------------------------
  reg [7:0] seed_val;
  task dout_check_seed();
    begin
      @(negedge clock);         // sample on stable edge
      seed_val = dout;
    end
  endtask

  //------------------------------------------------
  // Local stimulus helpers
  //------------------------------------------------
  task drive_defaults();
    begin
      pkt_valid   = 0;
      data_in     = 8'h00;
      fifo_full   = 0;
      detect_add  = 0;
      lfd_state   = 0;
      ld_state    = 0;
      laf_state   = 0;
      full_state  = 0;
      rst_int_reg = 0;
    end
  endtask

  // Test sequence
  initial begin
    // Initialize
    resetn           = 0;
    pkt_valid        = 0;
    data_in          = 8'h00;
    fifo_full        = 0;
    detect_add       = 0;
    lfd_state        = 0;
    ld_state         = 0;
    laf_state        = 0;
    full_state       = 0;
    rst_int_reg      = 0;

    #20;                 // wait 2 cycles
    resetn = 1;         // release reset
    #10;

    //-------------------------------------------
    // 1) HEADER CAPTURE & dout on lfd_state
    //-------------------------------------------
    $display("--- Test 1: Header capture ---");
    // Simulate detect_add pulse with valid header byte
    data_in    = 8'hA5;
    pkt_valid  = 1;
    detect_add = 1;
    #10;                // one clock
    detect_add = 0;
    lfd_state  = 1;
    #10;                // on lfd_state, dout should be header (A5)
    assert_eq(dout, 8'hA5, "dout header");
    lfd_state  = 0;
    pkt_valid  = 0;
    #10;

    resetn = 0;
    #20;
    resetn = 1;
    #10;

    //----------------------------------------------
    // CASE 1a: detect_add asserted – dout must hold
    //----------------------------------------------
    $display("\n--- CASE 1a: detect_add hold path ---");
    drive_defaults();
    dout_check_seed();           // capture current dout value
    detect_add  = 1;
    data_in     = 8'hAA;
    pkt_valid   = 1;
    #10;
    assert_eq(dout, seed_val, "dout holds during detect_add");
    detect_add = 0;

    //----------------------------------------------
    // CASE 1b: lfd_state asserted – dout = header
    //----------------------------------------------
    $display("\n--- CASE 1b: lfd_state header path ---");
    drive_defaults();
    // fake header captured earlier; emulate header byte 0x11
    detect_add = 1; pkt_valid = 1; data_in = 8'h11; #10;
    detect_add = 0; pkt_valid = 0;
    lfd_state = 1;  // first data cycle
    #10;
    assert_eq(dout, 8'h11, "dout header byte");
    lfd_state = 0;

    //----------------------------------------------
    // CASE 1c: ld_state & fifo_full == 0 – dout = data_in
    //----------------------------------------------
    $display("\n--- CASE 1c: normal payload path ---");
    drive_defaults();
    ld_state   = 1;
    fifo_full  = 0;
    data_in    = 8'h22;
    #10;
    assert_eq(dout, 8'h22, "dout payload when FIFO not full");
    ld_state = 0;

    //----------------------------------------------
    // CASE 1d: ld_state & fifo_full == 1 – dout holds (buffer)
    //----------------------------------------------
    $display("\n--- CASE 1d: FIFO‑full hold path ---");
    drive_defaults();
    // Seed dout with known value so we can detect hold
    dout_check_seed();
    ld_state   = 1;
    fifo_full  = 1;
    data_in    = 8'h33;         // should be captured in buffer, NOT on dout
    #10;
    assert_eq(dout, seed_val, "dout holds when FIFO full");
    ld_state = 0; fifo_full = 0;

    //----------------------------------------------
    // CASE 1e: laf_state replay – dout = buffered byte
    //----------------------------------------------
    $display("\n--- CASE 1e: replay buffered byte path ---");
    // laf_state asserted one cycle after we release FIFO full
    laf_state  = 1;
    #10;
    assert_eq(dout, 8'h33, "dout replays buffered byte");
    laf_state = 0;

    //----------------------------------------------
    // CASE 1f: idle hold – no state strobes asserted
    //----------------------------------------------
    $display("\n--- CASE 1f: idle hold path ---");
    drive_defaults();
    // preload dout
    dout_check_seed();
    #10;
    assert_eq(dout, seed_val, "dout holds when idle");

    //-------------------------------------------
    // 2) PAYLOAD LOAD & parity accumulation
    //-------------------------------------------
    $display("--- Test 2: Payload load & parity ---");
    // Send two payload bytes 0x01, 0x02
    // Expected internal_parity = A5 ^ 01 ^ 02 = A6
    pkt_valid = 1;
    ld_state  = 1;
    data_in   = 8'h01;
    full_state = 0;
    #10;
    assert_eq(dout, 8'h01, "dout first payload");
    data_in = 8'h02;
    #10;
    assert_eq(dout, 8'h02, "dout second payload");
    ld_state = 0;
    pkt_valid = 0;
    #10;

    //-------------------------------------------
    // 3) LOW_PACKET_VALID pulse
    //-------------------------------------------
    $display("--- Test 3: low_packet_valid pulse ---");
    // On ld_state deasserting pkt_valid, low_packet_valid should go high
    rst_int_reg = 1; // reset internal parity register
    #10;  // wait for reset to take effect
    assert_bit(low_packet_valid, 1'b0, "low_packet_valid reset complete");
    rst_int_reg = 0; // release reset
    ld_state = 1;
    pkt_valid = 0;
    #10;
    assert_bit(low_packet_valid, 1'b1, "low_packet_valid");
    ld_state = 0;
    #10;

    //-------------------------------------------
    // 4) PARITY BYTE & parity_done
    //-------------------------------------------
    $display("--- Test 4: Parity capture & done ---");
    // Transmitter sends parity byte, which is internal_parity (12)
    data_in = 8'h12;
    ld_state = 1;
    pkt_valid = 0;
    fifo_full = 0;
    #10;
    // parity_done should assert
    assert_bit(parity_done, 1'b1, "parity_done");
    // packet_parity should match
    // err should be 0 for correct parity
    #10;
    assert_bit(err, 1'b0, "err (good parity)");
    ld_state = 0;
    #10;

    //-------------------------------------------
    // 5) Parity error detection
    //-------------------------------------------
    $display("--- Test 5: Parity error detection ---");
    // Start new packet
    detect_add = 1; pkt_valid = 1; data_in = 8'hFF;
    #10; detect_add = 0; lfd_state = 1; pkt_valid = 0;
    #10; lfd_state = 0;
    // Internal parity = FF
    // Send wrong parity 0x00
    data_in = 8'h00; ld_state = 1; pkt_valid = 0;
    #10;
    #10;
    assert_bit(err, 1'b1, "err (bad parity)");
    ld_state = 0;
    #10;

    //-------------------------------------------
    // 6) FIFO-FULL buffering & replay (laf_state)
    //-------------------------------------------
    $display("--- Test 6: FIFO full buffering & replay ---");
    // New packet header
    detect_add = 1; pkt_valid = 1; data_in = 8'h10;
    #10; detect_add = 0; lfd_state = 1; pkt_valid = 0;
    #10; lfd_state = 0;
    // Payload byte arrives but FIFO full
    ld_state = 1; fifo_full = 1; data_in = 8'h55;
    #10;
    // full_state_byte should buffer 0x55; dout holds prior value
    assert_eq(dout, 8'h10, "dout holds before replay");
    ld_state = 0; fifo_full = 0; full_state = 1;
    #10;
    // Now laf_state: replay buffered byte
    laf_state = 1;
    #10;
    assert_eq(dout, 8'h55, "dout replay buffered");
    laf_state = 0; full_state = 0;
    #10;

    $display("All register tests completed.");
    $finish;
  end


  initial begin
      $dumpfile("router_register_tb.vcd");
      $dumpvars(0, router_register_tb);
  end
endmodule
