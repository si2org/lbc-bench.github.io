module router_fsm_tb;
  // Clock and reset
  reg        clock;
  reg        resetn;

  // Inputs to DUT
  reg        pkt_valid;
  reg  [1:0] data_in;
  reg        fifo_full;
  reg        fifo_empty_0;
  reg        fifo_empty_1;
  reg        fifo_empty_2;
  reg        soft_reset_0;
  reg        soft_reset_1;
  reg        soft_reset_2;
  reg        parity_done;
  reg        low_packet_valid;

  // Outputs from DUT
  wire       write_enb_reg;
  wire       detect_add;
  wire       ld_state;
  wire       laf_state;
  wire       lfd_state;
  wire       full_state;
  wire       rst_int_reg;
  wire       busy;

  // State values for internal reference
  localparam DECODE_ADDRESS   = 3'b000;
  localparam LOAD_FIRST_DATA  = 3'b001;
  localparam WAIT_TILL_EMPTY  = 3'b010;

  // Instantiate the FSM
  router_fsm uut (
    .clock(clock),
    .resetn(resetn),
    .pkt_valid(pkt_valid),
    .data_in(data_in),
    .fifo_full(fifo_full),
    .fifo_empty_0(fifo_empty_0),
    .fifo_empty_1(fifo_empty_1),
    .fifo_empty_2(fifo_empty_2),
    .soft_reset_0(soft_reset_0),
    .soft_reset_1(soft_reset_1),
    .soft_reset_2(soft_reset_2),
    .parity_done(parity_done),
    .low_packet_valid(low_packet_valid),
    .write_enb_reg(write_enb_reg),
    .detect_add(detect_add),
    .ld_state(ld_state),
    .laf_state(laf_state),
    .lfd_state(lfd_state),
    .full_state(full_state),
    .rst_int_reg(rst_int_reg),
    .busy(busy)
  );

  // Clock generation
  initial begin
    clock = 0;
    forever #5 clock = ~clock;
  end

  // Simple assertion task
  task assert_signal(input bit cond, input string name);
    begin
      if (!cond) begin
        $error("[ERROR] %s failed at time %0t", name, $time);
        $fatal(1);
      end
      else
        $display("[PASS] %s at time %0t", name, $time);
    end
  endtask

  // Test sequence
  initial begin
    // Initialize inputs
    resetn           = 0;
    pkt_valid        = 0;
    data_in          = 2'd0;
    fifo_full        = 0;
    fifo_empty_0     = 1;
    fifo_empty_1     = 1;
    fifo_empty_2     = 1;
    soft_reset_0     = 0;
    soft_reset_1     = 0;
    soft_reset_2     = 0;
    parity_done      = 0;
    low_packet_valid = 0;

    // Apply reset
    #20;
    resetn = 1;
    #10;

    // After reset, should be in DECODE_ADDRESS
    assert_signal(detect_add,      "detect_add after reset");
    assert_signal(!busy,           "busy after reset");

    // --------- Test 1: Normal packet to FIFO0 ---------
    $display("-- Test 1: Normal packet to FIFO0 --");
    data_in       = 2'd0;
    fifo_empty_0  = 1;
    pkt_valid     = 1;
    #10;
    assert_signal(lfd_state,       "LF first data");
    #10;
    assert_signal(ld_state,        "LD state begin");

    #30;
    pkt_valid = 0;
    low_packet_valid = 1;
    #10;
    assert_signal(write_enb_reg,  "write_enb in LOAD_PARITY");
    #10;
    assert_signal(rst_int_reg,    "rst_int_reg in CHECK_PARITY_ERROR");
    #10;

    // --------- Test 2: FIFO full during data load ---------
    $display("-- Test 2: FIFO full mid-packet --");
    soft_reset_0 = 1;
    #10;
    soft_reset_0 = 0;
    #10;
    data_in       = 2'd1;
    fifo_empty_1  = 1;
    pkt_valid     = 1;
    #10;
    assert_signal(lfd_state,      "LF first data (FIFO1)");
    #10;
    assert_signal(ld_state,       "LD state begin (FIFO1)");

    #10;
    fifo_full = 1;
    #10;
    assert_signal(full_state,     "full_state asserted");
    assert_signal(busy,           "busy during FIFO_FULL_STATE");

    fifo_full = 0;
    #10;
    parity_done      = 0;
    assert_signal(laf_state,      "laf_state asserted");
    low_packet_valid = 0;
    #10;
    assert_signal(ld_state,       "back to LD state after full");

    pkt_valid        = 0;
    low_packet_valid = 1;
    #10;
    assert_signal(write_enb_reg,  "write_enb in parity after full");
    #10;
    assert_signal(rst_int_reg,    "rst_int_reg in parity check after full");

    // --------- Test 3: DECODE_ADDRESS -> WAIT_TILL_EMPTY ---------
    $display("-- Test 3: Entry to WAIT_TILL_EMPTY state --");
    // Ensure FSM idle
    soft_reset_2 = 1; #10; soft_reset_2 = 0; #10;
    // Target FIFO2 is not empty, packet arrives
    data_in       = 2'd2;
    fifo_empty_2  = 0;
    pkt_valid     = 1;
    #10;
    // Check internal state is WAIT_TILL_EMPTY
    assert_signal(uut.present_state == WAIT_TILL_EMPTY,
                  "FSM entered WAIT_TILL_EMPTY");

    $display("All tests completed");
    $finish;
  end


  initial begin
      $dumpfile("router_fsm_tb.vcd");
      $dumpvars(0, router_fsm_tb);
  end
endmodule
