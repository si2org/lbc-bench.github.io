import cocotb
from cocotb.triggers import Timer
import logging
import random

def check_condition(condition, fail_msg, pass_msg, test_failures):
    if not condition:
        cocotb.log.error(fail_msg)
        test_failures.append(fail_msg)
    else:
        cocotb.log.info(pass_msg)

def ref_lowest(nr, req):
    """Reference model for lowest_nr_identifier_8 logic."""
    min_val = None
    min_idx = None
    for i in range(8):
        if req[i]:
            if (min_val is None) or (nr[i] < min_val) or (nr[i] == min_val and i > min_idx):
                min_val = nr[i]
                min_idx = i
    if min_val is None:
        return (0, 0, 0)  # no valid request
    else:
        return (min_val, min_idx, 1)

@cocotb.test()
async def test_lowest_nr_identifier_8(dut):
    """Full stimulus and checker for lowest_nr_identifier_8"""

    logger = dut._log
    logger.setLevel(logging.INFO)
    test_failures = []

    # Test 1: Only one req active in each line
    for i in range(8):
        nr_vec = [random.randint(0, 255) for _ in range(8)]
        packed_nr = 0
        for i in range(8):
            packed_nr = (packed_nr << 8) | nr_vec[7 - i]

        req_vec = [0]*8
        req_vec[i] = 1
        packed_req = 0
        for i in range(8):
            packed_req = (packed_req << 1) | req_vec[7 - i]

        for j in range(8):
            dut.nr.value = packed_nr
            dut.req.value = packed_req
        await Timer(1, unit="ns")
        exp_val, exp_idx, exp_valid = ref_lowest(nr_vec, req_vec)
        check_condition(
            int(dut.lowest_valid.value) == exp_valid,
            f"FAIL: only req[{i}]=1: lowest_valid={int(dut.lowest_valid.value)} exp={exp_valid}",
            f"PASS: only req[{i}]=1: lowest_valid={int(dut.lowest_valid.value)}",
            test_failures
        )
        if exp_valid:
            check_condition(
                int(dut.lowest_nr.value) == exp_val,
                f"FAIL: only req[{i}]=1: lowest_nr=0x{int(dut.lowest_nr.value):02x} exp=0x{exp_val:02x}",
                f"PASS: only req[{i}]=1: lowest_nr=0x{int(dut.lowest_nr.value):02x}",
                test_failures
            )
            check_condition(
                int(dut.lowest_line.value) == exp_idx,
                f"FAIL: only req[{i}]=1: lowest_line={int(dut.lowest_line.value)} exp={exp_idx}",
                f"PASS: only req[{i}]=1: lowest_line={int(dut.lowest_line.value)}",
                test_failures
            )

    # Test 2: All req active, random nr, covers tie-break
    for t in range(5):
        nr_vec = [random.randint(0, 255) for _ in range(8)]
        packed_nr = 0
        for i in range(8):
            packed_nr = (packed_nr << 8) | nr_vec[7 - i]

        req_vec = [1]*8
        packed_req = 0
        for i in range(8):
            packed_req = (packed_req << 1) | req_vec[7 - i]

        for j in range(8):
            dut.nr.value = packed_nr
            dut.req.value = packed_req
        await Timer(1, unit="ns")
        exp_val, exp_idx, exp_valid = ref_lowest(nr_vec, req_vec)
        check_condition(
            int(dut.lowest_nr.value) == exp_val,
            f"FAIL: all req: lowest_nr=0x{int(dut.lowest_nr.value):02x} exp=0x{exp_val:02x}",
            f"PASS: all req: lowest_nr=0x{int(dut.lowest_nr.value):02x}",
            test_failures
        )
        check_condition(
            int(dut.lowest_line.value) == exp_idx,
            f"FAIL: all req: lowest_line={int(dut.lowest_line.value)} exp={exp_idx}",
            f"PASS: all req: lowest_line={int(dut.lowest_line.value)}",
            test_failures
        )

    # Test 3: No req active
    nr_vec = [random.randint(0, 255) for _ in range(8)]
    packed_nr = 0
    for i in range(8):
        packed_nr = (packed_nr << 8) | nr_vec[7 - i]

    req_vec = [0]*8
    packed_req = 0
    for i in range(8):
        packed_req = (packed_req << 1) | req_vec[7 - i]

    for j in range(8):
        dut.nr.value = packed_nr
        dut.req.value = packed_req
    await Timer(1, unit="ns")
    exp_val, exp_idx, exp_valid = ref_lowest(nr_vec, req_vec)
    check_condition(
        int(dut.lowest_valid.value) == 0,
        f"FAIL: no req active: lowest_valid={int(dut.lowest_valid.value)} exp=0",
        f"PASS: no req active: lowest_valid=0",
        test_failures
    )

    # Test 4: Multiple tied lowest values, prefer highest index
    min_val = 0x22
    # Define specific values for nr_vec (for example)
    nr_vec = [0x10, min_val, 0x33, min_val, 0x44, min_val, 0x55, min_val]
    # Only indices 1, 3, 5, 7 are enabled
    req_vec = [0, 1, 0, 1, 0, 1, 0, 1]

    # Pack nr_vec and req_vec as single integers
    packed_nr = 0
    for i in range(8):
        packed_nr = (packed_nr << 8) | nr_vec[7 - i]

    packed_req = 0
    for i in range(8):
        packed_req = (packed_req << 1) | req_vec[7 - i]

    dut.nr.value = packed_nr
    dut.req.value = packed_req
    await Timer(1, unit="ns")

    exp_val, exp_idx, exp_valid = ref_lowest(nr_vec, req_vec)
    check_condition(
        int(dut.lowest_nr.value) == min_val,
        f"FAIL: tie: lowest_nr=0x{int(dut.lowest_nr.value):02x} exp=0x{min_val:02x}",
        f"PASS: tie: lowest_nr=0x{int(dut.lowest_nr.value):02x}",
        test_failures
    )
    check_condition(
        int(dut.lowest_line.value) == max([i for i, v in enumerate(req_vec) if nr_vec[i] == min_val and v == 1]),
        f"FAIL: tie: lowest_line={int(dut.lowest_line.value)} exp={max([i for i, v in enumerate(req_vec) if nr_vec[i] == min_val and v == 1])}",
        f"PASS: tie: lowest_line={int(dut.lowest_line.value)}",
        test_failures
    )

    # Test 5: Random patterns
    for t in range(10):
        nr_vec = [random.randint(0, 255) for _ in range(8)]
        packed_nr = 0
        for i in range(8):
            packed_nr = (packed_nr << 8) | nr_vec[7 - i]

        req_vec = [random.randint(0, 1) for _ in range(8)]
        packed_req = 0
        for i in range(8):
            packed_req = (packed_req << 1) | req_vec[7 - i]

        for j in range(8):
            dut.nr.value = packed_nr
            dut.req.value = packed_req
        await Timer(1, unit="ns")
        exp_val, exp_idx, exp_valid = ref_lowest(nr_vec, req_vec)
        check_condition(
            int(dut.lowest_valid.value) == exp_valid,
            f"FAIL: rand pattern {t}: lowest_valid={int(dut.lowest_valid.value)} exp={exp_valid}",
            f"PASS: rand pattern {t}: lowest_valid={int(dut.lowest_valid.value)}",
            test_failures
        )
        if exp_valid:
            check_condition(
                int(dut.lowest_nr.value) == exp_val,
                f"FAIL: rand pattern {t}: lowest_nr=0x{int(dut.lowest_nr.value):02x} exp=0x{exp_val:02x}",
                f"PASS: rand pattern {t}: lowest_nr=0x{int(dut.lowest_nr.value):02x}",
                test_failures
            )
            check_condition(
                int(dut.lowest_line.value) == exp_idx,
                f"FAIL: rand pattern {t}: lowest_line={int(dut.lowest_line.value)} exp={exp_idx}",
                f"PASS: rand pattern {t}: lowest_line={int(dut.lowest_line.value)}",
                test_failures
            )

    if test_failures:
        raise AssertionError("Test failed:\n" + "\n".join(test_failures))
    else:
        logger.info("lowest_nr_identifier_8 test passed all checks.")
