import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
import logging

def check_condition(condition, fail_msg, pass_msg, test_failures):
    if not condition:
        cocotb.log.error(fail_msg)
        test_failures.append(fail_msg)
    else:
        cocotb.log.info(pass_msg)

def lfsr_next(val, w):
    # Compute feedback (XNOR reduction of bits 0,1,3,4)
    a = (val >> 0) & 1
    b = (val >> 1) & 1
    c = (val >> 3) & 1
    d = (val >> 4) & 1
    feedback = int(not (a ^ b ^ c ^ d))
    # Shift right, insert feedback at MSB
    return ( (feedback << (w-1)) | (val >> 1) ) & ((1 << w) - 1)

@cocotb.test()
async def test_lfsr_seeding_and_advancing(dut):
    """Test seeding, write (readyMig), and read (rd_valid) for lfsr_gen"""

    logger = dut._log
    logger.setLevel(logging.INFO)
    test_failures = []

    WIDTH = int(dut.lfsr_width.value) if hasattr(dut, "lfsr_width") else 64

    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())

    # Reset all
    dut.new_seed.value = 0
    dut.seed.value = 0
    dut.readyMig.value = 0
    dut.regen.value = 0
    dut.rd_valid.value = 0

    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # Test: Seed the LFSR
    # List of 10 64-bit test seeds
    test_seeds = [
        0x0123456789ABCDEF,
        0xFEDCBA9876543210,
        0xDEADBEEFDEADBEEF,
        0x0F0F0F0F0F0F0F0F,
        0xF0F0F0F0F0F0F0F0,
        0xAAAAAAAAAAAAAAAA,
        0x5555555555555555,
        0xFFFFFFFFFFFFFFFF,
        0x8000000000000001,
        0x0000000000000001
    ]

    for idx, test_seed in enumerate(test_seeds):
        dut.seed.value = test_seed
        dut.new_seed.value = 1
        await RisingEdge(dut.clk)
        dut.new_seed.value = 0
        lfsr_val = test_seed
        got = int(dut.gen_pattern.value)
        check_condition(
            got == lfsr_val,
            f"FAIL: Seed {idx}: LFSR not seeded correctly: expected {lfsr_val:016x}, got {got:016x}",
            f"PASS: Seed {idx}: LFSR seeded as {got:016x}",
            test_failures
        )

    # Test: Advance LFSR on write (regen=0, readyMig=1)
    dut.regen.value = 0
    dut.readyMig.value = 1
    for _ in range(5):
        await RisingEdge(dut.clk)
        lfsr_val = lfsr_next(lfsr_val, WIDTH)
        got = int(dut.gen_pattern.value)
        check_condition(
            got == lfsr_val,
            f"FAIL: Write LFSR step: expected {lfsr_val:02x}, got {got:02x}",
            f"PASS: Write LFSR advanced: {got:02x}",
            test_failures
        )

    # Hold readyMig low, should not advance
    dut.readyMig.value = 0
    await RisingEdge(dut.clk)
    last = int(dut.gen_pattern.value)
    await RisingEdge(dut.clk)
    got = int(dut.gen_pattern.value)
    check_condition(
        got == last,
        f"FAIL: LFSR advanced with readyMig=0 (write), got {got:02x}",
        f"PASS: LFSR held with readyMig=0 (write)",
        test_failures
    )
    await RisingEdge(dut.clk)

    # Test: Advance LFSR on read (regen=1, rd_valid=1)
    dut.regen.value = 1
    dut.rd_valid.value = 1
    for _ in range(5):
        await RisingEdge(dut.clk)
        lfsr_val = lfsr_next(lfsr_val, WIDTH)
        got = int(dut.gen_pattern.value)
        check_condition(
            got == lfsr_val,
            f"FAIL: Read LFSR step: expected {lfsr_val:02x}, got {got:02x}",
            f"PASS: Read LFSR advanced: {got:02x}",
            test_failures
        )

    # Hold rd_valid low, should not advance
    dut.rd_valid.value = 0
    await RisingEdge(dut.clk)
    last = int(dut.gen_pattern.value)
    await RisingEdge(dut.clk)
    got = int(dut.gen_pattern.value)
    check_condition(
        got == last,
        f"FAIL: LFSR advanced with rd_valid=0 (read), got {got:02x}",
        f"PASS: LFSR held with rd_valid=0 (read)",
        test_failures
    )
    await RisingEdge(dut.clk)

    # Reseed and recheck
    dut.regen.value = 0
    dut.readyMig.value = 0
    dut.rd_valid.value = 0
    new_seed = 0x3C
    dut.seed.value = new_seed
    dut.new_seed.value = 1
    await RisingEdge(dut.clk)
    dut.new_seed.value = 0
    lfsr_val = new_seed
    got = int(dut.gen_pattern.value)
    check_condition(
        got == lfsr_val,
        f"FAIL: LFSR not reseeded: expected {lfsr_val:02x}, got {got:02x}",
        f"PASS: LFSR reseeded: {got:02x}",
        test_failures
    )
    await RisingEdge(dut.clk)

    if test_failures:
        raise AssertionError("Test failed:\n" + "\n".join(test_failures))
    else:
        logger.info("LFSR gen test passed all checks.")