import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer
import logging

async def common_reset_sequence(dut):
    """Common reset sequence for all tests."""
    dut._log.info("Applying reset...")
    dut.rst_n.value = 0
    # Initialize all relevant DUT inputs
    dut.data_gnt_i.value = 0
    dut.data_rvalid_i.value = 0
    dut.data_err_i.value = 0
    dut.data_rdata_i.value = 0
    dut.data_req_ex_i.value = 0
    dut.data_we_ex_i.value = 0
    dut.data_type_ex_i.value = 0
    dut.data_wdata_ex_i.value = 0
    dut.data_reg_offset_ex_i.value = 0
    dut.data_sign_ext_ex_i.value = 0
    dut.operand_a_ex_i.value = 0
    dut.operand_b_ex_i.value = 0
    dut.addr_useincr_ex_i.value = 0
    dut.data_misaligned_ex_i.value = 0 # Default, tests can override
    dut.data_atop_ex_i.value = 0       # Default, tests can override
    # dut.ex_valid_i.value = 0 # Kept commented as in original

    # Wait for a few cycles for reset to propagate
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk) # Wait for one cycle after reset release
    dut._log.info("DUT Reset applied and released.")

async def lsu_store(dut, addr, wdata, dtype):
    """Coroutine to simulate an LSU store operation."""

    dut.data_req_ex_i.value = 1
    dut.data_we_ex_i.value = 1
    dut.data_type_ex_i.value = dtype
    dut.data_wdata_ex_i.value = wdata
    dut.data_reg_offset_ex_i.value = 0
    dut.data_sign_ext_ex_i.value = 0
    dut.operand_a_ex_i.value = addr
    dut.operand_b_ex_i.value = 0
    dut.addr_useincr_ex_i.value = 0
    # dut.ex_valid_i.value = 1 # Kept commented

    # Simulate memory interface grant and response
    dut.data_gnt_i.value = 1
    await RisingEdge(dut.clk)
    dut.data_req_ex_i.value = 0
    dut.data_we_ex_i.value = 0
    dut.data_gnt_i.value = 0

    dut.data_rvalid_i.value = 1 # Using rvalid to signal completion/ack
    await RisingEdge(dut.clk)
    dut.data_rvalid_i.value = 0
    # dut._log.debug(f"Store completed: addr=0x{addr:08X}")


async def lsu_load(dut, addr, dtype):
    """Coroutine to simulate an LSU load operation."""

    dut.data_req_ex_i.value = 1
    dut.data_we_ex_i.value = 0
    dut.data_type_ex_i.value = dtype
    dut.data_reg_offset_ex_i.value = 0
    dut.data_sign_ext_ex_i.value = 0
    dut.operand_a_ex_i.value = addr
    dut.operand_b_ex_i.value = 0
    dut.addr_useincr_ex_i.value = 0

    # Simulate memory interface grant and response
    dut.data_gnt_i.value = 1
    await RisingEdge(dut.clk)
    dut.data_req_ex_i.value = 0
    dut.data_gnt_i.value = 0

    dut.data_rvalid_i.value = 1
    dut.data_rdata_i.value = 0xDEADBEEF # Dummy read data
    await RisingEdge(dut.clk)
    dut.data_rvalid_i.value = 0
    dut.data_rdata_i.value = 0 # Clear data after one cycle
    # dut._log.debug(f"Load completed: addr=0x{addr:08X}, rdata=0x{0xDEADBEEF:08X}")


async def delayed_store(dut, addr, wdata, delay_cycles):
    """Simulates a store operation with delayed grant."""
    dut.data_gnt_i.value = 0 # Keep grant low initially
    dut.data_req_ex_i.value = 1
    dut.data_we_ex_i.value = 1
    dut.data_type_ex_i.value = 0 # WORD
    dut.data_wdata_ex_i.value = wdata
    dut.operand_a_ex_i.value = addr
    dut._log.info(f"Delayed Store: Requesting 0x{addr:08X}, grant held low for {delay_cycles} cycles.")

    for i in range(delay_cycles):
        await RisingEdge(dut.clk)

    dut.data_gnt_i.value = 1
    dut._log.info(f"Delayed Store: Granting 0x{addr:08X}.")
    await RisingEdge(dut.clk)

    # Deassert request after grant cycle
    dut.data_req_ex_i.value = 0
    dut.data_we_ex_i.value = 0
    dut.data_gnt_i.value = 0

    # Memory response
    dut.data_rvalid_i.value = 1
    await RisingEdge(dut.clk)
    dut.data_rvalid_i.value = 0
    dut._log.info(f"Delayed Store: Completed 0x{addr:08X}.")


async def delayed_load(dut, addr, delay_cycles):
    """Simulates a load operation with delayed grant."""

    dut.data_gnt_i.value = 0 # Keep grant low initially
    dut.data_req_ex_i.value = 1
    dut.data_we_ex_i.value = 0 # Load
    dut.data_type_ex_i.value = 0 # WORD
    dut.operand_a_ex_i.value = addr
    dut._log.info(f"Delayed Load: Requesting 0x{addr:08X}, grant held low for {delay_cycles} cycles.")
    # Log state during potential stall

    for i in range(delay_cycles):
        await RisingEdge(dut.clk)

    dut.data_gnt_i.value = 1
    dut._log.info(f"Delayed Load: Granting 0x{addr:08X}.")
    await RisingEdge(dut.clk)

    # Deassert request after grant cycle
    dut.data_req_ex_i.value = 0
    dut.data_gnt_i.value = 0

    # Memory response
    dut.data_rvalid_i.value = 1
    dut.data_rdata_i.value = 0xDEADBEEF # Dummy read data for this load
    await RisingEdge(dut.clk)
    dut.data_rvalid_i.value = 0
    dut.data_rdata_i.value = 0 # Clear data
    dut._log.info(f"Delayed Load: Completed 0x{addr:08X}.")


@cocotb.test()
async def test_normal_ops(dut):
    """Tests normal word, halfword, and byte load/store operations."""
    dut._log.info("Starting test_normal_ops")
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())
    await common_reset_sequence(dut)

    num_word_ops = 10
    dut._log.info(f"Performing {num_word_ops} Word operations")
    for i in range(num_word_ops):
        await lsu_store(dut, 0x10000000 + 4*i, 0xAABBCCDD + i, 0) # type 0 for word
        await lsu_load(dut, 0x10000000 + 4*i, 0) # Load the data just written (if memory model supports)

    num_halfword_ops = 7
    dut._log.info(f"Performing {num_halfword_ops} Halfword operations")
    for i in range(num_halfword_ops):
        await lsu_store(dut, 0x10001000 + 2*i, 0x11223344 + i, 1) # type 1 for halfword
        await lsu_load(dut, 0x10001000 + 2*i, 1)

    num_byte_ops = 12
    dut._log.info(f"Performing {num_byte_ops} Byte operations")
    for i in range(num_byte_ops):
        await lsu_store(dut, 0x10002000 + i, 0xAA112233 + i, 2) # type 2 for byte
        await lsu_load(dut, 0x10002000 + i, 2)

    await RisingEdge(dut.clk) # Allow operations to settle

    # --- Add Counter Reading and Logging for test_normal_ops ---
    dut._log.info("Waiting for 10 clock cycles for counters to settle.")
    for _ in range(10):
        await RisingEdge(dut.clk)

    dut._log.info("Reading final counter values for test_normal_ops.")
    try:
        store_count = int(dut.store_count.value)
        load_count = int(dut.load_count.value)
        misaligned_count = int(dut.misaligned_count.value)
        atomic_count = int(dut.atomic_count.value)
        stall_count = int(dut.stall_count.value)

        dut._log.info(f"Store Count          = {store_count}")
        dut._log.info(f"Load Count           = {load_count}")
        dut._log.info(f"Misaligned Count     = {misaligned_count}")
        dut._log.info(f"Atomic Count         = {atomic_count}")
        dut._log.info(f"Stall Count          = {stall_count}")

        # Expected counts for this specific test
        expected_stores = num_word_ops + num_halfword_ops + num_byte_ops
        expected_loads = num_word_ops + num_halfword_ops + num_byte_ops

        if not (store_count >= expected_stores and load_count >= expected_loads):
             error_msg = (f"TEST FAILED ❌: Store/Load counts incorrect in test_normal_ops. "
                          f"Expected Stores >= {expected_stores} (Got {store_count}), "
                          f"Expected Loads >= {expected_loads} (Got {load_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        # Misaligned, Atomic, Stall counts expected to be 0 for normal ops
        if not (misaligned_count == 0 and atomic_count == 0 and stall_count == 0):
             dut._log.warning(f"Warning: Unexpected non-zero counts in test_normal_ops: Misaligned={misaligned_count}, Atomic={atomic_count}, Stall={stall_count}")

        dut._log.info("TEST PASSED ✅ (test_normal_ops completed)")

    except AttributeError as e:
        error_msg = f"AttributeError accessing counters in test_normal_ops: {e}. Ensure counter signals are outputs of the DUT."
        dut._log.error(error_msg)
        assert False, error_msg

    except Exception as e:
        error_msg = f"An unexpected error occurred during counter checks in test_normal_ops: {e}"
        dut._log.error(error_msg)
        assert False, error_msg
    # --- End Counter Reading and Logging ---

    dut._log.info("Finished test_normal_ops")


@cocotb.test()
async def test_special_ops(dut):
    """Tests misaligned store and atomic store hint operations."""
    dut._log.info("Starting test_special_ops")
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())
    await common_reset_sequence(dut)

    num_misaligned_ops = 8
    dut._log.info(f"Performing {num_misaligned_ops} Misaligned Stores")
    # Store count includes these misaligned stores
    for i in range(num_misaligned_ops):
        dut.data_misaligned_ex_i.value = 1 # Assert misaligned flag for the next operation
        addr = 0x10003001 + i # Example misaligned addresses
        await lsu_store(dut, addr, 0xDEAD0000 + i*100, 0) # Misaligned word store
        dut.data_misaligned_ex_i.value = 0 # Deassert after the operation

    num_atomic_ops = 6
    dut._log.info(f"Performing {num_atomic_ops} Atomic Hint Stores")
     # Store count includes these atomic stores
    for i in range(num_atomic_ops):
        dut.data_atop_ex_i.value = 0b000001 # Example ATOP hint (AMOADD)
        addr = 0x10004000 + i*4 # Atomic word store addresses
        await lsu_store(dut, addr, 0xCAFEBABE + i*200, 0) # Atomic word store address
        dut.data_atop_ex_i.value = 0 # Deassert after the operation

    await RisingEdge(dut.clk)

    # --- Add Counter Reading and Logging for test_special_ops ---
    dut._log.info("Waiting for 10 clock cycles for counters to settle.")
    for _ in range(10):
        await RisingEdge(dut.clk)

    dut._log.info("Reading final counter values for test_special_ops.")
    try:
        store_count = int(dut.store_count.value)
        load_count = int(dut.load_count.value)
        misaligned_count = int(dut.misaligned_count.value)
        atomic_count = int(dut.atomic_count.value)
        stall_count = int(dut.stall_count.value)

        dut._log.info(f"Store Count          = {store_count}")
        dut._log.info(f"Load Count           = {load_count}")
        dut._log.info(f"Misaligned Count     = {misaligned_count}")
        dut._log.info(f"Atomic Count         = {atomic_count}")
        dut._log.info(f"Stall Count          = {stall_count}")

        # Expected counts for this specific test
        expected_stores = num_misaligned_ops + num_atomic_ops
        expected_loads = 0 # No loads in this test

        if not (store_count >= expected_stores and load_count == expected_loads):
             error_msg = (f"TEST FAILED ❌: Store/Load counts incorrect in test_special_ops. "
                          f"Expected Stores >= {expected_stores} (Got {store_count}), "
                          f"Expected Loads == {expected_loads} (Got {load_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        # Assertions for misaligned and atomic counts

        if not (misaligned_count >= num_misaligned_ops):
             error_msg = (f"TEST FAILED ❌: Misaligned count incorrect in test_special_ops. "
                          f"Expected Misaligned >= {num_misaligned_ops} (Got {misaligned_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        if not (atomic_count >= num_atomic_ops):
             error_msg = (f"TEST FAILED ❌: Atomic count incorrect in test_special_ops. "
                          f"Expected Atomic >= {num_atomic_ops} (Got {atomic_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        # Stall count expected to be 0 for non-delayed ops
        if not (stall_count == 0):
             dut._log.warning(f"Warning: Unexpected non-zero stall count in test_special_ops: Stall={stall_count}")

        dut._log.info("TEST PASSED ✅ (test_special_ops completed)")

    except AttributeError as e:
        error_msg = f"AttributeError accessing counters in test_special_ops: {e}. Ensure counter signals are outputs of the DUT."
        dut._log.error(error_msg)
        assert False, error_msg

    except Exception as e:
        error_msg = f"An unexpected error occurred during counter checks in test_special_ops: {e}"
        dut._log.error(error_msg)
        assert False, error_msg
    # --- End Counter Reading and Logging ---


    dut._log.info("Finished test_special_ops")


@cocotb.test()
async def test_delayed_grant_ops_sequential(dut): # Renaming to emphasize sequential
    """Tests sequential store and load operations with delayed memory grant (stall simulation)."""
    dut._log.info("Starting test_delayed_grant_ops_sequential")
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())
    await common_reset_sequence(dut)

    num_sequential_pairs = 10 # Number of sequential delayed store/load pairs
    base_delay_cycles = 8 # Base delay cycles for the grant

    dut._log.info(f"Performing {num_sequential_pairs} delayed grant store/load pairs sequentially with base delay {base_delay_cycles} cycles.")

    total_expected_stall_cycles = 0 # Exact expected stall cycles in this deterministic test

    for i in range(num_sequential_pairs):
        # Vary delay slightly around the base delay
        store_delay = base_delay_cycles + (i % 3)
        load_delay = base_delay_cycles + 1 + (i % 2) # Ensure loads have slightly different delays

        # Sequential Delayed Store
        dut._log.info(f"Initiating Sequential Delayed Store {i}: addr=0x{0x10005000 + i*8:08X}, delay={store_delay} cycles.")
        dut.data_req_ex_i.value = 1
        dut.data_we_ex_i.value = 1
        dut.data_type_ex_i.value = 0 # WORD
        dut.data_wdata_ex_i.value = 0xAAAA0000 + i
        dut.operand_a_ex_i.value = 0x10005000 + i*8
        # data_gnt_i is already 0 from initialization

        # Wait for stall cycles
        for d in range(store_delay):
            await RisingEdge(dut.clk)
            # Stall condition is active here (req=1, gnt=0)
            dut._log.debug(f"  Cycle {d+1}/{store_delay} during Store Stall {i}: req={dut.data_req_ex_i.value}, gnt={dut.data_gnt_i.value}")
        total_expected_stall_cycles += store_delay # Add simulated stall cycles

        # Grant the request
        dut.data_gnt_i.value = 1
        await RisingEdge(dut.clk) # Wait one cycle with req=1, gnt=1

        # Deassert request and grant
        dut.data_req_ex_i.value = 0
        dut.data_we_ex_i.value = 0
        dut.data_gnt_i.value = 0

        # Wait for memory response (simulate completion)
        dut.data_rvalid_i.value = 1
        await RisingEdge(dut.clk)
        dut.data_rvalid_i.value = 0
        dut._log.info(f"Sequential Delayed Store {i} Completed.")
        await RisingEdge(dut.clk) # Wait a cycle between operations

        # Sequential Delayed Load
        dut._log.info(f"Initiating Sequential Delayed Load {i}: addr=0x{0x10005004 + i*8:08X}, delay={load_delay} cycles.")
        dut.data_req_ex_i.value = 1
        dut.data_we_ex_i.value = 0 # Load
        dut.data_type_ex_i.value = 0 # WORD
        dut.operand_a_ex_i.value = 0x10005004 + i*8
        # data_gnt_i is already 0

        # Wait for stall cycles
        for d in range(load_delay):
            await RisingEdge(dut.clk)
            # Stall condition is active here (req=1, gnt=0)
            dut._log.debug(f"  Cycle {d+1}/{load_delay} during Load Stall {i}: req={dut.data_req_ex_i.value}, gnt={dut.data_gnt_i.value}")
        total_expected_stall_cycles += load_delay # Add simulated stall cycles

        # Grant the request
        dut.data_gnt_i.value = 1
        dut.data_rdata_i.value = 0xDEADBEEF + i # Dummy read data
        await RisingEdge(dut.clk) # Wait one cycle with req=1, gnt=1

        # Deassert request and grant, signal rvalid
        dut.data_req_ex_i.value = 0
        dut.data_gnt_i.value = 0
        dut.data_rvalid_i.value = 1 # Response valid
        dut.data_rdata_i.value = 0 # Clear dummy data

        await RisingEdge(dut.clk)
        dut.data_rvalid_i.value = 0
        dut._log.info(f"Sequential Delayed Load {i} Completed.")
        await RisingEdge(dut.clk) # Wait a cycle between operations


    await RisingEdge(dut.clk) # Give one clock cycle for final updates


    # --- Add Counter Reading and Logging ---
    dut._log.info("Waiting for 10 clock cycles for counters to settle.")
    for _ in range(10):
        await RisingEdge(dut.clk)

    dut._log.info("Reading final counter values for test_delayed_grant_ops_sequential.")
    try:
        store_count = int(dut.store_count.value)
        load_count = int(dut.load_count.value)
        misaligned_count = int(dut.misaligned_count.value)
        atomic_count = int(dut.atomic_count.value)
        stall_count = int(dut.stall_count.value)

        dut._log.info(f"Store Count          = {store_count}")
        dut._log.info(f"Load Count           = {load_count}")
        dut._log.info(f"Misaligned Count     = {misaligned_count}")
        dut._log.info(f"Atomic Count         = {atomic_count}")
        dut._log.info(f"Stall Count          = {stall_count}")

        # Expected counts for this specific test
        expected_stores = num_sequential_pairs
        expected_loads = num_sequential_pairs

        if not (store_count >= expected_stores and load_count >= expected_loads):
             error_msg = (f"TEST FAILED ❌: Store/Load counts incorrect in test_delayed_grant_ops_sequential. "
                          f"Expected Stores >= {expected_stores} (Got {store_count}), "
                          f"Expected Loads >= {expected_loads} (Got {load_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        # Misaligned and Atomic counts expected to be 0 in this specific test
        if not (misaligned_count == 0 and atomic_count == 0):
             dut._log.warning(f"Warning: Unexpected non-zero Misaligned/Atomic counts in test_delayed_grant_ops_sequential: Misaligned={misaligned_count}, Atomic={atomic_count}")
             # Assert False if they should strictly be zero


        # Stall count assertion: Should match the total simulated stall cycles precisely
        if not (stall_count == total_expected_stall_cycles):
             dut._log.error(f"TEST FAILED ❌: Stall count incorrect in test_delayed_grant_ops_sequential. "
                          f"Expected Stall == {total_expected_stall_cycles} (Got {stall_count})")
             assert False, error_msg


        dut._log.info("TEST PASSED ✅ (test_delayed_grant_ops_sequential completed)")

    except AttributeError as e:
        error_msg = f"AttributeError accessing counters in test_delayed_grant_ops_sequential: {e}. Ensure counter signals are outputs of the DUT."
        dut._log.error(error_msg)
        assert False, error_msg

    except Exception as e:
        error_msg = f"An unexpected error occurred during counter checks in test_delayed_grant_ops_sequential: {e}"
        dut._log.error(error_msg)
        assert False, error_msg
    # --- End Counter Reading and Logging ---


    dut._log.info("Finished test_delayed_grant_ops_sequential")


@cocotb.test()
async def test_edge_cases(dut):
    """Tests edge address store/load and basic functionality check, includes counter check."""
    dut._log.info("Starting test_edge_cases")
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())
    await common_reset_sequence(dut)

    # These are 1 store and 1 load
    dut._log.info("Performing Edge Address Store (0xFFFFFFFC)")
    await lsu_store(dut, 0xFFFFFFFC, 0xDEADBEEF, 0) # Edge address (Word)

    dut._log.info("Performing Base Address Load (0x00000000)")
    await lsu_load(dut, 0x00000000, 0)              # Base address (Word)

    # Add more basic operations
    num_additional_ops = 15 # Increased number of additional ops
    dut._log.info(f"Performing {num_additional_ops} additional word store/load pairs.")
    # These add num_additional_ops stores and num_additional_ops loads
    for i in range(num_additional_ops):
        await lsu_store(dut, 0x10006000 + 4*i, 0x12340000 + i, 0)
        await lsu_load(dut, 0x10006000 + 4*i, 0) # Load the data we just wrote (if memory model supports)


    # --- Add Counter Reading and Logging ---
    dut._log.info("Waiting for 10 clock cycles for counters to settle.")
    for _ in range(10):
        await RisingEdge(dut.clk)

    dut._log.info("Reading final counter values for test_edge_cases.")
    try:
        store_count = int(dut.store_count.value)
        load_count = int(dut.load_count.value)
        misaligned_count = int(dut.misaligned_count.value)
        atomic_count = int(dut.atomic_count.value)
        stall_count = int(dut.stall_count.value)

        dut._log.info(f"Store Count          = {store_count}")
        dut._log.info(f"Load Count           = {load_count}")
        dut._log.info(f"Misaligned Count     = {misaligned_count}")
        dut._log.info(f"Atomic Count         = {atomic_count}")
        dut._log.info(f"Stall Count          = {stall_count}")

        # Expected counts for this specific test

        expected_stores = 1 + num_additional_ops

        expected_loads = 1 + num_additional_ops

        if not (store_count >= expected_stores and load_count >= expected_loads):
             error_msg = (f"TEST FAILED ❌: Store/Load counts incorrect in test_edge_cases. "
                          f"Expected Stores >= {expected_stores} (Got {store_count}), "
                          f"Expected Loads >= {expected_loads} (Got {load_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        # Misaligned, Atomic, Stall counts expected to be 0 for these ops
 
        if not (atomic_count == 0 and stall_count == 0):
             dut._log.warning(f"Warning: Unexpected non-zero Atomic/Stall counts in test_edge_cases: Atomic={atomic_count}, Stall={stall_count}")
             # Assert False if they should strictly be zero

        if misaligned_count > 0:
             dut._log.info(f"Info: Misaligned count > 0 ({misaligned_count}) in test_edge_cases. This might be expected if DUT detects edge address misalignment.")

        dut._log.info("TEST PASSED ✅ (test_edge_cases completed)")

    except AttributeError as e:
        error_msg = f"AttributeError accessing counters in test_edge_cases: {e}. Ensure counter signals are outputs of the DUT."
        dut._log.error(error_msg)
        assert False, error_msg

    except Exception as e:
        error_msg = f"An unexpected error occurred during counter checks in test_edge_cases: {e}"
        dut._log.error(error_msg)
        assert False, error_msg
    # --- End Counter Reading and Logging ---


    dut._log.info("Finished test_edge_cases")


@cocotb.test()
async def test_sequential_delayed_ops(dut):
    """Tests sequential delayed store and load operations."""
    dut._log.info("Starting test_sequential_delayed_ops")
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())
    await common_reset_sequence(dut)

    num_sequential_pairs = 7 # Number of sequential delayed pairs
    base_delay_cycles = 5 # Base delay for each operation

    dut._log.info(f"Performing {num_sequential_pairs} delayed store/load pairs sequentially with base delay {base_delay_cycles} cycles.")

    total_expected_min_stall_cycles = 0

    for i in range(num_sequential_pairs):
        store_delay = base_delay_cycles + (i % 3)
        load_delay = base_delay_cycles + 1 + (i % 2) # Ensure loads have slightly different delays

        total_expected_min_stall_cycles += store_delay
        total_expected_min_stall_cycles += load_delay

        # Perform store then load, waiting for each to complete
        await delayed_store(dut, addr=0x10007000 + i*8, wdata=0xBBBB0000 + i, delay_cycles=store_delay)
        await delayed_load(dut, addr=0x10007004 + i*8, delay_cycles=load_delay)

    await RisingEdge(dut.clk) # Give one clock cycle for final updates

    # --- Add Counter Reading and Logging for test_sequential_delayed_ops ---
    dut._log.info("Waiting for 10 clock cycles for counters to settle.")
    for _ in range(10):
        await RisingEdge(dut.clk)

    dut._log.info("Reading final counter values for test_sequential_delayed_ops.")
    try:
        store_count = int(dut.store_count.value)
        load_count = int(dut.load_count.value)
        misaligned_count = int(dut.misaligned_count.value)
        atomic_count = int(dut.atomic_count.value)
        stall_count = int(dut.stall_count.value)

        dut._log.info(f"Store Count          = {store_count}")
        dut._log.info(f"Load Count           = {load_count}")
        dut._log.info(f"Misaligned Count     = {misaligned_count}")
        dut._log.info(f"Atomic Count         = {atomic_count}")
        dut._log.info(f"Stall Count          = {stall_count}")

        # Expected counts for this specific test
        expected_stores = num_sequential_pairs
        expected_loads = num_sequential_pairs

        if not (store_count >= expected_stores and load_count >= expected_loads):
             error_msg = (f"TEST FAILED ❌: Store/Load counts incorrect in test_sequential_delayed_ops. "
                          f"Expected Stores >= {expected_stores} (Got {store_count}), "
                          f"Expected Loads >= {expected_loads} (Got {load_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        # Misaligned and Atomic counts expected to be 0 for these specific helpers
        if not (misaligned_count == 0 and atomic_count == 0):
             dut._log.warning(f"Warning: Unexpected non-zero Misaligned/Atomic counts in test_sequential_delayed_ops: Misaligned={misaligned_count}, Atomic={atomic_count}")
             # Assert False if they should strictly be zero

        # Stall count assertion

        if not (stall_count >= total_expected_min_stall_cycles):
             dut._log.error(f"TEST FAILED ❌: Stall count incorrect in test_sequential_delayed_ops. "
                          f"Expected Stall >= {total_expected_min_stall_cycles} (Got {stall_count})")
             assert False, error_msg


        dut._log.info("TEST PASSED ✅ (test_sequential_delayed_ops completed)")

    except AttributeError as e:
        error_msg = f"AttributeError accessing counters in test_sequential_delayed_ops: {e}. Ensure counter signals are outputs of the DUT."
        dut._log.error(error_msg)
        assert False, error_msg

    except Exception as e:
        error_msg = f"An unexpected error occurred during counter checks in test_sequential_delayed_ops: {e}"
        dut._log.error(error_msg)
        assert False, error_msg
    # --- End Counter Reading and Logging ---

    dut._log.info("Finished test_sequential_delayed_ops")


@cocotb.test()
async def test_mixed_ops(dut):
    """Tests a mix of normal, misaligned, atomic, and delayed operations."""
    dut._log.info("Starting test_mixed_ops")
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())
    await common_reset_sequence(dut)

    # Keep track of expected counts
    expected_stores = 0
    expected_loads = 0
    expected_misaligned = 0
    expected_atomic = 0
    expected_min_stall_cycles = 0

    dut._log.info("Performing a mix of LSU operations.")

    # Normal Word Store/Load
    await lsu_store(dut, 0x10008000, 0xAAAA5555, 0)
    expected_stores += 1
    await lsu_load(dut, 0x10008004, 0)
    expected_loads += 1

    # Misaligned Store
    dut.data_misaligned_ex_i.value = 1
    await lsu_store(dut, 0x10008007, 0xBBBBCCCC, 0) # Misaligned word
    dut.data_misaligned_ex_i.value = 0
    expected_stores += 1
    expected_misaligned += 1

    # Normal Halfword Store/Load
    await lsu_store(dut, 0x10008010, 0x12345678, 1)
    expected_stores += 1
    await lsu_load(dut, 0x10008012, 1)
    expected_loads += 1

    # Atomic Hint Store
    dut.data_atop_ex_i.value = 0b000010 # Example ATOP hint (AMOOR)
    await lsu_store(dut, 0x10008020, 0xDDDEEEFF, 0) # Atomic word
    dut.data_atop_ex_i.value = 0
    expected_stores += 1
    expected_atomic += 1

    # Delayed Load
    delayed_load_delay = 6
    await delayed_load(dut, addr=0x10008030, delay_cycles=delayed_load_delay)
    expected_loads += 1
    expected_min_stall_cycles += delayed_load_delay

    # Normal Byte Store/Load
    await lsu_store(dut, 0x10008040, 0x99887766, 2)
    expected_stores += 1
    await lsu_load(dut, 0x10008041, 2)
    expected_loads += 1

    # Another Misaligned Load

    dut.data_misaligned_ex_i.value = 1
    await lsu_load(dut, 0x10008051, 0) # Misaligned word load
    dut.data_misaligned_ex_i.value = 0
    expected_loads += 1
    expected_misaligned += 1 # Counting this load as misaligned

    # Delayed Store
    delayed_store_delay = 7
    await delayed_store(dut, addr=0x10008060, wdata=0xFEDCBA98, delay_cycles=delayed_store_delay)
    expected_stores += 1
    expected_min_stall_cycles += delayed_store_delay


    await RisingEdge(dut.clk) # Give one clock cycle for final updates

    # --- Add Counter Reading and Logging for test_mixed_ops ---
    dut._log.info("Waiting for 10 clock cycles for counters to settle.")
    for _ in range(10):
        await RisingEdge(dut.clk)

    dut._log.info("Reading final counter values for test_mixed_ops.")
    try:
        store_count = int(dut.store_count.value)
        load_count = int(dut.load_count.value)
        misaligned_count = int(dut.misaligned_count.value)
        atomic_count = int(dut.atomic_count.value)
        stall_count = int(dut.stall_count.value)

        dut._log.info(f"Store Count          = {store_count}")
        dut._log.info(f"Load Count           = {load_count}")
        dut._log.info(f"Misaligned Count     = {misaligned_count}")
        dut._log.info(f"Atomic Count         = {atomic_count}")
        dut._log.info(f"Stall Count          = {stall_count}")

        # Expected counts for this specific test
        if not (store_count >= expected_stores and load_count >= expected_loads):
             error_msg = (f"TEST FAILED ❌: Store/Load counts incorrect in test_mixed_ops. "
                          f"Expected Stores >= {expected_stores} (Got {store_count}), "
                          f"Expected Loads >= {expected_loads} (Got {load_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        # Assertions for misaligned, atomic, and stall counts
        if not (misaligned_count >= expected_misaligned):
             error_msg = (f"TEST FAILED ❌: Misaligned count incorrect in test_mixed_ops. "
                          f"Expected Misaligned >= {expected_misaligned} (Got {misaligned_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        if not (atomic_count >= expected_atomic):
             error_msg = (f"TEST FAILED ❌: Atomic count incorrect in test_mixed_ops. "
                          f"Expected Atomic >= {expected_atomic} (Got {atomic_count})")
             dut._log.error(error_msg)
             assert False, error_msg

        if not (stall_count >= expected_min_stall_cycles):
             dut._log.error(f"TEST FAILED ❌: Stall count incorrect in test_mixed_ops. "
                          f"Expected Stall >= {expected_min_stall_cycles} (Got {stall_count})")
             assert False, error_msg


        dut._log.info("TEST PASSED ✅ (test_mixed_ops completed)")

    except AttributeError as e:
        error_msg = f"AttributeError accessing counters in test_mixed_ops: {e}. Ensure counter signals are outputs of the DUT."
        dut._log.error(error_msg)
        assert False, error_msg

    except Exception as e:
        error_msg = f"An unexpected error occurred during counter checks in test_mixed_ops: {e}"
        dut._log.error(error_msg)
        assert False, error_msg
    # --- End Counter Reading and Logging ---


    dut._log.info("Finished test_mixed_ops")

@cocotb.test()
async def test_error_handling(dut):
    """Test handling of memory errors during store and load operations."""
    dut._log.info("Starting test_error_handling")
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())
    await common_reset_sequence(dut)

    expected_stores = 0
    expected_loads = 0
    expected_misaligned = 0 # Assuming no misaligned/atomic in this test
    expected_atomic = 0
    expected_stall = 0      # Assuming no stalls in this test

    # Perform a normal store using the helper
    dut._log.info("Performing a normal store.")
    await lsu_store(dut, 0x1000A000, 0x12345678, 0)
    expected_stores += 1 # Count this store

    # Perform a store with error by manually driving signals
    dut._log.info("Simulating a store operation with a memory error.")
    addr = 0x1000A004
    wdata = 0xDEADBEEF
    dtype = 0  # WORD

    # Request phase
    dut.data_req_ex_i.value = 1
    dut.data_we_ex_i.value = 1
    dut.data_type_ex_i.value = dtype
    dut.data_wdata_ex_i.value = wdata
    dut.operand_a_ex_i.value = addr
    # Ensure other control signals are default/inactive for this manual sequence
    dut.data_reg_offset_ex_i.value = 0
    dut.data_sign_ext_ex_i.value = 0
    dut.operand_b_ex_i.value = 0
    dut.addr_useincr_ex_i.value = 0
    dut.data_misaligned_ex_i.value = 0
    dut.data_atop_ex_i.value = 0

    # Grant the request (assuming immediate grant for simplicity in error test)
    dut.data_gnt_i.value = 1
    await RisingEdge(dut.clk)
    # Deassert request and grant after one cycle
    dut.data_req_ex_i.value = 0
    dut.data_we_ex_i.value = 0
    dut.data_gnt_i.value = 0

    # Response with error (assuming error is indicated via data_err_i with data_rvalid_i)
    dut.data_rvalid_i.value = 1
    dut.data_err_i.value = 1 # Assert error signal
    await RisingEdge(dut.clk)
    # Deassert response and error
    dut.data_rvalid_i.value = 0
    dut.data_err_i.value = 0

    expected_stores += 1 # Count this manually driven store

    # Perform a normal load using the helper
    dut._log.info("Performing a normal load.")
    await lsu_load(dut, 0x1000A000, 0)
    expected_loads += 1 # Count this load

    # Perform a load with error by manually driving signals
    dut._log.info("Simulating a load operation with a memory error.")
    addr = 0x1000A008
    # Request phase
    dut.data_req_ex_i.value = 1
    dut.data_we_ex_i.value = 0  # Load
    dut.data_type_ex_i.value = 0 # WORD
    dut.operand_a_ex_i.value = addr
    # Ensure other control signals are default/inactive
    dut.data_reg_offset_ex_i.value = 0
    dut.data_sign_ext_ex_i.value = 0
    dut.operand_b_ex_i.value = 0
    dut.addr_useincr_ex_i.value = 0
    dut.data_misaligned_ex_i.value = 0
    dut.data_atop_ex_i.value = 0

    # Grant the request
    dut.data_gnt_i.value = 1
    await RisingEdge(dut.clk)
    # Deassert request and grant
    dut.data_req_ex_i.value = 0
    dut.data_gnt_i.value = 0

    # Response with error
    dut.data_rvalid_i.value = 1
    dut.data_err_i.value = 1 # Assert error signal
    dut.data_rdata_i.value = 0xDEADBEEF  # Dummy data (often ignored on error, but good practice)
    await RisingEdge(dut.clk)
    # Deassert response, error, and dummy data
    dut.data_rvalid_i.value = 0
    dut.data_err_i.value = 0
    dut.data_rdata_i.value = 0

    expected_loads += 1 # Count this manually driven load

    # Wait for counters to settle
    dut._log.info("Waiting for 10 clock cycles for counters to settle.")
    for _ in range(10):
        await RisingEdge(dut.clk)

    # Check counters
    dut._log.info("Reading final counter values for test_error_handling.")
    try:
        store_count = int(dut.store_count.value)
        load_count = int(dut.load_count.value)
        misaligned_count = int(dut.misaligned_count.value)
        atomic_count = int(dut.atomic_count.value)
        stall_count = int(dut.stall_count.value)

        dut._log.info(f"Store Count          = {store_count}")
        dut._log.info(f"Load Count           = {load_count}")
        dut._log.info(f"Misaligned Count     = {misaligned_count}")
        dut._log.info(f"Atomic Count         = {atomic_count}")
        dut._log.info(f"Stall Count          = {stall_count}")

        # Assertions for expected counts
        if store_count != expected_stores:
            error_msg = (f"TEST FAILED ❌: Store count mismatch: expected {expected_stores}, got {store_count}")
            dut._log.error(error_msg)
            assert False, error_msg

        if load_count != expected_loads:
            error_msg = (f"TEST FAILED ❌: Load count mismatch: expected {expected_loads}, got {load_count}")
            dut._log.error(error_msg)
            assert False, error_msg

        # Check other counts are zero as expected for this test
        if misaligned_count != expected_misaligned:
             error_msg = (f"TEST FAILED ❌: Misaligned count mismatch: expected {expected_misaligned}, got {misaligned_count}")
             dut._log.error(error_msg)
             assert False, error_msg

        if atomic_count != expected_atomic:
             error_msg = (f"TEST FAILED ❌: Atomic count mismatch: expected {expected_atomic}, got {atomic_count}")
             dut._log.error(error_msg)
             assert False, error_msg

        if stall_count != expected_stall:
             error_msg = (f"TEST FAILED ❌: Stall count mismatch: expected {expected_stall}, got {stall_count}")
             dut._log.error(error_msg)
             assert False, error_msg


        dut._log.info("TEST PASSED ✅ (test_error_handling completed)")

    except AttributeError as e:
        error_msg = f"AttributeError accessing counters in test_error_handling: {e}. Ensure counter signals are outputs of the DUT."
        dut._log.error(error_msg)
        assert False, error_msg

    except Exception as e:
        # Catch any other unexpected errors during counter checks
        error_msg = f"An unexpected error occurred during counter checks in test_error_handling: {e}"
        dut._log.error(error_msg)
        assert False, error_msg

    dut._log.info("Finished test_error_handling")


@cocotb.test()
async def test_random_delays(dut):
    """Test stall count with random grant delays."""
    import random
    random.seed(42)  # For reproducibility

    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())
    await common_reset_sequence(dut)

    num_ops = 10
    delays = [random.randint(1, 20) for _ in range(num_ops)]
    total_expected_stall = sum(delays)

    for i, delay in enumerate(delays):
        addr = 0x1000C000 + i * 4
        if i % 2 == 0:
            # Store operation
            await delayed_store(dut, addr=addr, wdata=0x12345678 + i, delay_cycles=delay)
        else:
            # Load operation
            await delayed_load(dut, addr=addr, delay_cycles=delay)

    # Wait for counters to settle
    for _ in range(10):
        await RisingEdge(dut.clk)

    # Check stall count
    try:
        stall_count = int(dut.stall_count.value)
        assert stall_count == total_expected_stall, f"Stall count mismatch: expected {total_expected_stall}, got {stall_count}"
        dut._log.info("TEST PASSED ✅ (test_random_delays)")
    except Exception as e:
        dut._log.error(f"Stall count check failed: {e}")
        assert False

        dut._log.info("All TEST RUN COMPLETED ✅")