import os
from cocotb_tools.runner import get_runner
import pytest

# Fetch environment variables for Verilog source setup
verilog_sources = os.getenv("VERILOG_SOURCES").split()
toplevel_lang   = os.getenv("TOPLEVEL_LANG")
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = os.getenv("WAVE")

# Runner to execute tests
def test_runner(MAX_LENGTH: int = 192):
    # Simulation parameters
    parameter = {
        "MAX_LENGTH": MAX_LENGTH
    }
        # Debug information
    print(f"[DEBUG] Running simulation with MAX_LENGTH={MAX_LENGTH}")
    print(f"[DEBUG] Parameters: {parameter}")
    runner = get_runner(sim)

    runner.build(
        sources=verilog_sources,
        hdl_toplevel=toplevel,
        parameters=parameter,
        always=True,
        clean=True,
        verbose=True,
        timescale=("1ns", "1ns"),
        log_file="sim.log"
    )
    runner.test(hdl_toplevel=toplevel, test_module=module,waves=True)

if __name__ == "__main__":
    test_runner()

    
