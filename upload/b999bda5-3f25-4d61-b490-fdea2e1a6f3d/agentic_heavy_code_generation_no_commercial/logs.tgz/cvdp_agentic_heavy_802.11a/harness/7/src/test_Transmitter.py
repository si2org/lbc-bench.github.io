import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, FallingEdge, Timer

DESIRED_OUT = (
    "1100110011001100110011001100110011001100110011001100110011001100"
    "1100110011001100110011001100110011001100110011001100110011001100"
    "1100110011001100110011001100110011001100110011001100110011001100"
    "0000000000000000000000000000000000000000000000000011010011101010"
    "1001100100110010000110110010110110011010011011000001011010111100"
    "1110000011100011011111111110110100110100101010011001011101010011"
    "0100001000000001110100001000110001110011100100000010101000111110"
    "0111101000010010111000100110000010110100100111111001010001001111"
    "1101101010111001011010111101001010111110001010100000111001100100"
    "11101011101001101001110100110110111010100110011111"
)

async def data_input_driver(dut):
    """After 544 ns, drive the 4-bit DATA_INPUT sequence."""
    await Timer(544, unit="ns")
    dut._log.info("[DATA_INPUT::START]")
    data = [1, 0, 0, 1]
    for bit in data:
        dut.Input.value = bit
        await Timer(4, unit="ns")
    dut.Input.value = 0
    dut._log.info("[DATA_INPUT::END]")


@cocotb.test()
async def transmitter_full_test(dut):
    """Cocotb test for Transmitter"""
    # Start clocks
    cocotb.start_soon(Clock(dut.Clock, 4, unit="ns").start())
    cocotb.start_soon(Clock(dut.Clock2, 2, unit="ns").start())

    # Initialize all inputs to zero
    dut.Reset.value = 0
    dut.Input.value = 0
    dut.Start.value = 0

    # Wait 10 ns before asserting reset
    await Timer(10, unit="ns")

    # Reset pulse
    dut.Reset.value = 1
    await Timer(4, unit="ns")
    dut.Reset.value = 0
    await Timer(4, unit="ns")

    # Single-cycle Start
    dut.Start.value = 1
    await Timer(4, unit="ns")
    dut.Start.value = 0

    # Launch the DATA_INPUT driver in parallel
    cocotb.start_soon(data_input_driver(dut))

    # Drive and check the DESIRED_OUT sequence
    pass_count = 0
    total_bits = len(DESIRED_OUT)
    await FallingEdge(dut.Clock2)
    for idx, bit_char in enumerate(DESIRED_OUT, start=1):
        await FallingEdge(dut.Clock2)
        inp = int(dut.Input.value)
        got = int(dut.Output.value)
        exp = int(bit_char)

        if got == exp:
            pass_count += 1
            dut._log.info(f"[OK]    ({idx}/{total_bits}) "
                          f"Input={inp} Expected={exp} Actual={got}")
        else:
            dut._log.error(f"[FAILED]({idx}/{total_bits}) "
                           f"Input={inp} Expected={exp} Actual={got}")
        assert got == exp, (
            f"Bit {idx} mismatch: Input={inp} Expected={exp} Got={got}"
        )

    if pass_count == total_bits:
        dut._log.info("ALL TESTS PASSED. :)")
    else:
        failed = total_bits - pass_count
        dut._log.warning(f"{failed} test(s) failed. :(")


@cocotb.test()
async def test_idle_state(dut):
    """Before Start, after reset, Output should stay at 0."""
    cocotb.start_soon(Clock(dut.Clock, 4, unit="ns").start())
    cocotb.start_soon(Clock(dut.Clock2, 2, unit="ns").start())

    # Reset
    dut.Reset.value = 1
    dut.Input.value = 0
    dut.Start.value = 0
    await Timer(10, unit="ns")
    dut.Reset.value = 0
    await Timer(4, unit="ns")

    # Sample 20 cycles on Clock2 and ensure Output never leaves 0
    for cycle in range(1, 21):
        await FallingEdge(dut.Clock2)
        out = int(dut.Output.value)
        dut._log.info(f"[IDLE] cycle={cycle} Output={out}")
        assert out == 0, f"At idle cycle {cycle}, expected Output=0, got {out}"


@cocotb.test()
async def test_preamble_bits(dut):
    """On Start, the first 192 bits should match the known DESIRED_OUT prefix."""
    cocotb.start_soon(Clock(dut.Clock, 4, unit="ns").start())
    cocotb.start_soon(Clock(dut.Clock2, 2, unit="ns").start())

    # Reset
    dut.Reset.value = 1
    dut.Input.value = 0
    dut.Start.value = 0
    await Timer(10, unit="ns")
    dut.Reset.value = 0
    await Timer(4, unit="ns")

    # Issue a Start pulse
    dut.Start.value = 1
    await Timer(4, unit="ns")
    dut.Start.value = 0

    # Skip one cycle for FSM to enter PREAMBLE
    await FallingEdge(dut.Clock2)

    # Collect the next 192 preamble bits
    seen = ""
    for _ in range(192):
        await FallingEdge(dut.Clock2)
        seen += str(int(dut.Output.value))

    # The expected 192‐bit prefix you provided:
    expected = (
        "1100110011001100110011001100110011001100110011001100110011001100"
        "1100110011001100110011001100110011001100110011001100110011001100"
        "1100110011001100110011001100110011001100110011001100110011001100"
    )

    dut._log.info(f"[PREAMBLE192] saw={seen}")
    assert seen == expected, (
        f"Preamble192 mismatch:\n"
        f" saw     = {seen}\n"
        f" expected= {expected}"
    )


