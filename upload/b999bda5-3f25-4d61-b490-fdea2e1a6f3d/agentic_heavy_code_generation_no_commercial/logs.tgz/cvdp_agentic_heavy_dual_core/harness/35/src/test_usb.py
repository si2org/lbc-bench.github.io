
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import Timer, RisingEdge, FallingEdge
import random

CLK_PERIOD = 20  # 48 MHz clock

USB_PID_SETUP = 0b0011
USB_PID_IN    = 0b1001
USB_PID_OUT   = 0b0001
USB_PID_ACK   = 0b0010
USB_PID_DATA0 = 0b1100
USB_PID_DATA1 = 0b0100

@cocotb.test()
async def test_usb_transaction(dut):
    cocotb.start_soon(Clock(dut.clk_48, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())

    # Apply reset
    dut.rst_n.value = 0
    dut.rx_j.value = 1
    dut.rx_se0.value = 0
    dut.tx_en.value = 0
    dut.tx_j.value = 0
    dut.tx_se0.value = 0
    dut.data_in.value = 0
    dut.data_in_valid.value = 0
    dut.handshake.value = 0
    await Timer(100, unit="ns")
    dut.rst_n.value = 1
    await Timer(100, unit="ns")

    # Simulate USB token reception (SYNC + PID)
    dut._log.info("Simulating SETUP Token")
    for _ in range(4):
        dut.rx_j.value = 1
        dut.rx_se0.value = 0
        await Timer(8, unit="ns")
    dut.rx_j.value = 0
    dut.rx_se0.value = 1
    await Timer(10, unit="ns")

    # Simulate USB DATA0 payload (8 bytes)
    dut._log.info("Sending DATA0 Payload")
    payload = [0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07]
    for byte in payload:
        dut.data_in.value = byte
        dut.data_in_valid.value = 1
        await RisingEdge(dut.clk_48)
        await Timer(6, unit="ns")
        dut.data_in_valid.value = 0
        await Timer(6, unit="ns")
        dut._log.info(f"Sent byte: 0x{byte:02X}")

    # Simulate ACK Handshake
    dut._log.info("Sending ACK handshake")
    dut.handshake.value = 0  # 0b00 = ACK
    await Timer(20, unit="ns")

    # Observe TX outputs after packet
    dut.tx_en.value = 1
    dut.tx_j.value = 1
    dut.tx_se0.value = 0
    await Timer(10, unit="ns")
    dut._log.info(f"TX: en={int(dut.tx_en.value)}, j={int(dut.tx_j.value)}, se0={int(dut.tx_se0.value)}")

    dut.tx_en.value = 0
    dut.tx_j.value = 0
    dut.tx_se0.value = 1
    await Timer(10, unit="ns")
    dut._log.info(f"TX Idle: en={int(dut.tx_en.value)}, j={int(dut.tx_j.value)}, se0={int(dut.tx_se0.value)}")

    # Final status
    dut._log.info(f"Transaction Active: {int(dut.transaction_active.value)}")
    dut._log.info(f"Data Strobe: {int(dut.data_strobe.value)}")
    dut._log.info(f"Success: {int(dut.success.value)}")
    dut._log.info("Single USB transaction test completed.")

async def apply_reset(dut):
    dut.rst_n.value = 0
    await Timer(100, unit='ns')
    dut.rst_n.value = 1
    await Timer(100, unit='ns')

@cocotb.test()
async def test_usb_rx_tx(dut):
    cocotb.start_soon(Clock(dut.clk_48, CLK_PERIOD, unit='ns', period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())
    await apply_reset(dut)

    dut._log.info("=== TEST: USB Reset detection (usb_rst) ===")
    dut.rx_se0.value = 1
    dut.rx_j.value = 0
    await Timer(5000, unit='ns')  # hold SE0 to trigger reset
    dut._log.info(f"usb_rst: {int(dut.usb_rst.value)}")
    dut.rx_se0.value = 0

    dut._log.info("=== TEST: Protocol sync + token reception ===")
    for i in range(10):
        dut.rx_j.value = i % 2
        dut.rx_se0.value = 0
        await Timer(10, unit='ns')

    dut._log.info("=== TEST: Send RX jitter noise and check transaction_active ===")
    for i in range(50):
        dut.rx_j.value = random.randint(0, 1)
        dut.rx_se0.value = random.randint(0, 1)
        await Timer(10, unit='ns')
    dut._log.info(f"transaction_active: {int(dut.transaction_active.value)}")

    dut._log.info("=== TEST: TX Path - Valid IN transaction ===")
    for i in range(20):
        dut.data_in.value = i
        dut.data_in_valid.value = 1
        await RisingEdge(dut.clk_48)
        await Timer(5, unit='ns')
        dut.data_in_valid.value = 0
        await FallingEdge(dut.clk_48)

    dut._log.info("=== TEST: Endpoint handshake behavior ===")
    for hs in range(4):
        dut.handshake.value = hs
        await Timer(20, unit='ns')
        dut._log.info(f"Handshake {hs}: success={int(dut.success.value)}")

    dut._log.info("=== TEST: Toggle TX line activity ===")
    for i in range(20):
        dut.tx_j.value = random.randint(0, 1)
        dut.tx_se0.value = random.randint(0, 1)
        await Timer(15, unit='ns')

    dut._log.info("=== TEST: Toggle RX line activity ===")
    for i in range(20):
        dut.rx_j.value = random.randint(0, 1)
        dut.rx_se0.value = random.randint(0, 1)
        await Timer(10, unit='ns')

    dut._log.info("=== TEST: Stimulate endpoint toggle/handshake logic ===")
    for i in range(30):
        dut.data_in.value = (i ^ 0xA5) & 0xFF
        dut.data_in_valid.value = random.randint(0, 1)
        dut.handshake.value = random.randint(0, 3)
        await Timer(12, unit='ns')

    dut._log.info("=== TEST: Final idle check ===")
    dut.data_in_valid.value = 0
    dut.rx_se0.value = 1
    dut.rx_j.value = 0
    await Timer(200, unit='ns')
    dut._log.info(f"Final usb_rst={int(dut.usb_rst.value)}, transaction_active={int(dut.transaction_active.value)}")
    
@cocotb.test()
async def test_usb_all_modules(dut):
    cocotb.start_soon(Clock(dut.clk_48, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())
    await apply_reset(dut)

    # === USB Reset Detection (usb_reset_detect) ===
    dut._log.info("Testing usb_reset_detect via SE0 line")
    dut.rx_j.value = 0
    dut.rx_se0.value = 1
    await Timer(5000, unit='ns')  # simulate SE0 long enough
    assert dut.usb_rst.value == 1, "usb_rst should be asserted during SE0 condition"
    dut.rx_se0.value = 0

    # === USB Sync Detection and NRZI decode ===
    dut._log.info("Testing NRZI decode and sync pattern")
    for i in range(20):
        dut.rx_j.value = i % 2
        await Timer(10, unit='ns')

    # === CRC Check (usb_crc5 / usb_crc16) via receive strobe ===
    dut._log.info("Testing CRC logic and packet FSM")
    for _ in range(50):
        dut.rx_j.value = random.randint(0, 1)
        dut.rx_se0.value = random.randint(0, 1)
        await Timer(10, unit='ns')

    # === Transmit FSM test ===
    dut._log.info("Testing usb_tx state transitions and strobe logic")
    for i in range(20):
        dut.data_in.value = i
        dut.data_in_valid.value = 1
        await RisingEdge(dut.clk_48)
        await FallingEdge(dut.clk_48)
        dut.data_in_valid.value = 0
        await Timer(5, unit='ns')

    # === usb_ep and handshake logic ===
    dut._log.info("Testing usb_ep endpoint response logic")
    for handshake in range(4):
        dut.handshake.value = handshake
        await Timer(15, unit='ns')
        dut._log.info(f"handshake={handshake}, success={int(dut.success.value)}")

    # === Test bit destuff, clk recovery, and sync detect ===
    dut._log.info("Testing bit destuff, clock recovery, and sync detect")
    for _ in range(30):
        dut.rx_j.value = random.randint(0, 1)
        await Timer(10, unit='ns')

    # === Toggle and transaction test ===
    dut._log.info("Testing protocol FSM and transaction_active behavior")
    for i in range(100):
        dut.rx_j.value = i % 2
        dut.rx_se0.value = (i % 5 == 0)
        dut.tx_j.value = (i % 3 == 0)
        dut.tx_se0.value = (i % 7 == 0)
        dut.tx_en.value = i % 2
        dut.data_in.value = random.randint(0, 255)
        dut.data_in_valid.value = random.randint(0, 1)
        await Timer(10, unit="ns")
# === Sync Pattern and RX Stability Test ===
    dut._log.info("NRZI Decode and Sync Pattern")
    for _ in range(40):
        dut.rx_j.value = random.randint(0, 1)
        await Timer(8, unit='ns')

    # === CRC and Packet Decoding Test ===
    dut._log.info("Packet Decoding and CRC Checks")
    for _ in range(50):
        dut.rx_j.value = random.randint(0, 1)
        dut.rx_se0.value = random.randint(0, 1)
        await Timer(10, unit='ns')

    # === TX Path Basic and Extended Test ===
    dut._log.info("TX Data Transfer Test")
    for i in range(50):
        val = (i * 13) & 0xFF
        dut.data_in.value = val
        dut.data_in_valid.value = 1
        await RisingEdge(dut.clk_48)
        await FallingEdge(dut.clk_48)
        dut.data_in_valid.value = 0
        await Timer(5, unit='ns')

    # === Endpoint Handshake Test ===
    dut._log.info("Endpoint Handshake Test")
    for hs in range(4):
        for _ in range(3):
            dut.handshake.value = hs
            await Timer(15, unit='ns')

    # === RX Glitch Filter and Bit Destuff Test ===
    dut._log.info("Bit Destuff and Glitch Rejection")
    for _ in range(60):
        dut.rx_j.value = random.randint(0, 1)
        await Timer(7, unit='ns')

    # === Protocol FSM Stimulus ===
    dut._log.info("Full Protocol FSM Stimulus")
    for i in range(100):
        dut.rx_j.value = (i % 2)
        dut.rx_se0.value = (i % 4 == 0)
        dut.tx_j.value = (i % 3 == 0)
        dut.tx_se0.value = (i % 5 == 0)
        dut.tx_en.value = (i % 2)
        dut.data_in.value = (i * 9) & 0xFF
        dut.data_in_valid.value = (i % 3 == 0)
        await Timer(10, unit="ns")

    # === Toggle/Setup/Success Behavior ===
    dut._log.info("Endpoint Setup and Toggle Handling")
    for i in range(32):
        dut.data_in.value = (i ^ 0x3C) & 0xFF
        dut.data_in_valid.value = i % 2
        dut.handshake.value = i % 4
        await Timer(12, unit='ns')

    # === USB IDLE Sequence to check recovery ===
    dut._log.info("IDLE Bus State Check")
    dut.data_in_valid.value = 0
    dut.rx_j.value = 1
    dut.rx_se0.value = 1
    await Timer(300, unit='ns')

    # === CRC Roll and Retry Stimulus ===
    dut._log.info("Rolling CRC-like Data Stream")
    for i in range(50):
        val = ((i ^ (i << 1)) + 13) & 0xFF
        dut.data_in.value = val
        dut.data_in_valid.value = 1
        await Timer(12, unit='ns')
        dut.data_in_valid.value = 0
        await Timer(5, unit='ns')
        
@cocotb.test()
async def test_usb_max_coverage(dut):
    cocotb.start_soon(Clock(dut.clk_48, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())
    await apply_reset(dut)

    # 1. USB Reset Hold Test
    dut._log.info("TEST: USB Reset Hold")
    dut.rx_se0.value = 1
    await Timer(8000, unit='ns')
    assert dut.usb_rst.value == 1
    dut.rx_se0.value = 0

    # 2. Alternating line patterns
    dut._log.info("TEST: Alternating RX lines")
    for _ in range(50):
        dut.rx_j.value = random.randint(0, 1)
        dut.rx_se0.value = random.randint(0, 1)
        await Timer(random.randint(5, 15), unit='ns')

    # 3. Invalid handshake values (simulating protocol error)
    dut._log.info("TEST: Invalid Handshake Scenarios")
    for h in range(4, 8):
        dut.handshake.value = h & 0x3
        await Timer(10, unit='ns')

    # 4. Repeated IN transaction data
    dut._log.info("TEST: Repeated IN Transactions")
    for i in range(16):
        val = (i * 19) & 0xFF
        dut.data_in.value = val
        dut.data_in_valid.value = 1
        await RisingEdge(dut.clk_48)
        dut.data_in_valid.value = 0
        await Timer(10, unit='ns')

    # 5. Staggered toggle activity
    dut._log.info("TEST: Endpoint Toggle Transitions")
    for i in range(32):
        dut.handshake.value = i % 4
        dut.tx_en.value = (i % 2)
        dut.tx_j.value = (i >> 1) & 1
        dut.tx_se0.value = (i >> 2) & 1
        await Timer(8, unit='ns')

    # 6. High-speed random fuzzing (aggressive)
    dut._log.info("TEST: Fuzzing RX/TX")
    for i in range(100):
        dut.rx_j.value = random.randint(0, 1)
        dut.rx_se0.value = random.randint(0, 1)
        dut.tx_j.value = random.randint(0, 1)
        dut.tx_se0.value = random.randint(0, 1)
        dut.tx_en.value = random.randint(0, 1)
        dut.data_in.value = random.randint(0, 255)
        dut.data_in_valid.value = random.randint(0, 1)
        await Timer(6, unit='ns')

    # 7. Bitwalk data_in test
    dut._log.info("TEST: Bitwalk Pattern")
    for i in range(8):
        val = 1 << i
        dut.data_in.value = val
        dut.data_in_valid.value = 1
        await Timer(12, unit='ns')
        dut.data_in_valid.value = 0
        await Timer(8, unit='ns')

    # 8. Boundary Value RX/TX flip
    dut._log.info("TEST: Boundary Patterns")
    boundaries = [0x00, 0xFF, 0x7F, 0x80]
    for val in boundaries:
        dut.data_in.value = val
        dut.data_in_valid.value = 1
        dut.tx_en.value = 1
        await Timer(20, unit='ns')
        dut.data_in_valid.value = 0
        dut.tx_en.value = 0
        await Timer(10, unit='ns')

    # 9. CRC-validating pseudo random test
    dut._log.info("TEST: CRC Patterned Inputs")
    for i in range(64):
        val = (i ^ (i << 2) ^ (i >> 1)) & 0xFF
        dut.data_in.value = val
        dut.data_in_valid.value = i % 2
        await Timer(11, unit='ns')

    # 10. Final Quiet Line Check
    dut._log.info("TEST: Final Quiet IDLE")
    dut.data_in_valid.value = 0
    dut.rx_j.value = 1
    dut.rx_se0.value = 0
    await Timer(200, unit='ns')

def check_tx(dut, expected_en, expected_j, expected_se0):
    assert int(dut.tx_en.value) == expected_en, f"TX_EN expected {expected_en}, got {int(dut.tx_en.value)}"
    assert int(dut.tx_j.value) == expected_j, f"TX_J expected {expected_j}, got {int(dut.tx_j.value)}"
    assert int(dut.tx_se0.value) == expected_se0, f"TX_SE0 expected {expected_se0}, got {int(dut.tx_se0.value)}"

def check_rx(dut):
    rx_valid = int(dut.rx_j.value) in [0, 1] and int(dut.rx_se0.value) in [0, 1]
    assert rx_valid, f"Invalid RX line values: rx_j={int(dut.rx_j.value)}, rx_se0={int(dut.rx_se0.value)}"

def check_data_transfer(dut, val, should_valid):
    assert int(dut.data_in.value) == val, f"Expected data_in=0x{val:02X}, got 0x{int(dut.data_in.value):02X}"
    assert int(dut.data_in_valid.value) == should_valid, f"Expected data_in_valid={should_valid}, got {int(dut.data_in_valid.value)}"

def check_transaction(dut):
    assert int(dut.transaction_active.value) in [0, 1], "transaction_active should be binary"


    dut._log.info(f"Final Results: usb_rst={int(dut.usb_rst.value)}, tx_en={int(dut.tx_en.value)}, transaction_active={int(dut.transaction_active.value)}")
    dut._log.info("USB MAX COVERAGE TEST COMPLETE")


    # === Final Check Summary ===
    dut._log.info(f"Final usb_rst={int(dut.usb_rst.value)} transaction_active={int(dut.transaction_active.value)}")
    dut._log.info("USB Full Coverage Test Completed.")
    # === Final state check ===
    dut._log.info(f"Final status: usb_rst={int(dut.usb_rst.value)}, transaction_active={int(dut.transaction_active.value)}")

    dut._log.info("USB Full System Test Passed.")

    dut._log.info("=== USB Complete PASS ===")
