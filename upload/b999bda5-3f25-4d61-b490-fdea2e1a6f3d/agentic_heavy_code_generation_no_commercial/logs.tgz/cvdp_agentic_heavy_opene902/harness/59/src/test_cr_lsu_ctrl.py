import cocotb
from cocotb.triggers import RisingEdge, Timer


async def clock_gen(signal):
    while True:
        signal.value = 0
        await Timer(5, unit="ns")
        signal.value = 1
        await Timer(5, unit="ns")


async def reset_dut(dut):
    dut.cpurst_b.value = 0
    await RisingEdge(dut.sm_clk)
    await RisingEdge(dut.sm_clk)
    dut.cpurst_b.value = 1
    await RisingEdge(dut.sm_clk)
    await RisingEdge(dut.sm_clk)
    


@cocotb.test()
async def test_basic_fast_retire(dut):
    dut._log.info("Test 1 Basic request granted and fast retire")

    cocotb.start_soon(clock_gen(dut.sm_clk))
    await reset_dut(dut)

    dut.iu_lsu_ex_data_sel.value = 1
    dut.iu_lsu_ex_sel.value = 1
    dut.iu_lsu_ex_store.value = 0
    dut.iu_lsu_oper_mux_en.value = 1
    dut.iu_lsu_stall_without_hready.value = 0
    dut.iu_lsu_wb_ldst.value = 0
    dut.iu_lsu_wb_load.value = 1
    dut.iu_lsu_wb_store.value = 0
    dut.dp_ctrl_misalign.value = 0
    dut.bmu_lsu_grnt.value = 1
    dut.bmu_lsu_trans_cmplt.value = 1
    dut.bmu_lsu_data_vld.value = 1
    dut.bmu_lsu_acc_err.value = 0
    dut.bmu_lsu_bstack_chk_fail.value = 0
    dut.iu_yy_xx_flush.value = 0
    dut.unalign_ctrl_not_last_beat.value = 0
    dut.unalign_ctrl_stall.value = 0
    dut.unalign_xx_split_on.value = 0

    await RisingEdge(dut.sm_clk)

    dut._log.info(
        f"lsu_bmu_req {int(dut.lsu_bmu_req.value)} "
        f"lsu_iu_req {int(dut.lsu_iu_req.value)} "
        f"lsu_iu_fast_retire {int(dut.lsu_iu_fast_retire.value)} "
        f"lsu_bmu_idle {int(dut.lsu_bmu_idle.value)}"
    )

    assert int(dut.lsu_bmu_req.value) == 1, "lsu_bmu_req should be 1"
    assert int(dut.lsu_iu_req.value) == 1, "lsu_iu_req should be 1"
    assert int(dut.lsu_iu_fast_retire.value) == 1, "lsu_iu_fast_retire should be 1"
    assert int(dut.lsu_bmu_idle.value) == 1, "lsu_bmu_idle should be 1"

    await Timer(10, unit="ns")


@cocotb.test()
async def test_ctrl_dp_ldst_info_buf_reuse_behavior(dut):
    dut._log.info("Test 2 Load-store instruction buffer reuse")

    cocotb.start_soon(clock_gen(dut.sm_clk))
    await reset_dut(dut)

    dut.iu_lsu_ex_data_sel.value = 1
    dut.iu_lsu_ex_sel.value = 0
    dut.iu_lsu_ex_store.value = 0
    dut.iu_lsu_oper_mux_en.value = 0
    dut.iu_lsu_stall_without_hready.value = 0
    dut.iu_lsu_wb_ldst.value = 1
    dut.iu_lsu_wb_load.value = 0
    dut.iu_lsu_wb_store.value = 1
    dut.dp_ctrl_misalign.value = 0
    dut.bmu_lsu_grnt.value = 1
    dut.bmu_lsu_trans_cmplt.value = 1
    dut.bmu_lsu_data_vld.value = 0
    dut.bmu_lsu_acc_err.value = 1
    dut.bmu_lsu_bstack_chk_fail.value = 0
    dut.iu_yy_xx_flush.value = 0
    dut.unalign_ctrl_not_last_beat.value = 0
    dut.unalign_ctrl_stall.value = 0
    dut.unalign_xx_split_on.value = 0

    await RisingEdge(dut.sm_clk)

    dut._log.info(
        f"cur_state = {int(dut.cur_state.value)} , "
        f"ctrl_dp_ldst_info_buf_reuse = {int(dut.ctrl_dp_ldst_info_buf_reuse.value)}"
    )
    assert int(dut.cur_state.value) == 0, "The FSM is not in the correct state" 
    assert int(dut.ctrl_dp_ldst_info_buf_reuse.value) == 1, "ctrl_dp_ldst_info_buf_reuse should be 1"
    await Timer(10, unit="ns")


@cocotb.test()
async def test_ctrl_dp_store_buffer_updt_behavior(dut):
    dut._log.info("Test 3 Store Buffer Update with new instruction")

    cocotb.start_soon(clock_gen(dut.sm_clk))
    await reset_dut(dut)

    dut.iu_lsu_ex_data_sel.value = 1
    dut.iu_lsu_ex_sel.value = 0
    dut.iu_lsu_ex_store.value = 1
    dut.iu_lsu_oper_mux_en.value = 1
    dut.iu_lsu_stall_without_hready.value = 0
    dut.iu_lsu_wb_ldst.value = 0
    dut.iu_lsu_wb_load.value = 0
    dut.iu_lsu_wb_store.value = 1
    dut.dp_ctrl_misalign.value = 0
    dut.bmu_lsu_grnt.value = 1
    dut.bmu_lsu_trans_cmplt.value = 1
    dut.bmu_lsu_data_vld.value = 0
    dut.bmu_lsu_acc_err.value = 0
    dut.bmu_lsu_bstack_chk_fail.value = 0
    dut.iu_yy_xx_flush.value = 0
    dut.unalign_ctrl_not_last_beat.value = 0
    dut.unalign_ctrl_stall.value = 0
    dut.unalign_xx_split_on.value = 0

    await RisingEdge(dut.sm_clk)

    dut._log.info(
        f"cur_state = {int(dut.cur_state.value)} , "
        f"ctrl_dp_store_buffer_updt = {int(dut.ctrl_dp_store_buffer_updt.value)}"
    )
    assert int(dut.cur_state.value) == 0, "The FSM is not in the correct state" 
    assert int(dut.ctrl_dp_store_buffer_updt.value) == 1, "ctrl_dp_store_buffer_updt should be 1"
    await Timer(10, unit="ns")


@cocotb.test()
async def test_lsu_iu_data_vld(dut):
    dut._log.info("Test 4 Load Data Valid Signal to IU")

    cocotb.start_soon(clock_gen(dut.sm_clk))
    await reset_dut(dut)

    dut.iu_lsu_ex_data_sel.value = 1
    dut.iu_lsu_ex_sel.value = 0
    dut.iu_lsu_ex_store.value = 1
    dut.iu_lsu_oper_mux_en.value = 1
    dut.iu_lsu_stall_without_hready.value = 0
    dut.iu_lsu_wb_ldst.value = 0
    dut.iu_lsu_wb_load.value = 0
    dut.iu_lsu_wb_store.value = 1
    dut.dp_ctrl_misalign.value = 0
    dut.bmu_lsu_grnt.value = 1
    dut.bmu_lsu_trans_cmplt.value = 1
    dut.bmu_lsu_data_vld.value = 1
    dut.bmu_lsu_acc_err.value = 0
    dut.bmu_lsu_bstack_chk_fail.value = 0
    dut.iu_yy_xx_flush.value = 0
    dut.unalign_ctrl_not_last_beat.value = 0
    dut.unalign_ctrl_stall.value = 0
    dut.unalign_xx_split_on.value = 1

    await RisingEdge(dut.sm_clk)
    await RisingEdge(dut.sm_clk)

    dut._log.info(
        f"cur_state = {int(dut.cur_state.value)} , "
        f"lsu_iu_data_vld = {int(dut.lsu_iu_data_vld.value)}"
    )
    assert int(dut.cur_state.value) == 1, "The FSM is not in the correct state" 
    assert int(dut.lsu_iu_data_vld.value) == 1, "lsu_iu_data_vld should be 1"
    await Timer(10, unit="ns")


@cocotb.test()
async def test_lsu_iu_expt_vld(dut):
    dut._log.info("Test 5 Valid Exception during Load Store Operation")

    cocotb.start_soon(clock_gen(dut.sm_clk))
    await reset_dut(dut)

    dut.iu_lsu_ex_data_sel.value = 1
    dut.iu_lsu_ex_sel.value = 0
    dut.iu_lsu_ex_store.value = 1
    dut.iu_lsu_oper_mux_en.value = 1
    dut.iu_lsu_stall_without_hready.value = 0
    dut.iu_lsu_wb_ldst.value = 0
    dut.iu_lsu_wb_load.value = 0
    dut.iu_lsu_wb_store.value = 1
    dut.dp_ctrl_misalign.value = 0
    dut.bmu_lsu_grnt.value = 1
    dut.bmu_lsu_trans_cmplt.value = 1
    dut.bmu_lsu_data_vld.value = 1
    dut.bmu_lsu_acc_err.value = 1
    dut.bmu_lsu_bstack_chk_fail.value = 0
    dut.iu_yy_xx_flush.value = 0
    dut.unalign_ctrl_not_last_beat.value = 0
    dut.unalign_ctrl_stall.value = 0
    dut.unalign_xx_split_on.value = 1

    await RisingEdge(dut.sm_clk)
    await RisingEdge(dut.sm_clk)

    dut._log.info(
        f"cur_state = {int(dut.cur_state.value)} , "
        f"lsu_iu_expt_vld = {int(dut.lsu_iu_expt_vld.value)}"
    )
    assert int(dut.cur_state.value) == 1, "The FSM is not in the correct state" 
    assert int(dut.lsu_iu_expt_vld.value) == 1, "lsu_iu_expt_vld should be 1"
    await Timer(10, unit="ns")


@cocotb.test()
async def test_lsu_had_addr_vld(dut):
    dut._log.info("Test 6 Valid Hardware Assisted Debug Address Available")

    cocotb.start_soon(clock_gen(dut.sm_clk))
    await reset_dut(dut)

    dut.iu_lsu_ex_data_sel.value = 1
    dut.iu_lsu_ex_sel.value = 0
    dut.iu_lsu_ex_store.value = 1
    dut.iu_lsu_oper_mux_en.value = 1
    dut.iu_lsu_stall_without_hready.value = 0
    dut.iu_lsu_wb_ldst.value = 0
    dut.iu_lsu_wb_load.value = 0
    dut.iu_lsu_wb_store.value = 1
    dut.dp_ctrl_misalign.value = 0
    dut.bmu_lsu_grnt.value = 1
    dut.bmu_lsu_trans_cmplt.value = 1
    dut.bmu_lsu_data_vld.value = 1
    dut.bmu_lsu_acc_err.value = 1
    dut.bmu_lsu_bstack_chk_fail.value = 0
    dut.iu_yy_xx_flush.value = 0
    dut.unalign_ctrl_not_last_beat.value = 0
    dut.unalign_ctrl_stall.value = 0
    dut.unalign_xx_split_on.value = 1

    await RisingEdge(dut.sm_clk)

    dut._log.info(
        f"cur_state = {int(dut.cur_state.value)} , "
        f"lsu_had_addr_vld = {int(dut.lsu_had_addr_vld.value)}"
    )
    assert int(dut.cur_state.value) == 0, "The FSM is not in the correct state" 
    assert int(dut.lsu_had_addr_vld.value) == 1, "lsu_had_addr_vld should be 1"
    await Timer(10, unit="ns")

