import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

@cocotb.test()
async def test_reset_only(dut):
    # Start the clock!
    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())
    dut.cpurst_b.value = 0
    for _ in range(3):
        await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    for _ in range(2):
        await RisingEdge(dut.clint_clk)
    msip_value = int(dut.msip_value.value)
    dut._log.info(f"Test1: msip_value = {msip_value:08x}")
    assert msip_value == 0, f"msip_value not zero after reset: {msip_value}"


@cocotb.test()
async def test_write_msip_mmode(dut):
    """Test2: Write MSIP in M-mode"""

    # Start the clock (safe to do again)
    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())

    # Reset
    dut.cpurst_b.value = 0
    for _ in range(3):
        await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    for _ in range(2):
        await RisingEdge(dut.clint_clk)

    # Set up inputs for MSIP write in M-mode
    dut.cpu_clint_mode.value = 0b11        # M-mode
    dut.busif_regs_wdata.value = 1         # Set LSB
    dut.busif_regs_msip_sel.value = 1
    dut.busif_regs_write_vld.value = 1

    # Wait two clocks as in the Verilog TB
    await RisingEdge(dut.clint_clk)
    await RisingEdge(dut.clint_clk)

    # Deassert after write
    dut.busif_regs_msip_sel.value = 0
    dut.busif_regs_write_vld.value = 0
    await RisingEdge(dut.clint_clk)

    # Sample output
    msip_value = int(dut.msip_value.value)
    clint_cpu_ms_int = int(dut.clint_cpu_ms_int.value)
    dut._log.info(f"Test2: Write MSIP in M-mode msip_value = {msip_value:08x}, clint_cpu_ms_int = {clint_cpu_ms_int}")

    assert (msip_value == 1 and clint_cpu_ms_int == 1), f"FAIL: Test2 msip_value = {msip_value:08x}, clint_cpu_ms_int = {clint_cpu_ms_int}"

@cocotb.test()
async def test_write_mtimecmp_lo_mmode(dut):
    """Test3: Write MTIMECMP_LO in M-mode"""

    # Start clock (if not already running in your sim setup)
    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())

    # Reset
    dut.cpurst_b.value = 0
    for _ in range(3):
        await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    for _ in range(2):
        await RisingEdge(dut.clint_clk)

    # Set up for MTIMECMP_LO write in M-mode
    dut.cpu_clint_mode.value = 0b11
    dut.busif_regs_wdata.value = 0xA5A5A5A5
    dut.busif_regs_mtimecmp_lo_sel.value = 1
    dut.busif_regs_write_vld.value = 1

    # Hold select and write for 2 cycles (as in original Verilog TB)
    await RisingEdge(dut.clint_clk)
    await RisingEdge(dut.clint_clk)

    # Deassert after write
    dut.busif_regs_mtimecmp_lo_sel.value = 0
    dut.busif_regs_write_vld.value = 0
    await RisingEdge(dut.clint_clk)

    # Check output
    mtimecmp_lo_value = int(dut.mtimecmp_lo_value.value)
    dut._log.info(f"Test3: Write MTIMECMP_LO in M-mode mtimecmp_lo_value = {mtimecmp_lo_value:08x}")
    assert mtimecmp_lo_value == 0xA5A5A5A5, f"FAIL: Test3 mtimecmp_lo_value = {mtimecmp_lo_value:08x}"

@cocotb.test()
async def test_write_mtimecmp_hi_mmode(dut):
    """Test4: Write MTIMECMP_HI in M-mode"""

    # Start clock (safe even if started before)
    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())

    # Reset
    dut.cpurst_b.value = 0
    for _ in range(3):
        await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    for _ in range(2):
        await RisingEdge(dut.clint_clk)

    # Set up for MTIMECMP_HI write in M-mode
    dut.cpu_clint_mode.value = 0b11
    dut.busif_regs_wdata.value = 0x5A5A5A5A
    dut.busif_regs_mtimecmp_hi_sel.value = 1
    dut.busif_regs_write_vld.value = 1

    # Hold select and write for 2 cycles (as in Verilog TB)
    await RisingEdge(dut.clint_clk)
    await RisingEdge(dut.clint_clk)

    # Deassert after write
    dut.busif_regs_mtimecmp_hi_sel.value = 0
    dut.busif_regs_write_vld.value = 0
    await RisingEdge(dut.clint_clk)

    # Check output
    mtimecmp_hi_value = int(dut.mtimecmp_hi_value.value)
    dut._log.info(f"Test4: Write MTIMECMP_HI in M-mode mtimecmp_hi_value = {mtimecmp_hi_value:08x}")
    assert mtimecmp_hi_value == 0x5A5A5A5A, f"FAIL: Test4 mtimecmp_hi_value = {mtimecmp_hi_value:08x}"

@cocotb.test()
async def test_write_msip_non_mmode(dut):
    """Test5: Write MSIP in non M-mode"""

    # Start the clock (only once per simulation if you have multiple tests!)
    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())

    # Reset sequence
    dut.cpurst_b.value = 0
    await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    await RisingEdge(dut.clint_clk)

    # Non-M-mode write attempt
    dut.cpu_clint_mode.value = 0b01        # Not M-mode
    dut.busif_regs_wdata.value = 1
    dut.busif_regs_msip_sel.value = 1
    dut.busif_regs_write_vld.value = 1
        
    # Sample outputs
    msip_value = int(dut.msip_value.value)
    clint_cpu_ms_int = int(dut.clint_cpu_ms_int.value)
    dut._log.info(f"Test5: Write MSIP in non M-mode msip_value = {msip_value:08x}, clint_cpu_ms_int = {clint_cpu_ms_int}")

    # This write should NOT be accepted, so both values should remain 0 after reset.
    assert msip_value == 0 and clint_cpu_ms_int == 0, \
        f"FAIL: Test5 msip_value = {msip_value:08x}, clint_cpu_ms_int = {clint_cpu_ms_int}"


@cocotb.test()
async def test_write_mtimecmp_lo_non_mmode(dut):
    """Test6: Write MTIMECMP_LO in non M-mode"""

    # Start the clock (do this only once if you run all tests in a suite)
    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())

    # Reset sequence
    dut.cpurst_b.value = 0
    await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    await RisingEdge(dut.clint_clk)

    # Attempt to write MTIMECMP_LO in non-M-mode
    dut.cpu_clint_mode.value = 0b00   # Not M-mode
    dut.busif_regs_wdata.value = 0x12345678
    dut.busif_regs_mtimecmp_lo_sel.value = 1
    dut.busif_regs_write_vld.value = 1
    await RisingEdge(dut.clint_clk)
    await RisingEdge(dut.clint_clk)

    # Sample output
    mtimecmp_lo_value = int(dut.mtimecmp_lo_value.value)
    dut._log.info(f"Test6: Write MTIMECMP_LO in non M-mode mtimecmp_lo_value = {mtimecmp_lo_value:08x}")

    # Should remain at reset value (0), because write is ignored unless in M-mode
    assert mtimecmp_lo_value == 0, f"FAIL: Test6 mtimecmp_lo_value = {mtimecmp_lo_value:08x}"

@cocotb.test()
async def test_mtime_update(dut):
    """Test7: MTIME update"""

    # Start the clock (do this only once per simulation if you have multiple tests!)
    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())

    # Optionally reset for completeness (good practice)
    dut.cpurst_b.value = 0
    for _ in range(3):
        await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    for _ in range(2):
        await RisingEdge(dut.clint_clk)

    # Set sysio_clint_mtime to test value
    dut.sysio_clint_mtime.value = 0xFFFF0000AAAA5555
    await RisingEdge(dut.clint_clk)

    # Read outputs
    mtime_lo_value = int(dut.mtime_lo_value.value)
    mtime_hi_value = int(dut.mtime_hi_value.value)
    dut._log.info(f"Test7: mtime_lo_value = {mtime_lo_value:08x}, mtime_hi_value = {mtime_hi_value:08x}")

    # Check that the lower 32 bits and upper 32 bits are extracted correctly
    assert mtime_lo_value == 0xAAAA5555 and mtime_hi_value == 0xFFFF0000, \
        f"FAIL: Test7 mtime_lo_value = {mtime_lo_value:08x}, mtime_hi_value = {mtime_hi_value:08x}"


@cocotb.test()
async def test_mtint_trigger(dut):
    """Test8: MT interrupt generation"""

    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())

    # Reset for consistency
    dut.cpurst_b.value = 0
    for _ in range(3):
        await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    for _ in range(2):
        await RisingEdge(dut.clint_clk)

    # Set M-mode for writes
    dut.cpu_clint_mode.value = 0b11

    # Write mtimecmp_lo = 0x10
    dut.busif_regs_wdata.value = 0x10
    dut.busif_regs_mtimecmp_lo_sel.value = 1
    dut.busif_regs_write_vld.value = 1
    await RisingEdge(dut.clint_clk)
    await RisingEdge(dut.clint_clk)
    dut.busif_regs_mtimecmp_lo_sel.value = 0
    dut.busif_regs_write_vld.value = 0
    await RisingEdge(dut.clint_clk)

    # Write mtimecmp_hi = 0
    dut.busif_regs_wdata.value = 0
    dut.busif_regs_mtimecmp_hi_sel.value = 1
    dut.busif_regs_write_vld.value = 1
    await RisingEdge(dut.clint_clk)
    await RisingEdge(dut.clint_clk)
    dut.busif_regs_mtimecmp_hi_sel.value = 0
    dut.busif_regs_write_vld.value = 0
    await RisingEdge(dut.clint_clk)

    # Set mtime < mtimecmp
    dut.sysio_clint_mtime.value = 0xF
    await RisingEdge(dut.clint_clk)
    clint_cpu_mt_int_before = int(dut.clint_cpu_mt_int.value)
    dut._log.info(f"Test8: Before crossing mtimecmp clint_cpu_mt_int = {clint_cpu_mt_int_before}")
    assert clint_cpu_mt_int_before == 0, f"FAIL: Test8 (before) clint_cpu_mt_int = {clint_cpu_mt_int_before}"

    # Set mtime > mtimecmp
    dut.sysio_clint_mtime.value = 0x11
    await RisingEdge(dut.clint_clk)
    clint_cpu_mt_int_after = int(dut.clint_cpu_mt_int.value)
    dut._log.info(f"Test8: After crossing mtimecmp clint_cpu_mt_int = {clint_cpu_mt_int_after}")
    assert clint_cpu_mt_int_after == 1, f"FAIL: Test8 (after) clint_cpu_mt_int = {clint_cpu_mt_int_after}"


@cocotb.test()
async def test_me_int_passthru(dut):
    """Test9: ME external interrupt pass through"""

    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())

    # Optionally reset for completeness
    dut.cpurst_b.value = 0
    for _ in range(3):
        await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    for _ in range(2):
        await RisingEdge(dut.clint_clk)

    # Set ME interrupt high, then check
    dut.sysio_clint_me_int.value = 1
    await RisingEdge(dut.clint_clk)
    clint_cpu_me_int_1 = int(dut.clint_cpu_me_int.value)
    dut._log.info(f"Test9: clint_cpu_me_int = {clint_cpu_me_int_1}")
    assert clint_cpu_me_int_1 == 1, f"FAIL: Test9 (high) clint_cpu_me_int = {clint_cpu_me_int_1}"

    # Set ME interrupt low, then check
    dut.sysio_clint_me_int.value = 0
    await RisingEdge(dut.clint_clk)
    clint_cpu_me_int_0 = int(dut.clint_cpu_me_int.value)
    dut._log.info(f"Test9: clint_cpu_me_int = {clint_cpu_me_int_0}")
    assert clint_cpu_me_int_0 == 0, f"FAIL: Test9 (low) clint_cpu_me_int = {clint_cpu_me_int_0}"


@cocotb.test()
async def test_msip_clear(dut):
    """Test10: Clear MSIP"""

    cocotb.start_soon(Clock(dut.clint_clk, 10, unit="ns").start())

    # Optional: reset for completeness
    dut.cpurst_b.value = 0
    for _ in range(3):
        await RisingEdge(dut.clint_clk)
    dut.cpurst_b.value = 1
    for _ in range(2):
        await RisingEdge(dut.clint_clk)

    # FIRST: Set MSIP = 1 (so we can clear it)
    dut.cpu_clint_mode.value = 0b11
    dut.busif_regs_wdata.value = 1
    dut.busif_regs_msip_sel.value = 1
    dut.busif_regs_write_vld.value = 1
    await RisingEdge(dut.clint_clk)
    dut.busif_regs_msip_sel.value = 0
    dut.busif_regs_write_vld.value = 0
    await RisingEdge(dut.clint_clk)

    # NOW: Clear MSIP (write 0)
    dut.busif_regs_wdata.value = 0
    dut.busif_regs_msip_sel.value = 1
    dut.busif_regs_write_vld.value = 1
    await RisingEdge(dut.clint_clk)
    await RisingEdge(dut.clint_clk)
    dut.busif_regs_msip_sel.value = 0
    dut.busif_regs_write_vld.value = 0
    await RisingEdge(dut.clint_clk)

    # Sample outputs
    msip_value = int(dut.msip_value.value)
    clint_cpu_ms_int = int(dut.clint_cpu_ms_int.value)
    dut._log.info(f"Test10: Clear MSIP msip_value = {msip_value:08x}, clint_cpu_ms_int = {clint_cpu_ms_int}")

    assert msip_value == 0 and clint_cpu_ms_int == 0, \
        f"FAIL: Test10 msip_value = {msip_value:08x}, clint_cpu_ms_int = {clint_cpu_ms_int}"



