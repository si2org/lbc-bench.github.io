import cocotb
from cocotb.clock import Clock
from cocotb.triggers import Timer

async def init_signals(dut):
    # Initialize inputs to zero/default
    dut.bmu_iahbl_dbus_acc_deny.value = 0
    dut.bmu_iahbl_dbus_addr.value = 0
    dut.bmu_iahbl_dbus_chk_fail.value = 0
    dut.bmu_iahbl_dbus_prot.value = 0
    dut.bmu_iahbl_dbus_req.value = 0
    dut.bmu_iahbl_dbus_req_without_cmplt.value = 0
    dut.bmu_iahbl_dbus_size.value = 0
    dut.bmu_iahbl_dbus_wdata.value = 0
    dut.bmu_iahbl_dbus_write.value = 0
    dut.bmu_iahbl_ibus_acc_deny.value = 0
    dut.bmu_iahbl_ibus_addr.value = 0
    dut.bmu_iahbl_ibus_hit.value = 0
    dut.bmu_iahbl_ibus_prot.value = 0
    dut.bmu_iahbl_ibus_req.value = 0
    dut.bmu_iahbl_ibus_req_no_hit.value = 0
    dut.bmu_iahbl_ibus_size.value = 0
    dut.bmu_iahbl_ibus_vec_redirect.value = 0
    dut.dahblif_other_mask.value = 0
    dut.pad_cpu_halt_ff2.value = 0
    dut.pad_iahbl_hrdata.value = 0xCAFEBABE
    dut.pad_iahbl_hready.value = 1
    dut.pad_iahbl_hresp.value = 0
    dut.pad_yy_gate_clk_en_b.value = 1
    dut.pwrm_cpu_bus_peak_power_limit_en.value = 0
    dut.sahblif_iahblif_mask.value = 0

async def reset_dut(dut):
    # Assert reset
    dut.cpurst_b.value = 0
    await Timer(20, unit="ns")
    dut.cpurst_b.value = 1
    await Timer(10, unit="ns")

# Clock generator shared
async def start_clock(dut):
    cocotb.start_soon(Clock(dut.forever_cpuclk, 10, unit="ns").start())

@cocotb.test()
async def test_idle_state(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)
    # Check idle
    await Timer(10, unit="ns")
    idle = dut.ahblif_idle.value
    assert idle == 1, f"Idle FAILED: ahblif_idle={int(idle)}"
    dut._log.info(f"[Test1] Idle PASSED: ahblif_idle={int(idle)}")

@cocotb.test()
async def test_ibus_read_address(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)
    # IBus request
    dut.bmu_iahbl_ibus_req.value = 1
    dut.bmu_iahbl_ibus_hit.value = 1
    dut.bmu_iahbl_ibus_addr.value = 0xA5A5A5A5
    await Timer(10, unit="ns")
    addr = dut.iahbl_pad_haddr.value
    assert int(addr) == 0xA5A5A5A5, f"IBus Addr FAILED: got {int(addr):#x}"
    dut._log.info(f"[Test2] IBus Addr PASSED: haddr={int(addr):#x}")

@cocotb.test()
async def test_dbus_write_forwarding(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)
    # DBus write
    dut.bmu_iahbl_dbus_req_without_cmplt.value = 1
    dut.bmu_iahbl_dbus_write.value = 1
    dut.bmu_iahbl_dbus_addr.value = 0x5A5A5A5A
    dut.bmu_iahbl_dbus_wdata.value = 0xDEADDEAD
    await Timer(10, unit="ns")
    addr = dut.iahbl_pad_haddr.value
    write = dut.iahbl_pad_hwrite.value
    assert int(addr) == 0x5A5A5A5A and int(write) == 1, \
        f"DBus Write FAILED: haddr={int(addr):#x} hwrite={int(write)}"
    dut._log.info(f"[Test3] DBus Write PASSED: haddr={int(addr):#x} hwrite={int(write)}")

@cocotb.test()
async def test_dbus_size_forwarding(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)
    # DBus size
    dut.bmu_iahbl_dbus_req_without_cmplt.value = 1
    dut.bmu_iahbl_dbus_size.value = 0b10
    await Timer(10, unit="ns")
    hsize = dut.iahbl_pad_hsize.value
    assert int(hsize) == 0b010, f"DBus Size FAILED: hsize={int(hsize):b}"
    dut._log.info(f"[Test4] DBus Size PASSED: hsize={int(hsize):b}")

@cocotb.test()
async def test_peak_power_mask(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)

    # Assert IBus request and turn on the peak-power limiter
    dut.bmu_iahbl_ibus_req.value               = 1
    dut.bmu_iahbl_ibus_hit.value               = 1
    dut.pwrm_cpu_bus_peak_power_limit_en.value = 1

    # exactly like the Verilog "#10"
    await Timer(10, unit="ns")
    await Timer(10, unit="ns")
    
    mask = int(dut.iahblif_other_mask.value)
    assert mask == 1, f"Power Mask FAILED: other_mask={mask}"
    dut._log.info(f"[Test5] Power Mask PASSED: other_mask={mask}")


@cocotb.test()
async def test_ibus_grant(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)
    # IBus grant
    dut.bmu_iahbl_ibus_req.value = 1
    dut.bmu_iahbl_ibus_hit.value = 1
    await Timer(10, unit="ns")
    grnt = dut.iahbl_bmu_ibus_grnt.value
    assert int(grnt) == 1, f"IBus Grant FAILED: grnt={int(grnt)}"
    dut._log.info(f"[Test6] IBus Grant PASSED: grnt={int(grnt)}")

@cocotb.test()
async def test_ibus_data_forwarding(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)

    # Drive a valid IBus read
    dut.bmu_iahbl_ibus_req.value = 1
    dut.bmu_iahbl_ibus_hit.value = 1
    dut.pad_iahbl_hrdata.value   = 0xABCD1234
    dut.pad_iahbl_hready.value   = 1

    # exactly like the Verilog "#10"
    await Timer(10, unit="ns")
    await Timer(10, unit="ns")
    vld  = int(dut.iahbl_bmu_ibus_data_vld.value)
    data = int(dut.iahbl_bmu_ibus_data.value)
    assert vld == 1 and data == 0xABCD1234, \
        f"IBus Data FAILED: vld={vld} data=0x{data:08X}"
    dut._log.info(f"[Test7] IBus Data PASSED: vld={vld} data=0x{data:08X}")


@cocotb.test()
async def test_dbus_prot_forwarding(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)
    # DBus protection bits
    dut.bmu_iahbl_dbus_req_without_cmplt.value = 1
    dut.bmu_iahbl_dbus_prot.value = 0b1010
    await Timer(10, unit="ns")
    prot = dut.iahbl_pad_hprot.value
    assert int(prot) == 0b1010, f"DBus Prot FAILED: hprot={int(prot):b}"
    dut._log.info(f"[Test8] DBus Prot PASSED: hprot={int(prot):b}")

@cocotb.test()
async def test_hburst_single(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)
    # HBURST single
    dut.bmu_iahbl_ibus_req.value = 1
    dut.bmu_iahbl_ibus_hit.value = 1
    await Timer(10, unit="ns")
    burst = dut.iahbl_pad_hburst.value
    assert int(burst) == 0b000, f"Hburst FAILED: hburst={int(burst):b}"
    dut._log.info(f"[Test9] Hburst PASSED: hburst={int(burst):b}")

@cocotb.test()
async def test_htrans_nonseq(dut):
    await start_clock(dut)
    await init_signals(dut)
    await reset_dut(dut)
    # HTRANS NONSEQ
    dut.bmu_iahbl_ibus_req.value = 1
    dut.bmu_iahbl_ibus_hit.value = 1
    await Timer(10, unit="ns")
    htrans = dut.iahbl_pad_htrans.value
    assert int(htrans[1]) == 1, f"HTRANS FAILED: htrans={bin(int(htrans))}"
    dut._log.info(f"[Test10] HTRANS PASSED: htrans={bin(int(htrans))}")

