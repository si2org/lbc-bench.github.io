import cocotb
from cocotb.triggers import RisingEdge, FallingEdge

# Clock generator
async def clk_gen(dut):
    while True:
        dut.deny_clk.value = 0
        await cocotb.triggers.Timer(5, unit='ns')
        dut.deny_clk.value = 1
        await cocotb.triggers.Timer(5, unit='ns')

def initialize_dut_inputs(dut):
    dut.biu_bmu_dbus_acc_err.value = 0
    dut.biu_bmu_dbus_data.value = 0
    dut.biu_bmu_dbus_data_vld.value = 0
    dut.biu_bmu_dbus_grnt.value = 0
    dut.biu_bmu_dbus_trans_cmplt.value = 0
    dut.cp0_yy_machine_mode_aft_dbg.value = 0
    dut.cpurst_b.value = 1
    dut.iahbl_bmu_dbus_acc_err.value = 0
    dut.iahbl_bmu_dbus_data.value = 0
    dut.iahbl_bmu_dbus_data_vld.value = 0
    dut.iahbl_bmu_dbus_grnt.value = 0
    dut.iahbl_bmu_dbus_trans_cmplt.value = 0
    dut.lsu_bmu_addr.value = 0
    dut.lsu_bmu_addr_check_fail.value = 0
    dut.lsu_bmu_idle.value = 0
    dut.lsu_bmu_prot.value = 0
    dut.lsu_bmu_req.value = 0
    dut.lsu_bmu_req_without_cmplt.value = 0
    dut.lsu_bmu_sg_chk_fail.value = 0
    dut.lsu_bmu_size.value = 0
    dut.lsu_bmu_store_error.value = 0
    dut.lsu_bmu_wdata.value = 0
    dut.lsu_bmu_wfd1.value = 0
    dut.lsu_bmu_write.value = 0
    dut.pad_bmu_iahbl_base.value = 0
    dut.pad_bmu_iahbl_mask.value = 0
    dut.pmp_bmu_dbus_acc_deny.value = 0
    dut.tcipif_bmu_dbus_acc_err.value = 0
    dut.tcipif_bmu_dbus_data.value = 0
    dut.tcipif_bmu_dbus_data_vld.value = 0
    dut.tcipif_bmu_dbus_grnt.value = 0
    dut.tcipif_bmu_dbus_trans_cmplt.value = 0


async def reset_dut(dut):
    dut.cpurst_b.value = 0
    await RisingEdge(dut.deny_clk)
    dut.cpurst_b.value = 1
    await RisingEdge(dut.deny_clk)



@cocotb.test()
async def test_reset(dut):
    """Test 1 : Verifying BMU FSM and Register Reset"""
    cocotb.start_soon(clk_gen(dut))
    dut.cpurst_b.value = 0
    await RisingEdge(dut.deny_clk)
    cross_cur_st = int(dut.cross_cur_st.value)
    iahbl_norm_hit_ff = int(dut.iahbl_norm_hit_ff.value)
    cur_state = int(dut.cur_state.value)
    cocotb.log.info(f"cross_cur_st[2:0] = {cross_cur_st}")
    cocotb.log.info(f"iahbl_norm_hit_ff = {iahbl_norm_hit_ff}")
    cocotb.log.info(f"cur_state = {cur_state}")
    assert cross_cur_st == 0, "cross_cur_st[2:0] is not 0 after reset"
    assert iahbl_norm_hit_ff == 0, "iahbl_norm_hit_ff is not 0 after reset"
    assert cur_state == 0, "cur_state is not 0 after reset"
    dut.cpurst_b.value = 1
    await FallingEdge(dut.deny_clk)


@cocotb.test()
async def test_bmu_biu_dbus_acc_deny(dut):
    """Test 2 : BMU BIU DBUS Access Deny Logic Verification"""
    cocotb.start_soon(clk_gen(dut))
    dut.pmp_bmu_dbus_acc_deny.value = 1
    dut.lsu_bmu_sg_chk_fail.value = 0
    dut.lsu_bmu_store_error.value = 0
    await RisingEdge(dut.deny_clk)
    acc_deny = int(dut.acc_deny.value)
    bmu_biu_dbus_acc_deny = int(dut.bmu_biu_dbus_acc_deny.value)
    cocotb.log.info(f"acc_deny = {acc_deny}")
    cocotb.log.info(f"bmu_biu_dbus_acc_deny = {bmu_biu_dbus_acc_deny}")
    assert acc_deny == 1, "acc_deny should be 1"
    assert bmu_biu_dbus_acc_deny == 1, "bmu_biu_dbus_acc_deny should be 1"
    await RisingEdge(dut.deny_clk)
    dut.pmp_bmu_dbus_acc_deny.value = 0
    dut.lsu_bmu_sg_chk_fail.value = 1
    dut.lsu_bmu_store_error.value = 0
    acc_deny = int(dut.acc_deny.value)
    bmu_biu_dbus_acc_deny = int(dut.bmu_biu_dbus_acc_deny.value)
    cocotb.log.info(f"acc_deny = {acc_deny}")
    cocotb.log.info(f"bmu_biu_dbus_acc_deny = {bmu_biu_dbus_acc_deny}")
    assert acc_deny == 1, "acc_deny should be 1 when lsu_bmu_sg_chk_fail is set"
    assert bmu_biu_dbus_acc_deny == 1, "bmu_biu_dbus_acc_deny should be 1 when lsu_bmu_sg_chk_fail is set"
    await RisingEdge(dut.deny_clk)
    dut.pmp_bmu_dbus_acc_deny.value = 0
    dut.lsu_bmu_sg_chk_fail.value = 0
    dut.lsu_bmu_store_error.value = 1
    acc_deny = int(dut.acc_deny.value)
    bmu_biu_dbus_acc_deny = int(dut.bmu_biu_dbus_acc_deny.value)
    cocotb.log.info(f"acc_deny = {acc_deny}")
    cocotb.log.info(f"bmu_biu_dbus_acc_deny = {bmu_biu_dbus_acc_deny}")
    assert acc_deny == 1, "acc_deny should be 1 when lsu_bmu_store_error is set"
    assert bmu_biu_dbus_acc_deny == 1, "bmu_biu_dbus_acc_deny should be 1 when lsu_bmu_store_error is set"
    await FallingEdge(dut.deny_clk)
    dut.pmp_bmu_dbus_acc_deny.value = 0
    dut.lsu_bmu_sg_chk_fail.value = 0
    dut.lsu_bmu_store_error.value = 0


@cocotb.test()
async def test_bmu_biu_dbus_req(dut):
    """Test 3 : BMU System Bus (BIU) Request Routing Logic"""
    cocotb.start_soon(clk_gen(dut))
    dut.lsu_bmu_req.value = 1
    dut.pad_bmu_iahbl_mask.value = 0xFFF
    dut.pad_bmu_iahbl_base.value = 0x123
    dut.lsu_bmu_addr.value = 0
    dut.lsu_bmu_prot.value = 0b1011
    await RisingEdge(dut.deny_clk)
    iahbl_hit = int(dut.iahbl_hit.value)
    iahbl_lrw_hit_ff = int(dut.iahbl_lrw_hit_ff.value)
    iahbl_hit_ff = int(dut.iahbl_hit_ff.value)
    tcipif_hit = int(dut.tcipif_hit.value)
    sahbl_vld = int(dut.sahbl_vld.value)
    bmu_biu_dbus_req = int(dut.bmu_biu_dbus_req.value)
    cocotb.log.info(f"iahbl_hit = {iahbl_hit}")
    cocotb.log.info(f"iahbl_lrw_hit_ff = {iahbl_lrw_hit_ff}")
    cocotb.log.info(f"iahbl_hit_ff = {iahbl_hit_ff}")
    cocotb.log.info(f"tcipif_hit = {tcipif_hit}")
    cocotb.log.info(f"sahbl_vld = {sahbl_vld}")
    cocotb.log.info(f"bmu_biu_dbus_req = {bmu_biu_dbus_req}")
    assert iahbl_hit == 0, "iahbl_hit should be 0"
    assert iahbl_lrw_hit_ff == 1, "iahbl_lrw_hit_ff should be 1"
    assert iahbl_hit_ff == 0, "iahbl_hit_ff should be 0"
    assert tcipif_hit == 0, "tcipif_hit should be 0"
    assert sahbl_vld == 1, "sahbl_vld should be 1"
    assert bmu_biu_dbus_req == 1, "bmu_biu_dbus_req should be 1"
    await FallingEdge(dut.deny_clk)
    dut.lsu_bmu_req.value = 0
    dut.pad_bmu_iahbl_mask.value = 0
    dut.pad_bmu_iahbl_base.value = 0
    dut.lsu_bmu_prot.value = 0


@cocotb.test()
async def test_bmu_lsu_data_vld(dut):
    """Test 4 : BMU LSU Data Valid Signal from IAHBL Path"""
    cocotb.start_soon(clk_gen(dut))
    dut.iahbl_bmu_dbus_data_vld.value = 1
    dut.tcipif_bmu_dbus_data_vld.value = 0
    dut.biu_bmu_dbus_data_vld.value = 0
    await RisingEdge(dut.deny_clk)
    bmu_lsu_data_vld = int(dut.bmu_lsu_data_vld.value)
    cocotb.log.info(f"bmu_lsu_data_vld = {bmu_lsu_data_vld}")
    assert bmu_lsu_data_vld == 1, "bmu_lsu_data_vld should be 1 when iahbl_bmu_dbus_data_vld is set"
    await FallingEdge(dut.deny_clk)
    dut.iahbl_bmu_dbus_data_vld.value = 0


@cocotb.test()
async def test_bmu_lsu_bstack_chk_fail(dut):
    """Test 5 : BMU LSU Stack/Bounds Check Failure Handling"""
    cocotb.start_soon(clk_gen(dut))
    dut.iahbl_bmu_dbus_grnt.value = 1
    dut.lsu_bmu_addr_check_fail.value = 1
    dut.lsu_bmu_wfd1.value = 1
    await RisingEdge(dut.deny_clk)
    await RisingEdge(dut.deny_clk)
    dbus_grnt = int(dut.dbus_grnt.value)
    cur_state = int(dut.cur_state.value)
    bstck_chk_fail = int(dut.bstck_chk_fail.value)
    bmu_lsu_bstack_chk_fail = int(dut.bmu_lsu_bstack_chk_fail.value)
    cocotb.log.info(f"dbus_grnt = {dbus_grnt}")
    cocotb.log.info(f"cur_state = {cur_state}")
    cocotb.log.info(f"bstck_chk_fail = {bstck_chk_fail}")
    cocotb.log.info(f"bmu_lsu_bstack_chk_fail = {bmu_lsu_bstack_chk_fail}")
    assert dbus_grnt == 1, "dbus_grnt should be 1"
    assert cur_state == 1, "cur_state should be 1"
    assert bstck_chk_fail == 1, "bstck_chk_fail should be 1"
    assert bmu_lsu_bstack_chk_fail == 1, "bmu_lsu_bstack_chk_fail should be 1"
    await FallingEdge(dut.deny_clk)
    dut.iahbl_bmu_dbus_grnt.value = 0
    dut.lsu_bmu_addr_check_fail.value = 0
    dut.lsu_bmu_wfd1.value = 0


@cocotb.test()
async def test_bmu_lsu_acc_err(dut):
    """Test 6 : BMU LSU Access Error on Deny Handling"""
    cocotb.start_soon(clk_gen(dut))
    initialize_dut_inputs(dut)
    await reset_dut(dut)
    dut.iahbl_bmu_dbus_grnt.value = 1
    dut.pmp_bmu_dbus_acc_deny.value = 1
    dut.lsu_bmu_sg_chk_fail.value = 0
    dut.lsu_bmu_store_error.value = 0
    dut.lsu_bmu_wfd1.value = 1
    await RisingEdge(dut.deny_clk)
    await RisingEdge(dut.deny_clk)
    dbus_grnt = int(dut.dbus_grnt.value)
    cur_state = int(dut.cur_state.value)
    acc_err_for_deny = int(dut.acc_err_for_deny.value)
    acc_err_val = dut.bmu_lsu_acc_err.value
    bmu_lsu_acc_err = int(acc_err_val)
    cocotb.log.info(f"dbus_grnt = {dbus_grnt}")
    cocotb.log.info(f"cur_state = {cur_state}")
    cocotb.log.info(f"acc_err_for_deny = {acc_err_for_deny}")
    cocotb.log.info(f"bmu_lsu_acc_err = {bmu_lsu_acc_err}")
    assert dbus_grnt == 1, "dbus_grnt should be 1"
    assert cur_state == 2, "cur_state should be 2"
    assert acc_err_for_deny == 1, "acc_err_for_deny should be 1"
    assert bmu_lsu_acc_err == 1, "bmu_lsu_acc_err should be 1"
    await FallingEdge(dut.deny_clk)
    dut.iahbl_bmu_dbus_grnt.value = 0
    dut.pmp_bmu_dbus_acc_deny.value = 0
    dut.lsu_bmu_wfd1.value = 0



