import math
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

class ConvolutorTester:
    def __init__(self, dut):
        self.dut = dut
        self.CONV_LEN  = 20
        self.CONV_LPOS = 13
        self.kernel_model    = [0]*9
        self.image_model     = [0]*9
        self.image_row_count = 0
        self.final_expected_signed = 0

    async def initialize_dut(self):
        # Drive inputs low, assert reset high
        for sig in ("i_dato0","i_dato1","i_dato2","i_selecK_I","i_valid"):
            getattr(self.dut, sig).value = 0
        self.dut.i_reset.value = 1
        cocotb.start_soon(Clock(self.dut.i_CLK, 5, unit="ns", period_high=3).start())
        # Hold reset for two cycles
        await RisingEdge(self.dut.i_CLK)
        await RisingEdge(self.dut.i_CLK)
        self.dut.i_reset.value = 0
        cocotb.log.info("[TB] DUT released from reset")

    def calculate_expected(self):
        conv_sum = sum(self.kernel_model[i] * self.image_model[i] for i in range(9))
        shift_amt = self.CONV_LEN - 2 - (self.CONV_LPOS - 1)
        masked = (conv_sum >> shift_amt) & ((1 << self.CONV_LPOS) - 1)
        raw = masked ^ (1 << (self.CONV_LPOS - 1))
        if raw & (1 << (self.CONV_LPOS - 1)):
            self.final_expected_signed = raw - (1 << self.CONV_LPOS)
        else:
            self.final_expected_signed = raw

    def update_reference_model(self, valid, KI):
        if valid:
            row = [
                self.dut.i_dato0.value.signed_integer,
                self.dut.i_dato1.value.signed_integer,
                self.dut.i_dato2.value.signed_integer,
            ]
            if KI == 0:
                self.kernel_model = self.kernel_model[3:] + row
            else:
                self.image_model = self.image_model[3:] + row
                if self.image_row_count < 3:
                    self.image_row_count += 1

# Helper to run any stimulus sequence with per-cycle prints
async def run_sequence(dut, test_sequence, name=""):
    tester = ConvolutorTester(dut)
    await tester.initialize_dut()

    # Flatten into per-clock stimuli
    CLK = 10
    stimuli = []
    last = dict(valid=0, KI=0, d0=0, d1=0, d2=0)
    for delay, v, k, a, b, c in test_sequence:
        cycles = math.ceil(delay / CLK)
        for i in range(cycles):
            stim = dict(valid=v, KI=k, d0=a, d1=b, d2=c) if i == 0 else last
            stimuli.append(stim)
        last = stimuli[-1]

    expected_fifo = []
    prev_valid = False  # 1-cycle delayed valid

    cocotb.log.info(f"[TB:{name}] Running {len(stimuli)} cycles (~{len(stimuli)*CLK}ns)")
    for cyc, stim in enumerate(stimuli):
        # Drive inputs
        dut.i_valid.value     = stim['valid']
        dut.i_selecK_I.value = stim['KI']
        dut.i_dato0.value    = stim['d0']
        dut.i_dato1.value    = stim['d1']
        dut.i_dato2.value    = stim['d2']

        await RisingEdge(dut.i_CLK)

        # Compute & buffer expected
        tester.calculate_expected()
        expected_fifo.append(tester.final_expected_signed)
        golden = expected_fifo.pop(0) if len(expected_fifo) >= 3 else None

        # Read DUT output
        out = dut.o_data.value.signed_integer
        ref_str = f"{golden:5}" if golden is not None else " ----"

        # Assertion on delayed valid
        if prev_valid and golden is not None:
            if out != golden:
                cocotb.log.error(
                    f"[{name} C{cyc:03d}] MISMATCH @ {cocotb.simulator.get_sim_time()}ns: DUT={out}, Exp={golden}"
                )
            assert out == golden, f"[{name} C{cyc:03d}] DUT={out} != Exp={golden}"

        # Per-cycle print
        cocotb.log.info(
            f"[{name} C{cyc:03d}] t={cocotb.simulator.get_sim_time()}ns | "
            f"v={stim['valid']} KI={stim['KI']} d=[{stim['d0']:4},{stim['d1']:4},{stim['d2']:4}] | "
            f"DUT={out:6} | REF={ref_str}"
        )

        # Update model and delayed-valid
        tester.update_reference_model(stim['valid'], stim['KI'])
        prev_valid = bool(stim['valid'])

@cocotb.test()
async def convolutor_test(dut):
    "Original convolutor sequence."  
    seq = [
        (15, 0, 0,   0,    0,    0),
        (5,  1, 0,   0,   32,    0),
        (5,  1, 0,  32, -128,   32),
        (5,  1, 0,   0,   32,    0),
        (5,  0, 0,   0,    0,    0),
        (5,  1, 1, 127,  127,  127),
        (5,  1, 1, 127,  127,  127),
        (5,  1, 1, 126,  126,  126),
        (5,  0, 1,   0,    0,    0),
        (5,  1, 1, 127,  127,  127),
        (25, 1, 1, 126,  126,  126),
        (45, 1, 1, 127,  127,  127),
        (30, 1, 1, 127,  127,  127),
        (20, 1, 1, 126,  126,  126),
        (15, 1, 1, 125,  125,  125),
        (10, 1, 1, 126,  126,  126),
        (5,  1, 1, 127,  127,  127),
        (10, 0, 0,    0,    0,    0),
    ]
    await run_sequence(dut, seq, name="MAIN")

@cocotb.test()
async def test_negative_kernel_edge(dut):
    "Negative kernel edge case."  
    seq = [
        (5,  1, 0, -128, -128, -128),
        (5,  1, 0, -128, -128, -128),
        (10, 1, 0, -128, -128, -128),
        (10, 0, 0,    0,    0,    0),
    ]
    await run_sequence(dut, seq, name="NEG_KER")

@cocotb.test()
async def test_midrange_image(dut):
    "Mid-range positive image values."  
    seq = [
        (5,  1, 0,   0,    0,    0),
        (5,  1, 1,  64,   64,   64),
        (10, 1, 1,  64,   64,   64),
        (10, 0, 0,    0,    0,    0),
    ]
    await run_sequence(dut, seq, name="MID_IMG")

@cocotb.test()
async def test_negative_image_midrange(dut):
    "Mid-range negative image values."  
    seq = [
        (5,  1, 0,   0,    0,    0),
        (5,  1, 1, -64,  -64,  -64),
        (10, 1, 1, -64,  -64,  -64),
        (10, 0, 0,    0,    0,    0),
    ]
    await run_sequence(dut, seq, name="NEG_IMG")

@cocotb.test()
async def test_alternating_kernel(dut):
    "Alternating positive/negative kernel values."
    seq = [
        (5,  1, 0,   1,   -1,    1),
        (5,  1, 0,  -1,    1,   -1),
        (5,  1, 0,   1,   -1,    1),
        (5,  1, 1, 127,  127,  127),
        (5,  1, 1, 127,  127,  127),
        (5,  1, 1, 127,  127,  127),
        (10, 0, 0,    0,    0,    0),
    ]
    await run_sequence(dut, seq, name="ALT_KERNEL")

@cocotb.test()
async def test_sparse_image(dut):
    "Test with sparse image data (mostly zeros with single non-zero)."
    seq = [
        (5,  1, 0,   0,    1,    0),
        (5,  1, 0,   1,    0,    1),
        (5,  1, 0,   0,    1,    0),
        (5,  1, 1,   0,    0,    0),
        (5,  1, 1,   0,  127,    0),
        (5,  1, 1,   0,    0,    0),
        (10, 0, 0,    0,    0,    0),
    ]
    await run_sequence(dut, seq, name="SPARSE_IMG")

@cocotb.test()
async def test_single_pixel(dut):
    "Test with single non-zero pixel in center."
    seq = [
        (5,  1, 0,   0,    0,    0),
        (5,  1, 0,   0,    1,    0),
        (5,  1, 0,   0,    0,    0),
        (5,  1, 1,   0,    0,    0),
        (5,  1, 1,   0,  100,    0),
        (5,  1, 1,   0,    0,    0),
        (10, 0, 0,    0,    0,    0),
    ]
    await run_sequence(dut, seq, name="SINGLE_PIXEL")

@cocotb.test()
async def test_vertical_edge(dut):
    "Test vertical edge detection pattern."
    seq = [
        (5,  1, 0,   1,   -1,    1),
        (5,  1, 0,   1,   -1,    1),
        (5,  1, 0,   1,   -1,    1),
        (5,  1, 1, 127, -128,  127),
        (5,  1, 1, 127, -128,  127),
        (5,  1, 1, 127, -128,  127),
        (10, 0, 0,    0,    0,    0),
    ]
    await run_sequence(dut, seq, name="VERT_EDGE")


@cocotb.test()
async def test_diagonal_pattern(dut):
    "Test diagonal pattern detection."
    seq = [
        (5,  1, 0,   1,    0,    0),
        (5,  1, 0,   0,    1,    0),
        (5,  1, 0,   0,    0,    1),
        (5,  1, 1, 127,    0,    0),
        (5,  1, 1,   0,  127,    0),
        (5,  1, 1,   0,    0,  127),
        (10, 0, 0,    0,    0,    0),
    ]
    await run_sequence(dut, seq, name="DIAGONAL")

