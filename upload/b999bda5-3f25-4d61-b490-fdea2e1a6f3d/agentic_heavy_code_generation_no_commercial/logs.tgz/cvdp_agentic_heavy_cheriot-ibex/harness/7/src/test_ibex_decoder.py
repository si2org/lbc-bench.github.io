
import cocotb
from cocotb.clock import Clock
from cocotb.types import LogicArray

class BinaryValue:
    """Minimal BinaryValue replacement supporting slice assignment for cocotb 2.x."""
    def __init__(self, value=0, n_bits=None, bigEndian=False):
        if isinstance(value, int):
            self._val = value
        elif isinstance(value, str):
            self._val = int(value, 16) if all(c in '0123456789abcdefABCDEF' for c in value) else int(value, 2)
        else:
            self._val = int(value)
        self._n_bits = n_bits or 32

    def _resolve_key(self, key):
        if isinstance(key, int):
            return key, key
        high = key.start if key.start is not None else self._n_bits - 1
        low = key.stop if key.stop is not None else 0
        return high, low

    def __setitem__(self, key, value):
        high, low = self._resolve_key(key)
        n = high - low + 1
        mask = ((1 << n) - 1) << low
        self._val = (self._val & ~mask) | ((int(value) & ((1 << n) - 1)) << low)

    def __getitem__(self, key):
        high, low = self._resolve_key(key)
        n = high - low + 1
        return (self._val >> low) & ((1 << n) - 1)

    @property
    def integer(self):
        return self._val

    @property
    def binstr(self):
        return format(self._val, f'0{self._n_bits}b')

    def __int__(self):
        return self._val

    def __index__(self):
        return self._val

    def __eq__(self, other):
        if isinstance(other, BinaryValue):
            return self._val == other._val
        try:
            return self._val == int(other)
        except (TypeError, ValueError):
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return f"BinaryValue(0x{self._val:x}, n_bits={self._n_bits})"
from cocotb.triggers import FallingEdge, RisingEdge, Edge, Timer
from copy import deepcopy

import harness_library as hrs_lb
import os
import inspect


@cocotb.test()
async def test_bugfix(dut):
    cocotb.log.setLevel("DEBUG")
    cocotb.log.info(f"Starting {inspect.currentframe().f_code.co_name}...")

    await hrs_lb.dut_init(dut)
    await cocotb.start(Clock(dut.clk_i, hrs_lb.CLK_PERIOD, unit=hrs_lb.CLK_TIME_UNIT).start(start_high=False))

    # Example of LW (Load Word) instruction compatible with RV32E 32 bits:
    # lw x3, 8(x4)
    # 000000000100 00100 010 00011 0000011
    # imm[11:0]=000000000100 (8), rs1=00100 (x4), funct3=010, rd=00011 (x3), opcode=0000011 (LW)

    dut.cheri_pmode_i.value = 1
    dut.illegal_c_insn_i.value = 0

    instruction = BinaryValue(0, 32, False)
    instruction[31:20] = int('000000000100', 2) # imm[11:0] (8)
    instruction[19:15] = int('00100', 2) # rs1 (x4)
    instruction[14:12] = int('010', 2) # funct3 (LW)
    instruction[11:7] = int('00011', 2) # rd (x3)
    instruction[6:0] = int('0000011', 2) # opcode (LW)
    dut.instr_rdata_i.value = int(instruction)

    assert dut.ibex_decoder_wrapped.CheriLimit16Regs.value == 1

    await Timer(hrs_lb.TINY_PERIOD, unit=hrs_lb.CLK_TIME_UNIT)
    assert dut.ibex_decoder_wrapped.illegal_reg_cheri.value == 0

    dut.cheri_pmode_i.value = 0
    await Timer(hrs_lb.TINY_PERIOD, unit=hrs_lb.CLK_TIME_UNIT)
    assert dut.ibex_decoder_wrapped.illegal_reg_rv32e.value == 0

    instruction_illegal = BinaryValue(instruction.integer, 32, False)
    instruction_illegal[11:7] = int('10011', 2) # Set illegal bit for rd
    dut.instr_rdata_i.value = int(instruction_illegal)
    dut.cheri_pmode_i.value = 1

    await Timer(hrs_lb.TINY_PERIOD, unit=hrs_lb.CLK_TIME_UNIT)
    assert dut.ibex_decoder_wrapped.illegal_reg_cheri.value == 1

    dut.cheri_pmode_i.value = 0
    await Timer(hrs_lb.TINY_PERIOD, unit=hrs_lb.CLK_TIME_UNIT)
    assert dut.ibex_decoder_wrapped.illegal_reg_rv32e.value == 1

    cocotb.log.info("All tests passed.")
