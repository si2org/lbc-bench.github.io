module ibex_decoder_wrapper import cheri_pkg::*; #(
  parameter bit RV32E               = 1,
  parameter ibex_pkg::rv32m_e RV32M = ibex_pkg::RV32MFast,
  parameter ibex_pkg::rv32b_e RV32B = ibex_pkg::RV32BNone,
  parameter bit BranchTargetALU     = 0,
  parameter bit CHERIoTEn           = 1'b1,
  parameter bit CheriPPLBC          = 1'b0,
  parameter bit CheriSBND2          = 1'b0
) (
  input  logic                 clk_i,
  input  logic                 rst_ni,

  input  logic                 cheri_pmode_i,
  input  logic                 cheri_tsafe_en_i,

  // to/from controller
  output logic                 illegal_insn_o,        // illegal instr encountered
  output logic                 ebrk_insn_o,           // trap instr encountered
  output logic                 mret_insn_o,           // return from exception instr
                                                      // encountered
  output logic                 dret_insn_o,           // return from debug instr encountered
  output logic                 ecall_insn_o,          // syscall instr encountered
  output logic                 wfi_insn_o,            // wait for interrupt instr encountered
  output logic                 jump_set_o,            // jump taken set signal
  input  logic                 branch_taken_i,        // registered branch decision
  output logic                 icache_inval_o,

  // from IF-ID pipeline register
  input  logic                 instr_first_cycle_i,   // instruction read is in its first cycle
  input  logic [31:0]          instr_rdata_i,         // instruction read from memory/cache
  input  logic [31:0]          instr_rdata_alu_i,     // instruction read from memory/cache
                                                      // replicated to ease fan-out)

  input  logic                 illegal_c_insn_i,      // compressed instruction decode failed

  // immediates
  output ibex_pkg::imm_a_sel_e  imm_a_mux_sel_o,       // immediate selection for operand a
  output ibex_pkg::imm_b_sel_e  imm_b_mux_sel_o,       // immediate selection for operand b
  output ibex_pkg::op_a_sel_e   bt_a_mux_sel_o,        // branch target selection operand a
  output ibex_pkg::imm_b_sel_e  bt_b_mux_sel_o,        // branch target selection operand b
  output logic [31:0]           imm_i_type_o,
  output logic [31:0]           imm_s_type_o,
  output logic [31:0]           imm_b_type_o,
  output logic [31:0]           imm_u_type_o,
  output logic [31:0]           imm_j_type_o,
  output logic [31:0]           zimm_rs1_type_o,

  // register file
  output ibex_pkg::rf_wd_sel_e rf_wdata_sel_o,   // RF write data selection
  output logic                 rf_we_o,          // write enable for regfile
  output logic [4:0]           rf_raddr_a_o,
  output logic [4:0]           rf_raddr_b_o,
  output logic [4:0]           rf_waddr_o,
  output logic                 rf_ren_a_o,          // Instruction reads from RF addr A
  output logic                 rf_ren_b_o,          // Instruction reads from RF addr B

  // ALU
  output ibex_pkg::alu_op_e    alu_operator_o,        // ALU operation selection
  output ibex_pkg::op_a_sel_e  alu_op_a_mux_sel_o,    // operand a selection: reg value, PC,
                                                      // immediate or zero
  output ibex_pkg::op_b_sel_e  alu_op_b_mux_sel_o,    // operand b selection: reg value or
                                                      // immediate
  output logic                 alu_multicycle_o,      // ternary bitmanip instruction

  // MULT & DIV
  output logic                 mult_en_o,             // perform integer multiplication
  output logic                 div_en_o,              // perform integer division or remainder
  output logic                 mult_sel_o,            // as above but static, for data muxes
  output logic                 div_sel_o,             // as above but static, for data muxes

  output ibex_pkg::md_op_e     multdiv_operator_o,
  output logic [1:0]           multdiv_signed_mode_o,

  // CSRs
  output logic                 csr_access_o,          // access to CSR
  output ibex_pkg::csr_op_e    csr_op_o,              // operation to perform on CSR
  output logic                 csr_cheri_always_ok_o, // CHERI safe-listed (no ASR needed) CSRs

  // LSU
  output logic                 data_req_o,            // start transaction to data memory
  output logic                 cheri_data_req_o,      // cheri lsu transaction
  output logic                 data_we_o,             // write enable
  output logic [1:0]           data_type_o,           // size of transaction: byte, half
                                                      // word or word
  output logic                 data_sign_extension_o, // sign extension for data read from
                                                      // memory

  // jump/branches
  output logic                 jump_in_dec_o,         // jump is being calculated in ALU
  output logic                 branch_in_dec_o,

  // output to cheri EX
  output logic                 instr_is_cheri_o,
  output logic                 instr_is_legal_cheri_o,
  output logic [11:0]          cheri_imm12_o,
  output logic [19:0]          cheri_imm20_o,
  output logic [20:0]          cheri_imm21_o,
  output logic [OPDW-1:0]      cheri_operator_o,
  output logic [4:0]           cheri_cs2_dec_o,
  output logic                 cheri_multicycle_dec_o
);

ibex_decoder #(
    .RV32E(RV32E)
) ibex_decoder_wrapped (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .cheri_pmode_i(cheri_pmode_i),
    .cheri_tsafe_en_i(cheri_tsafe_en_i),
    .illegal_insn_o(illegal_insn_o),
    .ebrk_insn_o(ebrk_insn_o),
    .mret_insn_o(mret_insn_o),
    .dret_insn_o(dret_insn_o),
    .ecall_insn_o(ecall_insn_o),
    .wfi_insn_o(wfi_insn_o),
    .jump_set_o(jump_set_o),
    .branch_taken_i(branch_taken_i),
    .icache_inval_o(icache_inval_o),
    .instr_first_cycle_i(instr_first_cycle_i),
    .instr_rdata_i(instr_rdata_i),
    .instr_rdata_alu_i(instr_rdata_alu_i),
    .illegal_c_insn_i(illegal_c_insn_i),
    .imm_a_mux_sel_o(imm_a_mux_sel_o),
    .imm_b_mux_sel_o(imm_b_mux_sel_o),
    .bt_a_mux_sel_o(bt_a_mux_sel_o),
    .bt_b_mux_sel_o(bt_b_mux_sel_o),
    .imm_i_type_o(imm_i_type_o),
    .imm_s_type_o(imm_s_type_o),
    .imm_b_type_o(imm_b_type_o),
    .imm_u_type_o(imm_u_type_o),
    .imm_j_type_o(imm_j_type_o),
    .zimm_rs1_type_o(zimm_rs1_type_o),
    .rf_wdata_sel_o(rf_wdata_sel_o),
    .rf_we_o(rf_we_o),
    .rf_raddr_a_o(rf_raddr_a_o),
    .rf_raddr_b_o(rf_raddr_b_o),
    .rf_waddr_o(rf_waddr_o),
    .rf_ren_a_o(rf_ren_a_o),
    .rf_ren_b_o(rf_ren_b_o),
    .alu_operator_o(alu_operator_o),
    .alu_op_a_mux_sel_o(alu_op_a_mux_sel_o),
    .alu_op_b_mux_sel_o(alu_op_b_mux_sel_o),
    .alu_multicycle_o(alu_multicycle_o),
    .mult_en_o(mult_en_o),
    .div_en_o(div_en_o),
    .mult_sel_o(mult_sel_o),
    .div_sel_o(div_sel_o),
    .multdiv_operator_o(multdiv_operator_o),
    .multdiv_signed_mode_o(multdiv_signed_mode_o),
    .csr_access_o(csr_access_o),
    .csr_op_o(csr_op_o),
    .csr_cheri_always_ok_o(csr_cheri_always_ok_o),
    .data_req_o(data_req_o),
    .cheri_data_req_o(cheri_data_req_o),
    .data_we_o(data_we_o),
    .data_type_o(data_type_o),
    .data_sign_extension_o(data_sign_extension_o),
    .jump_in_dec_o(jump_in_dec_o),
    .branch_in_dec_o(branch_in_dec_o),
    .instr_is_cheri_o(instr_is_cheri_o),
    .instr_is_legal_cheri_o(instr_is_legal_cheri_o),
    .cheri_imm12_o(cheri_imm12_o),
    .cheri_imm20_o(cheri_imm20_o),
    .cheri_imm21_o(cheri_imm21_o),
    .cheri_operator_o(cheri_operator_o),
    .cheri_cs2_dec_o(cheri_cs2_dec_o),
    .cheri_multicycle_dec_o(cheri_multicycle_dec_o)
);

endmodule : ibex_decoder_wrapper