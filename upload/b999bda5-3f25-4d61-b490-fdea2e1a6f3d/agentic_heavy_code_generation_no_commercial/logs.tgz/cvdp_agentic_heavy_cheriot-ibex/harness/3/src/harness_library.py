
from cocotb.types import LogicArray as BinaryValue
from cocotb.triggers import Edge, FallingEdge, RisingEdge, Timer
import random

TINY_PERIOD = 1
CLK_HALF_PERIOD = 10
CLK_PERIOD = CLK_HALF_PERIOD * 20
CLK_TIME_UNIT = 'ns'

OP_A_REG_A = 0

async def dut_init(dut):
    # iterate all the input signals and initialize with 0
    for signal in dut:
        try:
            signal.value = 0
        except Exception:
            pass

async def reset_dut(dut):
    dut.rst_ni.value = 0
    await Timer(2 * CLK_PERIOD, unit=CLK_TIME_UNIT)
    dut.rst_ni.value = 1
