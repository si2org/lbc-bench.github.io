from cocotb_tools.runner import get_runner
from typing import Mapping
import os
import pytest
import test_coverage as coverage
import random
import traceback

# Environment configuration
inc_dirs        = os.getenv("VERILOG_INCLUDE_DIRS", "").split()
verilog_sources = os.getenv("VERILOG_SOURCES").split()
toplevel_lang   = os.getenv("TOPLEVEL_LANG")
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = os.getenv("WAVE", "false").lower() in ("1", "true", "yes")
cov_check       = os.getenv("COVERAGE", "false").lower() in ("1", "true", "yes")
cov_selections  = os.getenv("COV_SELECTIONS", "").split()
cov_thresholds  = [float(s) for s in os.getenv("COV_THRESHOLDS", "").split()]


def call_runner():
    encoder_in = random.randint(0, 255)
    plus_args = [f'+encoder_in={encoder_in}']
    args = []
    if sim == "xcelium":
        args = ["-sv", "-svseed random"]
    elif sim == "verilator":
        args = ["-Wno-UNOPTFLAT", "-Wno-WIDTHTRUNC", "-Wno-WIDTHEXPAND", "-Wno-PINMISSING", "-Wno-LATCH", "--trace-structs"]

    try:
        runner = get_runner(sim)
        runner.build(
            includes=inc_dirs,
            sources=verilog_sources,
            hdl_toplevel=toplevel,
            # Arguments
            parameters={},
            # compiler args
            build_args=args,
            always=True,
            clean=True,
            verbose=True,
            timescale=("1ns", "1ns"),
            log_file="build.log"
        )

        extra_env: Mapping[str, str] = {}

        runner.test(
            hdl_toplevel=toplevel,
            test_module=module,
            waves=wave,
            plusargs=plus_args,
            log_file="sim.log",
            extra_env=extra_env
        )

    except SystemExit:
        traceback.print_exc()
        raise SystemError("simulation failed")


def call_covered_runner(cov_selection:tuple[str, float] = None):
    encoder_in = random.randint(0, 255)
    plusargs = [f'+encoder_in={encoder_in}']
    try:
        args = []
        if sim == "xcelium":
            args = ("-coverage all", " -covoverwrite", "-sv", "-covtest test", "-svseed random")

        coverage.coverage_report_clear()
        coverage.runner(
            wave=wave,
            toplevel=toplevel,
            plusargs=plusargs,
            module=module,
            inc_dirs=inc_dirs,
            src=verilog_sources,
            sim=sim,
            args=args,
            parameter={},
            cov_selection=cov_selection[0] if cov_selection else "",
        )

        coverage.coverage_report("assertion")
        if cov_selection:
            print(f'cov_selection[0]: {cov_selection[0]} cov_selection[1]: {cov_selection[1]}')
            coverage.coverage_report_check(cov_selection[1])
        else:
            coverage.coverage_report_check()

    except SystemExit:
        traceback.print_exc()
        raise SystemError("simulation failed due to assertion failed in your test")


@pytest.mark.parametrize("test", range(1))
def test_data(test):

    if not cov_check:
        # Run the simulation
        print("Calling runner without arguments")
        call_runner()
        return

    if len(cov_selections) == 0:
        # Run the simulation
        print("Calling covered runner without arguments")
        call_covered_runner()
        return

    print("Identified special coverage selections")

    assert len(cov_selections) == len(cov_thresholds), "incompatible coverage selections and thresholds"

    for selection, threshold in zip(cov_selections, cov_thresholds):
        print(f"> Running selection: {selection}, for threshold: {threshold}")
        call_covered_runner((selection, threshold))
