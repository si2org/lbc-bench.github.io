
import cocotb
from cocotb.clock import Clock
from cocotb.types import LogicArray

class BinaryValue:
    """Minimal BinaryValue replacement supporting slice assignment for cocotb 2.x."""
    def __init__(self, value=0, n_bits=None, bigEndian=False):
        if isinstance(value, int):
            self._val = value
        elif isinstance(value, str):
            self._val = int(value, 16) if all(c in '0123456789abcdefABCDEF' for c in value) else int(value, 2)
        else:
            self._val = int(value)
        self._n_bits = n_bits or 32

    def _resolve_key(self, key):
        if isinstance(key, int):
            return key, key
        high = key.start if key.start is not None else self._n_bits - 1
        low = key.stop if key.stop is not None else 0
        return high, low

    def __setitem__(self, key, value):
        high, low = self._resolve_key(key)
        n = high - low + 1
        mask = ((1 << n) - 1) << low
        self._val = (self._val & ~mask) | ((int(value) & ((1 << n) - 1)) << low)

    def __getitem__(self, key):
        high, low = self._resolve_key(key)
        n = high - low + 1
        return (self._val >> low) & ((1 << n) - 1)

    @property
    def integer(self):
        return self._val

    @property
    def binstr(self):
        return format(self._val, f'0{self._n_bits}b')

    def __int__(self):
        return self._val

    def __index__(self):
        return self._val

    def __eq__(self, other):
        if isinstance(other, BinaryValue):
            return self._val == other._val
        try:
            return self._val == int(other)
        except (TypeError, ValueError):
            return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return f"BinaryValue(0x{self._val:x}, n_bits={self._n_bits})"
from cocotb.triggers import FallingEdge, RisingEdge, Edge, Timer
from copy import deepcopy

import harness_library as hrs_lb
import os
import inspect


@cocotb.test()
async def test_bugfix(dut):
    cocotb.log.setLevel("DEBUG")
    cocotb.log.info(f"Starting {inspect.currentframe().f_code.co_name}...")

    await hrs_lb.dut_init(dut)
    await cocotb.start(Clock(dut.clk_i, hrs_lb.CLK_PERIOD, unit=hrs_lb.CLK_TIME_UNIT).start(start_high=False))

    instruction_input = BinaryValue(0, 32, False)
    instruction_input[31:16] = 0
    instruction_input[15:13] = 0
    instruction_input[12] = 0
    instruction_input[11:7] = int('10101', 2)
    instruction_input[6:2] = 0
    instruction_input[1:0] = 1

    dut.instr_i.value = int(instruction_input)
    dut.cheri_pmode_i.value = 1
    dut.valid_i.value = 0

    assert dut.CHERIoTEn.value == 1

    await Timer(hrs_lb.TINY_PERIOD, unit=hrs_lb.CLK_TIME_UNIT)

    instruction_not_expected = BinaryValue(0, 32, False)
    instruction_not_expected[31:26] = 0
    instruction_not_expected[25] = 0
    instruction_not_expected[24:20] = 0
    instruction_not_expected[19:15] = int('10101', 2)
    instruction_not_expected[14:12] = 0
    instruction_not_expected[11:7] = int('10101', 2) # before fix
    instruction_not_expected[6:0] = int('13', 16)

    instruction_expected = BinaryValue(instruction_not_expected.integer, 32, False)
    instruction_expected[11:7] = 0 # after fix

    cocotb.log.info(f"Input instruction:               {instruction_input.binstr}")
    cocotb.log.info(f"Expected output instruction:     {instruction_expected.binstr}")
    cocotb.log.info(f"Not expected output instruction: {instruction_not_expected.binstr}")
    cocotb.log.info(f"Actual output instruction:       {str(dut.instr_o.value)}")

    assert dut.instr_o.value != int(instruction_not_expected)
    assert dut.instr_o.value == int(instruction_expected)

    cocotb.log.info("All tests passed.")
