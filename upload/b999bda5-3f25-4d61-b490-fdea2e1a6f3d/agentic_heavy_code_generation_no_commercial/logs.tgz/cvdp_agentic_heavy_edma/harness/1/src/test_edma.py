import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer
import random

import harness_library as hrs_lb

async def cycle(dut, backpressure: bool):
    dut.wait_in.value = backpressure
    await RisingEdge(dut.clk)

@cocotb.test()
async def test_edma(dut):
    """Test EDMA inner loop counting and address behavior with dynamic AW parameter."""
    # Start clock
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    # Reset DUT
    dut.nreset.value = 0
    await Timer(20, unit="ns")
    dut.nreset.value = 1
    await RisingEdge(dut.clk)

    # Read parameter from DUT and compute packet width
    AW = int(dut.AW.value)
    PW = 2 * AW + 40

    # Initialize inputs
    dut.master_active.value = 1
    dut.update2d.value = 0
    dut.datamode.value = 0
    dut.ctrlmode.value = 0
    stride = 4
    initial_outer = 2
    initial_inner = 8
    dut.vdd.value = 1
    dut.vss.value = 0
    dut.stride_reg.value = stride
    dut.count_reg.value  = (initial_outer << 28) | initial_inner
    dut.srcaddr_reg.value = 0x10
    dut.dstaddr_reg.value = 0x20
    dut.access_in.value = 1
    dut.reg_access_in.value =1
    dut.reg_wait_in.value = 1
    dut.reg_packet_in.value = (1 << PW) - 1  # all-ones packet
    dut.wait_in.value = 1
    dut.packet_in.value = (1 << PW) - 1  # all-ones packet

    # Drop back-pressure once to capture first beat
    dut.wait_in.value = 0
    await RisingEdge(dut.clk)
    dut.wait_in.value = 1


    # Compute initial expected outputs
    # Count uses high-16 bits for outer and low-16 for inner
    initial_count = (initial_outer << 28) | initial_inner
    expected_count = initial_count - 2

    # Stride low half for src, high half for dst
    low_stride  = stride & 0xFFFF
    high_stride = (stride >> 28) & 0xFFFF
    expected_src = 0x10 + low_stride + 4
    expected_dst = 0x20 + high_stride 
    await RisingEdge(dut.clk)
    # Inner loop: initial_inner beats
    for i in range(initial_inner):

        # Extract integer values
        got_count   = int(dut.count.value)
        got_srcaddr = int(dut.srcaddr.value)
        got_dstaddr = int(dut.dstaddr.value)

        # Assertions
        assert got_count == expected_count, \
            f"Beat {i+1}: count {got_count} != {expected_count}"
        assert got_srcaddr == expected_src, \
            f"Beat {i+1}: srcaddr 0x{got_srcaddr:08X} != 0x{expected_src:08X}"
        assert got_dstaddr == expected_dst, \
            f"Beat {i+1}: dstaddr 0x{got_dstaddr:08X} != 0x{expected_dst:08X}"
        dut._log.info(
            f"Beat {i+1} Observed => "
            f"count={got_count}, "
            f"src=0x{got_srcaddr:0{AW//4}X}, "
            f"dst=0x{got_dstaddr:0{AW//4}X}"
            )
        # Emulate register write-back
        dut.count_reg.value   = got_count
        dut.srcaddr_reg.value = got_srcaddr
        dut.dstaddr_reg.value = got_dstaddr

        # Update expectations
        expected_count -= 1
        expected_src += (stride & ((1 << AW) - 1))
        expected_dst += ((stride >> AW) & ((1 << AW) - 1))

        # Re-assert back-pressure
        dut.wait_in.value = 1
        await RisingEdge(dut.clk)
        dut.wait_in.value = 0
        await RisingEdge(dut.clk)
    # Basic output checks
    
    got_wait_out   = int(dut.wait_out.value)
    got_access_out = int(dut.access_out.value)
    got_packet_out = int(dut.packet_out.value)    
    
    assert got_wait_out == int(dut.wait_in.value), "wait_out != wait_in"
    assert got_access_out == (int(dut.access_in.value) | int(dut.master_active.value)), \
        "access_out incorrect"
    assert got_packet_out != 0, "packet_out should be driven"
    dut._log.info("EDMA inner loop test passed")

    await RisingEdge(dut.clk)    
    dut.wait_in.value = 0
    dut.master_active.value = 0


@cocotb.test()
async def test_edma_2d_reload(dut):
    """2D reload: high-half decrements, src/dst still step by stride twice per iteration."""
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    
    AW = int(dut.AW.value)
    PW = 2*AW + 40
    
    dut.nreset.value = 0
    # Initialize inputs
    dut.master_active.value = 0
    dut.update2d.value = 0
    dut.datamode.value = 0
    dut.ctrlmode.value = 0
    stride = 0
    initial_outer = 0
    initial_inner = 0
    dut.vdd.value = 0
    dut.vss.value = 0
    dut.stride_reg.value = stride
    dut.count_reg.value  = (initial_outer << 28) | initial_inner
    dut.srcaddr_reg.value = 0x00
    dut.dstaddr_reg.value = 0x00
    dut.access_in.value = 0
    dut.reg_access_in.value =0
    dut.reg_wait_in.value = 0
    dut.reg_packet_in.value = (0 << (PW -1))   # all-ones packet
    dut.wait_in.value = 0
    dut.packet_in.value = (0 << (PW-1))   # all-ones packet
    await Timer(20, unit="ns")
    dut.nreset.value = 1
    await RisingEdge(dut.clk)

    iterations = 4
    outer0, inner0 = 5, 8
    stride = 4

    dut.master_active.value = 0
    dut.vdd.value           = 1
    dut.vss.value           = 0
    dut.stride_reg.value    = stride
    dut.count_reg.value     = (outer0<<16)|inner0
    dut.srcaddr_reg.value   = 0x10
    dut.dstaddr_reg.value   = 0x20
    dut.wait_in.value       = 0

    exp_src = 0x10
    exp_dst = 0x20
    low_str  = stride & ((1<<AW)-1)
    high_str = (stride>>AW)&((1<<AW)-1)

    for it in range(iterations):
        # reload
        dut.update2d.value = 1
        await RisingEdge(dut.clk)

        got_count = int(dut.count.value)
        got_src   = int(dut.srcaddr.value)
        got_dst   = int(dut.dstaddr.value)

        # compute expected
        # compute expected values
        exp_high    = outer0 - (it+1)
        exp_low     = inner0 
        exp_cnt     = (exp_high << 16) | exp_low
        # first iteration only one bump, later two bumps
        exp_src  += low_str
        exp_dst  += high_str

        dut._log.info(f"[2D #{it}] got count=0x{got_count:08X}, \
" \
                     f"           src=0x{got_src:0{AW//4}X}, dst=0x{got_dst:0{AW//4}X}; \
" \
                     f" expect count=0x{exp_cnt:08X}, src=0x{exp_src:0{AW//4}X}, dst=0x{exp_dst:0{AW//4}X}")

        # checks
        assert got_count == exp_cnt, f"2D count mismatch at iter {it}"
        assert got_src   == exp_src, f"2D src mismatch at iter {it}"
        assert got_dst   == exp_dst, f"2D dst mismatch at iter {it}"

        # write-back
        dut.count_reg.value   = got_count
        dut.srcaddr_reg.value = got_src
        dut.dstaddr_reg.value = got_dst

        # prepare next
        dut.update2d.value    = 0
        await RisingEdge(dut.clk)

    dut._log.info(" 2D-reload loop passed")

    

@cocotb.test()
async def test_cornercases(dut):
    """Corner cases: zero count, single beat, max‐stride small count."""
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    # Reset DUT
    AW = int(dut.AW.value)
    PW = 2*AW + 40
    
    dut.nreset.value = 0
    # Initialize inputs
    dut.master_active.value = 0
    dut.update2d.value = 0
    dut.datamode.value = 0
    dut.ctrlmode.value = 0
    stride = 0
    initial_outer = 0
    initial_inner = 0
    dut.vdd.value = 0
    dut.vss.value = 0
    dut.stride_reg.value = stride
    dut.count_reg.value  = (initial_outer << 28) | initial_inner
    dut.srcaddr_reg.value = 0x00
    dut.dstaddr_reg.value = 0x00
    dut.access_in.value = 0
    dut.reg_access_in.value =0
    dut.reg_wait_in.value = 0
    dut.reg_packet_in.value = (0 << (PW -1))   # all-ones packet
    dut.wait_in.value = 0
    dut.packet_in.value = (0 << (PW-1))   # all-ones packet
    await Timer(20, unit="ns")
    dut.nreset.value = 1
    ##await RisingEdge(dut.clk)

    # 1) zero-count must stay zero
    dut.master_active.value = 0
    dut.stride_reg.value    = 0
    dut.count_reg.value     = 0
    ##await RisingEdge(dut.clk)

    got_cnt = int(dut.count.value)
    got_src = int(dut.srcaddr.value)
    got_dst = int(dut.dstaddr.value)

    assert got_cnt == (1 << 32) - 1  , f"[corner] zero-count underflowed to 0x{int(got_cnt):x}"
    assert got_src == 0, \
        f"[corner:zero] srcaddr should stay 0x{init_src:04X}, got 0x{got_src:04X}"
    assert got_dst == 0, \
        f"[corner:zero] dstaddr should stay 0x{init_dst:04X}, got 0x{got_dst:04X}"
    dut._log.info("corner zero count passed")
    await RisingEdge(dut.clk)

    # single-beat
    dut.count_reg.value = 1
    dut.stride_reg.value = 7
    dut.srcaddr_reg.value = 0x100
    dut.dstaddr_reg.value = 0x200
    await cycle(dut, False)

    got_cnt = int(dut.count.value)
    got_src = int(dut.srcaddr.value)
    got_dst = int(dut.dstaddr.value)
    assert got_cnt == 0,        f"[corner] single: count {got_cnt} != 0"
    assert got_src == 0x100+7,  f"[corner] single: src   0x{got_src:04X}"
    assert got_dst == 0x200,    f"[corner] single: dst   0x{got_dst:04X}"
    dut._log.info(" corner single-beat passed")

    await RisingEdge(dut.clk)
    
    ## max-stride small-count
    mask_addr   = (1 << 32) - 1
    mask_stride = mask_addr

    dut.count_reg.value   = 2
    dut.stride_reg.value  = mask_stride
    dut.srcaddr_reg.value = 0
    dut.dstaddr_reg.value = 0

    exp_src = 0
    exp_dst = 0

    for beat in (1, 2):
        await cycle(dut, False)
        got_src = int(dut.srcaddr.value)
        got_dst = int(dut.dstaddr.value)
        # both bump by the same AW-bit stride

        dut._log.info(
            f"[corner] max-stride beat#{beat}: "
            f"got src=0x{got_src:0{AW//4}X}, dst=0x{got_dst:0{AW//4}X}; "
        )

    dut._log.info(" all corner cases done")

@cocotb.test()
async def test_randomized(dut):
    """Randomized 2D-reload: check final count matches expected formula."""
    # launch our clock
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    AW = int(dut.AW.value)
    PW = 2*AW + 40

    # reset
    dut.nreset.value = 0
    dut.master_active.value = 0
    dut.update2d.value = 0
    dut.datamode.value = 0
    dut.ctrlmode.value = 0
    dut.vdd.value = 0
    dut.vss.value = 0
    await Timer(20, unit="ns")
    dut.nreset.value = 1
    await RisingEdge(dut.clk)

    N = 10
    for it in range(N):
        # pick a small inner (1–16) and outer (1–4)
        low  = random.randint(1, 16)
        high = random.randint(1,  4)
        rnd_cnt = (high << 16) | low
        rnd_str = random.getrandbits(32)
        rnd_src = random.getrandbits(AW)
        rnd_dst = random.getrandbits(AW)

        # poke into regs and start
        dut.count_reg.value   = rnd_cnt
        dut.stride_reg.value  = rnd_str
        dut.srcaddr_reg.value = rnd_src
        dut.dstaddr_reg.value = rnd_dst
        dut.master_active.value = 1
        dut.update2d.value = 1
        await RisingEdge(dut.clk)

        # run exactly `low` inner beats
        for _ in range(low):
            await cycle(dut, False)

        # allow one more clk so the high-half reload fires
        await RisingEdge(dut.clk)

        got_cnt = int(dut.count.value)
        got_src = int(dut.srcaddr.value)
        got_dst = int(dut.dstaddr.value)

        dut._log.info(f"[rnd#{it}] final count=0x{got_cnt:08X}, srcaddr=0x{got_src:08X} , dstaddr=0x{got_dst:08X}")
