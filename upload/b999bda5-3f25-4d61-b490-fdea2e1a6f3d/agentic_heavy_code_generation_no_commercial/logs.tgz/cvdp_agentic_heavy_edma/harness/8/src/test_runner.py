import os
from cocotb_tools.runner import get_runner
import pytest

verilog_sources = os.getenv("VERILOG_SOURCES").split()
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = bool(os.getenv("WAVE"))

def runner(AW: int = 32, PW: int = None):
    """Invoke simulator runner with given AW and PW parameters."""
    if PW is None:
        PW = 3 * AW + 8
    params = {"AW": AW, "PW": PW}
    print(f"[DEBUG] Parameters: {params}")

    runner = get_runner(sim)
    runner.build(
        sources=verilog_sources,
        hdl_toplevel=toplevel,
        parameters=params,
        always=True,
        clean=True,
        verbose=True,
        timescale=("1ns", "1ns"),
        log_file="sim.log"
    )
    runner.test(hdl_toplevel=toplevel, test_module=module, waves=wave)

# Explicitly test for AW=32 and AW=64, naming the test 'test_edma'
@pytest.mark.parametrize("AW", [32, 64])
@pytest.mark.parametrize("test", range(5))
def test_edma(AW,test):
    """Run EDMA tests for given address width AW."""
    PW = 3 * AW + 8
    runner(AW=AW, PW=PW)
