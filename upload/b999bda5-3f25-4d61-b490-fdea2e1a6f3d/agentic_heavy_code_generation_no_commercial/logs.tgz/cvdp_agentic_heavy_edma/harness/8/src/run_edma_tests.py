import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer
import random

# constants
EDMA_CONFIG  = 0
EDMA_STRIDE  = 1
EDMA_COUNT   = 2
EDMA_SRCADDR = 3
EDMA_DSTADDR = 4
EDMA_STATUS  = 7
EDMA_SECBASE = 8
EDMA_SECMASK = 9

async def reset_dut(dut):
    dut.nreset.value = 0
    dut.access_in.value = 0
    dut.wait_in.value = 0
    dut.reg_access_in.value = 0
    dut.reg_wait_in.value = 0
    dut.vdd.value = 1
    dut.vss.value = 0
    await Timer(20, unit="ns")
    dut.nreset.value = 1
    await RisingEdge(dut.clk)

# build an eMesh packet integer
def build_packet(write, datamode, ctrlmode, dstaddr, data, srcaddr,AW):
    pkt = 0
    pkt |= (srcaddr & ((1<<AW)-1)) << (2*AW + 8)
    pkt |= (data   & ((1<<AW)-1)) << (AW   + 8)
    pkt |= (dstaddr & ((1<<AW)-1)) << 8
    pkt |= (ctrlmode & 0x1F) << 3
    pkt |= (datamode & 0x3) << 1
    pkt |= (write & 0x1)
    return pkt

# write a register via the config/fetch interface
async def write_reg(dut, addr, data,AW):
    pkt = build_packet(1, 0, addr, addr, data & 0xFFFFFFFF, 0,AW)
    await RisingEdge(dut.clk)
    dut.reg_packet_in.value = pkt
    dut.reg_access_in.value = 1
    await RisingEdge(dut.clk)
    dut.reg_access_in.value = 0
    # allow write-through
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

# wait for a master transfer and assert it matches expected
async def expect_transfer(dut, expected_pkt):
    # wait until master drives access_out
    AW = int(dut.AW.value)
    PW = 3*AW + 8
    hex_digits = (PW + 3) // 4  
    got = int (dut.packet_out.value)
    assert got == expected_pkt, (
        f"Transfer mismatch: got 0x{got:0{hex_digits}X}, "
        f"expected 0x{expected_pkt:0{hex_digits}X}"
    )
    await RisingEdge(dut.clk)

@cocotb.test()
async def run_edma_tests(dut):
    # start clock
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    AW = int(dut.AW.value)
    PW = 3 * AW + 8
    await reset_dut(dut)

    # Test 1: Slave passthrough
    dut._log.info("Test1: Slave passthrough")
    pkt = build_packet(0, 2, 1, 42, 99, 7,AW)
    dut.packet_in.value = pkt
    dut.access_in.value = 1
    await RisingEdge(dut.clk)
    assert dut.access_out.value != 1, "Slave access_out mismatch"
    dut.access_in.value = 0
    await RisingEdge(dut.clk)
    assert dut.packet_out.value != pkt, "Slave pkt matches input"
    await RisingEdge(dut.clk)

    # Test 2: Security violation → IRQ
    dut._log.info("Test2: Security violation triggers IRQ")
    await write_reg(dut, EDMA_SECBASE, 1,AW)
    await write_reg(dut, EDMA_SECMASK, 0xFFFFFFFF,AW)
    await write_reg(dut, EDMA_COUNT, 1,AW)
    await write_reg(dut, EDMA_STRIDE, 0x00010000,AW)
    await write_reg(dut, EDMA_SRCADDR, 0,AW)
    await write_reg(dut, EDMA_DSTADDR, 0,AW)
    await write_reg(dut, EDMA_CONFIG, 3,AW)
    # wait a few cycles
    for _ in range(10):
        await RisingEdge(dut.clk)
    assert dut.irq.value == 1, "Expected IRQ on security violation"

    # Test 3: Single manual transfer
    await reset_dut(dut)
    dut._log.info("Test3: Single manual transfer")
    await write_reg(dut, EDMA_CONFIG, 0xB,AW)
    await write_reg(dut, EDMA_SECMASK, 0xFFFFFFFF,AW)
    await write_reg(dut, EDMA_COUNT, 2,AW)
    await write_reg(dut, EDMA_STRIDE, 0x00010000,AW)
    await write_reg(dut, EDMA_SRCADDR, 4,AW)
    await write_reg(dut, EDMA_DSTADDR, 8,AW)
    expected = build_packet(0,2,1,9,99,7,AW)
    await expect_transfer(dut, expected)

    await RisingEdge(dut.clk)
    # Test 4: Chain-mode continuous transfers
    await reset_dut(dut)
    dut._log.info("Test4: Chain-mode continuous transfers")
    await write_reg(dut, EDMA_SECBASE, 0,AW)
    await write_reg(dut, EDMA_SECMASK, 0,AW)
    await write_reg(dut, EDMA_CONFIG, 15,AW)
    await write_reg(dut, EDMA_COUNT, 4,AW)
    await write_reg(dut, EDMA_STRIDE, 0x00010000,AW)
    await write_reg(dut, EDMA_SRCADDR, 10,AW)
    await write_reg(dut, EDMA_DSTADDR, 20,AW)
    for i in [21,22,23,24,25]:
        expected = build_packet(0,0,0,i,0,0,AW)
        await expect_transfer(dut, expected)

    await RisingEdge(dut.clk)
    # Test 5: Register-fetch readback
    await reset_dut(dut)
    dut._log.info("Test5: Register-fetch readback")
    await write_reg(dut, EDMA_CONFIG, 3,AW)
    for _ in range(20):
        await RisingEdge(dut.clk)
        if dut.reg_access_out.value == 1:
            pkt = dut.reg_packet_out.value
            write_bit = pkt & 1
            datamode = (pkt >> 1) & 0x3
            assert write_bit == 0 and datamode == 3, f"Fetch packet wrong: {pkt:08X}"
            break
    await RisingEdge(dut.clk)

    # Test 6: Back-pressure stall
    await reset_dut(dut)
    dut._log.info("Test6: Back-pressure stall")
    await write_reg(dut, EDMA_CONFIG, 0xB,AW)
    await write_reg(dut, EDMA_SECMASK, 0xFFFFFFFF,AW)
    await write_reg(dut, EDMA_COUNT, 1,AW)
    await write_reg(dut, EDMA_STRIDE, 0,AW)
    await write_reg(dut, EDMA_SRCADDR, 5,AW)
    await write_reg(dut, EDMA_DSTADDR, 15,AW)
    dut.wait_in.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.wait_in.value = 0
    expected = build_packet(0,2,1,15,99,7,AW)
    await expect_transfer(dut, expected)
    await RisingEdge(dut.clk)

    # Test 7: Security recovery + safe transfer
    await reset_dut(dut)
    dut._log.info("Test7: Disable security and perform safe DMA")
    await write_reg(dut, EDMA_SECBASE, 0,AW)
    await write_reg(dut, EDMA_SECMASK, 0,AW)
    await write_reg(dut, EDMA_CONFIG, 0xB,AW)
    await write_reg(dut, EDMA_COUNT, 1,AW)
    await write_reg(dut, EDMA_STRIDE, 0,AW)
    await write_reg(dut, EDMA_SRCADDR, 0,AW)
    await write_reg(dut, EDMA_DSTADDR, 0,AW)
    for _ in range(5): await RisingEdge(dut.clk)
    assert dut.irq.value == 0, "IRQ should be clear when security disabled"
    expected = build_packet(0,2,1,0,99,7,AW)
    await expect_transfer(dut, expected)
    await RisingEdge(dut.clk)

    # Test 8: 2D multidimensional transfer
    await reset_dut(dut)
    dut._log.info("Test8: 2D multidimensional transfer")
    for _ in range(10): await RisingEdge(dut.clk)
    dut.wait_in.value = 0
    await write_reg(dut, EDMA_SECBASE, 0,AW)
    await write_reg(dut, EDMA_SECMASK, 0,AW)
    await write_reg(dut, EDMA_CONFIG, 15,AW)
    await write_reg(dut, EDMA_COUNT, ((2<<16) | 3),AW)
    await write_reg(dut, EDMA_STRIDE, 0x00020001,AW)
    await write_reg(dut, EDMA_SRCADDR, 100,AW)
    await write_reg(dut, EDMA_DSTADDR, 200,AW)
    for dst in [202,204,206,208,210,212]:
        expected = build_packet(0,0,0,dst,0,0,AW)
        await expect_transfer(dut, expected)
    await RisingEdge(dut.clk)

    # Test 9: Descriptor chaining
    await reset_dut(dut)
    dut._log.info("Test9: Descriptor chaining via fetch")
    await write_reg(dut, EDMA_SECBASE, 0,AW)
    await write_reg(dut, EDMA_SECMASK, 0,AW)
    await write_reg(dut, EDMA_CONFIG, (0x0010<<16) | 0xF,AW)
    async def fake_mem():
        while True:
            await RisingEdge(dut.clk)
            if dut.reg_access_out.value == 1:
                pkt = build_packet(1,0,EDMA_COUNT,EDMA_COUNT,2,0,AW)
                dut.reg_packet_in.value = pkt
                dut.reg_access_in.value = 1
                await RisingEdge(dut.clk)
                dut.reg_access_in.value = 0
                await RisingEdge(dut.clk)
                pkt2 = build_packet(1,0,EDMA_STRIDE,EDMA_STRIDE,1,0,AW)
                dut.reg_packet_in.value = pkt2
                dut.reg_access_in.value = 1
                await RisingEdge(dut.clk)
                dut.reg_access_in.value = 0
                break
    cocotb.start_soon(fake_mem())
    await RisingEdge(dut.clk)
    while True:
        await RisingEdge(dut.clk)
        if dut.access_out.value == 1:
            break
    expected = build_packet(0,0,0,0,0,0,AW)
    await expect_transfer(dut, expected)
    await RisingEdge(dut.clk)

    # Test 10: Status-register readback
    await reset_dut(dut)
    dut._log.info("Test10: Status-register fetch readback")
    await write_reg(dut, EDMA_SECBASE, 0,AW)
    await write_reg(dut, EDMA_SECMASK, 0,AW)
    await write_reg(dut, EDMA_CONFIG, (0xBEEF<<16) | 0xB,AW)
    await write_reg(dut, EDMA_COUNT, 5,AW)
    await write_reg(dut, EDMA_STRIDE, 0,AW)
    await write_reg(dut, EDMA_SRCADDR, 1,AW)
    await write_reg(dut, EDMA_DSTADDR, 2,AW)
    await write_reg(dut, EDMA_STATUS, 0x12340007,AW)
    for _ in range(20):
        await RisingEdge(dut.clk)
        if dut.reg_access_out.value == 1:
            pkt = dut.reg_packet_out.value
            data_field = (pkt >> (AW+8)) & ((1<<AW)-1)
            assert data_field == 0x12340007, f"Status readback mismatch: {data_field:08X}"
            break

    dut._log.info("All tests passed.")
