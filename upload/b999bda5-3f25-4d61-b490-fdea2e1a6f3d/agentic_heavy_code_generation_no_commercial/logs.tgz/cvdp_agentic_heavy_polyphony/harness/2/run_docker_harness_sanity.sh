#!/bin/bash

# Auto-generated script to run harness Docker container
# Usage: run_docker_harness_sanity.sh [-d] (where -d enables debug mode with bash entrypoint)
set -e

# Parse command line arguments
DEBUG_MODE=false
while getopts 'd' flag; do
  case "${flag}" in
    d) DEBUG_MODE=true ;;
  esac
done

# Use shared bridge network: cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc
NETWORK_CREATED=0

# Check if network exists, create if needed
if ! docker network inspect cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc &>/dev/null; then
  echo "Creating Docker network cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc..."
  docker network create --driver bridge cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc
  NETWORK_CREATED=1
fi

# Function to clean up resources
cleanup() {
  echo "Cleaning up Docker resources..."
  docker compose -f <source-results>/cvdp_agentic_heavy_polyphony/harness/2/docker-compose.yml -p cvdp_agentic_heavy_polyphony_2_1784862470 kill sanity 2>/dev/null || true
  docker rmi cvdp_agentic_heavy_polyphony_2_1784862470-sanity 2>/dev/null || true
  if [ $NETWORK_CREATED -eq 1 ]; then
    echo "Removing Docker network cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc..."
    docker network rm cvdp-bridge-cvdp_v1-1-0_agentic_heavy_code_generation_no_commerc 2>/dev/null || true
  fi
}

# Set up cleanup trap
trap cleanup EXIT

# Run the harness container
echo "Running harness with project name: cvdp_agentic_heavy_polyphony_2_1784862470"
# Get current user and group IDs
USER_ID=$(id -u)
GROUP_ID=$(id -g)

if [ "$DEBUG_MODE" = true ]; then
  echo "DEBUG MODE: Starting container with bash entrypoint"
  docker compose -f <source-results>/cvdp_agentic_heavy_polyphony/harness/2/docker-compose.yml -p cvdp_agentic_heavy_polyphony_2_1784862470 run --rm --user $USER_ID:$GROUP_ID -e HOME=/rundir -e XDG_CACHE_HOME=/rundir/.cache --entrypoint bash -v cvdp_agentic_heavy_polyphony_0002_workspace:/code -v "<source-results>/cvdp_agentic_heavy_polyphony/harness/2/src:/src" -v "<source-results>/cvdp_agentic_heavy_polyphony/harness/2/rundir:/rundir" -v "<home>/for_github/cvdp_benchmark/llm_lib:/pysubj" --rm -w /rundir sanity
else
  docker compose -f <source-results>/cvdp_agentic_heavy_polyphony/harness/2/docker-compose.yml -p cvdp_agentic_heavy_polyphony_2_1784862470 run --rm --user $USER_ID:$GROUP_ID -e HOME=/rundir -e XDG_CACHE_HOME=/rundir/.cache -v cvdp_agentic_heavy_polyphony_0002_workspace:/code -v "<source-results>/cvdp_agentic_heavy_polyphony/harness/2/src:/src" -v "<source-results>/cvdp_agentic_heavy_polyphony/harness/2/rundir:/rundir" -v "<home>/for_github/cvdp_benchmark/llm_lib:/pysubj" --rm -w /rundir sanity
fi
exit_code=$?

# Exit with the same code as the docker command
exit $exit_code
