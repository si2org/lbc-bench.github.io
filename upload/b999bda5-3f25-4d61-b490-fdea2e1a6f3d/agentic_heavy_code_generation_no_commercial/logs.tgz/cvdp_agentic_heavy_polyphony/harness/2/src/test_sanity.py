import cocotb
from cocotb.triggers import RisingEdge
from cocotb.clock import Clock
import random

LATENCY = 4  


def float_to_f22(f):
    """Convert Python float to 22-bit format with explicit 16-bit mantissa."""
    if f == 0.0:
        return 0
    sign = 0 if f >= 0 else 1
    f = abs(f)
    exp = 0
    # normalize into [1.0, 2.0)
    while f >= 2.0:
        f /= 2.0
        exp += 1
    while f < 1.0:
        f *= 2.0
        exp -= 1
    exp += 15
    if not (0 <= exp <= 31):
        raise ValueError("Exponent out of range")
    # store the full mantissa (1.xxx) in 16 bits
    mant = int(f * (1 << 15)) & 0xFFFF
    return (sign << 21) | (exp << 16) | mant


def f22_to_float(x):
    """Convert 22-bit format (explicit 16-bit mantissa) back to Python float."""
    sign = -1 if (x >> 21) & 1 else 1
    exp  = ((x >> 16) & 0x1F) - 15
    mant = x & 0xFFFF
    return sign * (mant / float(1 << 15)) * (2 ** exp)


def is_normal_f22(f):
    """Return True if f encodes to a normal f22 (exp in [1..30])."""
    if f == 0.0:
        return False
    try:
        x = float_to_f22(f)
    except ValueError:
        return False
    e = (x >> 16) & 0x1F
    return 1 <= e <= 30


def random_normal_f22():
    """Generate a random float whose f22 encoding is a normal number."""
    while True:
        f = random.uniform(-1000, 1000)
        if is_normal_f22(f):
            return f, float_to_f22(f)


async def reset_dut(dut):
    dut.i_en.value = 0
    dut.i_a.value = 0
    dut.i_b.value = 0
    dut.i_adsb.value = 0
    for _ in range(5):
        await RisingEdge(dut.clk_core)


@cocotb.test()
async def test_fm_3d_fadd_verbose(dut):
    """Verbose basic tests, including subnormal-output cases"""
    cocotb.start_soon(Clock(dut.clk_core, 10, unit="ns").start())
    await reset_dut(dut)

    # basic functionality + subnormal-output testcases
    test_vectors = [
        (1.75, 2.25, 0),      # A + B = 4.00
        (5.75, 1.25, 1),      # A - B = 4.50
        (-1.0, 1.0, 0),       # -1 + 1 = 0
        (1000.0, -999.0, 0),  # Large pos + large neg = 1
        (-10.0, -5.0, 1),     # -10 - (-5) = -5
        (3.1415, 2.7182, 0),  # π + e
        (1.0 + 1/(1<<15), 1.0, 1),          
        (2**-14 + 2**-15, 2**-14, 1),       
        (1.0, 1.0 + 1/(1<<15), 1),        
    ]

    print("\n==== INPUT & OUTPUT PHASE ====")
    expected_outputs = []
    output_index = 0
    cycle = 0
    TOTAL_CYCLES = len(test_vectors) + LATENCY

    for idx in range(TOTAL_CYCLES):
        print(f"\n--- Cycle {cycle + 1} / {TOTAL_CYCLES} ---")

        if idx < len(test_vectors):
            a, b, adsb = test_vectors[idx]
            a_encoded = float_to_f22(a)
            b_encoded = float_to_f22(b)
            expected = a - b if adsb else a + b

            # Apply inputs
            dut.i_a.value = a_encoded
            dut.i_b.value = b_encoded
            dut.i_adsb.value = adsb
            dut.i_en.value = 1

            expected_outputs.append((expected, a, b, adsb, a_encoded, b_encoded))
            print(f"[Cycle {cycle}] INPUT: A={a} ({bin(a_encoded)}) "
                  f"{'-' if adsb else '+'} B={b} ({bin(b_encoded)}) → Expected = {expected:.6f}")
        else:
            print(f"[Cycle {cycle}] No new input (pipeline drain)")

        # Check output
        if cycle >= LATENCY and output_index < len(expected_outputs):
            ref, a_prev, b_prev, adsb_prev, a_enc, b_enc = expected_outputs[output_index]
            result_raw   = int(dut.o_c.value)
            result_float = f22_to_float(result_raw)
            error        = abs(result_float - ref)
            print(f"[Cycle {cycle}] OUTPUT {output_index}: "
                  f"float={result_float:.6f}, expected={ref:.6f}, error={error:.6e}")
            # allow tiny error for normals, subnormals may have larger relative error
            assert error < 0.01 or (result_float == 0.0 and abs(ref) < 2**-16), \
                f"ERROR at out {output_index}: got {result_float}, expected {ref}"
            output_index += 1

        await RisingEdge(dut.clk_core)
        cycle += 1


@cocotb.test()
async def test_fm_3d_fadd_random_verbose(dut):
    """Verbose random tests with only normal-number inputs"""
    cocotb.start_soon(Clock(dut.clk_core, 10, unit="ns").start())
    await reset_dut(dut)

    NUM_TESTS  = 15
    expected_outputs = []
    output_index     = 0
    cycle            = 0
    TOTAL_CYCLES     = NUM_TESTS + LATENCY

    print("\n==== RANDOM INPUT & OUTPUT PHASE ====")

    for idx in range(TOTAL_CYCLES):
        print(f"\n--- Cycle {cycle + 1} / {TOTAL_CYCLES} ---")

        if idx < NUM_TESTS:
            # generate only normal inputs
            a, a_encoded = random_normal_f22()
            b, b_encoded = random_normal_f22()
            adsb = random.randint(0, 1)

            expected = a - b if adsb else a + b

            dut.i_a.value    = a_encoded
            dut.i_b.value    = b_encoded
            dut.i_adsb.value = adsb
            dut.i_en.value   = 1

            expected_outputs.append((expected, a, b, adsb, a_encoded, b_encoded))
            print(f"[Cycle {cycle}] INPUT: A={a:.6f}, B={b:.6f}, op={'-' if adsb else '+'} → expected {expected:.6f}")
        else:
            print(f"[Cycle {cycle}] No new input (pipeline drain)")

        # Check output
        if cycle >= LATENCY and output_index < len(expected_outputs):
            ref, a_prev, b_prev, adsb_prev, a_enc, b_enc = expected_outputs[output_index]
            result_raw   = int(dut.o_c.value)
            result_float = f22_to_float(result_raw)
            error        = abs(result_float - ref)
            print(f"[Cycle {cycle}] OUTPUT {output_index}: "
                  f"float={result_float:.6f}, expected={ref:.6f}, error={error:.6e}")
            assert error < 0.9, \
                f"ERROR at out {output_index}: got {result_float}, expected {ref}"  
            output_index += 1

        await RisingEdge(dut.clk_core)
        cycle += 1
