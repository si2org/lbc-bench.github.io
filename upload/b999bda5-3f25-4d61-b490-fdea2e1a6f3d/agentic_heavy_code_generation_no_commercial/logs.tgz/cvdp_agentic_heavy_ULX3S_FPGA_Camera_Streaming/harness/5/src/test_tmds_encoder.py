import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
import random

# TMDS control symbol patterns
CRTPAR = {
    0: 0b1101010100,
    1: 0b0010101011,
    2: 0b0101010100,
    3: 0b1010101011
}

def tmds_decode_ref(datain):
    """
    Decode TMDS reference model for control and data.
    Returns (de_ref, tmdsout_ref, ctrl_ref).
    """
    # Control symbol detection
    if datain == CRTPAR[0]:
        return False, 0, 0
    if datain == CRTPAR[1]:
        return False, 0, 1
    if datain == CRTPAR[2]:
        return False, 0, 2
    if datain == CRTPAR[3]:
        return False, 0, 3

    inverted = (datain >> 9) & 0x1
    raw_data = datain & 0xFF
    data = (~raw_data & 0xFF) if inverted else raw_data
    invert_flag = (datain >> 8) & 0x1

    tmdsout = 0
    for i in range(8):
        if i == 0:
            out_bit = (data >> 0) & 0x1
        else:
            d_i = (data >> i) & 0x1
            d_prev = (data >> (i-1)) & 0x1
            if invert_flag:
                out_bit = d_i ^ d_prev
            else:
                out_bit = (~(d_i ^ d_prev)) & 0x1
        tmdsout |= (out_bit << i)
    return True, tmdsout, None  # ctrl_ref unused for data

async def setup_dut(dut):
    """Initialize DUT inputs and start clock."""
    dut.DE.value = 0
    dut.D.value = 0
    dut.C1.value = 0
    dut.C0.value = 0
    cocotb.start_soon(Clock(dut.clk, 10, unit='ns').start())
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

async def log_cycle(dut):
    """Log inputs, output, and reference decode each clock."""
    datain = int(dut.q_out.value)
    de_ref, tmdsout_ref, _ = tmds_decode_ref(datain)
    dut._log.info(
        f"DE={int(dut.DE.value)} | D=0x{int(dut.D.value):02X} | "
        f"C1={int(dut.C1.value)} | C0={int(dut.C0.value)} | "
        f"q_out=0b{datain:010b} | ref_DE={int(de_ref)} | ref_data=0b{tmdsout_ref:08b}"
    )

@cocotb.test()
async def test_data_walking_ones(dut):
    await setup_dut(dut)
    prev_D = None
    pattern = [(1 << i) & 0xFF for i in range(8)] + [((1 << i) | 1) & 0xFF for i in range(8)]
    dut.DE.value = 1
    dut.C1.value = 0
    dut.C0.value = 0
    for D in pattern:
        dut.D.value = D
        await RisingEdge(dut.clk)
        await log_cycle(dut)
        if prev_D is not None:
            datain = int(dut.q_out.value)
            de_ref, tmdsout, _ = tmds_decode_ref(datain)
            assert de_ref and tmdsout == prev_D, \
                f"Walking Ones: got {tmdsout:08b}, expected {prev_D:08b}"
        prev_D = D
    dut._log.info("Walking ones test passed.")

@cocotb.test()
async def test_data_walking_zeros(dut):
    await setup_dut(dut)
    prev_D = None
    pattern = [~(1 << i) & 0xFF for i in range(8)] + [~(((1 << i) | 1) & 0xFF) & 0xFF for i in range(8)]
    dut.DE.value = 1
    dut.C1.value = 0
    dut.C0.value = 0
    for D in pattern:
        dut.D.value = D
        await RisingEdge(dut.clk)
        await log_cycle(dut)
        if prev_D is not None:
            datain = int(dut.q_out.value)
            de_ref, tmdsout, _ = tmds_decode_ref(datain)
            assert de_ref and tmdsout == prev_D, \
                f"Walking Zeros: got {tmdsout:08b}, expected {prev_D:08b}"
        prev_D = D
    dut._log.info("Walking zeros test passed.")

@cocotb.test()
async def test_data_special_patterns(dut):
    await setup_dut(dut)
    prev_D = None
    pattern = [0x00,0xFF,0x55,0xAA,0x33,0xCC,0x0F,0xF0,0x7F,0x80,0x81,0x7E]
    dut.DE.value = 1
    dut.C1.value = 0
    dut.C0.value = 0
    for D in pattern:
        dut.D.value = D
        await RisingEdge(dut.clk)
        await log_cycle(dut)
        if prev_D is not None:
            datain = int(dut.q_out.value)
            de_ref, tmdsout, _ = tmds_decode_ref(datain)
            assert de_ref and tmdsout == prev_D, \
                f"Special Patterns: got {tmdsout:08b}, expected {prev_D:08b}"
        prev_D = D
    dut._log.info("Special patterns test passed.")

@cocotb.test()
async def test_long_random_data(dut):
    await setup_dut(dut)
    prev_D = None
    LONG_TEST_CYCLES = 1000
    dut.DE.value = 1
    dut.C1.value = 0
    dut.C0.value = 0
    for _ in range(LONG_TEST_CYCLES):
        D = random.getrandbits(8)
        dut.D.value = D
        await RisingEdge(dut.clk)
        await log_cycle(dut)
        if prev_D is not None:
            datain = int(dut.q_out.value)
            de_ref, tmdsout, _ = tmds_decode_ref(datain)
            assert de_ref and tmdsout == prev_D, \
                f"Random Data: got {tmdsout:08b}, expected {prev_D:08b}"
        prev_D = D
    dut._log.info("Long random data test passed.")

