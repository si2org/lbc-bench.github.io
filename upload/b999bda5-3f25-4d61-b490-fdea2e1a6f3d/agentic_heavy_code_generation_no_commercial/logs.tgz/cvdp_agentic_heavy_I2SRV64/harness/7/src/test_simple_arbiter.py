import cocotb
from cocotb.triggers import RisingEdge, FallingEdge, Timer

# Helper: Set all request/abort/data signals to zero (reset state)
def reset_inputs(dut):
    dut.InReq0_Valid.value = 0
    dut.InReq0_Addr.value = 0
    dut.InReq0_DataType.value = 0
    dut.InReq0_Abort.value = 0
    dut.InReq1_Valid.value = 0
    dut.InReq1_Addr.value = 0
    dut.InReq1_DataType.value = 0
    dut.InReq1_Abort.value = 0
    dut.InReq2_Valid.value = 0
    dut.InReq2_Addr.value = 0
    dut.InReq2_DataType.value = 0
    dut.InReq2_Abort.value = 0
    dut.OutResp_Done.value = 0
    dut.OutResp_Ready.value = 0
    dut.OutResp_Data.value = 0

async def clk_gen(dut):
    while True:
        dut.clk.value = 0
        await Timer(5, unit="ns")
        dut.clk.value = 1
        await Timer(5, unit="ns")

@cocotb.test()
async def test_InResp0_Done(dut):
    """Test 1 : Verification of Response Completion Signaling for Port 0 Request"""
    cocotb.start_soon(clk_gen(dut))
    reset_inputs(dut)
    dut.rst.value = 1
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    dut.InReq0_Valid.value = 1
    dut.InReq1_Valid.value = 0
    dut.InReq2_Valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Ready.value = 1
    dut.InReq0_Abort.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Done.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut._log.info(f"InResp0_Done = {int(dut.InResp0_Done.value)}")
    dut._log.info(f"InResp1_Done = {int(dut.InResp1_Done.value)}")
    dut._log.info(f"InResp2_Done = {int(dut.InResp2_Done.value)}")
    assert int(dut.InResp0_Done.value) == 1, "InResp0_Done should be 1"
    assert int(dut.InResp1_Done.value) == 0, "InResp1_Done should be 0"
    assert int(dut.InResp2_Done.value) == 0, "InResp2_Done should be 0"
    await FallingEdge(dut.clk)
    dut.InReq0_Valid.value = 0
    dut.OutResp_Ready.value = 0
    dut.OutResp_Done.value = 0
    

@cocotb.test()
async def test_InResp1_Done(dut):
    """Test 2 : Verification of Response Completion Signaling for Port 1 Request"""
    cocotb.start_soon(clk_gen(dut))
    reset_inputs(dut)
    dut.rst.value = 1
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    dut.InReq1_Valid.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Ready.value = 1
    dut.InReq1_Abort.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Done.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut._log.info(f"InResp0_Done = {int(dut.InResp0_Done.value)}")
    dut._log.info(f"InResp1_Done = {int(dut.InResp1_Done.value)}")
    dut._log.info(f"InResp2_Done = {int(dut.InResp2_Done.value)}")
    assert int(dut.InResp0_Done.value) == 0, "InResp0_Done should be 0"
    assert int(dut.InResp1_Done.value) == 1, "InResp1_Done should be 1"
    assert int(dut.InResp2_Done.value) == 0, "InResp2_Done should be 0"
    await FallingEdge(dut.clk)
    dut.InReq1_Valid.value = 0
    dut.OutResp_Ready.value = 0
    dut.OutResp_Done.value = 0

@cocotb.test()
async def test_InResp2_Done(dut):
    """Test 3 : Verification of Response Completion Signaling for Port 2 Request"""
    cocotb.start_soon(clk_gen(dut))
    reset_inputs(dut)
    dut.rst.value = 1
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    dut.InReq2_Valid.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Ready.value = 1
    dut.InReq2_Abort.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Done.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut._log.info(f"InResp0_Done = {int(dut.InResp0_Done.value)}")
    dut._log.info(f"InResp1_Done = {int(dut.InResp1_Done.value)}")
    dut._log.info(f"InResp2_Done = {int(dut.InResp2_Done.value)}")
    assert int(dut.InResp0_Done.value) == 0, "InResp0_Done should be 0"
    assert int(dut.InResp1_Done.value) == 0, "InResp1_Done should be 0"
    assert int(dut.InResp2_Done.value) == 1, "InResp2_Done should be 1"
    await FallingEdge(dut.clk)
    dut.InReq2_Valid.value = 0
    dut.OutResp_Ready.value = 0
    dut.OutResp_Done.value = 0

@cocotb.test()
async def test_InResp0_Data(dut):
    """Test 4 : Verification of Response Data Routing for Port 0 Requests"""
    cocotb.start_soon(clk_gen(dut))
    reset_inputs(dut)
    dut.rst.value = 1
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    dut.InReq0_Valid.value = 1
    dut.InReq1_Valid.value = 0
    dut.InReq2_Valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Ready.value = 1
    dut.InReq0_Abort.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Data.value = 0x567843211234ABCD
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut._log.info(f"InResp0_Data = {hex(int(dut.InResp0_Data.value))}")
    dut._log.info(f"InResp1_Data = {hex(int(dut.InResp1_Data.value))}")
    dut._log.info(f"InResp2_Data = {hex(int(dut.InResp2_Data.value))}")
    assert int(dut.InResp0_Data.value) == 0x567843211234ABCD, "InResp0_Done should be 0x567843211234ABCD"
    assert int(dut.InResp1_Data.value) == 0, "InResp1_Done should be 0"
    assert int(dut.InResp2_Data.value) == 0, "InResp2_Done should be 0"
    await FallingEdge(dut.clk)
    dut.InReq0_Valid.value = 0
    dut.OutResp_Ready.value = 0

@cocotb.test()
async def test_InResp1_Data(dut):
    """Test 5 : Verification of Response Data Routing for Port 1 Requests"""
    cocotb.start_soon(clk_gen(dut))
    reset_inputs(dut)
    dut.rst.value = 1
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    dut.InReq0_Valid.value = 0
    dut.InReq1_Valid.value = 1
    dut.InReq2_Valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Ready.value = 1
    dut.InReq1_Abort.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Data.value = 0x111179868986BFAD
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut._log.info(f"InResp0_Data = {hex(int(dut.InResp0_Data.value))}")
    dut._log.info(f"InResp1_Data = {hex(int(dut.InResp1_Data.value))}")
    dut._log.info(f"InResp2_Data = {hex(int(dut.InResp2_Data.value))}")
    assert int(dut.InResp0_Data.value) == 0, "InResp0_Done should be 0"
    assert int(dut.InResp1_Data.value) == 0x111179868986BFAD, "InResp1_Done should be 0x111179868986BFAD"
    assert int(dut.InResp2_Data.value) == 0, "InResp2_Done should be 0"
    await FallingEdge(dut.clk)
    dut.InReq1_Valid.value = 0
    dut.OutResp_Ready.value = 0

@cocotb.test()
async def test_InResp2_Data(dut):
    """Test 6 : Verification of Response Data Routing for Port 2 Requests"""
    cocotb.start_soon(clk_gen(dut))
    reset_inputs(dut)
    dut.rst.value = 1
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    dut.InReq0_Valid.value = 0
    dut.InReq1_Valid.value = 0
    dut.InReq2_Valid.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Ready.value = 1
    dut.InReq2_Abort.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Data.value = 0x79868986BFAD9898
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut._log.info(f"InResp0_Data = {hex(int(dut.InResp0_Data.value))}")
    dut._log.info(f"InResp1_Data = {hex(int(dut.InResp1_Data.value))}")
    dut._log.info(f"InResp2_Data = {hex(int(dut.InResp2_Data.value))}")
    assert int(dut.InResp0_Data.value) == 0, "InResp0_Done should be 0"
    assert int(dut.InResp1_Data.value) == 0, "InResp1_Done should be 0"
    assert int(dut.InResp2_Data.value) == 0x79868986BFAD9898, "InResp2_Done should be 0x79868986BFAD9898"
    await FallingEdge(dut.clk)
    dut.InReq2_Valid.value = 0
    dut.OutResp_Ready.value = 0

@cocotb.test()
async def test_OutReq_Abort(dut):
    """Test 7 : Verification of OutReq_Abort Signal Propagation for All Input Ports"""
    cocotb.start_soon(clk_gen(dut))
    reset_inputs(dut)
    dut.rst.value = 1
    await RisingEdge(dut.clk)
    dut.rst.value = 0

    # Port 0 abort
    dut.InReq0_Valid.value = 1
    dut.InReq1_Valid.value = 0
    dut.InReq2_Valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Ready.value = 1
    dut.InReq0_Abort.value = 0
    await RisingEdge(dut.clk)
    dut.InReq0_Abort.value = 1
    await RisingEdge(dut.clk)
    dut._log.info(f"First Time OutReq_Abort = {int(dut.OutReq_Abort.value)}")
    assert int(dut.OutReq_Abort.value) == 1, "OutReq_Abort should be 1"
    await FallingEdge(dut.clk)
    dut.InReq0_Valid.value = 0
    dut.OutResp_Ready.value = 0

    # Port 1 abort
    dut.InReq1_Valid.value = 1
    dut.InReq2_Valid.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Ready.value = 1
    dut.InReq1_Abort.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.InReq1_Abort.value = 1
    await RisingEdge(dut.clk)
    dut._log.info(f"Second Time OutReq_Abort = {int(dut.OutReq_Abort.value)}")
    assert int(dut.OutReq_Abort.value) == 1, "OutReq_Abort should be 1"
    await FallingEdge(dut.clk)
    dut.InReq1_Valid.value = 0
    dut.OutResp_Ready.value = 0

    # Port 2 abort
    dut.InReq2_Valid.value = 1
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.OutResp_Ready.value = 1
    dut.InReq2_Abort.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.InReq2_Abort.value = 1
    await RisingEdge(dut.clk)
    dut._log.info(f"Third Time OutReq_Abort = {int(dut.OutReq_Abort.value)}")
    assert int(dut.OutReq_Abort.value) == 1, "OutReq_Abort should be 1"
    await FallingEdge(dut.clk)
    dut.InReq2_Valid.value = 0
    dut.OutResp_Ready.value = 0

