import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock


@cocotb.test()
async def test_immediate_write_after_reset(dut):
    """
    Test 1: Single write immediately after reset
      - DUT is idle: arbiter_busy=0, req_pending={0,0}, last_valid=0.
      - Drive one write with Resp_Ready=1; sample grant next clock.
    """
    # Start 100 MHz clock (10 ns period)
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    # Apply reset and initialize all inputs
    dut.rst.value = 1
    dut.DCache_RdReq_Valid.value = 0
    dut.DCache_RdReq_Paddr.value = 0
    dut.DCache_RdReq_DataType.value = 0
    dut.DCache_RdReq_Abort.value = 0
    dut.DCache_WrReq_Valid.value = 0
    dut.DCache_WrReq_DataType.value = 0
    dut.DCache_WrReq_Paddr.value = 0
    dut.DCache_WrReq_Data.value = 0
    dut.DCache_Resp_Done.value = 0
    dut.DCache_Resp_Ready.value = 0
    dut.DCache_Resp_Rddata.value = 0

    # Hold reset for 20 ns, then release at next posedge
    await Timer(20, unit="ns")
    await RisingEdge(dut.clk)
    dut.rst.value = 0

    # Give two full clocks to clear any pending bits
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # Drive the write request on the next cycle
    dut.DCache_WrReq_Paddr.value = int(0x123456789ABC)
    dut.DCache_WrReq_DataType.value = 0b101
    dut.DCache_WrReq_Data.value = int(0xFEEDFACECAFED00D)
    dut.DCache_WrReq_Valid.value = 1
    dut.DCache_RdReq_Valid.value = 0
    dut.DCache_Resp_Ready.value = 1

    # Wait two clocks, then sample the arbiter grant
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    grant_valid = int(dut.DCache_Req_Valid.value)
    grant_type = int(dut.DCache_Req_Type.value)      # expect 1
    grant_paddr = int(dut.DCache_Req_Paddr.value)    # expect 0x123456789ABC
    grant_wrdata = int(dut.DCache_Req_Wrdata.value)  # expect 0xFEEDFACECAFED00D
    grant_dtype = int(dut.DCache_Req_DataType.value) # expect 0b101
    arb_busy = int(dut.arbiter_busy.value)
    pending = int(dut.req_pending.value)
    wr_valid_still = int(dut.DCache_WrReq_Valid.value)

    dut._log.info(
        f"Grant: Req_Valid={grant_valid}, Req_Type={grant_type}, "
        f"Req_Paddr=0x{grant_paddr:012X}, Req_Wrdata=0x{grant_wrdata:016X}, "
        f"Req_DataType={grant_dtype:03b}, arbiter_busy={arb_busy}, "
        f"req_pending={pending:02b}, DCache_WrReq_Valid={wr_valid_still}"
    )

    # Assertions based on the expected values
    assert grant_valid == 1,       f"Expected Req_Valid=1, got {grant_valid}"
    assert grant_type == 1,        f"Expected Req_Type=1 (write), got {grant_type}"
    assert grant_paddr == 0x123456789ABC, f"Expected Req_Paddr=0x123456789ABC, got 0x{grant_paddr:012X}"
    assert grant_wrdata == 0xFEEDFACECAFED00D, f"Expected Req_Wrdata=0xFEEDFACECAFED00D, got 0x{grant_wrdata:016X}"
    assert grant_dtype == 0b101,   f"Expected Req_DataType=0b101, got {grant_dtype:03b}"
    assert arb_busy == 1,          f"Expected arbiter_busy=1, got {arb_busy}"
    assert pending == 0b10,        f"Expected req_pending=0b10, got {pending:02b}"
    assert wr_valid_still == 1,    f"Expected DCache_WrReq_Valid still=1, got {wr_valid_still}"

    # One cycle later, complete the write
    await RisingEdge(dut.clk)
    dut.DCache_Resp_Done.value = 1   # (Active_Req==1 internally → clears req_pending[1])
    dut.DCache_WrReq_Valid.value = 0

    # Finally, sample the write-response one more clock later
    await RisingEdge(dut.clk)
    wrresp_ready = int(dut.DCache_WrResp_Ready.value)  # expect 1
    wrresp_done = int(dut.DCache_WrResp_Done.value)    # expect 1 for exactly one cycle

    dut._log.info(f"WrResp_Ready={wrresp_ready}, WrResp_Done={wrresp_done}")

    # Assertions for write response
    assert wrresp_ready == 1, f"Expected WrResp_Ready=1, got {wrresp_ready}"
    assert wrresp_done == 1,  f"Expected WrResp_Done=1, got {wrresp_done}"

    # Clean up for next tests
    dut.DCache_Resp_Done.value = 0


@cocotb.test()
async def test_immediate_read_after_reset(dut):
    """
    Test 2: Single read immediately after reset
      - Arbiter is idle once more (we just cleared the write).
      - Drive one read with Resp_Ready=1; sample grant next clock.
      - Wait one cycle for Active_Req→0, then assert Done.
    """
    # Start 100 MHz clock (10 ns period)
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    # Apply reset and initialize all inputs
    dut.rst.value = 1
    dut.DCache_RdReq_Valid.value = 0
    dut.DCache_RdReq_Paddr.value = 0
    dut.DCache_RdReq_DataType.value = 0
    dut.DCache_RdReq_Abort.value = 0
    dut.DCache_WrReq_Valid.value = 0
    dut.DCache_WrReq_DataType.value = 0
    dut.DCache_WrReq_Paddr.value = 0
    dut.DCache_WrReq_Data.value = 0
    dut.DCache_Resp_Done.value = 0
    dut.DCache_Resp_Ready.value = 0
    dut.DCache_Resp_Rddata.value = 0

    # Hold reset for 20 ns, then release at next posedge
    await Timer(20, unit="ns")
    await RisingEdge(dut.clk)
    dut.rst.value = 0

    # Give two full clocks to clear state
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # Ensure no leftover write is pending
    dut.DCache_WrReq_Valid.value = 0
    dut.DCache_Resp_Done.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # Drive the read request
    dut.DCache_RdReq_Paddr.value = int(0xA5A5A5A5A5A5)
    dut.DCache_RdReq_DataType.value = 0b010
    dut.DCache_RdReq_Valid.value = 1
    dut.DCache_RdReq_Abort.value = 0
    dut.DCache_Resp_Ready.value = 1
    dut.DCache_Resp_Rddata.value = int(0xDEADBEEFCAFEBABE)

    # On next clock: arbiter takes the read
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    grant_valid = int(dut.DCache_Req_Valid.value)
    grant_type = int(dut.DCache_Req_Type.value)      # expect 0
    grant_paddr = int(dut.DCache_Req_Paddr.value)    # expect 0xA5A5A5A5A5A5
    grant_dtype = int(dut.DCache_Req_DataType.value) # expect 0b010

    dut._log.info(
        f"Grant: Req_Valid={grant_valid}, Req_Type={grant_type}, "
        f"Req_Paddr=0x{grant_paddr:012X}, Req_DataType={grant_dtype:03b}"
    )

    # Assertions for the grant
    assert grant_valid == 1, f"Expected Req_Valid=1, got {grant_valid}"
    assert grant_type == 0,  f"Expected Req_Type=0 (read), got {grant_type}"
    assert grant_paddr == 0xA5A5A5A5A5A5, f"Expected Req_Paddr=0xA5A5A5A5A5A5, got 0x{grant_paddr:012X}"
    assert grant_dtype == 0b010, f"Expected Req_DataType=0b010, got {grant_dtype:03b}"

    # Wait one more clock so that Active_Req becomes 0
    await RisingEdge(dut.clk)
    dut.DCache_Resp_Done.value = 1  # (Active_Req==0 & Resp_Done==1 → clears req_pending[0])

    # Next clock: clear signals
    await RisingEdge(dut.clk)
    dut.DCache_Resp_Done.value = 0
    dut.DCache_RdReq_Valid.value = 0

    # One more clock to let things settle, then sample the response
    await RisingEdge(dut.clk)
    rdresp_ready = int(dut.DCache_RdResp_Ready.value)  # expect 1
    rdresp_data = int(dut.DCache_RdResp_Data.value)    # expect 0xDEADBEEFCAFEBABE
    rdresp_done = int(dut.DCache_RdResp_Done.value)    # per log, expect 0

    dut._log.info(
        f"RdResp_Ready={rdresp_ready}, RdResp_Data=0x{rdresp_data:016X}, RdResp_Done={rdresp_done}"
    )

    # Assertions for read response
    assert rdresp_ready == 1,      f"Expected RdResp_Ready=1, got {rdresp_ready}"
    assert rdresp_data == 0xDEADBEEFCAFEBABE, f"Expected RdResp_Data=0xDEADBEEFCAFEBABE, got 0x{rdresp_data:016X}"
    assert rdresp_done == 0,       f"Expected RdResp_Done=0 (per log), got {rdresp_done}"


@cocotb.test()
async def test_simultaneous_rw_after_reset(dut):
    """
    Test 3: Simultaneous read+write immediately after reset
      - At reset, last_valid=0. Driving both should pick the write.
    """
    # Start 100 MHz clock (10 ns period)
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    # Apply reset and initialize all inputs
    dut.rst.value = 1
    dut.DCache_RdReq_Valid.value = 0
    dut.DCache_RdReq_Paddr.value = 0
    dut.DCache_RdReq_DataType.value = 0
    dut.DCache_RdReq_Abort.value = 0
    dut.DCache_WrReq_Valid.value = 0
    dut.DCache_WrReq_DataType.value = 0
    dut.DCache_WrReq_Paddr.value = 0
    dut.DCache_WrReq_Data.value = 0
    dut.DCache_Resp_Done.value = 0
    dut.DCache_Resp_Ready.value = 0
    dut.DCache_Resp_Rddata.value = 0

    # Hold reset for 20 ns, then release at next posedge
    await Timer(20, unit="ns")
    await RisingEdge(dut.clk)
    dut.rst.value = 0

    # Give two full clocks to clear state
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # Ensure idle again
    dut.DCache_RdReq_Valid.value = 0
    dut.DCache_WrReq_Valid.value = 0
    dut.DCache_Resp_Done.value = 0
    dut.DCache_Resp_Ready.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # Drive both read and write together
    dut.DCache_RdReq_Paddr.value = int(0x111111111111)
    dut.DCache_RdReq_DataType.value = 0b001
    dut.DCache_RdReq_Abort.value = 0
    dut.DCache_RdReq_Valid.value = 1
    dut.DCache_WrReq_Paddr.value = int(0x222222222222)
    dut.DCache_WrReq_DataType.value = 0b011
    dut.DCache_WrReq_Data.value = int(0xAAAAAAAA55555555)  # 0xAAAA_AAAA_5555_5555
    dut.DCache_WrReq_Valid.value = 1
    dut.DCache_Resp_Ready.value = 1

    # On the very next clock, last_valid=0 → write wins
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    grant_valid = int(dut.DCache_Req_Valid.value)
    grant_type = int(dut.DCache_Req_Type.value)   # expect 1
    grant_paddr = int(dut.DCache_Req_Paddr.value) # expect 0x222222222222

    dut._log.info(
        f"Grant: Req_Valid={grant_valid}, Req_Type={grant_type} (expect 1 for write), "
        f"Req_Paddr=0x{grant_paddr:012X}"
    )

    # Assertions for simultaneous-RW grant
    assert grant_valid == 1,   f"Expected Req_Valid=1, got {grant_valid}"
    assert grant_type == 1,    f"Expected Req_Type=1 (write), got {grant_type}"
    assert grant_paddr == 0x222222222222, f"Expected Req_Paddr=0x222222222222, got 0x{grant_paddr:012X}"

    # Complete that write
    await RisingEdge(dut.clk)
    dut.DCache_Resp_Done.value = 1     # (Active_Req=1 → clears req_pending[1])
    dut.DCache_WrReq_Valid.value = 0
    dut.DCache_RdReq_Valid.value = 0

    await RisingEdge(dut.clk)
    dut.DCache_Resp_Done.value = 0

    # One more clock to settle
    await RisingEdge(dut.clk)
    dut._log.info("test_simultaneous_rw_after_reset: End")


@cocotb.test()
async def test_abort_read(dut):
    """
    Test 4: Abort a read before it completes
      - Drive a read, wait one clock (so Active_Req→0), then assert RdReq_Abort=1.
      - Confirm that no read‐response ever appears.
    """
    # Start 100 MHz clock (10 ns period)
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    # Apply reset and initialize all inputs
    dut.rst.value = 1
    dut.DCache_RdReq_Valid.value = 0
    dut.DCache_RdReq_Paddr.value = 0
    dut.DCache_RdReq_DataType.value = 0
    dut.DCache_RdReq_Abort.value = 0
    dut.DCache_WrReq_Valid.value = 0
    dut.DCache_WrReq_DataType.value = 0
    dut.DCache_WrReq_Paddr.value = 0
    dut.DCache_WrReq_Data.value = 0
    dut.DCache_Resp_Done.value = 0
    dut.DCache_Resp_Ready.value = 0
    dut.DCache_Resp_Rddata.value = 0

    # Hold reset for 20 ns, then release at next posedge
    await Timer(20, unit="ns")
    await RisingEdge(dut.clk)
    dut.rst.value = 0

    # Give one clock to settle
    await RisingEdge(dut.clk)

    # Drive a read
    dut.DCache_RdReq_Paddr.value = int(0x333333333333)
    dut.DCache_RdReq_DataType.value = 0b010
    dut.DCache_RdReq_Valid.value = 1
    dut.DCache_RdReq_Abort.value = 0
    dut.DCache_WrReq_Valid.value = 0
    dut.DCache_Resp_Ready.value = 1

    # Next clock: arbiter must grant the read
    await RisingEdge(dut.clk)
    accepted_paddr = int(dut.DCache_Req_Paddr.value)
    dut._log.info(f"Read accepted: Req_Paddr=0x{accepted_paddr:012X}")

    # Assertion for read acceptance
    assert accepted_paddr == 0x333333333333, f"Expected Req_Paddr=0x333333333333, got 0x{accepted_paddr:012X}"

    # Wait one clock so that Active_Req→0 inside the DUT
    await RisingEdge(dut.clk)

    # Now assert abort
    dut.DCache_RdReq_Abort.value = 1
    dut.DCache_RdReq_Valid.value = 0

    # One more clock so DUT sees (Active_Req==0 & RdReq_Abort==1) → clears req_pending[0]
    await RisingEdge(dut.clk)
    dut.DCache_RdReq_Abort.value = 0

    # Finally sample: there should be no RdResp_Done
    await RisingEdge(dut.clk)
    rdresp_done = int(dut.DCache_RdResp_Done.value)   # expect 0
    rdresp_ready = int(dut.DCache_RdResp_Ready.value) # expect 1

    dut._log.info(f"After abort: RdResp_Done={rdresp_done}, RdResp_Ready={rdresp_ready}")

    # Assertions for aborted read
    assert rdresp_done == 0,  f"Expected RdResp_Done=0 after abort, got {rdresp_done}"
    assert rdresp_ready == 1, f"Expected RdResp_Ready=1 after abort, got {rdresp_ready}"

