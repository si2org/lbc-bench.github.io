import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer
import logging
import random

class TB:
    def __init__(self, dut):
        """Initialize testbench with clock and logging"""
        self.dut = dut
        self.log = logging.getLogger("cocotb.tb")
        self.log.setLevel(logging.DEBUG)
        cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    async def cycle_reset(self):
        """Reset the DUT with proper synchronization"""
        self.log.info("Applying reset...")
        self.dut.rst.value = 1
        await RisingEdge(self.dut.clk)
        await RisingEdge(self.dut.clk)
        self.dut.rst.value = 0
        await RisingEdge(self.dut.clk)
        await RisingEdge(self.dut.clk)
        self.log.info("Reset complete")

    async def perform_read(self, addr, expected_data, id_val=0, size=2, burst=1):
        """
        Complete read transaction with handshaking
        Args:
            addr: Memory address to read
            expected_data: Data to verify
            id_val: Transaction ID (default 0)
            size: Transfer size (default 2 for 4 bytes)
            burst: Burst type (default 1 for INCR)
        """
        # Setup read command
        self.dut.s_axi_araddr.value = addr
        self.dut.s_axi_arvalid.value = 1
        self.dut.s_axi_arsize.value = size
        self.dut.s_axi_arburst.value = burst
        self.dut.s_axi_rready.value = 1
        
        # Accept command
        self.dut.ram_rd_cmd_ready.value = 1
        
        # Wait for address acceptance
        await RisingEdge(self.dut.clk)
        while self.dut.s_axi_arready.value != 1:
            await RisingEdge(self.dut.clk)
        
        # Complete address phase
        self.dut.s_axi_arvalid.value = 0
        self.dut.ram_rd_cmd_ready.value = 0
        
        # Verify RAM command
        await RisingEdge(self.dut.clk)
        assert self.dut.ram_rd_cmd_en.value == 1
        assert self.dut.ram_rd_cmd_addr.value == addr
        
        # Simulate RAM response
        self.dut.ram_rd_resp_valid.value = 1
        self.dut.ram_rd_resp_data.value = expected_data
        self.dut.ram_rd_resp_last.value = 1
        
        # Wait for read data
        await RisingEdge(self.dut.clk)
        while self.dut.s_axi_rvalid.value != 1:
            await RisingEdge(self.dut.clk)
        
        # Verify received data
        assert self.dut.s_axi_rdata.value == expected_data
        assert self.dut.s_axi_rlast.value == 1
        
        # Cleanup
        self.dut.ram_rd_resp_valid.value = 0
        await RisingEdge(self.dut.clk)
        await RisingEdge(self.dut.clk)

# ====================== TEST CASES ======================

@cocotb.test()
async def test_basic_operations(dut):
    """Test basic read functionality"""
    tb = TB(dut)
    await tb.cycle_reset()
    
    test_cases = [
        (0x0000, 0x12345678, "Basic read"),
        (0x1000, 0xAAAAAAAA, "All bits high"),
        (0x2000, 0x55555555, "Alternating bits"),
        (0x3000, 0x00000000, "All zeros")
    ]
    
    for addr, data, desc in test_cases:
        dut._log.info(f"Testing {desc} at 0x{addr:04x}")
        await tb.perform_read(addr, data)
        dut._log.info(f"Passed {desc}")

@cocotb.test()
async def test_address_boundaries(dut):
    """Verify all address ranges work correctly"""
    tb = TB(dut)
    await tb.cycle_reset()
    
    addr_width = int(dut.ADDR_WIDTH)
    max_addr = (1 << addr_width) - 4  # 32-bit aligned
    
    test_cases = [
        (0x0000, 0x11111111, "Minimum address"),
        (max_addr//4, 0x22222222, "Quarter address"),
        (max_addr//2, 0x33333333, "Mid-range address"), 
        (max_addr, 0x44444444, "Maximum address")
    ]
    
    for addr, data, desc in test_cases:
        dut._log.info(f"Testing {desc} (0x{addr:04x})")
        await tb.perform_read(addr, data)
        dut._log.info(f"Passed {desc}")

@cocotb.test()
async def test_sequential_reads(dut):
    """Test back-to-back read operations"""
    tb = TB(dut)
    await tb.cycle_reset()
    
    base_addr = 0x4000
    for i in range(8):
        addr = base_addr + i*4
        data = 0x10000000 * (i+1)
        dut._log.info(f"Read {i}: 0x{addr:04x}")
        await tb.perform_read(addr, data)
        dut._log.info(f"Completed read {i}")

@cocotb.test()
async def test_randomized_reads(dut):
    """Test with random addresses and data"""
    tb = TB(dut)
    await tb.cycle_reset()
    
    addr_width = int(dut.ADDR_WIDTH)
    max_addr = (1 << addr_width) - 4
    
    for i in range(16):
        addr = random.randint(0, max_addr) & 0xFFFFFFFC  # Align to 4 bytes
        data = random.randint(0, 0xFFFFFFFF)
        dut._log.info(f"Random test {i}: 0x{addr:04x}")
        await tb.perform_read(addr, data)
        dut._log.info(f"Passed random test {i}")

@cocotb.test()
async def test_burst_reads(dut):
    """Test burst read operations"""
    tb = TB(dut)
    await tb.cycle_reset()
    
    base_addr = 0x8000
    burst_length = 4
    
    # Configure burst
    dut.s_axi_arlen.value = burst_length - 1  # AXI uses len-1 encoding
    dut.s_axi_arburst.value = 1  # INCR burst
    
    for beat in range(burst_length):
        addr = base_addr + beat*4
        data = 0xC0000000 | (beat << 16)
        dut._log.info(f"Burst beat {beat}: 0x{addr:04x}")
        await tb.perform_read(addr, data)
        dut._log.info(f"Completed burst beat {beat}")

@cocotb.test()
async def test_protocol_stress(dut):
    """Stress test with random ready signal delays"""
    tb = TB(dut)
    await tb.cycle_reset()
    
    for i in range(8):
        addr = 0xA000 + i*4
        data = 0xDEAD0000 | i
        
        # Randomize ready signals
        dut.ram_rd_cmd_ready.value = random.randint(0, 1)
        dut.s_axi_rready.value = random.randint(0, 1)
        
        await Timer(random.randint(10, 50), unit="ns")
        dut._log.info(f"Stress test {i} with random delays")
        await tb.perform_read(addr, data)
        dut._log.info(f"Completed stress test {i}")

@cocotb.test()
async def test_error_responses(dut):
    """Test error response handling"""
    tb = TB(dut)
    await tb.cycle_reset()
    
    # Test SLVERR response
    dut._log.info("Testing SLVERR response")
    await tb.perform_read(0xF000, 0xBAD0BAD0)
    dut.s_axi_rresp.value = 2  # SLVERR
    await RisingEdge(dut.clk)
    assert dut.s_axi_rresp.value == 2, "Did not get SLVERR response"
    dut._log.info("SLVERR test passed")

@cocotb.test()
async def test_wrap_bursts(dut):
    """Test WRAP burst read operations"""
    tb = TB(dut)
    await tb.cycle_reset()
    
    base_addr = 0x9000
    burst_length = 8  # Must be power of 2 for WRAP bursts
    wrap_boundary = 0x100  # 256-byte boundary for this example
    
    # Configure WRAP burst (burst type = 2)
    dut.s_axi_arlen.value = burst_length - 1
    dut.s_axi_arburst.value = 2  # WRAP burst
    
    for beat in range(burst_length):
        # Calculate WRAP address
        offset = (base_addr + beat*4) % wrap_boundary
        wrapped_addr = (base_addr & ~(wrap_boundary-1)) | offset
        data = 0xE0000000 | (beat << 16)
        
        dut._log.info(f"WRAP burst beat {beat}: 0x{wrapped_addr:04x}")
        await tb.perform_read(wrapped_addr, data, burst=2)
        dut._log.info(f"Completed WRAP beat {beat}")

@cocotb.test()
async def test_fixed_bursts(dut):
    """Test FIXED burst read operations"""
    tb = TB(dut)
    await tb.cycle_reset()
    
    fixed_addr = 0xC000
    burst_length = 4
    
    # Configure FIXED burst (burst type = 0)
    dut.s_axi_arlen.value = burst_length - 1
    dut.s_axi_arburst.value = 0  # FIXED burst
    
    for beat in range(burst_length):
        data = 0xF0000000 | (beat << 16)
        dut._log.info(f"FIXED burst beat {beat}")
        await tb.perform_read(fixed_addr, data, burst=0)  # Same address each time
        dut._log.info(f"Completed FIXED beat {beat}")