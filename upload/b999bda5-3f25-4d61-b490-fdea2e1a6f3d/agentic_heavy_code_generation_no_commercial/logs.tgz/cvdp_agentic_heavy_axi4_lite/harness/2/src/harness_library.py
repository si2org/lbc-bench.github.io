
from cocotb.triggers import FallingEdge, RisingEdge, Timer
import random

async def reset_dut(reset, duration_ns = 10):
     # Restart Interface
    reset.value = 1
    await Timer(duration_ns, unit="ns")
    reset.value = 0
    await Timer(duration_ns, unit='ns')
    reset._log.debug("Reset complete")


async def dut_init(dut):
    # iterate all the input signals and initialize with 0
    for signal in dut:
        try:
            signal.value = 0
        except Exception:
            pass
