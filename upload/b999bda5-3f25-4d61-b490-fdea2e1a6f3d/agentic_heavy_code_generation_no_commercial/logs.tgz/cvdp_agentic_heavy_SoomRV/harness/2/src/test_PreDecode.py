# tests/test_predecode_cornercases.py

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

# Match the Verilog parameter
BUF_SIZE = 4

async def reset_dut(dut):
    """Reset for two cycles, then release."""
    dut.rst.value       = 1
    dut.ifetchValid.value = 0
    dut.outEn.value     = 0
    dut.mispred.value   = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.rst.value = 0
    await RisingEdge(dut.clk)

def make_instr_bundle(valid: bool) -> int:
    """
    Build the 8×54-bit IN_instrs word.
    We only toggle slot[0].valid; all other bits remain zero.
    """
    bundle = 0
    if valid:
        bundle |= 1 << 0
    return bundle

@cocotb.test()
async def test_no_ifetch_never_full(dut):
    """If we never assert ifetchValid, OUT_full should remain 0 forever."""
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset_dut(dut)

    for _ in range(BUF_SIZE * 2):
        dut.ifetchValid.value = 0
        await RisingEdge(dut.clk)
        assert dut.OUT_full.value == 0, f"OUT_full rose without any inputs!"

@cocotb.test()
async def test_out_full_timing(dut):
    """
    Verify OUT_full is asserted exactly on the cycle when freeEntries reaches zero,
    and remains deasserted before that.
    """
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset_dut(dut)

    # Drive valid fetches one by one and sample OUT_full each time
    for cycle in range(BUF_SIZE+1):
        dut.IN_instrs.value = make_instr_bundle(True)
        dut.ifetchValid.value = 1
        await RisingEdge(dut.clk)

        # Only on the last fill should OUT_full == 1
        expected = 1 if cycle > (BUF_SIZE-1) else 0
        actual = int(dut.OUT_full.value)
        assert actual == expected, (
            f"Cycle {cycle}: expected OUT_full={expected}, got {actual}"
        )

    # Cleanup: stop sending fetches
    dut.ifetchValid.value = 0
    await RisingEdge(dut.clk)

@cocotb.test()
async def test_mispred_clears_immediately(dut):
    """
    Complete fill, then assert mispred. Check that on the very next cycle
    OUT_full deasserts, regardless of ifetchValid.
    """
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset_dut(dut)

    # Fill 3 of 4 entries
    for _ in range(BUF_SIZE):
        dut.IN_instrs.value = make_instr_bundle(True)
        dut.ifetchValid.value = 1
        await RisingEdge(dut.clk)

    await RisingEdge(dut.clk)
    assert int(dut.OUT_full.value) == 1, "Should be full"
    dut.ifetchValid.value = 0
    await RisingEdge(dut.clk)

    # Assert mispred while driving ifetchValid=1
    dut.mispred.value = 1
    dut.ifetchValid.value = 1
    await RisingEdge(dut.clk)
    assert dut.OUT_full.value == 0, "mispred must clear OUT_full immediately"

@cocotb.test()
async def test_back_to_back_mispred(dut):
    """
    Assert mispred for multiple cycles in a row; 
    buffers must remain cleared and OUT_full stays 0.
    """
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset_dut(dut)

    # Fill to full
    for _ in range(BUF_SIZE):
        dut.IN_instrs.value = make_instr_bundle(True)
        dut.ifetchValid.value = 1
        await RisingEdge(dut.clk)
    dut.ifetchValid.value = 0
    await RisingEdge(dut.clk)
    assert dut.OUT_full.value == 1

    # Now hold mispred for 3 cycles
    dut.mispred.value = 1
    await RisingEdge(dut.clk)
    for _ in range(3):
        await RisingEdge(dut.clk)
        assert dut.OUT_full.value == 0, "OUT_full must stay 0 during extended mispred"

    # Release mispred, ensure buffer can refill
    dut.mispred.value = 0
    await RisingEdge(dut.clk)
    for _ in range(BUF_SIZE):
        dut.IN_instrs.value = make_instr_bundle(True)
        dut.ifetchValid.value = 1
        await RisingEdge(dut.clk)
    dut.ifetchValid.value = 0
    await RisingEdge(dut.clk)
    assert dut.OUT_full.value == 1, "Should refill after clearing from mispred"

@cocotb.test()
async def test_interleaved_mispred(dut):
    """
    Fill 2 entries, mispred clears, then immediately new fetches
    still work correctly.
    """
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    await reset_dut(dut)

    # Fill two
    for _ in range(2):
        dut.IN_instrs.value = make_instr_bundle(True)
        dut.ifetchValid.value = 1
        await RisingEdge(dut.clk)
    dut.ifetchValid.value = 0
    await RisingEdge(dut.clk)

    # Clear with mispred
    dut.mispred.value = 1
    await RisingEdge(dut.clk)
    assert dut.OUT_full.value == 0

    # Immediately deassert mispred and feed 4 new entries
    dut.mispred.value = 0
    for _ in range(BUF_SIZE):
        dut.IN_instrs.value = make_instr_bundle(True)
        dut.ifetchValid.value = 1
        await RisingEdge(dut.clk)
    dut.ifetchValid.value = 0
    await RisingEdge(dut.clk)
    assert dut.OUT_full.value == 1, "Should reach full after interleaved mispred"
