import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer
import logging
import struct
import random


class TB:
    def __init__(self, dut):
        self.dut = dut
        self.log = logging.getLogger("cocotb.tb.pre_norm")
        self.log.setLevel(logging.DEBUG)
        cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())

    async def initialize(self):
        """Initialize signals if necessary"""
        self.dut.rmode.value = 0
        self.dut.add.value = 0
        self.dut.opa.value = 0
        self.dut.opb.value = 0
        self.dut.opa_nan.value = 0
        self.dut.opb_nan.value = 0
        await RisingEdge(self.dut.clk)

    async def apply_inputs(self, opa, opb, add, rmode, opa_nan, opb_nan):
        self.dut.opa.value = opa
        self.dut.opb.value = opb
        self.dut.add.value = add
        self.dut.rmode.value = rmode
        self.dut.opa_nan.value = opa_nan
        self.dut.opb_nan.value = opb_nan
        await RisingEdge(self.dut.clk)
        await RisingEdge(self.dut.clk)

    def display_outputs(self):
        self.log.info(f"fracta_out = {self.dut.fracta_out.value}")
        self.log.info(f"fractb_out = {self.dut.fractb_out.value}")
        self.log.info(f"exp_dn_out = {self.dut.exp_dn_out.value}")
        self.log.info(f"sign = {self.dut.sign.value}")
        self.log.info(f"nan_sign = {self.dut.nan_sign.value}")
        self.log.info(f"result_zero_sign = {self.dut.result_zero_sign.value}")
        self.log.info(f"fasu_op = {self.dut.fasu_op.value}")
    async def apply_inputs(self, opa, opb, add, rmode=0, opa_nan=0, opb_nan=0):
        self.dut.opa.value = opa
        self.dut.opb.value = opb
        self.dut.add.value = add
        self.dut.rmode.value = rmode
        self.dut.opa_nan.value = opa_nan
        self.dut.opb_nan.value = opb_nan
        await RisingEdge(self.dut.clk)
        await RisingEdge(self.dut.clk)  # Wait for pipeline
        await Timer(1, unit="ns")  # Small delay for signal stabilization

    def log_outputs(self):
        self.log.info(f"fracta_out = 0x{int(self.dut.fracta_out.value):07x}")
        self.log.info(f"fractb_out = 0x{int(self.dut.fractb_out.value):07x}")
        self.log.info(f"exp_dn_out = 0x{int(self.dut.exp_dn_out.value):02x}")
        self.log.info(f"sign = {self.dut.sign.value}")
        self.log.info(f"nan_sign = {self.dut.nan_sign.value}")
        self.log.info(f"result_zero_sign = {self.dut.result_zero_sign.value}")
        self.log.info(f"fasu_op = {self.dut.fasu_op.value}")
        self.log.info("--------------------------------------------------")

def float_to_hex(f):
    """Convert Python float to IEEE 754 hex"""
    return struct.unpack('<I', struct.pack('<f', f))[0]


@cocotb.test()
async def test_basic_cases(dut):
    tb = TB(dut)
    await tb.initialize()

    test_vectors = [
        # (opa, opb, add, rmode, opa_nan, opb_nan, description)
        (float_to_hex(1.0), float_to_hex(2.0), 1, 0, 0, 0, "1.0 + 2.0"),
        (float_to_hex(5.5), float_to_hex(1.25), 0, 0, 0, 0, "5.5 - 1.25"),
        (float_to_hex(-2.0), float_to_hex(-3.0), 1, 0, 0, 0, "-2.0 + -3.0"),
        (0x7FC00000, float_to_hex(1.0), 1, 0, 1, 0, "NaN + 1.0"),
        (float_to_hex(2.0), float_to_hex(2.0), 0, 0, 0, 0, "2.0 - 2.0 (Zero Result)"),
    ]

    for opa, opb, add, rmode, opa_nan, opb_nan, desc in test_vectors:
        dut._log.info(f"\n--- Test: {desc} ---")
        await tb.apply_inputs(opa, opb, add, rmode, opa_nan, opb_nan)
        tb.display_outputs()


@cocotb.test()
async def test_random_cases(dut):
    """Test pre_norm with randomized input values"""
    tb = TB(dut)
    await tb.initialize()

    for i in range(10):
        opa = random.randint(0, 0xFFFFFFFF)
        opb = random.randint(0, 0xFFFFFFFF)
        add = random.randint(0, 1)
        rmode = random.randint(0, 3)
        opa_nan = (opa >> 23) & 0xFF == 0xFF and (opa & 0x7FFFFF) != 0
        opb_nan = (opb >> 23) & 0xFF == 0xFF and (opb & 0x7FFFFF) != 0

        dut._log.info(f"\n--- Random Test {i}: opa={opa:08X}, opb={opb:08X} ---")
        await tb.apply_inputs(opa, opb, add, rmode, opa_nan, opb_nan)
        tb.display_outputs()


@cocotb.test()
async def test_sticky_bit_logic(dut):
    """Test sticky bit logic for various shift cases"""
    tb = TB(dut)
    await tb.initialize()

    # Test all possible shifts and sticky bit scenarios
    for shift in range(28):  # From shift 0 to 27
        opa = 0x400000  # A small fraction (1.0 in normalized form)
        opb = 0x200000  # Another fraction (0.5 in normalized form)
        add = 1  # Test for addition
        rmode = 0  # Round to nearest
        opa_nan = 0
        opb_nan = 0

        dut._log.info(f"\n--- Test Sticky Bit: Shift = {shift} ---")
        await tb.apply_inputs(opa, opb, add, rmode, opa_nan, opb_nan)
        tb.display_outputs()

        # Check if the sticky bit behaves correctly for each shift
        # You can compare expected sticky bits based on your specific model and design expectations.


@cocotb.test()
async def test_zero_result(dut):
    """Test all zero result cases"""
    tb = TB(dut)
    await tb.initialize()

    zero_cases = [
        (0x00000000, 0x00000000, 1, 0, 0, 0, "0 + 0"),
        (0x80000000, 0x00000000, 1, 0, 0, 0, "-0 + 0"),
        (0x00000000, 0x80000000, 1, 0, 0, 0, "0 + -0"),
        (0x80000000, 0x80000000, 1, 0, 0, 0, "-0 + -0"),
        (float_to_hex(2.0), float_to_hex(2.0), 0, 0, 0, 0, "2.0 - 2.0 (Zero Result)"),
    ]

    for opa, opb, add, rmode, opa_nan, opb_nan, desc in zero_cases:
        dut._log.info(f"\n--- Zero Result Test: {desc} ---")
        await tb.apply_inputs(opa, opb, add, rmode, opa_nan, opb_nan)
        tb.display_outputs()


@cocotb.test()
async def test_all_rounding_modes(dut):
    """Test all rounding modes"""
    tb = TB(dut)
    await tb.initialize()

    rounding_cases = [
        (float_to_hex(1.5), float_to_hex(1.5), 1, 0, 0, 0, "1.5 + 1.5", 0),  # Round to nearest
        (float_to_hex(1.5), float_to_hex(1.5), 1, 1, 0, 0, "1.5 + 1.5", 1),  # Round towards zero
        (float_to_hex(1.5), float_to_hex(1.5), 1, 2, 0, 0, "1.5 + 1.5", 2),  # Round towards +∞
        (float_to_hex(1.5), float_to_hex(1.5), 1, 3, 0, 0, "1.5 + 1.5", 3),  # Round towards −∞
    ]

    for opa, opb, add, rmode, opa_nan, opb_nan, desc, rmode in rounding_cases:
        dut._log.info(f"\n--- Rounding Mode Test: {desc} ---")
        await tb.apply_inputs(opa, opb, add, rmode, opa_nan, opb_nan)
        tb.display_outputs()

@cocotb.test()
async def test_denormalized_cases(dut):
    """Test pre_norm with denormalized input values"""
    tb = TB(dut)
    await tb.initialize()

    # Denormalized inputs and zero handling
    denorm_opa = 0x00000001  # Smallest non-zero denormalized float
    denorm_opb = 0x00000002  # Slightly larger denormalized number
    zero = 0x00000000        # Zero input
    inf = 0x7F800000         # Positive infinity input

    test_vectors = [
        (denorm_opa, denorm_opb, 1, 0, 0, 0, "Denormalized Test 1"),
        (zero, denorm_opb, 1, 0, 0, 0, "Zero and Denormalized Test"),
        (inf, denorm_opb, 1, 0, 0, 0, "Infinity and Denormalized Test"),
        (denorm_opa, inf, 1, 0, 0, 0, "Denormalized and Infinity Test")
    ]

    for opa, opb, add, rmode, opa_nan, opb_nan, desc in test_vectors:
        dut._log.info(f"\n--- Test: {desc} ---")
        await tb.apply_inputs(opa, opb, add, rmode, opa_nan, opb_nan)
        tb.display_outputs()
@cocotb.test()
async def test_denormalized_cases(dut):
    """Test pre_norm with denormalized input values"""
    tb = TB(dut)
    await tb.initialize()

    # Denormalized inputs and zero handling
    denorm_opa = 0x00000001  # Smallest non-zero denormalized float
    denorm_opb = 0x00000002  # Slightly larger denormalized number
    zero = 0x00000000        # Zero input
    inf = 0x7F800000         # Positive infinity input
    neg_inf = 0xFF800000     # Negative infinity input

    test_vectors = [
        (denorm_opa, denorm_opb, 1, 0, 0, 0, "Denormalized Test 1"),
        (zero, denorm_opb, 1, 0, 0, 0, "Zero and Denormalized Test"),
        (inf, denorm_opb, 1, 0, 0, 0, "Infinity and Denormalized Test"),
        (denorm_opa, inf, 1, 0, 0, 0, "Denormalized and Infinity Test"),
        (inf, zero, 1, 0, 0, 0, "Infinity and Zero Test"),
        (neg_inf, zero, 0, 0, 0, 0, "Negative Infinity and Zero Test")
    ]

    for opa, opb, add, rmode, opa_nan, opb_nan, desc in test_vectors:
        dut._log.info(f"\n--- Test: {desc} ---")
        await tb.apply_inputs(opa, opb, add, rmode, opa_nan, opb_nan)
        tb.display_outputs()

@cocotb.test()
async def test_rounding_modes(dut):
    """Test pre_norm with different rounding modes"""
    tb = TB(dut)
    await tb.initialize()

    # Test vectors with rounding mode (rmode)
    rmode_cases = [0, 1, 2, 3]  # Round to nearest, round down, etc.
    test_vectors = [
        (0x3F800000, 0x40000000, 1, rmode, 0, 0, f"Round Test {rmode}")
        for rmode in rmode_cases
    ]
    
    for opa, opb, add, rmode, opa_nan, opb_nan, desc in test_vectors:
        dut._log.info(f"\n--- Test: {desc} ---")
        await tb.apply_inputs(opa, opb, add, rmode, opa_nan, opb_nan)
        tb.display_outputs()

@cocotb.test()
async def test_guard_bit_overflow(dut):
    """Test guard-bit overflow detection functionality"""
    tb = TB(dut)
    await tb.initialize()

    # Test cases designed to trigger guard-bit overflow
    test_vectors = [
        # (opa, opb, description)
        # Case 1: Largest normal number + smallest denormal
        (0x7F7FFFFF, 0x00000001, "Max normal + Tiny denormal (overflow expected)"),
        # Case 2: Large exponent difference (28)
        (0xFF8FFFFF, 0x00000003, "Exp diff=28 (overflow expected)"),
        # Case 3: No overflow case (control test)
        (0x40000000, 0x3F800000, "No overflow expected")

        
    ]

    for opa, opb, desc in test_vectors:
        dut._log.info(f"\n--- Guard-bit Overflow Test: {desc} ---")
        
        # Apply inputs (addition operation, no NaNs)
        await tb.apply_inputs(opa, opb, 1, 0, 0, 0)

        await RisingEdge(dut.clk)  
        tb.display_outputs()
        # Calculate expected exponent difference
        expa = (opa >> 23) & 0xFF
        expb = (opb >> 23) & 0xFF
        exp_diff = expa - expb if expa > expb else expb - expa
        
        # Check for overflow condition
        if exp_diff > 27 and (opa & 0x7FFFFF) != 0 and (opb & 0x7FFFFF) != 0:
            # Should assert nan_sign when overflow occurs
            assert dut.nan_sign.value == 1, f"Overflow not detected! {desc}"
            dut._log.info("✓ Overflow correctly detected")


        else:
            # Should not assert nan_sign
            assert dut.nan_sign.value == 0, f"False overflow detected! {desc}"
            dut._log.info("✓ No overflow correctly detected")

@cocotb.test()
async def test_fraction_outputs(dut):
    """Test to verify fraction outputs and related signals"""
    tb = TB(dut)
    await tb.initialize()
    
    # Scenario 1: expa_lt_expb=true (normal A, denormal B)
    await tb.apply_inputs(opa=0x3f800000, opb=0x00000001, add=1)
    assert int(tb.dut.fracta_out.value) == 0x4000000
    assert int(tb.dut.fractb_out.value) == 0x0000001
    assert tb.dut.sign.value == 0
    assert tb.dut.fasu_op.value == 1
    
    # Scenario 2: expa_lt_expb=false (denormal A, normal B)
    await tb.apply_inputs(opa=0x00000001, opb=0x3f800000, add=1)
    assert int(tb.dut.fracta_out.value) == 0x4000000
    assert int(tb.dut.fractb_out.value) == 0x0000001
    assert tb.dut.sign.value == 0
    assert tb.dut.fasu_op.value == 1
    
    # Scenario 3: expa_lt_expb=true (both normal, large exp diff)
    await tb.apply_inputs(opa=0x7f7fffff, opb=0x3f800000, add=1)
    assert int(tb.dut.fracta_out.value) == 0x7fffff8
    assert int(tb.dut.fractb_out.value) == 0x0000001
    assert tb.dut.sign.value == 0
    assert tb.dut.fasu_op.value == 1
    
    # Scenario 4: expa_lt_expb=false (subtraction)
    await tb.apply_inputs(opa=0x3f000000, opb=0x3f800000, add=0)
    assert int(tb.dut.fracta_out.value) == 0x4000000
    assert int(tb.dut.fractb_out.value) == 0x2000000
    assert tb.dut.sign.value == 1
    assert tb.dut.fasu_op.value == 0
    
    # Scenario 5: expa_lt_expb=true (both denormal)
    await tb.apply_inputs(opa=0x00000002, opb=0x00000001, add=1)
    assert int(tb.dut.fracta_out.value) == 0x0000010
    assert int(tb.dut.fractb_out.value) == 0x0000008
    assert tb.dut.sign.value == 0
    assert tb.dut.fasu_op.value == 1
    
    # Scenario 6: Zero handling (different signs)
    await tb.apply_inputs(opa=0x00000000, opb=0x80000000, add=1)
    assert int(tb.dut.fracta_out.value) == 0x0000000
    assert int(tb.dut.fractb_out.value) == 0x0000000
    assert tb.dut.sign.value == 0
    assert tb.dut.fasu_op.value == 0
    
    dut._log.info("\nAll fraction and sign-related outputs match expected values")

        
##end