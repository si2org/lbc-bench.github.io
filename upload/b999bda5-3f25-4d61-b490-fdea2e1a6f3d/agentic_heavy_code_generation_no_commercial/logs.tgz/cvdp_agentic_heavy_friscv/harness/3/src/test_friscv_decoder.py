# test_friscv_decoder.py
import cocotb
from cocotb.triggers import Timer

def set_instr(dut, value):
    dut.instruction.value = value

# Utility to print out key results for each test (optional)
def print_result(dut, name):
    print(f"\nTesting {name}")
    print(f"opcode = 0x{int(dut.opcode.value):02x}, funct3 = 0x{int(dut.funct3.value):01x}, funct7 = 0x{int(dut.funct7.value):02x}, "
          f"rs1 = {int(dut.rs1.value)}, rs2 = {int(dut.rs2.value)}, rd = {int(dut.rd.value)}")
    print(f"lui = {int(dut.lui.value)}, auipc = {int(dut.auipc.value)}, jal = {int(dut.jal.value)}, "
          f"jalr = {int(dut.jalr.value)}, branching = {int(dut.branching.value)}, processing = {int(dut.processing.value)}, dec_error = {int(dut.dec_error.value)}")
    print(f"imm12 = 0x{int(dut.imm12.value):03x}, imm20 = 0x{int(dut.imm20.value):05x}, sys = 0x{int(dut.sys.value):02x}, fence = 0x{int(dut.fence.value):01x}")

@cocotb.test()
async def test_lui(dut):
    set_instr(dut, 0b000000000000_00010_101_011_0110111)
    await Timer(1, unit="ns")
    print_result(dut, "LUI")
    assert int(dut.lui.value) == 1
    assert int(dut.opcode.value) == 0x37
    assert int(dut.imm20.value) == 0x00005

@cocotb.test()
async def test_auipc(dut):
    set_instr(dut, 0b000000000000_00010_010_101_0010111)
    await Timer(1, unit="ns")
    print_result(dut, "AUIPC")
    assert int(dut.auipc.value) == 1
    assert int(dut.opcode.value) == 0x17
    assert int(dut.imm20.value) == 0x00004

@cocotb.test()
async def test_jal(dut):
    set_instr(dut, 0b00000000000000000000_00000_1101111)
    await Timer(1, unit="ns")
    print_result(dut, "JAL")
    assert int(dut.jal.value) == 1
    assert int(dut.opcode.value) == 0x6f

@cocotb.test()
async def test_jalr(dut):
    set_instr(dut, 0b000000000000_00001_000_00000_1100111)
    await Timer(1, unit="ns")
    print_result(dut, "JALR")
    assert int(dut.jalr.value) == 1
    assert int(dut.rs1.value) == 1
    assert int(dut.opcode.value) == 0x67

@cocotb.test()
async def test_beq(dut):
    set_instr(dut, 0b0000000_10101_01011_000_01100_1100011)
    await Timer(1, unit="ns")
    print_result(dut, "BEQ")
    assert int(dut.branching.value) == 1
    assert int(dut.rs1.value) == 11
    assert int(dut.rs2.value) == 21
    assert int(dut.opcode.value) == 0x63

@cocotb.test()
async def test_ecall(dut):
    set_instr(dut, 0b000000000000_00000_000_00000_1110011)
    await Timer(1, unit="ns")
    print_result(dut, "ECALL")
    assert int(dut.sys.value) == 1
    assert int(dut.opcode.value) == 0x73

@cocotb.test()
async def test_fence(dut):
    set_instr(dut, 0b000000000000_00000_000_00000_0001111)
    await Timer(1, unit="ns")
    print_result(dut, "FENCE")
    assert int(dut.fence.value) == 1
    assert int(dut.opcode.value) == 0x0f

@cocotb.test()
async def test_load_lb(dut):
    set_instr(dut, 0b000000000000_00000_000_00101_0000011)
    await Timer(1, unit="ns")
    print_result(dut, "LOAD LB")
    assert int(dut.processing.value) == 1
    assert int(dut.opcode.value) == 0x03

@cocotb.test()
async def test_store_sw(dut):
    set_instr(dut, 0b0000000_01011_00010_010_00000_0100011)
    await Timer(1, unit="ns")
    print_result(dut, "STORE SW")
    assert int(dut.processing.value) == 1
    assert int(dut.rs2.value) == 11
    assert int(dut.opcode.value) == 0x23

@cocotb.test()
async def test_addi(dut):
    set_instr(dut, 0b000000000001_00000_000_00001_0010011)
    await Timer(1, unit="ns")
    print_result(dut, "ADDI")
    assert int(dut.processing.value) == 1
    assert int(dut.imm12.value) == 1
    assert int(dut.rd.value) == 1
    assert int(dut.opcode.value) == 0x13

@cocotb.test()
async def test_add(dut):
    set_instr(dut, 0b0000000_00010_00001_000_00011_0110011)
    await Timer(1, unit="ns")
    print_result(dut, "ADD")
    assert int(dut.processing.value) == 1
    assert int(dut.rs2.value) == 2
    assert int(dut.opcode.value) == 0x33

@cocotb.test()
async def test_invalid(dut):
    set_instr(dut, 0xffffffff)
    await Timer(1, unit="ns")
    print_result(dut, "INVALID")
    assert int(dut.dec_error.value) == 1
    assert int(dut.opcode.value) == 0x7f


