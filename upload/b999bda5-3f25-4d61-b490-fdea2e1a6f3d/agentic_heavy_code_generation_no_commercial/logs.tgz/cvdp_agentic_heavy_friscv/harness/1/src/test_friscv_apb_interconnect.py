import cocotb
from cocotb.triggers import RisingEdge, FallingEdge

# Clock generator
async def clk_gen(dut):
    while True:
        dut.aclk.value = 0
        await cocotb.triggers.Timer(5, unit='ns')
        dut.aclk.value = 1
        await cocotb.triggers.Timer(5, unit='ns')

@cocotb.test()
async def test_asynchronous_reset(dut):
    """Test 1: Asynchronous Reset Test"""
    cocotb.start_soon(clk_gen(dut))
    dut.aresetn.value = 0
    await RisingEdge(dut.aclk)
    dut.aresetn.value = 1
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv_rdata = {int(dut.slv_rdata.value)}")
    val = int(dut.slv_rdata.value)
    assert val == 0, f"Assertion failed: slv_rdata = {val}, expected 0"
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 0, f"Assertion failed: slv_ready = {val}, expected 0"
    dut._log.info(f"mst0_en = {int(dut.mst0_en.value)}")
    val = int(dut.mst0_en.value)
    assert val == 0, f"Assertion failed: mst0_en = {val}, expected 0"
    dut._log.info(f"mst0_wr = {int(dut.mst0_wr.value)}")
    val = int(dut.mst0_wr.value)
    assert val == 0, f"Assertion failed: mst0_wr = {val}, expected 0"
    dut._log.info(f"mst0_addr = {int(dut.mst0_addr.value)}")
    val = int(dut.mst0_addr.value)
    assert val == 0, f"Assertion failed: mst0_addr = {val}, expected 0"
    dut._log.info(f"mst0_wdata = {int(dut.mst0_wdata.value)}")
    val = int(dut.mst0_wdata.value)
    assert val == 0, f"Assertion failed: mst0_wdata = {val}, expected 0"
    dut._log.info(f"mst0_strb = {int(dut.mst0_strb.value)}")
    val = int(dut.mst0_strb.value)
    assert val == 0, f"Assertion failed: mst0_strb = {val}, expected 0"
    dut._log.info(f"mst1_en = {int(dut.mst1_en.value)}")
    val = int(dut.mst1_en.value)
    assert val == 0, f"Assertion failed: mst1_en = {val}, expected 0"
    dut._log.info(f"mst1_wr = {int(dut.mst1_wr.value)}")
    val = int(dut.mst1_wr.value)
    assert val == 0, f"Assertion failed: mst1_wr = {val}, expected 0"
    dut._log.info(f"mst1_addr = {int(dut.mst1_addr.value)}")
    val = int(dut.mst1_addr.value)
    assert val == 0, f"Assertion failed: mst1_addr = {val}, expected 0"
    dut._log.info(f"mst1_wdata = {int(dut.mst1_wdata.value)}")
    val = int(dut.mst1_wdata.value)
    assert val == 0, f"Assertion failed: mst1_wdata = {val}, expected 0"
    dut._log.info(f"mst1_strb = {int(dut.mst1_strb.value)}")
    val = int(dut.mst1_strb.value)
    assert val == 0, f"Assertion failed: mst1_strb = {val}, expected 0"
    dut._log.info(f"mst2_en = {int(dut.mst2_en.value)}")
    val = int(dut.mst2_en.value)
    assert val == 0, f"Assertion failed: mst2_en = {val}, expected 0"
    dut._log.info(f"mst2_wr = {int(dut.mst2_wr.value)}")
    val = int(dut.mst2_wr.value)
    assert val == 0, f"Assertion failed: mst2_wr = {val}, expected 0"
    dut._log.info(f"mst2_addr = {int(dut.mst2_addr.value)}")
    val = int(dut.mst2_addr.value)
    assert val == 0, f"Assertion failed: mst2_addr = {val}, expected 0"
    dut._log.info(f"mst2_wdata = {int(dut.mst2_wdata.value)}")
    val = int(dut.mst2_wdata.value)
    assert val == 0, f"Assertion failed: mst2_wdata = {val}, expected 0"
    dut._log.info(f"mst2_strb = {int(dut.mst2_strb.value)}")
    val = int(dut.mst2_strb.value)
    assert val == 0, f"Assertion failed: mst2_strb = {val}, expected 0"
    await FallingEdge(dut.aclk)

@cocotb.test()
async def test_slv0_ready(dut):
    """Test 2: Slave 0 Write Handshake and Ready Signal Protocol Test"""
    cocotb.start_soon(clk_gen(dut))
    dut.slv_en.value    = 1
    dut.slv_wr.value    = 1
    dut.slv_addr.value  = 0x7
    dut.mst0_ready.value = 0
    dut.slv_wdata.value = 0x87649876
    dut.mst0_rdata.value = 0xAB
    dut.slv_strb.value  = 1

    await RisingEdge(dut.aclk)
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv0_addr = {0}")
    dut._log.info(f"slv_addr = {int(dut.slv_addr.value)}")
    val = int(dut.slv_addr.value)
    assert val == 7, f"Assertion failed: slv_addr = {val}, expected 7"
    dut._log.info(f"mst0_addr = {int(dut.mst0_addr.value):x}")
    val = int(dut.mst0_addr.value)
    assert val == 7, f"Assertion failed: mst0_addr = {val}, expected 7"
    dut._log.info(f"mst0_en = {int(dut.mst0_en.value)}")
    val = int(dut.mst0_en.value)
    assert val == 1, f"Assertion failed: mst0_en = {val}, expected 1"
    dut._log.info(f"mst0_wr = {int(dut.mst0_wr.value)}")
    val = int(dut.mst0_wr.value)
    assert val == 1, f"Assertion failed: mst0_wr = {val}, expected 1"
    dut._log.info(f"mst0_wdata = {int(dut.mst0_wdata.value):x}")
    val = int(dut.mst0_wdata.value)
    assert val == 0x87649876, f"Assertion failed: mst0_wdata = {val}, expected 0x87649876"
    dut._log.info(f"mst0_strb = {int(dut.mst0_strb.value)}")
    val = int(dut.mst0_strb.value)
    assert val == 1, f"Assertion failed: mst0_strb = {val}, expected 1"
    dut._log.info(f"slv_rdata = {int(dut.slv_rdata.value):x}")
    val = int(dut.slv_rdata.value)
    assert val == 0xAB, f"Assertion failed: slv_rdata = {val}, expected 0xAB"
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 0, f"Assertion failed: slv_ready = {val}, expected 0"
    dut.mst0_ready.value = 1
    await RisingEdge(dut.aclk)
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 1, f"Assertion failed: slv_ready = {val}, expected 1"
    dut._log.info(f"mst0_en = {int(dut.mst0_en.value)}")
    val = int(dut.mst0_en.value)
    assert val == 0, f"Assertion failed: mst0_en = {val}, expected 0"
    dut._log.info(f"mst0_wr = {int(dut.mst0_wr.value)}")
    val = int(dut.mst0_wr.value)
    assert val == 0, f"Assertion failed: mst0_wr = {val}, expected 0"
    await FallingEdge(dut.aclk)
    dut.slv_en.value    = 0
    dut.slv_wr.value    = 0
    dut.slv_addr.value  = 0
    dut.mst0_ready.value = 0
    dut.slv_wdata.value = 0
    dut.mst0_rdata.value = 0
    dut.slv_strb.value  = 0
    await RisingEdge(dut.aclk)

@cocotb.test()
async def test_slv1_ready(dut):
    """Test 3: Slave 1 Write Handshake and Ready Signal Protocol Test"""
    cocotb.start_soon(clk_gen(dut))
    dut.slv_en.value    = 1
    dut.slv_wr.value    = 1
    dut.slv_addr.value  = 0xB
    dut.mst1_ready.value = 0
    dut.slv_wdata.value = 0x4532ABCD
    dut.mst1_rdata.value = 0xCD09
    dut.slv_strb.value  = 1

    await RisingEdge(dut.aclk)
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv1_addr = {8}")
    dut._log.info(f"slv_addr = {int(dut.slv_addr.value)}")
    val = int(dut.slv_addr.value)
    assert val == 0xB, f"Assertion failed: slv_addr = {val}, expected 0xB"
    dut._log.info(f"mst1_addr = {int(dut.mst1_addr.value):x}")
    val = int(dut.mst1_addr.value)
    assert val == 3, f"Assertion failed: mst1_addr = {val}, expected 3"
    dut._log.info(f"mst1_en = {int(dut.mst1_en.value)}")
    val = int(dut.mst1_en.value)
    assert val == 1, f"Assertion failed: mst1_en = {val}, expected 1"
    dut._log.info(f"mst1_wr = {int(dut.mst1_wr.value)}")
    val = int(dut.mst1_wr.value)
    assert val == 1, f"Assertion failed: mst1_en = {val}, expected 1"
    dut._log.info(f"mst1_wdata = {int(dut.mst1_wdata.value):x}")
    val = int(dut.mst1_wdata.value)
    assert val == 0x4532ABCD, f"Assertion failed: mst1_wdata = {val}, expected 0x4532ABCD"
    dut._log.info(f"mst1_strb = {int(dut.mst1_strb.value)}")
    val = int(dut.mst1_strb.value)
    assert val == 1, f"Assertion failed: mst1_strb = {val}, expected 1"
    dut._log.info(f"slv_rdata = {int(dut.slv_rdata.value):x}")
    val = int(dut.slv_rdata.value)
    assert val == 0xCD09, f"Assertion failed: slv_rdata = {val}, expected 0xCD09"
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 0, f"Assertion failed: slv_ready = {val}, expected 0"
    dut.mst1_ready.value = 1
    await RisingEdge(dut.aclk)
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 1, f"Assertion failed: slv_ready = {val}, expected 1"
    dut._log.info(f"mst1_en = {int(dut.mst1_en.value)}")
    val = int(dut.mst1_en.value)
    assert val == 0, f"Assertion failed: mst1_en = {val}, expected 0"
    dut._log.info(f"mst1_wr = {int(dut.mst1_wr.value)}")
    val = int(dut.mst1_wr.value)
    assert val == 0, f"Assertion failed: mst1_wr = {val}, expected 0"
    await FallingEdge(dut.aclk)
    dut.slv_en.value    = 0
    dut.slv_wr.value    = 0
    dut.slv_addr.value  = 0
    dut.mst1_ready.value = 0
    dut.slv_wdata.value = 0
    dut.mst1_rdata.value = 0
    dut.slv_strb.value  = 0
    await RisingEdge(dut.aclk)

@cocotb.test()
async def test_slv2_ready(dut):
    """Test 4: Slave 2 Write Handshake and Ready Signal Protocol Test"""
    cocotb.start_soon(clk_gen(dut))
    dut.slv_en.value    = 1
    dut.slv_wr.value    = 1
    dut.slv_addr.value  = 0xC
    dut.mst2_ready.value = 0
    dut.slv_wdata.value = 0x9895EFDC
    dut.mst2_rdata.value = 0x65432100
    dut.slv_strb.value  = 1

    await RisingEdge(dut.aclk)
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv2_addr = {8}")
    dut._log.info(f"slv_addr = {int(dut.slv_addr.value)}")
    val = int(dut.slv_addr.value)
    assert val == 0xC, f"Assertion failed: slv_addr = {val}, expected 0xC" 
    dut._log.info(f"mst2_addr = {int(dut.mst2_addr.value):x}")
    val = int(dut.mst2_addr.value)
    assert val == 4, f"Assertion failed: mst2_addr = {val}, expected 4"
    dut._log.info(f"mst2_en = {int(dut.mst2_en.value)}")
    val = int(dut.mst2_en.value)
    assert val == 1, f"Assertion failed: mst2_en = {val}, expected 1"
    dut._log.info(f"mst2_wr = {int(dut.mst2_wr.value)}")
    val = int(dut.mst2_wr.value)
    assert val == 1, f"Assertion failed: mst2_wr = {val}, expected 1"
    dut._log.info(f"mst2_wdata = {int(dut.mst2_wdata.value):x}")
    val = int(dut.mst2_wdata.value)
    assert val == 0x9895EFDC, f"Assertion failed: mst2_wdata = {val}, expected 0x9895EFDC"
    dut._log.info(f"mst2_strb = {int(dut.mst2_strb.value)}")
    val = int(dut.mst2_strb.value)
    assert val == 1, f"Assertion failed: mst2_strb = {val}, expected 1"
    dut._log.info(f"slv_rdata = {int(dut.slv_rdata.value):x}")
    val = int(dut.slv_rdata.value)
    assert val == 0x65432100, f"Assertion failed: slv_rdata = {val}, expected 0x65432100"
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 0, f"Assertion failed: slv_ready = {val}, expected 0"
    dut.mst2_ready.value = 1
    await RisingEdge(dut.aclk)
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 1, f"Assertion failed: slv_ready = {val}, expected 1"
    dut._log.info(f"mst2_en = {int(dut.mst2_en.value)}")
    val = int(dut.mst2_en.value)
    assert val == 0, f"Assertion failed: mst2_en = {val}, expected 0"
    dut._log.info(f"mst2_wr = {int(dut.mst2_wr.value)}")
    val = int(dut.mst2_wr.value)
    assert val == 0, f"Assertion failed: mst2_wr = {val}, expected 0"
    await FallingEdge(dut.aclk)
    dut.slv_en.value    = 0
    dut.slv_wr.value    = 0
    dut.slv_addr.value  = 0
    dut.mst2_ready.value = 0
    dut.slv_wdata.value = 0
    dut.mst2_rdata.value = 0
    dut.slv_strb.value  = 0
    await RisingEdge(dut.aclk)

@cocotb.test()
async def test_unmapped_address_default_ready(dut):
    """Test 5: Out-of-Range Address Handling Test"""
    cocotb.start_soon(clk_gen(dut))
    dut.slv_en.value    = 1
    dut.slv_wr.value    = 1
    dut.slv_addr.value  = 0x12
    await RisingEdge(dut.aclk)
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 1, f"Assertion failed: slv_ready = {val}, expected 1" 
    await FallingEdge(dut.aclk)
    dut.slv_en.value    = 0
    dut.slv_wr.value    = 0
    dut.slv_addr.value  = 0
    await RisingEdge(dut.aclk)

@cocotb.test()
async def test_idle_state_default_outputs(dut):
    """Test 6: Idle State and Default Output Verification"""
    cocotb.start_soon(clk_gen(dut))
    dut.slv_en.value    = 0
    await RisingEdge(dut.aclk)
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv_rdata = {int(dut.slv_rdata.value)}")
    val = int(dut.slv_rdata.value)
    assert val == 0, f"Assertion failed: slv_rdata = {val}, expected 0"
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 0, f"Assertion failed: slv_ready = {val}, expected 0"
    dut._log.info(f"mst0_en = {int(dut.mst0_en.value)}")
    val = int(dut.mst0_en.value)
    assert val == 0, f"Assertion failed: mst0_en = {val}, expected 0"
    dut._log.info(f"mst0_wr = {int(dut.mst0_wr.value)}")
    val = int(dut.mst0_wr.value)
    assert val == 0, f"Assertion failed: mst0_wr = {val}, expected 0"
    dut._log.info(f"mst0_addr = {int(dut.mst0_addr.value)}")
    val = int(dut.mst0_addr.value)
    assert val == 0, f"Assertion failed: mst0_addr = {val}, expected 0"
    dut._log.info(f"mst0_wdata = {int(dut.mst0_wdata.value)}")
    val = int(dut.mst0_wdata.value)
    assert val == 0, f"Assertion failed: mst0_wdata = {val}, expected 0"
    dut._log.info(f"mst0_strb = {int(dut.mst0_strb.value)}")
    val = int(dut.mst0_strb.value)
    assert val == 0, f"Assertion failed: mst0_strb = {val}, expected 0"
    dut._log.info(f"mst1_en = {int(dut.mst1_en.value)}")
    val = int(dut.mst1_en.value)
    assert val == 0, f"Assertion failed: mst1_en = {val}, expected 0"
    dut._log.info(f"mst1_wr = {int(dut.mst1_wr.value)}")
    val = int(dut.mst1_wr.value)
    assert val == 0, f"Assertion failed: mst1_wr = {val}, expected 0"
    dut._log.info(f"mst1_addr = {int(dut.mst1_addr.value)}")
    val = int(dut.mst1_addr.value)
    assert val == 0, f"Assertion failed: mst1_addr = {val}, expected 0"
    dut._log.info(f"mst1_wdata = {int(dut.mst1_wdata.value)}")
    val = int(dut.mst1_wdata.value)
    assert val == 0, f"Assertion failed: mst1_wdata = {val}, expected 0"
    dut._log.info(f"mst1_strb = {int(dut.mst1_strb.value)}")
    val = int(dut.mst1_strb.value)
    assert val == 0, f"Assertion failed: mst1_strb = {val}, expected 0"
    dut._log.info(f"mst2_en = {int(dut.mst2_en.value)}")
    val = int(dut.mst2_en.value)
    assert val == 0, f"Assertion failed: mst2_en = {val}, expected 0"
    dut._log.info(f"mst2_wr = {int(dut.mst2_wr.value)}")
    val = int(dut.mst2_wr.value)
    assert val == 0, f"Assertion failed: mst2_wr = {val}, expected 0"
    dut._log.info(f"mst2_addr = {int(dut.mst2_addr.value)}")
    val = int(dut.mst2_addr.value)
    assert val == 0, f"Assertion failed: mst2_addr = {val}, expected 0"
    dut._log.info(f"mst2_wdata = {int(dut.mst2_wdata.value)}")
    val = int(dut.mst2_wdata.value)
    assert val == 0, f"Assertion failed: mst2_wdata = {val}, expected 0"
    dut._log.info(f"mst2_strb = {int(dut.mst2_strb.value)}")
    val = int(dut.mst2_strb.value)
    assert val == 0, f"Assertion failed: mst2_strb = {val}, expected 0"
    await FallingEdge(dut.aclk)

@cocotb.test()
async def test_synchronous_reset(dut):
    """Test 7: Synchronous Reset Test"""
    cocotb.start_soon(clk_gen(dut))
    dut.srst.value = 1
    await RisingEdge(dut.aclk)
    dut.srst.value = 0
    await RisingEdge(dut.aclk)
    dut._log.info(f"slv_rdata = {int(dut.slv_rdata.value)}")
    val = int(dut.slv_rdata.value)
    assert val == 0, f"Assertion failed: slv_rdata = {val}, expected 0"
    dut._log.info(f"slv_ready = {int(dut.slv_ready.value)}")
    val = int(dut.slv_ready.value)
    assert val == 0, f"Assertion failed: slv_ready = {val}, expected 0"
    dut._log.info(f"mst0_en = {int(dut.mst0_en.value)}")
    val = int(dut.mst0_en.value)
    assert val == 0, f"Assertion failed: mst0_en = {val}, expected 0"
    dut._log.info(f"mst0_wr = {int(dut.mst0_wr.value)}")
    val = int(dut.mst0_wr.value)
    assert val == 0, f"Assertion failed: mst0_wr = {val}, expected 0"
    dut._log.info(f"mst0_addr = {int(dut.mst0_addr.value)}")
    val = int(dut.mst0_addr.value)
    assert val == 0, f"Assertion failed: mst0_addr = {val}, expected 0"
    dut._log.info(f"mst0_wdata = {int(dut.mst0_wdata.value)}")
    val = int(dut.mst0_wdata.value)
    assert val == 0, f"Assertion failed: mst0_wdata = {val}, expected 0"
    dut._log.info(f"mst0_strb = {int(dut.mst0_strb.value)}")
    val = int(dut.mst0_strb.value)
    assert val == 0, f"Assertion failed: mst0_strb = {val}, expected 0"
    dut._log.info(f"mst1_en = {int(dut.mst1_en.value)}")
    val = int(dut.mst1_en.value)
    assert val == 0, f"Assertion failed: mst1_en = {val}, expected 0"
    dut._log.info(f"mst1_wr = {int(dut.mst1_wr.value)}")
    val = int(dut.mst1_wr.value)
    assert val == 0, f"Assertion failed: mst1_wr = {val}, expected 0"
    dut._log.info(f"mst1_addr = {int(dut.mst1_addr.value)}")
    val = int(dut.mst1_addr.value)
    assert val == 0, f"Assertion failed: mst1_addr = {val}, expected 0"
    dut._log.info(f"mst1_wdata = {int(dut.mst1_wdata.value)}")
    val = int(dut.mst1_wdata.value)
    assert val == 0, f"Assertion failed: mst1_wdata = {val}, expected 0"
    dut._log.info(f"mst1_strb = {int(dut.mst1_strb.value)}")
    val = int(dut.mst1_strb.value)
    assert val == 0, f"Assertion failed: mst1_strb = {val}, expected 0"
    dut._log.info(f"mst2_en = {int(dut.mst2_en.value)}")
    val = int(dut.mst2_en.value)
    assert val == 0, f"Assertion failed: mst2_en = {val}, expected 0"
    dut._log.info(f"mst2_wr = {int(dut.mst2_wr.value)}")
    val = int(dut.mst2_wr.value)
    assert val == 0, f"Assertion failed: mst2_wr = {val}, expected 0"
    dut._log.info(f"mst2_addr = {int(dut.mst2_addr.value)}")
    val = int(dut.mst2_addr.value)
    assert val == 0, f"Assertion failed: mst2_addr = {val}, expected 0"
    dut._log.info(f"mst2_wdata = {int(dut.mst2_wdata.value)}")
    val = int(dut.mst2_wdata.value)
    assert val == 0, f"Assertion failed: mst2_wdata = {val}, expected 0"
    dut._log.info(f"mst2_strb = {int(dut.mst2_strb.value)}")
    val = int(dut.mst2_strb.value)
    assert val == 0, f"Assertion failed: mst2_strb = {val}, expected 0"
    await FallingEdge(dut.aclk)

