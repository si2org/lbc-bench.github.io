import cocotb
from cocotb.triggers import RisingEdge, Timer
import random

CLK_PERIOD = 10  # ns


async def clk_gen(dut):
    """Simple clock generator."""
    while True:
        dut.aclk.value = 0
        await Timer(CLK_PERIOD // 2, unit="ns")
        dut.aclk.value = 1
        await Timer(CLK_PERIOD // 2, unit="ns")


async def reset_dut(dut):
    """Apply reset and bring out of reset."""
    dut.aresetn.value = 0
    dut.srst.value = 0
    dut.flush.value = 0
    dut.push.value = 0
    dut.pull.value = 0
    await Timer(2 * CLK_PERIOD, unit="ns")
    dut.aresetn.value = 1
    await Timer(CLK_PERIOD, unit="ns")


@cocotb.test()
async def test_reset(dut):
    """Test 1: Check reset and initial state."""
    cocotb.start_soon(clk_gen(dut))
    await reset_dut(dut)
    await Timer(CLK_PERIOD, unit="ns")
    assert int(dut.empty.value) == 1, "FIFO should be empty after reset"
    assert int(dut.full.value) == 0, "FIFO should not be full after reset"


@cocotb.test()
async def test_simple_push_pop(dut):
    """Test 2: Simple push and pop."""
    cocotb.start_soon(clk_gen(dut))
    await reset_dut(dut)

    test_val = 0x5A
    dut.data_in.value = test_val
    dut.push.value = 1
    await RisingEdge(dut.aclk)
    dut.push.value = 0
    await Timer(CLK_PERIOD, unit="ns")

    # data_out should now be valid BEFORE the pull (since FIFO is not empty)
    out_val = int(dut.data_out.value)
    assert out_val == test_val, f"Output before pop ({out_val}) did not match input ({test_val})"

    # Now pop
    dut.pull.value = 1
    await RisingEdge(dut.aclk)
    dut.pull.value = 0
    await Timer(CLK_PERIOD, unit="ns")

    # FIFO should now be empty
    assert int(dut.empty.value) == 1, "FIFO should be empty after pop"




@cocotb.test()
async def test_fifo_overflow(dut):
    """Test 3: Overflow protection."""
    cocotb.start_soon(clk_gen(dut))
    await reset_dut(dut)
    depth = 2**int(dut.ADDR_WIDTH.value)
    last_val = 0

    # Fill the FIFO
    for i in range(depth):
        dut.data_in.value = i
        dut.push.value = 1
        await RisingEdge(dut.aclk)
        dut.push.value = 0
        await Timer(CLK_PERIOD // 2, unit="ns")
        last_val = i

    # FIFO must be full now
    assert int(dut.full.value) == 1, "FIFO should be full after max pushes"

    # Try to push once more
    dut.data_in.value = 0xAA
    dut.push.value = 1
    await RisingEdge(dut.aclk)
    dut.push.value = 0
    await Timer(CLK_PERIOD // 2, unit="ns")

    assert int(dut.full.value) == 1, "FIFO should remain full"
    # Data should not change (FIFO doesn't take the push)


@cocotb.test()
async def test_fifo_underflow(dut):
    """Test 4: Underflow protection."""
    cocotb.start_soon(clk_gen(dut))
    await reset_dut(dut)

    # Try to pop when empty
    dut.pull.value = 1
    await RisingEdge(dut.aclk)
    await Timer(CLK_PERIOD // 2, unit="ns")
    dut.pull.value = 0

    assert int(dut.empty.value) == 1, "FIFO should remain empty"
    # data_out should be stable (could be x, 0 or undefined, but no crash)


@cocotb.test()
async def test_flush_and_pass_thru(dut):
    """Test 5: Flush and PASS_THRU (if enabled)."""
    cocotb.start_soon(clk_gen(dut))
    await reset_dut(dut)

    # Push in data, but then flush before pop
    test_val1 = 0x1C
    dut.data_in.value = test_val1
    dut.push.value = 1
    await RisingEdge(dut.aclk)
    dut.push.value = 0
    await Timer(CLK_PERIOD, unit="ns")

    dut.flush.value = 1
    await RisingEdge(dut.aclk)
    dut.flush.value = 0
    await Timer(CLK_PERIOD // 2, unit="ns")

    assert int(dut.empty.value) == 1, "FIFO should be empty after flush"

    # Test PASS_THRU: pull while empty and provide data, expect data_out to mirror data_in
    if hasattr(dut, "PASS_THRU") and int(dut.PASS_THRU.value) == 1:
        val2 = 0xA5
        dut.data_in.value = val2
        dut.pull.value = 1
        await RisingEdge(dut.aclk)
        await Timer(CLK_PERIOD // 2, unit="ns")
        out_val = int(dut.data_out.value)
        dut.pull.value = 0
        assert out_val == val2, "PASS_THRU failed to pass input directly to output"


