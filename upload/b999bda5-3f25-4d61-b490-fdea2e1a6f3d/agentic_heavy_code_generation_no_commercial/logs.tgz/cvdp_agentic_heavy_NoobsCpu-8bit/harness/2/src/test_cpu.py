#  test_cpu.py  ----------------------------------------------------------------
#  Cocotb test that replicates the original Verilog TB
# ---------------------------------------------------------------------------
import cocotb
from cocotb.clock    import Clock
from cocotb.triggers import RisingEdge, ReadOnly
from pathlib         import Path

# ---------- golden config ----------------------------------------------------
REG0_FINAL_EXP = 0x00
REG1_FINAL_EXP = 0x00
REG2_FINAL_EXP = 0x00
REG3_FINAL_EXP = 0x00
MEM010_EXP     = 0x00

IMEM_DEPTH     = 4096
DMEM_DEPTH     = 4096
MAX_MEM_LIMIT  = 2048
CLK_HALF_NS    = 50            # 20 MHz
# -----------------------------------------------------------------------------

def load_hex(fname):
    data = []
    for ln in Path(fname).read_text().splitlines():
        ln = ln.split("#", 1)[0].strip()
        if ln:
            data.append(int(ln, 16))
    return data


@cocotb.test()
async def cpu_smoke_test(dut):
    # 1. clock
    cocotb.start_soon(Clock(dut.clk, CLK_HALF_NS, unit="ns", period_high=(CLK_HALF_NS+1)//2 if CLK_HALF_NS%2 else CLK_HALF_NS//2).start())
    dut._log.info("Clock started")

    # 2. load program/data
    imem = load_hex("/src/code.txt") + [0] * (IMEM_DEPTH - len(load_hex("/src/code.txt")))
    dmem = load_hex("/src/data.txt") + [0] * (DMEM_DEPTH - len(load_hex("/src/data.txt")))
    dut._log.info("Loaded %d IMEM bytes, %d DMEM bytes", len(imem), len(dmem))

    # drive default bus values
    dut.i_data.setimmediatevalue(0)
    dut.m_rd_data.setimmediatevalue(0)

    # 3. memory models --------------------------------------------------
    async def imem_driver():
        """Pure combinational ROM: i_data follows i_addr each clock."""
        while True:
            await RisingEdge(dut.clk)                 # wait for edge
            # convert address only if it is fully resolved (no X/Z)
            a_val = dut.i_addr.value
            addr  = int(a_val) if a_val.is_resolvable else 0
            dut.i_data.value = imem[addr]

    async def dmem_driver():
        """Single-cycle RAM on m_* bus (writes & reads on clock edge)."""
        while True:
            await RisingEdge(dut.clk)        # write phase

            m_en_val = dut.m_en.value
            if not (m_en_val.is_resolvable and int(m_en_val)):
                continue

            # safe address conversion (treat X/Z as 0)
            a_val = dut.m_addr.value
            addr  = int(a_val) if a_val.is_resolvable else 0

            # write first, then read (same-cycle read-after-write matches old TB)
            if dut.m_wr.value:
                w_val = dut.m_wr_data.value
                data  = int(w_val) if w_val.is_resolvable else 0
                dmem[addr] = data & 0xFF

            if dut.m_rd.value:
                dut.m_rd_data.value = dmem[addr]

    cocotb.start_soon(imem_driver())
    cocotb.start_soon(dmem_driver())

    # 4. generate reset_
    dut.reset_.value = 0
    for _ in range(4):
        await RisingEdge(dut.clk)
    dut.reset_.value = 1
    await RisingEdge(dut.clk)     # settle
    dut._log.info("reset_ de-asserted")

    # helper
    def check(tag, obj, exp):
        """Compare either a signal *or* plain int against the expected value."""
        got = int(obj.value) if hasattr(obj, "value") else int(obj)
        assert got == exp, f"{tag}: got 0x{got:02x}, exp 0x{exp:02x}"
        dut._log.info("[PASS] %s (0x%02x)", tag, exp)

    # 5. post-reset sanity
    check("REG0 reset", dut.u_reg_file.reg0, 0)
    check("REG1 reset", dut.u_reg_file.reg1, 0)
    check("REG2 reset", dut.u_reg_file.reg2, 0)
    check("REG3 reset", dut.u_reg_file.reg3, 0)
    check("SR  reset",  dut.u_execute.sr,    0)
    check("PC  reset",  dut.u_ifetch.PC,     0)

    # 6. wait for HALT
    dut._log.info("Waiting for HALT …")
    while dut.u_idecode.halted.value == 0:
        await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)

    # 7. golden registers
    check("REG0 final", dut.u_reg_file.reg0, REG0_FINAL_EXP)
    check("REG1 final", dut.u_reg_file.reg1, REG1_FINAL_EXP)
    check("REG2 final", dut.u_reg_file.reg2, REG2_FINAL_EXP)
    check("REG3 final", dut.u_reg_file.reg3, REG3_FINAL_EXP)

    # 8. DMEM[0x010]
    check("MEM[0x010]", dmem[0x010], MEM010_EXP)

    # 9. dump DMEM
    with open("data_out.txt", "w") as fh:
        for a in range(8, MAX_MEM_LIMIT + 1):
            fh.write(f"{dmem[a]:02x}\n")
    dut._log.info("DMEM dumped to data_out.txt")

    dut._log.info("All checks passed.")
