# test_cr_cp0_lpmd.py
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import Timer, RisingEdge

async def _start_clocks(dut):
    """Spawn all three clocks in the background."""
    cocotb.start_soon(Clock(dut.forever_cpuclk, 10, unit="ns").start())
    cocotb.start_soon(Clock(dut.lpmd_sm_clk,      14, unit="ns").start())
    cocotb.start_soon(Clock(dut.shut_seq_clk,      6, unit="ns").start())
    # allow clocks to spin up
    await Timer(1, unit="ns")

def _init_dut(dut):
    """Common reset and initial signal values."""
    dut.cpurst_b.value                    = 0
    dut.status_lpmd_lpmd.value            = 0b11
    dut.sysio_cp0_sys_view_lpmd_b.value   = 0b11
    dut.cache_cp0_lpmd_ack.value          = 0
    dut.ifu_cp0_lpmd_ack.value            = 0
    dut.inst_lpmd.value                   = 0
    dut.iu_cp0_ex_sel.value               = 0
    dut.iu_cp0_lp_wk_int.value            = 0
    dut.iu_yy_xx_dbgon.value              = 0
    dut.iu_yy_xx_flush.value              = 0
    dut.iui_lpmd_inst_lpmd_for_data.value = 0
    dut.pad_yy_gate_clk_en_b.value        = 1
    dut.shut_seq_rst_b.value              = 0
    dut.shut_seq_reset_ack.value          = 0

@cocotb.test()
async def tc_reset(dut):
    """TC_RESET: apply reset and observe idle outputs."""
    await _start_clocks(dut)
    _init_dut(dut)
    await Timer(20, unit="ns")
    dut.cpurst_b.value       = 1
    dut.shut_seq_rst_b.value = 1
    await Timer(20, unit="ns")
    # sample after reset — cp0_yy_clk_en comes up high, lpmd_sm_clk_en stays low
    assert int(dut.cp0_yy_clk_en.value) == 1, \
        f"cp0_yy_clk_en expected 1, got {int(dut.cp0_yy_clk_en.value)}"
    assert int(dut.lpmd_sm_clk_en.value) == 0, \
        f"lpmd_sm_clk_en expected 0, got {int(dut.lpmd_sm_clk_en.value)}"


@cocotb.test()
async def tc_lpmd_handshake(dut):
    """TC_LPMD_HS: handshake sequence for LPMD instruction."""
    await _start_clocks(dut)
    _init_dut(dut)
    dut.cpurst_b.value       = 1
    dut.shut_seq_rst_b.value = 1
    await Timer(20, unit="ns")

    # 1) issue LP instruction → WFACK
    dut.inst_lpmd.value = 1
    await Timer(10, unit="ns")
    dut.inst_lpmd.value = 0
    await Timer(10, unit="ns")
    assert int(dut.cp0_ifu_lpmd_req.value) == 1, \
        f"CP0 IFU LPMD REQ expected 1, got {int(dut.cp0_ifu_lpmd_req.value)}"
    assert int(dut.lpmd_iui_stall.value) == 1, \
        f"LPMD IUI STALL expected 1, got {int(dut.lpmd_iui_stall.value)}"

    # 2) provide both ACKs → WFCPLT, the cache request should now de-assert
    dut.cache_cp0_lpmd_ack.value = 1
    dut.ifu_cp0_lpmd_ack.value   = 1
    await Timer(10, unit="ns")
    assert int(dut.cp0_cache_lpmd_req.value) == 0, \
        f"CP0 CACHE LPMD REQ expected 0 after ACKs, got {int(dut.cp0_cache_lpmd_req.value)}"

    # 3) drop ACKs, stall remains
    dut.cache_cp0_lpmd_ack.value = 0
    dut.ifu_cp0_lpmd_ack.value   = 0
    await Timer(5, unit="ns")
    assert int(dut.lpmd_iui_stall.value) == 1, \
        f"LPMD IUI STALL expected 1 after dropping ACKs, got {int(dut.lpmd_iui_stall.value)}"


@cocotb.test()
async def tc_debug_flush(dut):
    """TC_FLUSH: flush while LPMD inst is pending."""
    await _start_clocks(dut)
    _init_dut(dut)
    dut.cpurst_b.value       = 1
    dut.shut_seq_rst_b.value = 1
    await Timer(20, unit="ns")

    dut.inst_lpmd.value    = 1
    await Timer(5, unit="ns")
    dut.iu_yy_xx_flush.value = 1
    await Timer(5, unit="ns")
    dut.iu_yy_xx_flush.value = 0
    await Timer(5, unit="ns")
    # flush should cancel request
    assert int(dut.cp0_ifu_lpmd_req.value) == 0

@cocotb.test()
async def tc_shutdown_sequence(dut):
    """TC_SHUT_SEQ: shutdown FSM request/done handshake."""
    # 1) Bring everything out of reset and start clocks
    await _start_clocks(dut)
    _init_dut(dut)
    dut.cpurst_b.value       = 1
    dut.shut_seq_rst_b.value = 1
    await Timer(20, unit="ns")

    # 2) Trigger entry to LP via interrupt + mode bits
    dut.iu_cp0_lp_wk_int.value          = 1
    dut.status_lpmd_lpmd.value          = 0b00
    dut.sysio_cp0_sys_view_lpmd_b.value = 0b00
    await Timer(10, unit="ns")
    assert int(dut.shut_seq_reset_req.value) == 1, \
        f"reset_req expected 1 on trigger, got {int(dut.shut_seq_reset_req.value)}"
    assert int(dut.shut_seq_done.value) == 0, \
        f"done expected 0 before ACK, got {int(dut.shut_seq_done.value)}"

    # 3) Still no ACK → reset_req stays high
    dut.shut_seq_reset_ack.value = 0
    await Timer(10, unit="ns")
    assert int(dut.shut_seq_reset_req.value) == 1, \
        f"reset_req expected 1 with no ACK, got {int(dut.shut_seq_reset_req.value)}"

    # 4) Provide ACK → wait 10 ns (≈3 FSM cycles), then done must be high
    dut.shut_seq_reset_ack.value = 1
    await Timer(10, unit="ns")
    assert int(dut.shut_seq_done.value) == 1, \
        f"done expected 1 after ACK+10ns, got {int(dut.shut_seq_done.value)}"

    # 5) Exit LP → drive mode bits back
    dut.iu_cp0_lp_wk_int.value          = 0
    dut.status_lpmd_lpmd.value          = 0b11
    dut.sysio_cp0_sys_view_lpmd_b.value = 0b11

    #    wait three FSM clocks for the 'done' to deassert
    await RisingEdge(dut.shut_seq_clk)
    await RisingEdge(dut.shut_seq_clk)
    await RisingEdge(dut.shut_seq_clk)
    assert int(dut.shut_seq_done.value) == 0, \
        f"done expected 0 after exit LP, got {int(dut.shut_seq_done.value)}"



@cocotb.test()
async def tc_lpmd_complete(dut):
    """TC_LPMD_CPLT: drive exit by mode bits after handshake."""
    await _start_clocks(dut)
    _init_dut(dut)
    dut.cpurst_b.value       = 1
    dut.shut_seq_rst_b.value = 1
    await Timer(20, unit="ns")

    # 1) handshake into WFCPLT
    dut.inst_lpmd.value = 1;  await Timer(10, unit="ns"); dut.inst_lpmd.value = 0
    await Timer(10, unit="ns")
    dut.cache_cp0_lpmd_ack.value = 1; dut.ifu_cp0_lpmd_ack.value = 1
    await Timer(10, unit="ns")
    dut.cache_cp0_lpmd_ack.value = 0; dut.ifu_cp0_lpmd_ack.value = 0
    await Timer(5, unit="ns")

    # 2) force exit
    dut.status_lpmd_lpmd.value        = 0b11
    dut.sysio_cp0_sys_view_lpmd_b.value = 0b11
    await Timer(1, unit="ns")
    # check we have exited
    assert int(dut.cp0_ifu_in_lpmd.value) == 0
    assert int(dut.cp0_had_lpmd_b.value)  == 0b11

@cocotb.test()
async def tc_debug_entry(dut):
    """TC_DBG_ENTRY: gated-clock debug path exercise."""
    await _start_clocks(dut)
    _init_dut(dut)
    dut.cpurst_b.value       = 1
    dut.shut_seq_rst_b.value = 1
    await Timer(20, unit="ns")

    # Assert debug request
    dut.had_yy_xx_dbg.value  = 1
    dut.iu_yy_xx_dbgon.value = 1
    await Timer(10, unit="ns")

    # cp0 clock should enable, LPMD-SM clock stays disabled
    assert int(dut.cp0_yy_clk_en.value) == 1, \
        f"cp0_yy_clk_en expected 1 in debug, got {int(dut.cp0_yy_clk_en.value)}"
    assert int(dut.lpmd_sm_clk_en.value) == 0, \
        f"lpmd_sm_clk_en expected 0 in debug, got {int(dut.lpmd_sm_clk_en.value)}"

    # return to normal
    dut.had_yy_xx_dbg.value  = 0
    dut.iu_yy_xx_dbgon.value = 0
    await Timer(5, unit="ns")


@cocotb.test()
async def tc_flush_during_wfack(dut):
    """TC_FLUSH_WFACK: flush during WFACK goes back to idle."""
    await _start_clocks(dut)
    _init_dut(dut)
    dut.cpurst_b.value       = 1
    dut.shut_seq_rst_b.value = 1
    await Timer(20, unit="ns")

    dut.inst_lpmd.value = 1
    await Timer(5, unit="ns")
    dut.inst_lpmd.value = 0
    dut.cache_cp0_lpmd_ack.value = 0
    dut.ifu_cp0_lpmd_ack.value   = 0
    await Timer(3, unit="ns")
    dut.iu_yy_xx_flush.value = 1
    await Timer(2, unit="ns")
    dut.iu_yy_xx_flush.value = 0
    await Timer(1, unit="ns")
    assert int(dut.cp0_ifu_lpmd_req.value) == 0

@cocotb.test()
async def tc_data_stall(dut):
    """TC_DATA_STALL: data-path stall in IDLE."""
    await _start_clocks(dut)
    _init_dut(dut)
    dut.cpurst_b.value       = 1
    dut.shut_seq_rst_b.value = 1
    await Timer(20, unit="ns")

    dut.iui_lpmd_inst_lpmd_for_data.value = 1
    await Timer(10, unit="ns")
    assert int(dut.lpmd_iui_stall.value) == 1
    dut.iui_lpmd_inst_lpmd_for_data.value = 0
    await Timer(5, unit="ns")
    assert int(dut.lpmd_iui_stall.value) == 0

