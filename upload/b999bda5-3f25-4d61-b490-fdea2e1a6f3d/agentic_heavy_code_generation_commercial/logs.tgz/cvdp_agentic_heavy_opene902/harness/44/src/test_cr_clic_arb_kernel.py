import cocotb
from cocotb.triggers import Timer

PRIO_WIDTH = 6
INT_NUM = 32

# Helper to build the wide priority vector
def build_vec(assignments):
    """
    assignments: list of (index, priority) tuples
    Returns an integer representing the packed prio_in_vec.
    """
    vec = 0
    for idx, pr in assignments:
        vec |= (pr & ((1 << PRIO_WIDTH) - 1)) << (PRIO_WIDTH * idx)
    return vec

# Generic checker
async def apply_test(dut, vec_int, expected_idx):
    # Drive input
    dut.prio_in_vec.value = vec_int
    # allow combinational logic to settle
    await Timer(1, unit='ns')
    # Read output one-hot as integer
    sel = int(dut.sel_out_onehot.value)
    expected = 1 << expected_idx
    assert sel == expected, f"Output mismatch: expected one-hot {expected:#010x}, got {sel:#010x}"

# Test cases
@cocotb.test()
async def default_zero_priorities_resolve_highest(dut):
    "[Test Case 1] Default zero priorities resolve to highest interrupt index"
    vec = build_vec([])
    await apply_test(dut, vec, 31)

@cocotb.test()
async def single_interrupt_priority_selection(dut):
    "[Test Case 2] Single interrupt priority selection"
    vec = build_vec([(5, 10)])
    await apply_test(dut, vec, 5)

@cocotb.test()
async def select_highest_among_two_distinct(dut):
    "[Test Case 3] Select highest among two distinct priorities"
    vec = build_vec([(3, 20), (7, 15)])
    await apply_test(dut, vec, 3)

@cocotb.test()
async def tie_break_selects_higher_index(dut):
    "[Test Case 4] Tie-break selecting higher indexed interrupt"
    vec = build_vec([(4, 30), (9, 30)])
    await apply_test(dut, vec, 9)

@cocotb.test()
async def maximum_priority_at_last_index(dut):
    "[Test Case 5] Maximum priority at last index"
    vec = build_vec([(31, 63)])
    await apply_test(dut, vec, 31)

@cocotb.test()
async def multiple_max_priorities_select_last(dut):
    "[Test Case 6] Multiple maximum priorities select last available index"
    vec = build_vec([(0, 63), (16, 63), (31, 63)])
    await apply_test(dut, vec, 31)

@cocotb.test()
async def priority_spread_selection(dut):
    "[Test Case 7] Priority spread selection among multiple interrupts"
    vec = build_vec([(2,12), (10,25), (20,18), (30,24)])
    await apply_test(dut, vec, 10)

@cocotb.test()
async def tie_lower_half_selects_upper(dut):
    "[Test Case 8] Tie in lower half selects higher indexed interrupt"
    vec = build_vec([(8,5), (15,12), (23,12)])
    await apply_test(dut, vec, 23)

@cocotb.test()
async def tie_upper_half_selects_upper(dut):
    "[Test Case 9] Tie in upper half selects higher indexed interrupt"
    vec = build_vec([(17,7), (28,7), (31,2)])
    await apply_test(dut, vec, 28)

@cocotb.test()
async def sparse_high_priority_selection(dut):
    "[Test Case 10] Sparse high priority selection across vectors"
    vec = build_vec([(1,3), (4,3), (6,9), (11,9), (25,9)])
    await apply_test(dut, vec, 25)

@cocotb.test()
async def continuous_block_tie_selects_end(dut):
    "[Test Case 11] Continuous block priority tie selects block end"
    assignments = [(i,40) for i in range(5,11)]
    vec = build_vec(assignments)
    await apply_test(dut, vec, 10)

@cocotb.test()
async def disjoint_range_tie_selects_upper(dut):
    "[Test Case 12] Disjoint range tie selects upper range"
    assignments = list((i,30) for i in range(0,4)) + list((i,30) for i in range(28,32))
    vec = build_vec(assignments)
    await apply_test(dut, vec, 31)

@cocotb.test()
async def alternating_priorities_select_even(dut):
    "[Test Case 13] Alternating priorities select highest-even index"
    assignments = [(i,20 if (i%2==0) else 10) for i in range(INT_NUM)]
    vec = build_vec(assignments)
    await apply_test(dut, vec, 30)

@cocotb.test()
async def sequential_index_priorities(dut):
    "[Test Case 14] Sequential index-based priorities select maximum index"
    assignments = [(i,i) for i in range(INT_NUM)]
    vec = build_vec(assignments)
    await apply_test(dut, vec, 31)

@cocotb.test()
async def low_and_mid_priorities_select_mid(dut):
    "[Test Case 15] Low and mid priorities select mid-level index"
    vec = build_vec([(0,1), (16,5)])
    await apply_test(dut, vec, 16)

@cocotb.test()
async def uniform_low_priorities(dut):
    "[Test Case 16] Uniform low priorities across all interrupts"
    vec = build_vec([(i,1) for i in range(INT_NUM)])
    await apply_test(dut, vec, 31)

@cocotb.test()
async def mid_range_tie_break(dut):
    "[Test Case 17] Mid-range tie-break selects upper index"
    vec = build_vec([(14,50), (15,50)])
    await apply_test(dut, vec, 15)

@cocotb.test()
async def single_low_index_selection(dut):
    "[Test Case 18] Single low-index interrupt priority"
    vec = build_vec([(0,10)])
    await apply_test(dut, vec, 0)

