
report -metrics overall -out coverage.log
