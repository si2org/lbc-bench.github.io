# File: tests/test_cr_ahbl_if.py
import cocotb
from cocotb.triggers import Timer
from cocotb.clock   import Clock


async def cycle_clock(dut, cycles=1, period_ns=10):
    """Toggle ahbl_gated_clk 'cycles' times with half-period of period_ns//2."""
    for _ in range(cycles):
        dut.ahbl_gated_clk.value = 0
        await Timer(period_ns//2, unit="ns")
        dut.ahbl_gated_clk.value = 1
        await Timer(period_ns//2, unit="ns")


async def reset_dut(dut):
    """Assert active-low reset for 1 clock, then release and run 2 clocks."""
    dut.cpurst_b.value = 0
    await cycle_clock(dut, 1)
    dut.cpurst_b.value = 1
    await cycle_clock(dut, 2)


def init_signals(dut):
    """Drive all inputs to their inactive defaults."""
    # CPU side
    dut.cpu_req.value               = 0
    dut.cpu_req_power_masked.value  = 0
    dut.cpu_write.value             = 0
    dut.cpu_addr.value              = 0
    dut.cpu_wr_data.value           = 0
    dut.cpu_size.value              = 0
    dut.cpu_prot.value              = 0
    dut.cpu_vec_redirect.value      = 0
    dut.pad_cpu_halt_ff2.value      = 0
    # AHB side
    dut.ahbl_ahbLif_hready.value    = 1
    dut.ahbl_ahbLif_hresp.value     = 0
    dut.ahbl_ahbLif_hrdata.value    = 0
    dut.ahblif_power_mask.value     = 0


@cocotb.test()
async def test_reset_state(dut):
    """After reset, should be IDLE, no busy, grant==1 (bus ready), clk_en==0."""
    init_signals(dut)
    await reset_dut(dut)

    # Log signals
    dut._log.info(f"test_reset_state: idle={int(dut.ahblif_idle.value)}, busy={int(dut.ahblif_busy.value)}, grant={int(dut.cpu_req_grnt.value)}, clk_en={int(dut.ahbl_clk_en.value)}")

    # Now sample immediately
    assert int(dut.ahblif_idle.value) == 1,  \
        f"Expected ahblif_idle=1, got {int(dut.ahblif_idle.value)}"
    assert int(dut.ahblif_busy.value) == 0,  \
        f"Expected ahblif_busy=0, got {int(dut.ahblif_busy.value)}"
    assert int(dut.cpu_req_grnt.value) == 1, \
        f"Expected cpu_req_grnt=1 (bus ready), got {int(dut.cpu_req_grnt.value)}"
    assert int(dut.ahbl_clk_en.value) == 0,   \
        f"Expected ahbl_clk_en=0, got {int(dut.ahbl_clk_en.value)}"


@cocotb.test()
async def test_simple_write(dut):
    """Single write: grant, trans_cmplt=1, data_vld=0 all in the same first cycle."""
    init_signals(dut)
    await reset_dut(dut)

    # Drive a write request
    dut.cpu_req.value              = 1
    dut.cpu_req_power_masked.value = 1
    dut.cpu_write.value            = 1
    dut.cpu_addr.value             = 0x1000
    dut.cpu_wr_data.value          = 0xA5A5
    dut.cpu_size.value             = 2
    dut.cpu_prot.value             = 0b0011

    # Log request
    dut._log.info(f"test_simple_write: req={int(dut.cpu_req.value)}, write={int(dut.cpu_write.value)}, addr=0x{int(dut.cpu_addr.value):08X}, wdata=0x{int(dut.cpu_wr_data.value):08X}")

    # One clock: grant + completion pulse should both appear here
    await cycle_clock(dut, 1)

    # Log response
    dut._log.info(f"test_simple_write: grant={int(dut.cpu_req_grnt.value)}, htrans={int(dut.ahbLif_ahbl_htrans.value)}, trans_cmplt={int(dut.cpu_trans_cmplt.value)}, data_vld={int(dut.cpu_data_vld.value)}")

    assert int(dut.cpu_req_grnt.value) == 1, \
        f"Expected grant=1, got {int(dut.cpu_req_grnt.value)}"
    assert int(dut.ahbLif_ahbl_haddr.value) == 0x1000
    assert int(dut.ahbLif_ahbl_hwdata.value) == 0xA5A5
    # HTRANS == NONSEQ == 2
    assert int(dut.ahbLif_ahbl_htrans.value) == 2, \
        f"Expected HTRANS=2, got {int(dut.ahbLif_ahbl_htrans.value)}"
    # completion and no data-valid (because it's a write)
    assert int(dut.cpu_trans_cmplt.value) == 1, \
        f"Expected trans_cmplt=1, got {int(dut.cpu_trans_cmplt.value)}"
    assert int(dut.cpu_data_vld.value) == 0, \
        f"Expected data_vld=0 on write, got {int(dut.cpu_data_vld.value)}"


@cocotb.test()
async def test_simple_read(dut):
    """Single read: grant, data_vld=1 and cpu_rdata matches hrdata in that same cycle."""
    init_signals(dut)
    await reset_dut(dut)

    # Set up bus return
    dut.ahbl_ahbLif_hrdata.value = 0xDEADBEEF
    dut._log.info(f"test_simple_read: hrdata=0x{int(dut.ahbl_ahbLif_hrdata.value):08X}")

    # Drive read
    dut.cpu_req.value              = 1
    dut.cpu_req_power_masked.value = 1
    dut.cpu_write.value            = 0
    dut.cpu_addr.value             = 0x2000
    dut.cpu_size.value             = 1
    dut.cpu_prot.value             = 0b0101

    # Log request
    dut._log.info(f"test_simple_read: req={int(dut.cpu_req.value)}, addr=0x{int(dut.cpu_addr.value):08X}")

    # One clock: grant + data-valid appear here
    await cycle_clock(dut, 1)

    # Log response
    dut._log.info(f"test_simple_read: grant={int(dut.cpu_req_grnt.value)}, data_vld={int(dut.cpu_data_vld.value)}, rdata=0x{int(dut.cpu_rdata.value):08X}")

    assert int(dut.cpu_req_grnt.value) == 1, \
        f"Expected grant=1, got {int(dut.cpu_req_grnt.value)}"
    assert int(dut.cpu_data_vld.value) == 1, \
        f"Expected data_vld=1, got {int(dut.cpu_data_vld.value)}"
    assert int(dut.cpu_rdata.value) == 0xDEADBEEF, \
        f"Expected rdata=0xDEADBEEF, got 0x{int(dut.cpu_rdata.value):08X}"


@cocotb.test()
async def test_back_to_back(dut):
    """If cpu_req stays high, back-to-back transfers remain in WFD (SEQ)."""
    init_signals(dut)
    await reset_dut(dut)

    # First read
    dut.ahbl_ahbLif_hrdata.value = 0x1234
    dut.cpu_req.value = 1
    dut.cpu_req_power_masked.value = 1
    dut.cpu_write.value = 0
    await cycle_clock(dut, 1)
    dut._log.info(f"test_back_to_back first: grant={int(dut.cpu_req_grnt.value)}, haddr=0x{int(dut.ahbLif_ahbl_haddr.value):08X}")

    # Change addr + data but keep req asserted
    dut.cpu_addr.value = 0x3000
    dut.ahbl_ahbLif_hrdata.value = 0x5678
    await cycle_clock(dut, 1)
    dut._log.info(f"test_back_to_back second: grant={int(dut.cpu_req_grnt.value)}, haddr=0x{int(dut.ahbLif_ahbl_haddr.value):08X}")

    # Should still be in transfer (SEQ), so haddr updated and grant stays
    assert int(dut.ahbLif_ahbl_haddr.value) == 0x3000
    assert int(dut.cpu_req_grnt.value) == 1


@cocotb.test()
async def test_power_mask_blocks(dut):
    """Even with ahblif_power_mask=1, the FSM moves to WFD and grants on that same edge."""
    init_signals(dut)
    await reset_dut(dut)

    dut.ahblif_power_mask.value      = 1
    dut.cpu_req.value                = 1
    dut.cpu_req_power_masked.value   = 1
    dut._log.info(f"test_power_mask_blocks: power_mask={int(dut.ahblif_power_mask.value)}, req={int(dut.cpu_req.value)}")

    # after one clock, cur_state==WFD → grant==1
    await cycle_clock(dut, 1)
    dut._log.info(f"test_power_mask_blocks: grant={int(dut.cpu_req_grnt.value)}")
    assert int(dut.cpu_req_grnt.value) == 1, \
        f"Expected grant=1 in WFD, got {int(dut.cpu_req_grnt.value)}"


@cocotb.test()
async def test_halt_blocks(dut):
    """pad_cpu_halt_ff2=1 must block grant even if cpu_req_powered."""
    init_signals(dut)
    await reset_dut(dut)

    dut.pad_cpu_halt_ff2.value = 1
    dut.cpu_req.value = 1
    dut.cpu_req_power_masked.value = 1
    dut._log.info(f"test_halt_blocks: halt={int(dut.pad_cpu_halt_ff2.value)}, req={int(dut.cpu_req.value)}")

    await cycle_clock(dut, 1)
    dut._log.info(f"test_halt_blocks: grant={int(dut.cpu_req_grnt.value)}, idle={int(dut.ahblif_idle.value)}")
    assert int(dut.cpu_req_grnt.value) == 0, \
        "Grant should be blocked by CPU halt"
    assert int(dut.ahblif_idle.value) == 1


@cocotb.test()
async def test_error_response(dut):
    """Drive an ERROR response (hresp=1,hready=1): should see cpu_acc_err on ERROR2."""
    init_signals(dut)
    await reset_dut(dut)

    # Issue a read
    dut.cpu_req.value = 1
    dut.cpu_req_power_masked.value = 1
    await cycle_clock(dut, 1)
    dut._log.info(f"test_error_response: granted, now inject error")

    # Inject error
    dut.ahbl_ahbLif_hresp.value = 1
    dut.ahbl_ahbLif_hready.value = 1

    # ERROR1 (no err yet)
    await cycle_clock(dut, 1)
    dut._log.info(f"test_error_response ERROR1: cpu_acc_err={int(dut.cpu_acc_err.value)}")
    assert int(dut.cpu_acc_err.value) == 0

    # ERROR2: now should pulse
    await cycle_clock(dut, 1)
    dut._log.info(f"test_error_response ERROR2: cpu_acc_err={int(dut.cpu_acc_err.value)}, trans_cmplt={int(dut.cpu_trans_cmplt.value)}")
    assert int(dut.cpu_acc_err.value) == 1, "cpu_acc_err should pulse"
    assert int(dut.cpu_trans_cmplt.value) == 1


@cocotb.test()
async def test_error_with_busy_low_ready(dut):
    """If hready=0 & hresp=1, FSM stays in ERROR1 until hready=1."""
    init_signals(dut)
    await reset_dut(dut)

    dut.cpu_req.value = 1
    dut.cpu_req_power_masked.value = 1
    await cycle_clock(dut, 1)

    dut.ahbl_ahbLif_hresp.value = 1
    dut.ahbl_ahbLif_hready.value = 0
    dut._log.info(f"test_error_with_busy_low_ready: entered ERROR1 (hready=0)")

    # Should hold in ERROR1
    await cycle_clock(dut, 2)
    dut._log.info(f"test_error_with_busy_low_ready: still ERROR1 cpu_acc_err={int(dut.cpu_acc_err.value)}")
    assert int(dut.cpu_acc_err.value) == 0

    # Now allow ready → ERROR2
    dut.ahbl_ahbLif_hready.value = 1
    await cycle_clock(dut, 1)
    dut._log.info(f"test_error_with_busy_low_ready ERROR2: cpu_acc_err={int(dut.cpu_acc_err.value)}")
    assert int(dut.cpu_acc_err.value) == 1


@cocotb.test()
async def test_hsize_hprot_hburst(dut):
    """Check that HSIZE, HPROT and HBURST follow cpu_size/prot (and burst==0)."""
    init_signals(dut)
    await reset_dut(dut)

    dut.cpu_req.value = 1
    dut.cpu_req_power_masked.value = 1
    dut.cpu_size.value = 3
    dut.cpu_prot.value = 0b1010
    await cycle_clock(dut, 1)
    dut._log.info(f"test_hsize_hprot_hburst: hsize={int(dut.ahbLif_ahbl_hsize.value)}, hprot={int(dut.ahbLif_ahbl_hprot.value)}, hburst={int(dut.ahbLif_ahbl_hburst.value)}")

    expected_hsize = (0 << 2) | (3 & 0b11)
    assert int(dut.ahbLif_ahbl_hsize.value) == expected_hsize
    assert int(dut.ahbLif_ahbl_hprot.value) == 0b1010
    assert int(dut.ahbLif_ahbl_hburst.value) == 0


@cocotb.test()
async def test_vec_redirect_toggle(dut):
    """Vector-redirect input should drive ahbLif_ahbl_vec_redrct output."""
    init_signals(dut)
    await reset_dut(dut)

    for val in (0, 1):
        dut.cpu_vec_redirect.value = val
        dut.cpu_req.value = 1
        dut.cpu_req_power_masked.value = 1
        await cycle_clock(dut, 1)
        dut._log.info(f"test_vec_redirect_toggle val={val}: vec_redrct={int(dut.ahbLif_ahbl_vec_redrct.value)}")
        assert int(dut.ahbLif_ahbl_vec_redrct.value) == val
        # clear for next iteration
        dut.cpu_req.value = 0
        dut.cpu_req_power_masked.value = 0
        await cycle_clock(dut, 1)

