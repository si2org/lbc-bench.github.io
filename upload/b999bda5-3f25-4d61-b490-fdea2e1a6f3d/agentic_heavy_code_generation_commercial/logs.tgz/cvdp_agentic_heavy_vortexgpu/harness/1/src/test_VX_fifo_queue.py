# File: tests/test_fifo_queue.py

import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
import random

# Match build parameters in test_runner.py
DEPTH = 4
DATAW = 8
ALM_FULL = DEPTH - 1   # 3
ALM_EMPTY = 1


async def reset_dut(dut):
    """Reset DUT."""
    dut.reset.value = 1
    for _ in range(5):
        await RisingEdge(dut.clk)
    dut.reset.value = 0
    await RisingEdge(dut.clk)


@cocotb.test()
async def fifo_push_pop_test(dut):
    """Test basic push and pop functionality; covers all 10 RTL assertions."""
    clock = Clock(dut.clk, 10, unit="ns")
    cocotb.start_soon(clock.start())

    dut.push.value = 0
    dut.pop.value = 0
    dut.data_in.value = 0

    await reset_dut(dut)

    # ---------------------------------------------------------------
    # Phase 1: Push DEPTH items (covers assertions 1,2,4,5,6,9)
    # ---------------------------------------------------------------
    input_values = [0x11, 0x22, 0x33, 0x44]

    for i, val in enumerate(input_values):
        dut.data_in.value = val
        dut.push.value = 1
        dut.pop.value = 0
        await RisingEdge(dut.clk)
        dut._log.info(f"Pushed 0x{val:x} at slot {i}, full={dut.full.value}, size={dut.size.value}")
        if i < DEPTH - 1:
            assert not dut.full.value, f"FIFO should not be full after {i+1} pushes"

    # Idle cycle with push=0 (assertion 8: !push -> wr_ptr stable)
    dut.push.value = 0
    await RisingEdge(dut.clk)
    assert dut.full.value, "FIFO should be full after DEPTH pushes"

    # ---------------------------------------------------------------
    # Phase 2: Pop DEPTH items (covers assertions 3,4,5,7,8)
    # Read data_out BEFORE the clock edge (async-read FIFO: rdata = ram[rd_ptr_r])
    # ---------------------------------------------------------------
    for i, expected in enumerate(input_values):
        await Timer(1, unit="ns")
        assert dut.data_out.value.is_resolvable, "data_out is X before pop"
        dout = int(dut.data_out.value)
        dut.pop.value = 1
        dut.push.value = 0
        await RisingEdge(dut.clk)
        dut._log.info(f"Popped 0x{dout:x}, expected 0x{expected:x}")
        assert dout == expected, f"Pop mismatch at index {i}: expected 0x{expected:x}, got 0x{dout:x}"

    dut.pop.value = 0
    await RisingEdge(dut.clk)
    assert dut.empty.value, "FIFO should be empty after popping all elements"

    # ---------------------------------------------------------------
    # Phase 3: Simultaneous push & pop (covers assertion 10)
    # ---------------------------------------------------------------
    # Prime with one element first
    dut.data_in.value = 0xAB
    dut.push.value = 1
    dut.pop.value = 0
    await RisingEdge(dut.clk)
    await Timer(1, unit="ns")
    dut.push.value = 0

    # Simultaneous push and pop; size should remain stable
    pre_size = int(dut.size.value)
    dut.data_in.value = 0xCD
    dut.push.value = 1
    dut.pop.value = 1
    await RisingEdge(dut.clk)
    await Timer(1, unit="ns")
    dut.push.value = 0
    dut.pop.value = 0
    post_size = int(dut.size.value)
    assert post_size == pre_size, f"Size changed during simultaneous push/pop: {pre_size} -> {post_size}"

    # ---------------------------------------------------------------
    # Phase 4: Coverage for alm_full / alm_empty intermediate states
    # (ensures assertions 4 and 5 both fire during size=2 state)
    # ---------------------------------------------------------------
    # Pop remaining element
    dut.pop.value = 1
    await RisingEdge(dut.clk)
    dut.pop.value = 0
    await RisingEdge(dut.clk)

    # Push exactly 2 items -> size=2 -> neither alm_full nor alm_empty
    for val in [0x11, 0x22]:
        dut.data_in.value = val
        dut.push.value = 1
        await RisingEdge(dut.clk)
    dut.push.value = 0
    await RisingEdge(dut.clk)
    assert int(dut.size.value) == 2, "Expected size=2"
    assert not dut.alm_full.value, "alm_full should be 0 at size=2"
    assert not dut.alm_empty.value, "alm_empty should be 0 at size=2"

    # Pop back to empty
    for _ in range(2):
        dut.pop.value = 1
        await RisingEdge(dut.clk)
    dut.pop.value = 0
    await RisingEdge(dut.clk)
    assert dut.empty.value, "FIFO should be empty at end of test"

    dut._log.info("All assertions covered.")
