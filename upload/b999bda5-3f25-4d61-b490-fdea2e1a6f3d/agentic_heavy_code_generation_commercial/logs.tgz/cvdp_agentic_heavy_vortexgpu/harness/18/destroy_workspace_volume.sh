#!/bin/bash
# Auto-generated script to destroy workspace volume for context heavy datapoint
# Datapoint ID: 18
# Volume name: cvdp_agentic_heavy_vortexgpu_0018_workspace

set -e

echo "Destroying workspace volume for context heavy datapoint..."
echo "Volume name: cvdp_agentic_heavy_vortexgpu_0018_workspace"

# Check if volume exists
if ! docker volume inspect cvdp_agentic_heavy_vortexgpu_0018_workspace &>/dev/null; then
  echo "Volume cvdp_agentic_heavy_vortexgpu_0018_workspace does not exist. Nothing to destroy."
  exit 0
fi

# Remove Docker volume
echo "Removing Docker volume: cvdp_agentic_heavy_vortexgpu_0018_workspace"
docker volume rm -f cvdp_agentic_heavy_vortexgpu_0018_workspace

echo "Workspace volume destruction complete!"
echo "Volume cvdp_agentic_heavy_vortexgpu_0018_workspace has been removed."
