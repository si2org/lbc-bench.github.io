`timescale 1ns/1ps

module packet2emesh #( 
    parameter AW = 32,                  // Address width
    parameter PW = (3*AW + 8)           // Packet width
)(
    input  logic [PW-1:0]  packet_in,       // Incoming EMESH packet
    output logic           write_in,        // Write bit
    output logic [1:0]     datamode_in,     // Data mode
    output logic [4:0]     ctrlmode_in,     // Control mode
    output logic [AW-1:0]  dstaddr_in,      // Destination address
    output logic [AW-1:0]  data_in,         // Data payload
    output logic [AW-1:0]  srcaddr_in       // Source address
);

  // Unpack fields from EMESH packet
  assign write_in     = packet_in[0];                  // Bit 0: write enable
  assign datamode_in  = packet_in[2:1];                // Bits [2:1]: data mode
  assign ctrlmode_in  = packet_in[7:3];                // Bits [7:3]: control mode
  assign dstaddr_in   = packet_in[8       +: AW];      // Bits [8 +: AW]: destination address
  assign data_in      = packet_in[8+AW    +: AW];      // Bits [8+AW +: AW]: data payload
  assign srcaddr_in   = packet_in[8+2*AW  +: AW];      // Bits [8+2*AW +: AW]: source address

endmodule