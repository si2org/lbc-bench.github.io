`timescale 1ns/1ps

module edma #(
    parameter AW = 32,               // Address width
    parameter PW = (3*AW + 8)        // Packet width (based on EMESH format)
) (
    // Power & Clocks
    input  logic          vdd,       // Power supply (placeholder for analog-aware simulation)
    input  logic          vss,       // Ground (placeholder)
    input  logic          clk,       // System clock
    input  logic          nreset,    // Active-low synchronous reset

    // Interrupt Output
    output logic          irq,       // Interrupt signal from DMA to processor

    // Data Path Interface (Memory Transaction)
    input  logic          access_in,     // Incoming access request
    input  logic [PW-1:0] packet_in,     // Incoming data/control packet
    output logic          wait_out,      // Backpressure signal to stall sender
    output logic          access_out,    // Outgoing access request
    output logic [PW-1:0] packet_out,    // Outgoing data/control packet
    input  logic          wait_in,       // Backpressure signal from receiver

    // Config/Fetch Interface (Register/Descriptor Access)
    input  logic          reg_access_in,     // Register/config access request
    input  logic [PW-1:0] reg_packet_in,     // Register/config packet
    output logic          reg_wait_out,      // Backpressure for register interface
    output logic          reg_access_out,    // Outgoing register access
    output logic [PW-1:0] reg_packet_out,    // Outgoing register packet
    input  logic          reg_wait_in        // Backpressure from register recipient
);

  // Internal wires for register outputs
  wire [AW-1:0] srcaddr_reg;          // Source address from registers
  wire [AW-1:0] dstaddr_reg;          // Destination address from registers

  // Datapath-generated addresses
  wire [AW-1:0] srcaddr;              // Current source address
  wire [AW-1:0] dstaddr;              // Current destination address

  // Control and configuration wires
  wire          dma_en;              // DMA enable signal
  wire          chainmode;           // Enable descriptor chaining
  wire          manualmode;          // Manual trigger mode
  wire          mastermode;          // Full master mode
  wire [1:0]    datamode;            // Data width mode (e.g., byte/halfword/word)
  wire [4:0]    ctrlmode;            // Control mode (e.g., write, read-modify-write)
  wire [15:0]   curr_descr;          // Current descriptor address
  wire [15:0]   next_descr;          // Next descriptor address (for chaining)
  wire [31:0]   count;               // Current transfer count
  wire [31:0]   count_reg;           // Registered transfer count
  wire [31:0]   stride_reg;          // Stride value for 2D transfers
  wire [3:0]    dma_state;           // Current state of DMA FSM
  wire          fetch_access;        // Descriptor fetch access request
  wire [PW-1:0] fetch_packet;        // Descriptor fetch packet
  wire          update;              // Trigger update of datapath state
  wire          update2d;            // Trigger 2D stride update
  wire          master_active;       // DMA transfer currently in progress
  wire [AW-1:0] secure_base;         // Secure base address
  wire [AW-1:0] secure_mask;         // Secure mask bits
  wire          sec_violation;       // Security violation flag

  // ----------------------------
  // Data Path Module Instantiation
  // ----------------------------
  edma_dp #(.AW(AW), .PW(PW)) u_dp (
    .clk           (clk),
    .nreset        (nreset),
    .master_active (master_active),
    .update2d      (update2d),
    .datamode      (datamode),
    .ctrlmode      (ctrlmode),
    .stride_reg    (stride_reg),
    .count_reg     (count_reg),
    .srcaddr_reg   (srcaddr_reg),
    .dstaddr_reg   (dstaddr_reg),
    .access_in     (access_in),
    .packet_in     (packet_in),
    .wait_in       (wait_in),
    .count         (count),
    .srcaddr       (srcaddr),
    .dstaddr       (dstaddr),
    .wait_out      (wait_out),
    .access_out    (access_out),
    .packet_out    (packet_out)
  );

  // ----------------------------
  // Register File Module Instantiation
  // ----------------------------
  edma_regs #(.AW(AW), .PW(PW)) u_regs (
    .clk            (clk),
    .nreset         (nreset),
    .reg_access_in  (reg_access_in),
    .reg_packet_in  (reg_packet_in),
    .reg_wait_out   (reg_wait_out),
    .reg_access_out (reg_access_out),
    .reg_packet_out (reg_packet_out),
    .dma_en         (dma_en),
    .mastermode     (mastermode),
    .manualmode     (manualmode),
    .datamode       (datamode),
    .ctrlmode       (ctrlmode),
    .chainmode      (chainmode),
    .irq            (),
    .next_descr     (next_descr),
    .curr_descr     (curr_descr),
    .stride_reg     (stride_reg),
    .count_reg      (count_reg),
    .dstaddr_reg    (dstaddr_reg),
    .srcaddr_reg    (srcaddr_reg),
    .secure_base_reg(secure_base),
    .secure_mask_reg(secure_mask),
    .fetch_access   (fetch_access),
    .fetch_packet   (fetch_packet),
    .count          (count),
    .dstaddr        (dstaddr),
    .srcaddr        (srcaddr),
    .dma_state      (dma_state),
    .update         (update)
  );

  // ----------------------------
  // Security checker Module Instantiation
  // ----------------------------

  edma_sec_checker #(.AW(AW)) u_sec (
    .clk            (clk),
    .nreset         (nreset),
    .srcaddr        (srcaddr),
    .dstaddr        (dstaddr),
    .secure_base    (secure_base),
    .secure_mask    (secure_mask),
    .violation      (sec_violation)
  );


  // ----------------------------
  // Control FSM Module Instantiation
  // ----------------------------
  edma_ctrl #(.AW(AW), .PW(PW)) u_ctrl (
    .clk           (clk),
    .nreset        (nreset),
    .dma_en        (dma_en),
    .chainmode     (chainmode),
    .manualmode    (manualmode),
    .mastermode    (mastermode),
    .count         (count),
    .curr_descr    (curr_descr),
    .next_descr    (next_descr),
    .reg_wait_in   (reg_wait_in),
    .access_in     (access_in),
    .wait_in       (wait_in),
    .sec_violation (sec_violation),
    .fetch_access  (fetch_access),
    .fetch_packet  (fetch_packet),
    .dma_state     (dma_state),
    .update        (update),
    .update2d      (update2d),
    .master_active (master_active)
  );

`ifndef BUG_0
  assign irq = sec_violation;
`else
  assign irq = 0;
`endif

endmodule
