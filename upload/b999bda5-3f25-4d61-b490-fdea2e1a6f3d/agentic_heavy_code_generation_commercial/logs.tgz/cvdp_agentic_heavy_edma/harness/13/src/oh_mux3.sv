`timescale 1ns/1ps

module oh_mux3 #( 
    parameter DW = 1                     // Data width of inputs/outputs
)(
    input  logic          sel0,         // Select line for input 0
    input  logic          sel1,         // Select line for input 1
    input  logic          sel2,         // Select line for input 2
    input  logic [DW-1:0] in0,          // Input 0
    input  logic [DW-1:0] in1,          // Input 1
    input  logic [DW-1:0] in2,          // Input 2
    output logic [DW-1:0] out           // Output selected input
);

  // One-hot multiplexer logic
  assign out = ({DW{sel0}} & in0) |
               ({DW{sel1}} & in1) |
               ({DW{sel2}} & in2);

endmodule