`timescale 1ns/1ps

module edma_dp #( 
    parameter AW = 32,                 // Address width
    parameter PW = (3*AW + 8)          // Packet width
) (
    input  logic           clk,            // Clock
    input  logic           nreset,         // Asynchronous reset, active low
    input  logic           master_active,  // Indicates master mode transfer
    input  logic           update2d,       // 2D update signal for outer loop
    input  logic [1:0]     datamode,       // Master data mode
    input  logic [4:0]     ctrlmode,       // Master control mode
    input  logic [31:0]    stride_reg,     // Stride value for 2D transfer
    input  logic [31:0]    count_reg,      // Count register
    input  logic [AW-1:0]  srcaddr_reg,    // Source address register
    input  logic [AW-1:0]  dstaddr_reg,    // Destination address register
    input  logic           access_in,      // Input access signal
    input  logic [PW-1:0]  packet_in,      // Incoming EMESH packet
    input  logic           wait_in,        // Wait input from downstream

    output logic [31:0]    count,          // Updated count
    output logic [AW-1:0]  srcaddr,        // Updated source address
    output logic [AW-1:0]  dstaddr,        // Updated destination address
    output logic           wait_out,       // Wait signal output
    output logic           access_out,     // Access signal output
    output logic [PW-1:0]  packet_out      // Outgoing EMESH packet
);

  // COUNT UPDATE
  assign count = ~nreset ? 32'd0 :
                 (update2d ? { count_reg[31:16] - 16'd1, count_reg[15:0] } :
                              (count_reg - 32'd1));

  // ADDRESS INCREMENT
  assign srcaddr = srcaddr_reg + {{(AW-16){stride_reg[15]}}, stride_reg[15:0]};
  assign dstaddr = dstaddr_reg + {{(AW-16){stride_reg[31]}}, stride_reg[31:16]};

  // Internal wires for packet conversion
  wire [4:0]      ctrlmode_out;
  wire [AW-1:0]   data_out;
  wire [1:0]      datamode_out;
  wire [AW-1:0]   dstaddr_out;
  wire [AW-1:0]   srcaddr_out;
  wire            write_out;
  wire [PW-1:0]   packet;

  // Decoded inputs from packet
  wire [4:0]      ctrlmode_in;
  wire [AW-1:0]   data_in;
  wire [1:0]      datamode_in;
  wire [AW-1:0]   dstaddr_in;
  wire [AW-1:0]   srcaddr_in;
  wire            write_in;

  // Decode incoming EMESH packet
  packet2emesh #(.AW(AW), .PW(PW)) u_p2e (
    .packet_in    (packet_in),
    .write_in     (write_in),
    .datamode_in  (datamode_in),
    .ctrlmode_in  (ctrlmode_in),
    .dstaddr_in   (dstaddr_in),
    .data_in      (data_in),
    .srcaddr_in   (srcaddr_in)
  );

  // Select fields based on master or slave mode
  assign write_out         = master_active ? 1'b0          : write_in;
  assign datamode_out      = master_active ? datamode      : datamode_in;
  assign ctrlmode_out      = master_active ? ctrlmode      : ctrlmode_in;
  `ifndef BUG_2
    assign dstaddr_out       = dstaddr;
  `else
    assign dstaddr_out       = 0;
  `endif
  assign data_out          = master_active ? {AW{1'b0}}     : data_in;
  `ifndef BUG_7
    assign srcaddr_out       = master_active ? {AW{1'b0}}     : srcaddr_in;
  `else
    assign srcaddr_out       = {AW{1'b1}} ;
  `endif
  // Encode EMESH packet
  emesh2packet #(.AW(AW), .PW(PW)) u_e2p (
    .write_out     (write_out),
    .datamode_out  (datamode_out),
    .ctrlmode_out  (ctrlmode_out),
    .dstaddr_out   (dstaddr_out),
    .data_out      (data_out),
    .srcaddr_out   (srcaddr_out),
    .packet_out    (packet)
  );

  // Drive output packet and access when not stalled
  always @(posedge clk or negedge nreset) begin
    if (!nreset) begin
      packet_out <= {PW{1'b0}};
      access_out <= 1'b0;
    end else if (~wait_in) begin
      `ifndef BUG_1
        packet_out <= packet;
      `else
        packet_out <= 0;
      `endif    
      access_out <= access_in | master_active;
    end
  end

  // Pass wait signal through
  assign wait_out = wait_in;

endmodule
