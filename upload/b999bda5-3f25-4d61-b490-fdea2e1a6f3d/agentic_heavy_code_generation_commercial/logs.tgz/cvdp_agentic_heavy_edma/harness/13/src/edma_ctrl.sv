`timescale 1ns/1ps

parameter ID = 4'b0000;      // Group ID for DMA regs [10:8]

module edma_ctrl #( 
  parameter AW = 32,                     // Address width
  parameter PW = (3*AW + 8)              // Packet width
)(
  input  logic          clk,             // Clock
  input  logic          nreset,          // Asynchronous reset, active low
  input  logic          dma_en,          // DMA enable
  input  logic          chainmode,       // Enable descriptor chaining
  input  logic          manualmode,      // Manual mode (non-fetch)
  input  logic          mastermode,      // Master initiator mode
  input  logic [31:0]   count,           // Transfer count: [31:16] outer, [15:0] inner
  input  logic [15:0]   curr_descr,      // Current descriptor address
  input  logic [15:0]   next_descr,      // Next descriptor address (for chaining)
  input  logic          reg_wait_in,     // Wait for register fetch to complete
  input  logic          access_in,       // Slave access trigger
  input  logic          wait_in,         // Wait input from downstream
  input  logic          sec_violation,   // Security violation detected

  output logic          fetch_access,    // Fetch enable signal
  output logic [PW-1:0] fetch_packet,    // Generated fetch EMESH packet
  output logic [3:0]    dma_state,       // Current DMA FSM state
  output logic          update,          // Update enable (based on access or master active)
  output logic          update2d,        // 2D update enable (for outer loops)
  output logic          master_active    // Master transfer active
);

  // DMA FSM states
  typedef enum logic [3:0] {
    DMA_IDLE   = 4'b0000,
    DMA_FETCH0 = 4'b0001,
    DMA_FETCH1 = 4'b0010,
    DMA_FETCH2 = 4'b0011,
    DMA_FETCH3 = 4'b0100,
    DMA_FETCH4 = 4'b0101,
    DMA_INNER  = 4'b0110,
    DMA_OUTER  = 4'b0111,
    DMA_DONE   = 4'b1000,
    DMA_ERROR  = 4'b1001
  } state_e;

  // Register addresses used during fetch
  typedef enum logic [4:0] {
    EDMA_CONFIG    = 0,
    EDMA_STRIDE    = 1,
    EDMA_COUNT     = 2,
    EDMA_SRCADDR   = 3,
    EDMA_DSTADDR   = 4,
    EDMA_SRCADDR64 = 5,
    EDMA_DSTADDR64 = 6,
    EDMA_STATUS    = 7,
    EDMA_SECBASE   = 8,
    EDMA_SECMASK   = 9
  } addr_e;

  // Internal signals
  wire [15:0]    descr;
  wire [15:0]    fetch_addr;
  wire [AW-1:0]  srcaddr_out;
  wire [4:0]     reg_addr;
  wire           incount_zero;
  wire           outcount_zero;

  // FSM: DMA state transitions
  always_ff @(posedge clk or negedge nreset) begin
    if (!nreset)
      dma_state <= DMA_IDLE;
    else if (sec_violation)
      dma_state <= DMA_ERROR;
    else begin
      case (dma_state[3:0])
        DMA_IDLE:
          casez ({dma_en, manualmode})
            2'b0? : dma_state <= DMA_IDLE;
            2'b11 : dma_state <= DMA_INNER;      // Manual immediate start
            2'b10 : dma_state <= DMA_FETCH0;     // Begin fetch sequence
          endcase

        DMA_FETCH0:
          dma_state <= reg_wait_in ? DMA_FETCH0 : DMA_FETCH1;
        DMA_FETCH1:
          dma_state <= reg_wait_in ? DMA_FETCH1 : DMA_FETCH2;
        DMA_FETCH2:
          dma_state <= reg_wait_in ? DMA_FETCH2 : DMA_FETCH3;
        DMA_FETCH3:
          dma_state <= reg_wait_in ? DMA_FETCH3 : DMA_FETCH4;
        DMA_FETCH4:
          dma_state <= reg_wait_in ? DMA_FETCH4 : DMA_INNER;

        DMA_INNER:
          casez ({update, incount_zero, outcount_zero})
            3'b0?? : dma_state <= DMA_INNER;
            3'b10? : dma_state <= DMA_INNER;
            3'b110 : dma_state <= DMA_OUTER;
            3'b111 : dma_state <= DMA_DONE;
          endcase

        DMA_OUTER:
          dma_state <= update ? DMA_INNER : DMA_OUTER;

        DMA_DONE:
          casez ({chainmode, manualmode})
            2'b0?  : dma_state <= DMA_DONE;
            2'b11  : dma_state <= DMA_IDLE;
            2'b10  : dma_state <= DMA_FETCH0;
          endcase

        DMA_ERROR:
          dma_state <= dma_en ? DMA_ERROR : DMA_IDLE;
      endcase
    end
  end

  // Master active signal is asserted during inner/outer loop when master mode is enabled
  assign master_active = mastermode && (dma_state == DMA_INNER || dma_state == DMA_OUTER);


  // Update conditions: only when wait is not asserted and access/master is active
  assign update    = !wait_in && (master_active || access_in);
  `ifndef BUG_5
    assign update2d  = update && (dma_state == DMA_OUTER);
  `else
    assign update2d  = 0;
  `endif

  // Fetch access enable based on DMA state range
  assign fetch_access = (dma_state >= DMA_FETCH0 && dma_state <= DMA_FETCH4);

  // Zero count detection for inner and outer loop
  assign incount_zero  = ~(|count[15:0]);     // Inner count
  assign outcount_zero = ~(|count[31:16]);    // Outer count

  // Descriptor selection logic
  assign descr = (dma_state == DMA_FETCH0) ? next_descr : curr_descr;

  // Fetch address generation based on FSM step
  oh_mux3 #(.DW(16)) mux3d (
    .out  (fetch_addr),
    .in0  (descr),
    .sel0 (dma_state == DMA_FETCH0),
    .in1  (descr + 16'd8),
    .sel1 (dma_state == DMA_FETCH1),
    .in2  (descr + 16'd16),
    .sel2 (dma_state == DMA_FETCH2)
  );

  // Register address selection for fetch
  oh_mux3 #(.DW(5)) mux3s (
    .out  (reg_addr),
    .in0  (EDMA_CONFIG),
    .sel0 (dma_state == DMA_FETCH0),
    .in1  (EDMA_COUNT),
    .sel1 (dma_state == DMA_FETCH1),
    .in2  (EDMA_SRCADDR),
    .sel2 (dma_state == DMA_FETCH2)
  );

  // Construct source address used in EMESH packet (includes group ID)
  assign srcaddr_out = {{(AW-11){1'b0}}, ID, reg_addr, 2'b0};

  // EMESH fetch packet construction
  emesh2packet #(.AW(AW), .PW(PW)) e2p (
    .packet_out     (fetch_packet),
    .write_out      (1'b0),                          // Read packet
    .datamode_out   (2'b11),                         // Word mode
    .ctrlmode_out   (5'b0),
    .dstaddr_out    ({{(AW-16){1'b0}}, fetch_addr}), // Destination address padded
    .data_out       ({AW{1'b0}}),                    // Unused data for read
    .srcaddr_out    (srcaddr_out)                    // Source address
  );

endmodule
