`timescale 1ns/1ps

module edma_sec_checker #( 
    parameter AW = 32                   // Address width
)(
    input  logic [AW-1:0] srcaddr,        // Source address from DMA
    input  logic [AW-1:0] dstaddr,        // Destination address from DMA
    input  logic [AW-1:0] secure_base,    // Base address of secure region
    input  logic [AW-1:0] secure_mask,    // Secure mask bits
    input  logic          clk,            // System clock
    input  logic          nreset,         // Active-low reset
    output logic          violation       // Security violation detected
);

  // On every clock cycle, check if source or destination addresses violate secure mask
  // Violation occurs if masked difference between address and secure base is non-zero
  always_ff @(posedge clk or negedge nreset) begin
    if (!nreset)
      violation <= 1'b0;
    else
      `ifndef BUG_3
        violation <= |((srcaddr ^ secure_base) & secure_mask) ||   // Source address check
                   |((dstaddr ^ secure_base) & secure_mask);     // Destination address check
      `else
        violation <= 1'b0;
      `endif
  end

endmodule