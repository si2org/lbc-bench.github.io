`timescale 1ns/1ps

module emesh2packet #( 
    parameter AW = 32,                  // Address width
    parameter PW = (3*AW + 8)           // Packet width
)(
    input  logic         write_out,        // Write enable bit
    input  logic [1:0]   datamode_out,     // Data mode (byte, halfword, word)
    input  logic [4:0]   ctrlmode_out,     // Control mode (custom signaling)
    input  logic [AW-1:0] dstaddr_out,     // Destination address
    input  logic [AW-1:0] data_out,        // Data payload
    input  logic [AW-1:0] srcaddr_out,     // Source address
    output logic [PW-1:0] packet_out       // Packed EMESH packet output
);

  // Bit layout of the EMESH packet
  // [0]        - write_out
  // [2:1]      - datamode_out
  // [7:3]      - ctrlmode_out
  // [8 +: AW]        - dstaddr_out
  // [8+AW +: AW]     - data_out
  // [8+2*AW +: AW]   - srcaddr_out

  assign packet_out[0]               = write_out;
  assign packet_out[2:1]             = datamode_out;
  assign packet_out[7:3]             = ctrlmode_out;
  assign packet_out[8        +: AW]  = dstaddr_out;
  assign packet_out[8+AW     +: AW]  = data_out;
  assign packet_out[8+2*AW   +: AW]  = srcaddr_out;

endmodule