`timescale 1ns/1ps

module edma_regs #( 
    parameter AW = 32,                  // Address width
    parameter PW = (3*AW + 8)           // Packet width
)(
    input  logic           clk,             // Clock
    input  logic           nreset,          // Asynchronous reset
    input  logic           reg_access_in,   // Input register access valid
    input  logic [PW-1:0]  reg_packet_in,   // Register access packet input
    output logic           reg_wait_out,    // Register wait output (not used)
    output logic           reg_access_out,  // Fetch access passthrough
    output logic [PW-1:0]  reg_packet_out,  // Fetch packet passthrough

    output logic           dma_en,          // DMA enable output
    output logic           mastermode,      // Master mode output
    output logic           manualmode,      // Manual mode output (inverted)
    output logic [1:0]     datamode,        // Data mode
    output logic [4:0]     ctrlmode,        // Control mode
    output logic           chainmode,       // Chain mode enable
    output logic           irq,             // IRQ output
    output logic [15:0]    next_descr,      // Next descriptor address
    output logic [15:0]    curr_descr,      // Current descriptor address
    output logic [31:0]    stride_reg,      // Stride register
    output logic [31:0]    count_reg,       // Count register
    output logic [AW-1:0]  dstaddr_reg,     // Destination address register
    output logic [AW-1:0]  srcaddr_reg,     // Source address register
    output logic [AW-1:0]  secure_base_reg, // Secure base address register
    output logic [AW-1:0]  secure_mask_reg, // Secure mask register

    input  logic           fetch_access,    // Fetch access input
    input  logic [PW-1:0]  fetch_packet,    // Fetch packet input
    input  logic [31:0]    count,           // Count input
    input  logic [AW-1:0]  dstaddr,         // Destination address input
    input  logic [AW-1:0]  srcaddr,         // Source address input
    input  logic [3:0]     dma_state,       // DMA FSM state
    input  logic           update           // Update enable
);

  // Internal control signals for register write decoding
  wire               reg_write;
  wire               config_write;
  wire               stride_write;
  wire               count_write;
  wire               src0_write;
  wire               src1_write;
  wire               dst0_write;
  wire               dst1_write;
  wire               status_write;
  wire               secbase_write;
  wire               secmask_write;
  wire               irqmode;

  // Address decode enumeration
  typedef enum logic [4:0] {
    EDMA_CONFIG    = 0,
    EDMA_STRIDE    = 1,
    EDMA_COUNT     = 2,
    EDMA_SRCADDR   = 3,
    EDMA_DSTADDR   = 4,
    EDMA_SRCADDR64 = 5,
    EDMA_DSTADDR64 = 6,
    EDMA_STATUS    = 7,
    EDMA_SECBASE   = 8,
    EDMA_SECMASK   = 9
  } addr_e;

  // Packet decoding wires
  wire [4:0]     ctrlmode_in;
  wire [AW-1:0]  data_in;
  wire [1:0]     datamode_in;
  wire [AW-1:0]  dstaddr_in;
  wire [AW-1:0]  srcaddr_in;
  wire          write_in;

  // Decode incoming EMESH packet for register accesses
  packet2emesh #(.AW(AW), .PW(PW)) p2e (
    .packet_in    (reg_packet_in),
    .write_in     (write_in),
    .datamode_in  (datamode_in),
    .ctrlmode_in  (ctrlmode_in),
    .dstaddr_in   (dstaddr_in),
    .srcaddr_in   (srcaddr_in),
    .data_in      (data_in)
  );

  // Decode address and enable signals for write ops
  assign reg_write     = write_in & reg_access_in;
  assign config_write  = reg_write & (dstaddr_in == EDMA_CONFIG);
  assign stride_write  = reg_write & (dstaddr_in == EDMA_STRIDE);
  assign count_write   = reg_write & (dstaddr_in == EDMA_COUNT);
  assign src0_write    = reg_write & (dstaddr_in == EDMA_SRCADDR);
  assign src1_write    = reg_write & (dstaddr_in == EDMA_SRCADDR64);
  assign dst0_write    = reg_write & (dstaddr_in == EDMA_DSTADDR);
  assign dst1_write    = reg_write & (dstaddr_in == EDMA_DSTADDR64);
  assign status_write  = reg_write & (dstaddr_in == EDMA_STATUS);
  assign secbase_write = reg_write & (dstaddr_in==EDMA_SECBASE);
  assign secmask_write = reg_write & (dstaddr_in==EDMA_SECMASK);

  // Configuration and status registers
  reg [31:0] status_reg;
  reg [31:0] config_reg;
  reg [AW-1:0] secure_base_r;
  reg [AW-1:0] secure_mask_r;

  // Config register logic
  always_ff @(posedge clk or negedge nreset) begin
    if (!nreset)
      config_reg <= 0;
    else if (config_write)
      config_reg <= data_in;
  end

  `ifndef BUG_6
    assign dma_en     = config_reg[0];
  `else
    assign dma_en     = ~config_reg[0];
  `endif
  assign mastermode = config_reg[1];
  assign chainmode  = config_reg[2];
  `ifndef BUG_4
    assign manualmode = ~config_reg[3];
  `else
    assign manualmode = config_reg[3];
  `endif
  assign irqmode    = config_reg[4];          // IRQ mode bit
  assign datamode   = config_reg[6:5];        // Data mode
  assign ctrlmode   = 5'd0;                   // Defaulted
  assign next_descr = config_reg[31:16];

  // Stride register logic
  always_ff @(posedge clk or negedge nreset) begin
    if (!nreset)
      stride_reg <= 32'd0;
    else if (stride_write)
      stride_reg <= data_in;
  end

  // Count register logic
  always_ff @(posedge clk or negedge nreset) begin
    if (!nreset)
      count_reg <= 32'd0;
    else if (count_write)
      count_reg <= data_in;
    else if (update)
      count_reg <= count;
  end

  // Source address register logic
  always_ff @(posedge clk or negedge nreset) begin
    if (!nreset)
      srcaddr_reg <= {AW{1'b0}};
    else if (src0_write)
      srcaddr_reg[31:0] <= data_in;
    else if (src1_write)
      srcaddr_reg[63:32] <= data_in;
    else if (update)
      srcaddr_reg <= srcaddr;
  end

  // Destination address register logic
  always_ff @(posedge clk or negedge nreset) begin
    if (!nreset)
      dstaddr_reg <= {AW{1'b0}};
    else if (dst0_write)
      dstaddr_reg[31:0] <= data_in;
    else if (dst1_write)
      dstaddr_reg[63:32] <= data_in;
    else if (update)
      dstaddr_reg <= dstaddr;
  end

  // Status register update
  always_ff @(posedge clk or negedge nreset) begin
    if (!nreset)
      status_reg <= 32'd0;
    else if (status_write)
      status_reg <= data_in;
    else if (config_write)
      status_reg <= {next_descr, 12'd0, dma_state};
  end

  assign curr_descr = status_reg[31:16];

  // secure registers
  always @(posedge clk or negedge nreset) begin
    if (!nreset) begin
      secure_base_reg <= {(AW-1){1'b0}};
      secure_mask_reg <= {(AW-1){1'b0}};
    end 
    else if (secbase_write) 
      secure_base_reg <= data_in[AW-1:0];
    else if (secmask_write) 
      secure_mask_reg <= data_in[AW-1:0];
  end

  // Register readback (pass through fetch packet)
  assign reg_wait_out   = 1'b0;
  assign reg_access_out = fetch_access;
  assign reg_packet_out = fetch_packet;


  // IRQ output (not used, hardwired to 0)
  assign irq = 1'b0;

endmodule
