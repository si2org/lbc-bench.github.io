import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
import random



SPI_REG = {
    "CPOL": 0x00,
    "CPHA": 0x04,
    "CHIP_SELECT": 0x08,
    "CLOCK_CONF": 0x0C,
    "WDATA": 0x10,
    "BUSY": 0x18
}


async def reset_dut(dut):
    dut.reset.value = 1
    await RisingEdge(dut.clock)
    await RisingEdge(dut.clock)
    dut.reset.value = 0
    await RisingEdge(dut.clock)


async def write_reg(dut, addr, data):
    dut.rw_address.value = addr
    dut.write_data.value = data
    dut.write_strobe.value = 0xF
    dut.write_request.value = 1
    await RisingEdge(dut.clock)
    dut.write_request.value = 0
    for _ in range(10):
        await RisingEdge(dut.clock)
        if dut.write_response.value.is_resolvable and int(dut.write_response.value) == 1:
            return
    raise Exception(f"Timeout waiting for write_response at addr 0x{addr:02X}")


async def read_reg(dut, addr):
    dut.rw_address.value = addr
    dut.read_request.value = 1
    await RisingEdge(dut.clock)
    dut.read_request.value = 0
    for _ in range(10):
        await RisingEdge(dut.clock)
        if dut.read_response.value.is_resolvable and int(dut.read_response.value) == 1:
            return int(dut.read_data.value)
    raise Exception(f"Timeout waiting for read_response at addr 0x{addr:02X}")


@cocotb.test()
async def test_TC01_cpol_write_read(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    await write_reg(dut, SPI_REG["CPOL"], 0)
    assert await read_reg(dut, SPI_REG["CPOL"]) == 0


@cocotb.test()
async def test_TC02_cpha_write_read(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    await write_reg(dut, SPI_REG["CPHA"], 0)
    assert await read_reg(dut, SPI_REG["CPHA"]) == 0


@cocotb.test()
async def test_TC03_chip_select_variety(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    for cs in [0x00, 0x01, 0xFF]:
        await write_reg(dut, SPI_REG["CHIP_SELECT"], cs)
        assert await read_reg(dut, SPI_REG["CHIP_SELECT"]) == cs


@cocotb.test()
async def test_TC04_clock_conf_sweep(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    for div in [2, 4, 8, 16, 32, 64]:
        await write_reg(dut, SPI_REG["CLOCK_CONF"], div)
        assert await read_reg(dut, SPI_REG["CLOCK_CONF"]) == div


@cocotb.test()
async def test_TC05_busy_before_after_wdata(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    await write_reg(dut, SPI_REG["CHIP_SELECT"], 0x00)
    assert await read_reg(dut, SPI_REG["BUSY"]) == 0
    await write_reg(dut, SPI_REG["WDATA"], 0xAA)
    assert await read_reg(dut, SPI_REG["BUSY"]) == 1


@cocotb.test()
async def test_TC06_multiple_wdata(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    await write_reg(dut, SPI_REG["CHIP_SELECT"], 0x00)
    for data in [0x11, 0x22, 0x33, 0x44]:
        await write_reg(dut, SPI_REG["WDATA"], data)
        assert await read_reg(dut, SPI_REG["BUSY"]) == 1


@cocotb.test()
async def test_TC07_reset_and_rewrite(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    await write_reg(dut, SPI_REG["CHIP_SELECT"], 0x00)
    await write_reg(dut, SPI_REG["WDATA"], 0x5A)
    assert await read_reg(dut, SPI_REG["BUSY"]) == 1


@cocotb.test()
async def test_TC08_register_unmodified_if_no_write(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    await write_reg(dut, SPI_REG["CPOL"], 0)
    assert await read_reg(dut, SPI_REG["CPOL"]) == 0


@cocotb.test()
async def test_TC09_partial_strobe_blocked(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    await write_reg(dut, SPI_REG["CPOL"], 0)
    dut.rw_address.value = SPI_REG["CPOL"]
    dut.write_data.value = 1
    dut.write_strobe.value = 0x0  # Disabled
    dut.write_request.value = 1
    await RisingEdge(dut.clock)
    dut.write_request.value = 0
    for _ in range(5): await RisingEdge(dut.clock)
    assert await read_reg(dut, SPI_REG["CPOL"]) == 0


@cocotb.test()
async def test_TC10_rapid_wdata_on_idle(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    await write_reg(dut, SPI_REG["CHIP_SELECT"], 0x00)
    for val in range(3):
        await write_reg(dut, SPI_REG["WDATA"], val * 0x11)
        assert await read_reg(dut, SPI_REG["BUSY"]) == 1


@cocotb.test()
async def test_TC11_loop_chip_select(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    for cs in range(0, 256, 17):  # Test CS every ~17 values
        await write_reg(dut, SPI_REG["CHIP_SELECT"], cs)
        assert await read_reg(dut, SPI_REG["CHIP_SELECT"]) == cs


@cocotb.test()
async def test_TC12_loop_clock_conf(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    for clkdiv in [0, 1, 2, 3, 4, 8, 15, 31, 63, 127, 255]:  # Boundary + edge values
        await write_reg(dut, SPI_REG["CLOCK_CONF"], clkdiv)
        assert await read_reg(dut, SPI_REG["CLOCK_CONF"]) == clkdiv

@cocotb.test()
async def test_TC13_max_min_config(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    for cpol in [0, 1]:
        await write_reg(dut, SPI_REG["CPOL"], cpol)
        assert await read_reg(dut, SPI_REG["CPOL"]) == cpol
    for cpha in [0, 1]:
        await write_reg(dut, SPI_REG["CPHA"], cpha)
        assert await read_reg(dut, SPI_REG["CPHA"]) == cpha
    for clk in [0x00, 0xFF]:
        await write_reg(dut, SPI_REG["CLOCK_CONF"], clk)
        assert await read_reg(dut, SPI_REG["CLOCK_CONF"]) == clk


@cocotb.test()
async def test_TC14_random_config_combo(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    for _ in range(10):
        cpol = random.randint(0, 1)
        cpha = random.randint(0, 1)
        clkconf = random.randint(0, 255)
        await write_reg(dut, SPI_REG["CPOL"], cpol)
        await write_reg(dut, SPI_REG["CPHA"], cpha)
        await write_reg(dut, SPI_REG["CLOCK_CONF"], clkconf)
        assert await read_reg(dut, SPI_REG["CPOL"]) == cpol
        assert await read_reg(dut, SPI_REG["CPHA"]) == cpha
        assert await read_reg(dut, SPI_REG["CLOCK_CONF"]) == clkconf

@cocotb.test()
async def test_chip_select_cs_00(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    dut._log.info("Writing CHIP_SELECT = 0x00")
    await write_reg(dut, SPI_REG["CHIP_SELECT"], 0)
    read_val = await read_reg(dut, SPI_REG["CHIP_SELECT"])
    dut._log.info(f"Read CHIP_SELECT = 0x{read_val:02X}")
    assert read_val == 0

@cocotb.test()
async def test_chip_select_cs_20(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    dut._log.info("Writing CHIP_SELECT = 0x20")
    await write_reg(dut, SPI_REG["CHIP_SELECT"], 32)
    read_val = await read_reg(dut, SPI_REG["CHIP_SELECT"])
    dut._log.info(f"Read CHIP_SELECT = 0x{read_val:02X}")
    assert read_val == 32

@cocotb.test()
async def test_chip_select_cs_40(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    dut._log.info("Writing CHIP_SELECT = 0x40")
    await write_reg(dut, SPI_REG["CHIP_SELECT"], 64)
    read_val = await read_reg(dut, SPI_REG["CHIP_SELECT"])
    dut._log.info(f"Read CHIP_SELECT = 0x{read_val:02X}")
    assert read_val == 64

@cocotb.test()
async def test_random_combo_0(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    cpol, cpha, clk = random.randint(0, 1), random.randint(0, 1), random.randint(0, 255)
    dut._log.info(f"Random config: CPOL={cpol}, CPHA={cpha}, CLK={clk}")
    await write_reg(dut, SPI_REG["CPOL"], cpol)
    await write_reg(dut, SPI_REG["CPHA"], cpha)
    await write_reg(dut, SPI_REG["CLOCK_CONF"], clk)
    assert await read_reg(dut, SPI_REG["CPOL"]) == cpol
    assert await read_reg(dut, SPI_REG["CPHA"]) == cpha
    assert await read_reg(dut, SPI_REG["CLOCK_CONF"]) == clk

@cocotb.test()
async def test_random_combo_1(dut):
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    cpol, cpha, clk = random.randint(0, 1), random.randint(0, 1), random.randint(0, 255)
    dut._log.info(f"Random config: CPOL={cpol}, CPHA={cpha}, CLK={clk}")
    await write_reg(dut, SPI_REG["CPOL"], cpol)
    await write_reg(dut, SPI_REG["CPHA"], cpha)
    await write_reg(dut, SPI_REG["CLOCK_CONF"], clk)
    assert await read_reg(dut, SPI_REG["CPOL"]) == cpol
    assert await read_reg(dut, SPI_REG["CPHA"]) == cpha
    assert await read_reg(dut, SPI_REG["CLOCK_CONF"]) == clk
@cocotb.test()
async def test_TC15_multiple_chip_selects(dut):
    """Test chip select values using loop for all power-of-two patterns"""
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    for i in range(8):
        cs_val = 1 << i  # 0x01, 0x02, ..., 0x80
        await write_reg(dut, SPI_REG["CHIP_SELECT"], cs_val)
        result = await read_reg(dut, SPI_REG["CHIP_SELECT"])
        assert result == cs_val
        dut._log.info(f"CHIP_SELECT = 0x{cs_val:02X} verified")


@cocotb.test()
async def test_TC16_increment_clock_div(dut):
    """Increment clock divider in steps to check internal counter load"""
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    for clkdiv in range(0, 256, 16):  # 0, 16, ..., 240
        await write_reg(dut, SPI_REG["CLOCK_CONF"], clkdiv)
        read_val = await read_reg(dut, SPI_REG["CLOCK_CONF"])
        assert read_val == clkdiv
        dut._log.info(f"CLOCK_CONF = {clkdiv} verified")


@cocotb.test()
async def test_TC17_cpol_cpha_flip_flop(dut):
    """Alternate CPOL/CPHA across combinations repeatedly"""
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    for cycle in range(6):
        cpol = cycle % 2
        cpha = (cycle + 1) % 2
        await write_reg(dut, SPI_REG["CPOL"], cpol)
        await write_reg(dut, SPI_REG["CPHA"], cpha)
        assert await read_reg(dut, SPI_REG["CPOL"]) == cpol
        assert await read_reg(dut, SPI_REG["CPHA"]) == cpha
        dut._log.info(f"Cycle {cycle}: CPOL={cpol}, CPHA={cpha}")

@cocotb.test()
async def test_TC18_repeat_edge_case_values(dut):
    """Repeat testing extreme boundary values multiple times"""
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)
    edge_values = [0x00, 0xFF]
    for i in range(5):
        for reg, val in [(SPI_REG["CPOL"], 0), (SPI_REG["CPOL"], 1),
                         (SPI_REG["CPHA"], 0), (SPI_REG["CPHA"], 1),
                         (SPI_REG["CLOCK_CONF"], 0x00), (SPI_REG["CLOCK_CONF"], 0xFF)]:
            await write_reg(dut, reg, val)
            r = await read_reg(dut, reg)
            assert r == val
            dut._log.info(f"Loop {i}: Reg 0x{reg:02X} = {val} verified")

@cocotb.test()
async def test_TC19_chip_select_bit_flip(dut):
    """Flip one bit at a time in CHIP_SELECT"""
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)

    cs_val = 0x00
    for bit in range(8):
        cs_val ^= (1 << bit)  # toggle one bit
        await write_reg(dut, SPI_REG["CHIP_SELECT"], cs_val)
        r = await read_reg(dut, SPI_REG["CHIP_SELECT"])
        assert r == cs_val
        dut._log.info(f"CHIP_SELECT toggled to 0x{cs_val:02X}")
        
@cocotb.test()
async def test_TC20_clock_conf_gray_code(dut):
    """Use 4-bit gray code patterns in CLOCK_CONF"""
    gray_codes = [0x0, 0x1, 0x3, 0x2, 0x6, 0x7, 0x5, 0x4, 0xC, 0xD, 0xF, 0xE, 0xA, 0xB, 0x9, 0x8]
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)

    for val in gray_codes:
        await write_reg(dut, SPI_REG["CLOCK_CONF"], val)
        r = await read_reg(dut, SPI_REG["CLOCK_CONF"])
        assert r == val
        dut._log.info(f"CLOCK_CONF gray step = {val:02X}")

@cocotb.test()
async def test_TC21_toggle_write_strobe_masking(dut):
    """Try valid vs invalid write_strobe toggles"""
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)

    for mask in [0xF, 0x0, 0x5, 0xA, 0x3, 0xC]:  # mix of full, none, and partial
        dut.rw_address.value = SPI_REG["CPHA"]
        dut.write_data.value = 1
        dut.write_strobe.value = mask
        dut.write_request.value = 1
        await RisingEdge(dut.clock)
        dut.write_request.value = 0
        await RisingEdge(dut.clock)

        val = await read_reg(dut, SPI_REG["CPHA"])
        if mask == 0xF:
            assert val == 1
        else:
            assert val in [0, 1]  # relaxed due to partial masking
        dut._log.info(f"Write_strobe=0x{mask:X}, CPHA readback={val}")

@cocotb.test()
async def test_TC22_clock_conf_bit_rotation(dut):
    """Rotate one-hot bit through CLOCK_CONF"""
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)

    for i in range(8):
        val = 1 << i
        await write_reg(dut, SPI_REG["CLOCK_CONF"], val)
        r = await read_reg(dut, SPI_REG["CLOCK_CONF"])
        assert r == val
        dut._log.info(f"CLOCK_CONF = 0x{val:02X} (bit {i} set)")
        
   
@cocotb.test()
async def test_TC24_alternating_cpha_write_verify(dut):
    """Toggle CPHA back and forth and verify stability across multiple writes."""
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)

    for i in range(10):
        val = i % 2
        await write_reg(dut, SPI_REG["CPHA"], val)
        read_back = await read_reg(dut, SPI_REG["CPHA"])
        assert read_back == val, f"Expected CPHA={val}, got {read_back}"
        dut._log.info(f"[{i}] CPHA toggled to {val}")

@cocotb.test()
async def test_TC25_chip_select_descending_pattern(dut):
    """Write descending chip select pattern from 0xFF to 0x00 in steps."""
    cocotb.start_soon(Clock(dut.clock, 10, unit="ns").start())
    await reset_dut(dut)

    for cs in range(0xFF, -1, -32):  # 0xFF, 0xDF, ..., 0x1F, 0x00
        await write_reg(dut, SPI_REG["CHIP_SELECT"], cs)
        r = await read_reg(dut, SPI_REG["CHIP_SELECT"])
        assert r == cs, f"Expected CS=0x{cs:02X}, got 0x{r:02X}"
        dut._log.info(f"CHIP_SELECT set to 0x{cs:02X} (descending test)")
