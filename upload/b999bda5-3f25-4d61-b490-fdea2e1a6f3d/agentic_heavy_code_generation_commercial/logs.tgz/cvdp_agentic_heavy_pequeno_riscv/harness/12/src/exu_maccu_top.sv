//#######################################################################
//  exu_maccu_top.sv   –  Wrapper used only for assertion simulation
//#######################################################################
`include "/code/src/include/pqr5_core_macros.svh"
import pqr5_core_pkg::*;

module exu_maccu_top #(
   parameter PC_INIT = `PC_INIT
)(
   //--------------------------------------------------------------------
   // Clock / Reset
   //--------------------------------------------------------------------
   input  logic clk,
   input  logic aresetn,

   //--------------------------------------------------------------------
   // ❶  Operand inputs driven by the test-bench
   //--------------------------------------------------------------------
   input  logic [`XLEN-1:0] op0,
   input  logic [`XLEN-1:0] op1,

   //--------------------------------------------------------------------
   // ❷  “Decode-stage” signals (all driven from the test-bench)
   //--------------------------------------------------------------------
   input  logic [`XLEN-1:0] du_pc,
   input  logic [`ILEN-1:0] du_instr,
   input  logic             du_bubble,

   input  logic [6:0]       du_opcode,
   input  logic [3:0]       du_alu_opcode,
   input  logic [4:0]       du_rs0,
   input  logic [4:0]       du_rs1,
   input  logic [4:0]       du_rdt,
   input  logic             du_rdt_not_x0,
   input  logic [2:0]       du_funct3,

   input  logic             du_is_r_type,
   input  logic             du_is_i_type,
   input  logic             du_is_s_type,
   input  logic             du_is_b_type,
   input  logic             du_is_u_type,
   input  logic             du_is_j_type,
   input  logic             du_is_risb,
   input  logic             du_is_riuj,
   input  logic             du_is_jalr,
   input  logic             du_is_load,
   input  logic             du_is_lui,

   input  logic [11:0]      du_i_type_imm,
   input  logic [11:0]      du_s_type_imm,
   input  logic [11:0]      du_b_type_imm,
   input  logic [19:0]      du_u_type_imm,
   input  logic [19:0]      du_j_type_imm,

   output logic             du_stall,         // back-pressure from EXU

   //--------------------------------------------------------------------
   // ❸  Data-Memory interface (visible to TB)
   //--------------------------------------------------------------------
   //  → DMEM request side
   output logic             dmem_wen,
   output logic [`XLEN-1:0] dmem_addr,
   output logic [1:0]       dmem_size,
   output logic [`XLEN-1:0] dmem_wdata,
   output logic             dmem_req,
   output logic             dmem_flush,
   //  ← DMEM back-pressure & read data
   input  logic             dmem_stall,
   input  logic [`XLEN-1:0] dmem_rdata,
   input  logic             dmem_ack,

   //--------------------------------------------------------------------
   // ❹  Write-Back-Unit back-pressure & observation
   //--------------------------------------------------------------------
   input  logic             wbu_stall,

   //  → outputs *from* MACCU towards WBU that a TB may inspect
   output logic [`XLEN-1:0] wbu_pc,
   output logic [`ILEN-1:0] wbu_instr,
   output logic             wbu_is_riuj,
   output logic             wbu_bubble,
   output logic [4:0]       wbu_rdt_addr,
   output logic [`XLEN-1:0] wbu_rdt_data,
   output logic             wbu_rdt_not_x0,
   output logic             wbu_is_macc,
   output logic             wbu_is_load,
   output logic             wbu_is_dwback,
   output logic [`XLEN-1:0] wbu_macc_addr
);

   //--------------------------------------------------------------------
   //  Internal wires connecting EXU ⇄ MACCU
   //--------------------------------------------------------------------
   logic             exu_stall_to_du;

   // EXU → MACCU payload
   logic [`XLEN-1:0] exu2maccu_pc;
   logic [`ILEN-1:0] exu2maccu_instr;
   logic             exu2maccu_is_riuj;
   logic             exu2maccu_bubble;

   logic [4:0]       exu2maccu_rdt_addr;
   logic [`XLEN-1:0] exu2maccu_rdt_data;
   logic             exu2maccu_rdt_not_x0;

   logic             exu2maccu_is_macc_op;
   logic             exu2maccu_macc_cmd;
   logic [`XLEN-1:0] exu2maccu_macc_addr;
   logic [1:0]       exu2maccu_macc_size;
   logic [`XLEN-1:0] exu2maccu_macc_data;

   // MACCU → EXU stall
   logic             maccu_stall_to_exu;

   //--------------------------------------------------------------------
   //  Execution-Unit instance
   //--------------------------------------------------------------------
   execution_unit #(.PC_INIT(PC_INIT)) u_exu (
      .clk                (clk),
      .aresetn            (aresetn),

      // debug – left open
      .o_exu_dbg          (),

      // operands
      .i_op0              (op0),
      .i_op1              (op1),

      // branch-unit side (tie-offs)
      .o_exu_bu_flush     (),
      .o_exu_bu_pc        (),
      .i_exu_bu_br_taken  (1'b0),

      // DU → EXU
      .i_du_pc            (du_pc),
      .i_du_instr         (du_instr),
      .i_du_bubble        (du_bubble),
      .o_du_stall         (du_stall),

      .i_du_opcode        (du_opcode),
      .i_du_alu_opcode    (du_alu_opcode),
      .i_du_rs0           (du_rs0),
      .i_du_rs1           (du_rs1),
      .i_du_rdt           (du_rdt),
      .i_du_rdt_not_x0    (du_rdt_not_x0),
      .i_du_funct3        (du_funct3),

      .i_du_is_r_type     (du_is_r_type),
      .i_du_is_i_type     (du_is_i_type),
      .i_du_is_s_type     (du_is_s_type),
      .i_du_is_b_type     (du_is_b_type),
      .i_du_is_u_type     (du_is_u_type),
      .i_du_is_j_type     (du_is_j_type),
      .i_du_is_risb       (du_is_risb),
      .i_du_is_riuj       (du_is_riuj),
      .i_du_is_jalr       (du_is_jalr),
      .i_du_is_load       (du_is_load),
      .i_du_is_lui        (du_is_lui),
      .i_du_i_type_imm    (du_i_type_imm),
      .i_du_s_type_imm    (du_s_type_imm),
      .i_du_b_type_imm    (du_b_type_imm),
      .i_du_u_type_imm    (du_u_type_imm),
      .i_du_j_type_imm    (du_j_type_imm),

      // EXU → MACCU interface
      .o_maccu_pc         (exu2maccu_pc),
      .o_maccu_instr      (exu2maccu_instr),
      .o_maccu_is_riuj    (exu2maccu_is_riuj),
      .o_maccu_bubble     (exu2maccu_bubble),
      .i_maccu_stall      (maccu_stall_to_exu),

      .o_maccu_rdt_addr   (exu2maccu_rdt_addr),
      .o_maccu_rdt_data   (exu2maccu_rdt_data),
      .o_maccu_rdt_not_x0 (exu2maccu_rdt_not_x0),

      .o_maccu_is_macc_op (exu2maccu_is_macc_op),
      .o_maccu_macc_cmd   (exu2maccu_macc_cmd),
      .o_maccu_macc_addr  (exu2maccu_macc_addr),
      .o_maccu_macc_size  (exu2maccu_macc_size),
      .o_maccu_macc_data  (exu2maccu_macc_data)
   );

   //--------------------------------------------------------------------
   //  Memory-Access-Unit instance
   //--------------------------------------------------------------------
   memory_access_unit #(.PC_INIT(PC_INIT)) u_maccu (
      .clk                (clk),
      .aresetn            (aresetn),

      // EXU → MACCU (connected wires)
      .i_exu_pc           (exu2maccu_pc),
      .i_exu_instr        (exu2maccu_instr),
      .i_exu_is_riuj      (exu2maccu_is_riuj),
      .i_exu_bubble       (exu2maccu_bubble),
      .o_exu_stall        (maccu_stall_to_exu),

      .i_exu_rdt_addr     (exu2maccu_rdt_addr),
      .i_exu_rdt_data     (exu2maccu_rdt_data),
      .i_exu_rdt_not_x0   (exu2maccu_rdt_not_x0),

      .i_exu_is_macc_op   (exu2maccu_is_macc_op),
      .i_exu_macc_cmd     (exu2maccu_macc_cmd),
      .i_exu_macc_addr    (exu2maccu_macc_addr),
      .i_exu_macc_size    (exu2maccu_macc_size),
      .i_exu_macc_data    (exu2maccu_macc_data),

      // DMEMIF side (promote to top ports)
      .o_dmem_wen         (dmem_wen),
      .o_dmem_addr        (dmem_addr),
      .o_dmem_size        (dmem_size),
      .o_dmem_wdata       (dmem_wdata),
      .o_dmem_req         (dmem_req),
      .i_dmem_stall       (dmem_stall),
      .o_dmem_flush       (dmem_flush),

      // // incoming data/ack from DMEM (top → MACCU)
      // .i_dmem_rdata       (dmem_rdata),
      // .i_dmem_ack         (dmem_ack),

      // to WBU (promote to top ports)
      .o_wbu_pc           (wbu_pc),
      .o_wbu_instr        (wbu_instr),
      .o_wbu_is_riuj      (wbu_is_riuj),
      .o_wbu_bubble       (wbu_bubble),
      .i_wbu_stall        (wbu_stall),
      .o_wbu_rdt_addr     (wbu_rdt_addr),
      .o_wbu_rdt_data     (wbu_rdt_data),
      .o_wbu_rdt_not_x0   (wbu_rdt_not_x0),
      .o_wbu_is_macc      (wbu_is_macc),
      .o_wbu_is_load      (wbu_is_load),
      .o_wbu_is_dwback    (wbu_is_dwback),
      .o_wbu_macc_addr    (wbu_macc_addr)
   );

endmodule
//#######################################################################
