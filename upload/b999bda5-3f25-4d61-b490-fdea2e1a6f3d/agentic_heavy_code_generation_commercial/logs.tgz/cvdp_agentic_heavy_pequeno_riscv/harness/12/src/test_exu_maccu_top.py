# verif/test_exu_maccu_top.py
#
# Stimulates exu_maccu_top so that every interface-level assertion inside
# execution_unit.sv and memory_access_unit.sv is evaluated and passes.

import cocotb
from  cocotb.clock    import Clock
from  cocotb.triggers import RisingEdge, Timer


CLK_NS = 10   # 100 MHz


# -----------------------------------------------------------------------------
#  Helpers
# -----------------------------------------------------------------------------
async def idle_cycle(dut, bubbles: int = 1):
    """Drive one-or-more bubble cycles on the Decode interface."""
    dut.du_bubble.value       = 1
    dut.du_is_r_type.value    = 0
    dut.du_is_i_type.value    = 0
    dut.du_is_s_type.value    = 0
    dut.du_is_b_type.value    = 0
    dut.du_is_u_type.value    = 0
    dut.du_is_j_type.value    = 0
    dut.du_is_load.value      = 0
    dut.du_is_lui.value       = 0
    dut.du_rs0.value          = 0
    dut.du_rs1.value          = 0
    dut.du_rdt.value          = 0
    dut.du_rdt_not_x0.value   = 0
    dut.du_instr.value        = 0
    dut.du_opcode.value       = 0

    for _ in range(bubbles):
        await RisingEdge(dut.clk)


def set_decode_defaults(dut):
    """Initialise / clear every DU input once."""
    dut.du_pc.value           = 0
    dut.du_instr.value        = 0
    dut.du_bubble.value       = 0
    dut.du_opcode.value       = 0
    dut.du_alu_opcode.value   = 0
    dut.du_rs0.value          = 0
    dut.du_rs1.value          = 0
    dut.du_rdt.value          = 0
    dut.du_rdt_not_x0.value   = 0
    dut.du_funct3.value       = 0
    dut.du_is_r_type.value    = 0
    dut.du_is_i_type.value    = 0
    dut.du_is_s_type.value    = 0
    dut.du_is_b_type.value    = 0
    dut.du_is_u_type.value    = 0
    dut.du_is_j_type.value    = 0
    dut.du_is_risb.value      = 0
    dut.du_is_riuj.value      = 0
    dut.du_is_jalr.value      = 0
    dut.du_is_load.value      = 0
    dut.du_is_lui.value       = 0
    dut.du_i_type_imm.value   = 0
    dut.du_s_type_imm.value   = 0
    dut.du_b_type_imm.value   = 0
    dut.du_u_type_imm.value   = 0
    dut.du_j_type_imm.value   = 0
    dut.op0.value             = 0
    dut.op1.value             = 0


async def drive_direct_wb(dut, pc, rd, data):
    """Issue a ‘direct write-back’ (fake R-type ADD)."""
    set_decode_defaults(dut)
    dut.du_pc.value         = pc
    dut.du_instr.value      = 0x33          # R-type opcode
    dut.du_is_r_type.value  = 1
    dut.du_rs0.value        = 1
    dut.du_rs1.value        = 2
    dut.du_rdt.value        = rd
    dut.du_rdt_not_x0.value = 1
    dut.du_alu_opcode.value = 0            # ADD
    dut.op0.value           = data
    dut.op1.value           = 0x1
    await RisingEdge(dut.clk)


async def drive_store(dut, pc, addr, data):
    """Issue an S-type store."""
    set_decode_defaults(dut)
    dut.du_pc.value          = pc
    dut.du_instr.value       = 0x23        # S-type opcode
    dut.du_is_s_type.value   = 1
    dut.du_funct3.value      = 0b010       # word
    dut.du_s_type_imm.value  = addr & 0xFFF
    dut.du_rs0.value         = 1
    dut.du_rs1.value         = 2
    dut.op0.value            = addr        # base addr
    dut.op1.value            = data
    await RisingEdge(dut.clk)


async def drive_load(dut, pc, addr):
    """Issue an I-type load."""
    set_decode_defaults(dut)
    dut.du_pc.value          = pc
    dut.du_instr.value       = 0x03        # I-type load opcode
    dut.du_is_i_type.value   = 1
    dut.du_is_load.value     = 1
    dut.du_funct3.value      = 0b010       # word
    dut.du_i_type_imm.value  = addr & 0xFFF
    dut.du_rs0.value         = 1
    dut.du_rdt.value         = 3
    dut.du_rdt_not_x0.value  = 1
    dut.op0.value            = addr
    dut.op1.value            = 0
    await RisingEdge(dut.clk)


# -----------------------------------------------------------------------------
#  Main test
# -----------------------------------------------------------------------------
@cocotb.test()
async def exu_maccu_assertion_coverage(dut):
    """Cover all interface assertions in EXU ↔ MACCU path (no failures)."""

    # Create clock
    cocotb.start_soon(Clock(dut.clk, CLK_NS, unit="ns", period_high=(CLK_NS+1)//2 if CLK_NS%2 else CLK_NS//2).start())

    # Apply reset
    dut.aresetn.value = 0
    await Timer(5 * CLK_NS, unit="ns")
    dut.aresetn.value = 1
    await RisingEdge(dut.clk)

    # Default values
    dut.dmem_rdata.value = 0
    dut.dmem_ack.value   = 0
    dut.dmem_stall.value = 0
    dut.wbu_stall.value  = 0
    set_decode_defaults(dut)
    await idle_cycle(dut, 2)

    # 1) Direct write-back
    await drive_direct_wb(dut, pc=0x0, rd=5, data=0x1111_2222)
    await idle_cycle(dut, 4)

    # 2) Store
    await drive_store(dut, pc=0x10, addr=0x1000_0000, data=0xA5A5_A5A5)
    await idle_cycle(dut, 4)

    # 3) Load with one-cycle ACK
    await drive_load(dut, pc=0x20, addr=0x1000_0004)
    await RisingEdge(dut.clk)             # request issued
    dut.dmem_rdata.value = 0xDEAD_BEEF
    dut.dmem_ack.value   = 1
    await RisingEdge(dut.clk)
    dut.dmem_ack.value   = 0
    await idle_cycle(dut, 4)

    # 4) External WBU stall during direct WB
    dut.wbu_stall.value = 1
    await drive_direct_wb(dut, pc=0x30, rd=6, data=0x3333_4444)
    await idle_cycle(dut, 3)
    dut.wbu_stall.value = 0
    await idle_cycle(dut, 4)

    # Finish
    await idle_cycle(dut, 10)
    dut._log.info("Simulation completed – all interface assertions covered & held.")
