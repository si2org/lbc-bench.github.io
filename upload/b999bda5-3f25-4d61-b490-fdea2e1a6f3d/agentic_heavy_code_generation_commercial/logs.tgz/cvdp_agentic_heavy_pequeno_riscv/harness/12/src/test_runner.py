import os
import re
import subprocess
import pytest
from cocotb_tools.runner import get_runner

# Fetch environment variables for Verilog source setup
verilog_sources = os.getenv("VERILOG_SOURCES", "").split()
toplevel_lang   = os.getenv("TOPLEVEL_LANG")
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = os.getenv("WAVE")

@pytest.mark.usefixtures(scope='session')
def test_simulate():
    """Run the simulation."""
    runner = get_runner(sim)

    # Enable full assertion coverage collection
    build_args = [
        "-coverage", "all",
        "-covoverwrite",
        "-covtest", "test",
    ]

    runner.build(
        sources=verilog_sources,
        hdl_toplevel=toplevel,
        always=True,
        clean=True,
        verbose=True,
        build_args=build_args,
        timescale=("1ns", "1ns"),
        log_file="build.log"
    )

    runner.test(
        hdl_toplevel=toplevel,
        test_module=module,
        waves=True,
        test_args=[]
    )

def test_coverage():
    """Merge and report assertion coverage for all modules."""
    cmd = (
        "imc -load /rundir/sim_build/cov_work/scope/test "
        "-execcmd \"report -metrics assertion -all -aspect sim "
        "-assertionStatus -overwrite -text -out coverage.log\""
    )
    result = subprocess.run(cmd, shell=True)
    assert result.returncode == 0, "Coverage merge didn't run correctly."

@pytest.mark.usefixtures(scope='test_coverage')
def test_report():
    """Parse coverage.log and ensure submodules meet the TARGET assertion coverage."""
    # Read and parse the coverage file
    with open("/rundir/coverage.log") as f:
        lines = f.readlines()

    # The first line has column headers, split on two or more spaces
    column_names = re.split(r'\s{2,}', lines[0].strip())

    metrics = {}
    for line in lines[2:]:
        fields = re.split(r'\s{2,}', line.strip())
        inst_name = fields[0].lstrip('|-')
        # Map each column to its percentage (strip the '%' suffix)
        metrics[inst_name] = {
            column_names[i]: fields[i].split('%')[0]
            for i in range(1, len(column_names))
        }

    print("Metrics:")
    print(metrics)

    top = os.getenv("TOPLEVEL")
    target = float(os.getenv("TARGET", "0"))

    top_metrics = metrics.get(top, {})

    # If the top level's own assertions are "n/a", ignore them and check only sub‐modules
    if top_metrics.get("Assertion", "n/a") == "n/a":
        submodules = [inst for inst in metrics.keys() if inst != top]
        assert submodules, f"No sub‐modules found under {top} to check coverage"
        for inst in submodules:
            cov = float(metrics[inst]["Assertion"])
            assert cov >= target, (
                f"{inst} assertion coverage {cov}% < target {target}%"
            )
    else:
        # Otherwise, require the top‐level itself meets TARGET
        if "Overall Average" in top_metrics:
            value = float(top_metrics["Overall Average"])
        else:
            value = float(top_metrics.get("Assertion", "0"))
        assert value >= target, (
            f"{top} assertion coverage {value}% < target {target}%"
        )
