import cocotb
import os
import harness_library as hrs_lb
import random
import pytest
from cocotb_tools.runner import get_runner

# Environment configuration
verilog_sources = os.getenv("VERILOG_SOURCES").split()
toplevel_lang   = os.getenv("TOPLEVEL_LANG")
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = bool(os.getenv("WAVE"))

def call_runner():
    try:
        args = []
        if sim == "xcelium":
            args = ( "-sv", "-svseed random")

        hrs_lb.runner(
            wave=wave,
            toplevel=toplevel,
            module=module,
            src=verilog_sources,
            sim=sim,
            args=args
        )
    except SystemExit:
        # hrs_lb.save_vcd(wave, toplevel, new_name=f"prioroty_encoder_{tst_seq}_test")
        raise SystemError("simulation failed due to assertion failed in your test")

def test_data():
     # Run the simulation
     call_runner()