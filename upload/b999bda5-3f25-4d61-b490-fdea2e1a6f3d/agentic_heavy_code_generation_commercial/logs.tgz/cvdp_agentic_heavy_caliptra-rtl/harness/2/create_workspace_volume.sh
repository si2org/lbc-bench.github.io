#!/bin/bash
# Auto-generated script to create workspace volume for context heavy datapoint
# Datapoint ID: 2
# Volume name: cvdp_agentic_heavy_caliptra-rtl_0002_workspace
# Repository: <home>/cvdp_benchmark_dataset/cvdp_v1.1.0_agentic_heavy_code_generation_public/cvdp_agentic_heavy_caliptra-rtl.bundle
# Commit: 938481cafe1ca9615de61a0f0614f1cccba0a88c

set -e

echo "Creating workspace volume for context heavy datapoint..."
echo "Volume name: cvdp_agentic_heavy_caliptra-rtl_0002_workspace"
echo "Repository: <home>/cvdp_benchmark_dataset/cvdp_v1.1.0_agentic_heavy_code_generation_public/cvdp_agentic_heavy_caliptra-rtl.bundle"
echo "Commit: 938481cafe1ca9615de61a0f0614f1cccba0a88c"

# Check if volume already exists
if docker volume inspect cvdp_agentic_heavy_caliptra-rtl_0002_workspace &>/dev/null; then
  echo "Volume cvdp_agentic_heavy_caliptra-rtl_0002_workspace already exists. Removing it first..."
  docker volume rm -f cvdp_agentic_heavy_caliptra-rtl_0002_workspace
fi

# Create Docker volume
echo "Creating Docker volume: cvdp_agentic_heavy_caliptra-rtl_0002_workspace"
docker volume create cvdp_agentic_heavy_caliptra-rtl_0002_workspace

# Look for existing git cache mirror
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK_DIR="$(dirname "$(dirname "$(dirname "$SCRIPT_DIR")")")"  # Go up to work directory
GIT_CACHE_DIR="$WORK_DIR/git_cache/mirrors"
MIRROR_DIR="$GIT_CACHE_DIR/46699072.git"

if [ ! -d "$MIRROR_DIR" ]; then
  echo "ERROR: Expected git cache mirror not found: $MIRROR_DIR"
  echo "Please run the benchmark with -l -g first to create the git cache."
  exit 1
fi
echo "Found git cache mirror: $MIRROR_DIR"

# Ensure patch_image Docker image exists
if ! docker image inspect patch_image &>/dev/null; then
  echo "Building patch_image Docker image..."
  TEMP_DOCKERFILE=$(mktemp)
  cat > "$TEMP_DOCKERFILE" << 'EOF'
FROM ubuntu:22.04
RUN apt update && apt install -y git
EOF
  docker build -t patch_image -f "$TEMP_DOCKERFILE" .
  rm "$TEMP_DOCKERFILE"
fi

# Create temporary directory for patches
PATCH_DIR=$(mktemp -d)
cleanup() {
  rm -rf "$PATCH_DIR"
}
trap cleanup EXIT

# Create patch.diff file (same format as GitRepositoryManager)
cat > "$PATCH_DIR/patch.diff" << 'PATCH_EOF'
PATCH_EOF

# Create safe patch application script
cat > "$PATCH_DIR/safe-apply.sh" << 'SCRIPT_EOF'
#!/bin/bash
PATCH="$1"
if [ -s "$PATCH" ]; then
	git apply -v "$PATCH"
else
	echo "Patch is empty, skipping apply."
fi
SCRIPT_EOF
chmod +x "$PATCH_DIR/safe-apply.sh"

# Setup git repository in volume using existing mirror
echo "Setting up workspace from git mirror..."
USER_ID=$(id -u)
GROUP_ID=$(id -g)
docker run --rm \
  -v "$MIRROR_DIR:/repo:ro" \
  -v "$PATCH_DIR:/patch:ro" \
  -v cvdp_agentic_heavy_caliptra-rtl_0002_workspace:/workspace \
  patch_image bash -c '
    set -ex
    mkdir /rundir && cd /rundir
    git config --global --add safe.directory /repo
    git init
    git remote add origin /repo
    git fetch --depth 1 origin 938481cafe1ca9615de61a0f0614f1cccba0a88c
    git checkout 938481cafe1ca9615de61a0f0614f1cccba0a88c
    bash /patch/safe-apply.sh /patch/patch.diff
    cp -a ./external/. /workspace/
    echo "Workspace setup complete"
'

# Fix volume ownership to current user
echo "Fixing volume ownership..."
docker run --rm \
  -v cvdp_agentic_heavy_caliptra-rtl_0002_workspace:/workspace \
  ubuntu:22.04 \
  chown -R "$USER_ID:$GROUP_ID" /workspace

echo "Workspace volume creation complete!"
echo "Volume cvdp_agentic_heavy_caliptra-rtl_0002_workspace is ready for use."
echo "You can now run the agent and harness scripts."
