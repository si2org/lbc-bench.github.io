import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock


@cocotb.test()
async def test_ptp_clock(dut):
    """Cocotb test for ptp_clock"""

    # Start clock
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    dut._log.info("Clock started")

    # Apply reset
    dut.rst.value = 1
    await Timer(50, unit="ns")
    dut.rst.value = 0
    await RisingEdge(dut.clk)
    dut._log.info("Reset released")

    # Wait for stabilization
    for _ in range(10):
        await RisingEdge(dut.clk)

    # Apply initial 96-bit timestamp
    dut.input_ts_96.value = 0x00000000000000000000
    dut.input_ts_96_valid.value = 1
    await RisingEdge(dut.clk)
    dut.input_ts_96_valid.value = 0
    dut._log.info("Initial 96-bit timestamp injected")

    await Timer(100, unit="ns")

    # Observe base timestamp
    ts_96_prev = int(dut.output_ts_96.value)
    ts_64_prev = int(dut.output_ts_64.value)

    # Log and monitor output over time
    for i in range(10):
        await RisingEdge(dut.clk)
        ts_96 = int(dut.output_ts_96.value)
        ts_64 = int(dut.output_ts_64.value)
        dut._log.info(f"[{i}] TS_96: {ts_96:024x}, TS_64: {ts_64:016x}, Step: {dut.output_ts_step.value}, PPS: {dut.output_pps.value}, AdjActive: {dut.input_adj_active.value}")
        assert ts_96 >= ts_96_prev, f"TS_96 is not monotonic at cycle {i}"
        assert ts_64 >= ts_64_prev, f"TS_64 is not monotonic at cycle {i}"
        ts_96_prev = ts_96
        ts_64_prev = ts_64

    # Apply period update
    dut.input_period_ns.value = 0xA
    dut.input_period_fns.value = 0x9999
    dut.input_period_valid.value = 1
    await RisingEdge(dut.clk)
    dut.input_period_valid.value = 0
    dut._log.info("Period updated")

    await Timer(100, unit="ns")

    # Apply offset adjustment
    dut.input_adj_ns.value = 1
    dut.input_adj_fns.value = 0x1111
    dut.input_adj_count.value = 5
    dut.input_adj_valid.value = 1
    await RisingEdge(dut.clk)
    dut.input_adj_valid.value = 0
    dut._log.info("Offset adjustment applied")

    await Timer(200, unit="ns")

    # Apply drift adjustment
    dut.input_drift_ns.value = 1
    dut.input_drift_fns.value = 0x0001
    dut.input_drift_rate.value = 0x0004
    dut.input_drift_valid.value = 1
    await RisingEdge(dut.clk)
    dut.input_drift_valid.value = 0
    dut._log.info("Drift adjustment applied")

    await Timer(500, unit="ns")

    # Final check
    ts_96_final = int(dut.output_ts_96.value)
    ts_64_final = int(dut.output_ts_64.value)
    dut._log.info(f"Final TS_96: {ts_96_final:024x}, TS_64: {ts_64_final:016x}")

    assert ts_96_final > ts_96_prev, "Final TS_96 did not increase"
    assert ts_64_final > ts_64_prev, "Final TS_64 did not increase"
    dut._log.info("Test completed successfully")
