#!/bin/bash
# Auto-generated script to destroy workspace volume for context heavy datapoint
# Datapoint ID: 6
# Volume name: cvdp_agentic_heavy_verilog_ethernet_0006_workspace

set -e

echo "Destroying workspace volume for context heavy datapoint..."
echo "Volume name: cvdp_agentic_heavy_verilog_ethernet_0006_workspace"

# Check if volume exists
if ! docker volume inspect cvdp_agentic_heavy_verilog_ethernet_0006_workspace &>/dev/null; then
  echo "Volume cvdp_agentic_heavy_verilog_ethernet_0006_workspace does not exist. Nothing to destroy."
  exit 0
fi

# Remove Docker volume
echo "Removing Docker volume: cvdp_agentic_heavy_verilog_ethernet_0006_workspace"
docker volume rm -f cvdp_agentic_heavy_verilog_ethernet_0006_workspace

echo "Workspace volume destruction complete!"
echo "Volume cvdp_agentic_heavy_verilog_ethernet_0006_workspace has been removed."
