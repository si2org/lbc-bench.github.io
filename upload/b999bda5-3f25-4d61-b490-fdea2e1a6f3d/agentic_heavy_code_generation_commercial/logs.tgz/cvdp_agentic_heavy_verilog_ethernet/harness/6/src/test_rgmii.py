import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock


def start_clocks(dut):
    cocotb.start_soon(Clock(dut.clk, 8, unit="ns").start())
    cocotb.start_soon(Clock(dut.clk90, 8, unit="ns").start())
    cocotb.start_soon(Clock(dut.phy_rgmii_rx_clk, 8, unit="ns").start())


async def reset_dut(dut):
    dut.rst.value = 1
    await Timer(100, unit="ns")
    dut.rst.value = 0
    await Timer(100, unit="ns")


async def send_phy_rx(dut, byte):
    dut.phy_rgmii_rxd.value = byte & 0x0F
    dut.phy_rgmii_rx_ctl.value = 1
    await RisingEdge(dut.phy_rgmii_rx_clk)

    dut.phy_rgmii_rxd.value = (byte >> 4) & 0x0F
    dut.phy_rgmii_rx_ctl.value = 0
    await RisingEdge(dut.phy_rgmii_rx_clk)
    await RisingEdge(dut.mac_gmii_rx_clk)
    await Timer(1, unit="ns")


async def send_mac_tx(dut, byte):
    dut.mac_gmii_txd.value = byte
    dut.mac_gmii_tx_en.value = 1
    dut.mac_gmii_tx_er.value = 0
    await Timer(40, unit="ns")
    dut.mac_gmii_tx_en.value = 0
    await Timer(40, unit="ns")


async def run_test(dut, rx_val, tx_val):
    await send_phy_rx(dut, rx_val)
    received = int(dut.mac_gmii_rxd.value)
    cocotb.log.info(f"mac_gmii_rxd:  0x{received:02X}")
    cocotb.log.info(f"mac_gmii_rx_dv: {dut.mac_gmii_rx_dv.value}")
    cocotb.log.info(f"mac_gmii_rx_er: {dut.mac_gmii_rx_er.value}")
    assert received == rx_val
    assert dut.mac_gmii_rx_dv.value == 1

    await send_mac_tx(dut, tx_val)
    txd = int(dut.phy_rgmii_txd.value)
    tx_ctl = int(dut.phy_rgmii_tx_ctl.value)
    cocotb.log.info(f"mac_gmii_tx_clk_en: {dut.mac_gmii_tx_clk_en.value}")
    cocotb.log.info(f"phy_rgmii_txd: {txd:01X}")
    cocotb.log.info(f"phy_rgmii_tx_ctl: {tx_ctl}")


@cocotb.test()
async def test_case_1(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0xAB, 0xCD)

@cocotb.test()
async def test_case_2(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0x55, 0x12)

@cocotb.test()
async def test_case_3(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0x00, 0xF0)

@cocotb.test()
async def test_case_4(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0xFF, 0x0F)

@cocotb.test()
async def test_case_5(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0xC3, 0xA5)

@cocotb.test()
async def test_case_6(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0x3C, 0x5A)

@cocotb.test()
async def test_case_7(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0x69, 0x99)

@cocotb.test()
async def test_case_8(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0x96, 0x66)

@cocotb.test()
async def test_case_9(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0x7E, 0x3C)

@cocotb.test()
async def test_case_10(dut): start_clocks(dut); await reset_dut(dut); await run_test(dut, 0x81, 0xC3)
