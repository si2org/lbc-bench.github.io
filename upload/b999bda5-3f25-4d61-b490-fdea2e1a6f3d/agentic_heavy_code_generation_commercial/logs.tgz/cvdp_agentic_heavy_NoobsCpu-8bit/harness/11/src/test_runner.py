import os
import re
from cocotb_tools.runner import get_runner
import pytest
import subprocess

# Fetch environment variables for Verilog source setup
verilog_sources = os.getenv("VERILOG_SOURCES").split()
toplevel_lang   = os.getenv("TOPLEVEL_LANG")
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = os.getenv("WAVE")

@pytest.mark.usefixtures(scope='session')
def test_simulate():
    """Run the simulation."""

    print('sim', sim)
    runner = get_runner(sim)

    # Add the -D CV32E40P_ASSERT_ON flag to build_args
    build_args = [
        "-sv -coverage", "all",
        "-covoverwrite",
        "-covtest", "test",
        "-gui"
        #"-D", "CV32E40P_ASSERT_ON", # Add this line to define the macro
    ]

    runner.build(
        sources=verilog_sources,
        hdl_toplevel=toplevel,
        always=True,
        clean=True,
        verbose=True,
        build_args=build_args, # Use the updated build_args list
        timescale=("1ns", "1ns"),
        log_file="build.log"
    )

    # You can optionally add run_args here if needed for the simulation execution
    run_args = []

    runner.test(
        hdl_toplevel=toplevel,
        test_module=module,
        waves=True,
        test_args=run_args # Pass run_args if defined
    )

# # ----------------------------------------
# # - Generate Coverage
# # ----------------------------------------

def test_coverage():

    cmd = "imc -load /rundir/sim_build/cov_work/scope/test -execcmd \"report -metrics assertion -all -aspect sim -assertionStatus -overwrite -text -out coverage.log\""

    assert(subprocess.run(cmd, shell=True)), "Coverage merge didn't ran correctly."

# ----------------------------------------
# - Report
# ----------------------------------------

@pytest.mark.usefixtures(scope='test_coverage')
def test_report():

    metrics = {}

    with open("/rundir/coverage.log") as f:
        lines = f.readlines()

    # ----------------------------------------
    # - Evaluate Report
    # ----------------------------------------
    column = re.split(r'\s{2,}', lines[0].strip())
    for line in lines[2:]:
        info = re.split(r'\s{2,}', line.strip())
        inst = info[0].lstrip('|-')
        metrics [inst] = {column[i]: info[i].split('%')[0] for i in range(1, len(column))}

    print("Metrics:")
    print(metrics)

    if "Overall Average" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Overall Average"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    elif "Assertion" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Assertion"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    elif "Toggle" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Toggle"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    elif "Block" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Block"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    else:
        assert False, "Couldn't find the required coverage result."

if __name__ == "__main__":
    test_simulate()