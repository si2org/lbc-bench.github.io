module hash_func(clk,rst,
    stall,
    tuple_in,
    initval,
    tuple_in_valid,
    hashed,
    hashed_valid
);
input clk;
input rst;
input stall;
input [31:0] initval;
input tuple_t tuple_in;
input tuple_in_valid;
output logic hashed_valid;
output logic [31:0] hashed;

logic [31:0] a;
logic [31:0] b;
logic [31:0] c;
logic [31:0] a1;
logic [31:0] b1;
logic [31:0] c1;
logic [31:0] a2;
logic [31:0] b2;
logic [31:0] c2;
logic [31:0] a3;
logic [31:0] b3;
logic [31:0] c3;
logic [31:0] a4;
logic [31:0] b4;
logic [31:0] c4;
logic [31:0] a5;
logic [31:0] b5;
logic [31:0] c5;
logic [31:0] a6;
logic [31:0] b6;
logic [31:0] c6;

logic valid;
logic valid1;
logic valid2;
logic valid3;
logic valid4;
logic valid5;
logic valid6;

logic [3:0] round;
logic [95:0] key;
`ifdef BUG_1
    assign key = {tuple_in.dIP,tuple_in.sPort,tuple_in.sIP,tuple_in.dPort};
`else
    assign key = {tuple_in.sIP,tuple_in.sPort,tuple_in.dIP,tuple_in.dPort};
`endif

//pipelined design
always@(posedge clk)begin
    `ifdef BUG_2
        if(rst || stall) begin
    `else
        if(rst) begin
    `endif
        valid  <= 0;
        valid1 <= 0;
        valid2 <= 0;
        valid3 <= 0;
        valid4 <= 0;
        valid5 <= 0;
        valid6 <= 0;

        `ifdef BUG_0
            hashed_valid <= 1;
        `else
            hashed_valid <= 0;
        `endif

        a  <= 0;
        a1 <= 0;
        a2 <= 0;
        a3 <= 0;
        a4 <= 0;
        a5 <= 0;
        a6 <= 0;

        b  <= 0;
        b1 <= 0;
        b2 <= 0;
        b3 <= 0;
        b4 <= 0;
        b5 <= 0;
        b6 <= 0;

        c  <= 0;
        c1 <= 0;
        c2 <= 0;
        c3 <= 0;
        c4 <= 0;
        c5 <= 0;
        c6 <= 0;

        `ifdef BUG_0
            hashed <= 1;
        `else
            hashed <= 0;
        `endif
    `ifdef BUG_2
        end else begin
    `else
        end else if(!stall)begin
    `endif
        valid <= tuple_in_valid;
        valid1 <= valid;
        valid2 <= valid1;
        valid3 <= valid2;
        valid4 <= valid3;
        valid5 <= valid4;
        valid6 <= valid5;
        `ifdef BUG_3
            hashed_valid <= valid5;
        `else
            hashed_valid <= valid6;
        `endif

        a <= 32'hdeadbefb + key[31:0] + initval;
        b <= 32'hdeadbefb + key[63:32] + initval;
        c <= 32'hdeadbefb + key[95:64] + initval;

        a1 <= a;
        b1 <= b;
        c1 <= (c ^ b) - {b[17:0],b[31:18]};

        a2 <= (a1 ^ c1) - {c1[20:0],c1[31:21]};
        b2 <= b1;
        c2 <= c1;

        a3 <= a2;
        b3 <= (b2 ^ a2) - {a2[6:0],a2[31:7]};
        c3 <= c2;

        a4 <= a3;
        b4 <= b3;
        c4 <= (c3 ^ b3) - {b3[15:0],b3[31:16]};

        a5 <= (a4 ^ c4) - {c4[27:0],c4[31:28]};
        b5 <= b4;
        c5 <= c4;

        a6 <= a5;
        b6 <= (b5 ^ a5) - {a5[17:0],a5[31:18]};
        c6 <= c5;

        hashed <= (c6 ^ b6) - {b6[7:0],b6[31:8]};
    end
end

endmodule
