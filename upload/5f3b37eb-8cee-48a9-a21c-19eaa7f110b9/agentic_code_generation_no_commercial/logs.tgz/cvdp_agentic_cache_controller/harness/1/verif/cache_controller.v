// Direct-mapped cache controller: 32 entries, 32-bit words, write-through policy
module cache_controller (
    input             clk,
    input             reset,
    input      [ 4:0] address,
    input      [31:0] write_data,
    input             read,
    input             write,
    output reg [31:0] read_data,
    output reg        hit,
    output reg        miss,
    output reg        mem_write,
    output reg [31:0] mem_address,
    output reg [31:0] mem_write_data,
    input      [31:0] mem_read_data,
    input             mem_ready
);

    // Cache arrays: 32 entries with valid bit, 5-bit tag, and 32-bit data
    reg        valid [0:31];
    reg  [4:0] tag   [0:31];
    reg [31:0] data  [0:31];

    // FSM
    localparam IDLE      = 1'b0;
    localparam READ_MISS = 1'b1;

    reg       state;
    reg [4:0] saved_addr;

    integer i;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state          <= IDLE;
            hit            <= 1'b0;
            miss           <= 1'b0;
            mem_write      <= 1'b0;
            mem_address    <= 32'b0;
            mem_write_data <= 32'b0;
            read_data      <= 32'b0;
            saved_addr     <= 5'b0;
            for (i = 0; i < 32; i = i + 1) begin
                valid[i] <= 1'b0;
                tag[i]   <= 5'b0;
                data[i]  <= 32'b0;
            end
        end else begin
            // Default de-assert each cycle
            hit       <= 1'b0;
            miss      <= 1'b0;
            mem_write <= 1'b0;

            case (state)
                IDLE: begin
                    if (read) begin
                        if (valid[address] && (tag[address] == address)) begin
                            // Read hit: return cached data immediately
                            hit       <= 1'b1;
                            read_data <= data[address];
                        end else begin
                            // Read miss: request data from main memory
                            miss        <= 1'b1;
                            mem_address <= {27'b0, address};
                            saved_addr  <= address;
                            state       <= READ_MISS;
                        end
                    end else if (write) begin
                        // Write-through: update cache on hit, always write to memory
                        if (valid[address] && (tag[address] == address)) begin
                            hit           <= 1'b1;
                            data[address] <= write_data;
                        end
                        mem_write      <= 1'b1;
                        mem_address    <= {27'b0, address};
                        mem_write_data <= write_data;
                        // Allocate the cache line on write even if it was invalid
                        valid[address] <= 1'b1;
                        tag[address]   <= address;
                    end
                end

                READ_MISS: begin
                    if (mem_ready) begin
                        // Fill cache line with data fetched from memory
                        valid[saved_addr] <= 1'b1;
                        tag[saved_addr]   <= saved_addr;
                        data[saved_addr]  <= mem_read_data;
                        read_data         <= mem_read_data;
                        hit               <= 1'b1;
                        state             <= IDLE;
                    end else begin
                        miss <= 1'b1;
                    end
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule
