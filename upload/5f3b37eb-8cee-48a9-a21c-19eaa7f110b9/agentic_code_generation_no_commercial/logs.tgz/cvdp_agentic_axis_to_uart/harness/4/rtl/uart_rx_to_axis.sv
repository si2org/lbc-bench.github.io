// UART-to-AXI-Stream receiver
// Converts a serial UART frame (start + data + optional parity + stop) into
// a parallel AXI-Stream word.  LSB is received first per standard UART.
module uart_rx_to_axis #(
    parameter int CLK_FREQ     = 100,    // Clock frequency in MHz
    parameter int BIT_RATE     = 115200, // UART baud rate in bps
    parameter int BIT_PER_WORD = 8,      // Data bits per UART frame
    parameter int PARITY_BIT   = 0,      // 0 = none, 1 = odd, 2 = even
    parameter int STOP_BITS_NUM = 1      // Number of stop bits (1 or 2)
) (
    input  logic                    aclk,
    input  logic                    aresetn,   // Active-low asynchronous reset
    input  logic                    RX,        // Serial UART input (idle high)

    output logic [BIT_PER_WORD-1:0] tdata,     // Parallel data word
    output logic                    tuser,     // Parity error flag
    output logic                    tvalid     // Data valid strobe
);

    // -----------------------------------------------------------------------
    // Timing parameters
    // -----------------------------------------------------------------------
    // Number of system clock cycles in one UART bit period.
    localparam int CYCLE_PER_PERIOD = (CLK_FREQ * 1000000) / BIT_RATE;
    // Half-period offset used to centre-align sampling within the start bit.
    localparam int HALF_PERIOD      = CYCLE_PER_PERIOD / 2;

    // Counter widths.
    localparam int CLK_CNT_W = $clog2(CYCLE_PER_PERIOD + 1);
    // BIT_PER_WORD is always >= 1; $clog2 gives 0 for argument 1, so guard it.
    localparam int BIT_CNT_W = (BIT_PER_WORD > 1) ? $clog2(BIT_PER_WORD) : 1;

    // -----------------------------------------------------------------------
    // FSM state encoding
    // -----------------------------------------------------------------------
    typedef enum logic [2:0] {
        IDLE    = 3'd0,
        START   = 3'd1,
        DATA    = 3'd2,
        PARITY  = 3'd3,
        STOP1   = 3'd4,
        STOP2   = 3'd5,
        OUT_RDY = 3'd6
    } state_t;

    state_t                  state;
    logic [CLK_CNT_W-1:0]   clk_count;
    logic [BIT_CNT_W-1:0]   bit_count;
    logic [BIT_PER_WORD-1:0] data_shift_reg;
    logic                    parity_error;

    // One-cycle-delayed RX for falling-edge detection
    logic rx_prev;
    wire  falling_edge = (rx_prev == 1'b1) && (RX == 1'b0);

    // Combinational expected parity (evaluated when data_shift_reg is complete)
    // Odd  (PARITY_BIT=1): parity bit = ~XOR(data)
    // Even (PARITY_BIT=2): parity bit =  XOR(data)
    wire computed_parity = (PARITY_BIT == 1) ? ~(^data_shift_reg)
                                              :  (^data_shift_reg);

    // -----------------------------------------------------------------------
    // RX edge-detection flip-flop
    // -----------------------------------------------------------------------
    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn)
            rx_prev <= 1'b1;
        else
            rx_prev <= RX;
    end

    // -----------------------------------------------------------------------
    // FSM + datapath
    // -----------------------------------------------------------------------
    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            state          <= IDLE;
            clk_count      <= '0;
            bit_count      <= '0;
            data_shift_reg <= '0;
            parity_error   <= 1'b0;
            tdata          <= '0;
            tuser          <= 1'b0;
            tvalid         <= 1'b0;
        end else begin
            // tvalid is a one-cycle strobe; deassert by default.
            tvalid <= 1'b0;

            case (state)
                // ----------------------------------------------------------
                // IDLE: wait for a falling edge on RX (start of start bit)
                // ----------------------------------------------------------
                IDLE: begin
                    clk_count <= '0;
                    bit_count <= '0;
                    if (falling_edge) begin
                        state     <= START;
                        clk_count <= '0;
                    end
                end

                // ----------------------------------------------------------
                // START: wait half a bit period, then sample the start bit.
                // A high sample means false trigger; return to IDLE.
                // ----------------------------------------------------------
                START: begin
                    if (clk_count == CLK_CNT_W'(HALF_PERIOD - 1)) begin
                        clk_count <= '0;
                        if (RX == 1'b0)
                            state <= DATA;
                        else
                            state <= IDLE; // False start — glitch on RX
                    end else begin
                        clk_count <= clk_count + 1'b1;
                    end
                end

                // ----------------------------------------------------------
                // DATA: sample BIT_PER_WORD bits, one per full bit period.
                // Shift right so that the first received bit (LSB) settles
                // at bit position 0 after all bits are loaded.
                // ----------------------------------------------------------
                DATA: begin
                    if (clk_count == CLK_CNT_W'(CYCLE_PER_PERIOD - 1)) begin
                        clk_count      <= '0;
                        // Insert new bit at MSB; earlier bits shift toward LSB.
                        data_shift_reg <= {RX, data_shift_reg[BIT_PER_WORD-1:1]};

                        if (bit_count == BIT_CNT_W'(BIT_PER_WORD - 1)) begin
                            bit_count <= '0;
                            state     <= (PARITY_BIT != 0) ? PARITY : STOP1;
                        end else begin
                            bit_count <= bit_count + 1'b1;
                        end
                    end else begin
                        clk_count <= clk_count + 1'b1;
                    end
                end

                // ----------------------------------------------------------
                // PARITY: sample the parity bit and compare with expectation.
                // ----------------------------------------------------------
                PARITY: begin
                    if (clk_count == CLK_CNT_W'(CYCLE_PER_PERIOD - 1)) begin
                        clk_count    <= '0;
                        parity_error <= (RX != computed_parity);
                        state        <= STOP1;
                    end else begin
                        clk_count <= clk_count + 1'b1;
                    end
                end

                // ----------------------------------------------------------
                // STOP1: wait through the first stop bit period.
                // ----------------------------------------------------------
                STOP1: begin
                    if (clk_count == CLK_CNT_W'(CYCLE_PER_PERIOD - 1)) begin
                        clk_count <= '0;
                        state     <= (STOP_BITS_NUM == 2) ? STOP2 : OUT_RDY;
                    end else begin
                        clk_count <= clk_count + 1'b1;
                    end
                end

                // ----------------------------------------------------------
                // STOP2: wait through the second stop bit period (optional).
                // ----------------------------------------------------------
                STOP2: begin
                    if (clk_count == CLK_CNT_W'(CYCLE_PER_PERIOD - 1)) begin
                        clk_count <= '0;
                        state     <= OUT_RDY;
                    end else begin
                        clk_count <= clk_count + 1'b1;
                    end
                end

                // ----------------------------------------------------------
                // OUT_RDY: drive AXI-Stream outputs for one clock cycle,
                //          then return to IDLE ready for the next frame.
                // ----------------------------------------------------------
                OUT_RDY: begin
                    tdata        <= data_shift_reg;
                    tuser        <= (PARITY_BIT != 0) ? parity_error : 1'b0;
                    tvalid       <= 1'b1;
                    parity_error <= 1'b0;
                    state        <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule
