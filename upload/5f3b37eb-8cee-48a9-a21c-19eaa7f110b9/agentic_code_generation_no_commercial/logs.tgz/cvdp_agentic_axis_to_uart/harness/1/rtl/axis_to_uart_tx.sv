module axis_to_uart_tx #(
    parameter integer CLK_FREQ      = 100,    // MHz
    parameter integer BIT_RATE      = 115200, // bps
    parameter integer BIT_PER_WORD  = 8,
    parameter integer PARITY_BIT    = 0,      // 0=none, 1=odd, 2=even
    parameter integer STOP_BITS_NUM = 1       // 1 or 2
)(
    input  wire                    aclk,
    input  wire                    aresetn,
    input  wire [BIT_PER_WORD-1:0] tdata,
    input  wire                    tvalid,
    output wire                    tready,
    output reg                     TX
);

    localparam integer CYCLE_PER_PERIOD = (CLK_FREQ * 1_000_000) / BIT_RATE;
    localparam integer CLK_CNT_W        = $clog2(CYCLE_PER_PERIOD);
    localparam integer BIT_CNT_W        = $clog2(BIT_PER_WORD);

    localparam [2:0]
        IDLE   = 3'd0,
        START  = 3'd1,
        DATA   = 3'd2,
        PARITY = 3'd3,
        STOP1  = 3'd4,
        STOP2  = 3'd5;

    reg [2:0]              state;
    reg [CLK_CNT_W-1:0]    Clk_Count;
    reg [BIT_CNT_W-1:0]    Bit_Count;
    reg [BIT_PER_WORD-1:0] Data;

    wire Clk_Count_Done = (Clk_Count == CYCLE_PER_PERIOD - 1);
    wire Bit_Count_Done = (Bit_Count == BIT_PER_WORD - 1);

    // Combinational parity on latched data
    wire parity_bit;
    generate
        if (PARITY_BIT == 1)
            assign parity_bit = ~^Data; // odd: invert XOR so total 1s is odd
        else if (PARITY_BIT == 2)
            assign parity_bit = ^Data;  // even: XOR so total 1s is even
        else
            assign parity_bit = 1'b0;
    endgenerate

    assign tready = (state == IDLE);

    // Clock counter: runs in all non-IDLE states, resets on period boundary or IDLE
    always @(posedge aclk or negedge aresetn) begin
        if (!aresetn)
            Clk_Count <= '0;
        else if (state == IDLE || Clk_Count_Done)
            Clk_Count <= '0;
        else
            Clk_Count <= Clk_Count + 1'b1;
    end

    // FSM, TX output, data latch, bit counter
    // TX is pre-loaded at each state transition so the new bit value takes
    // effect on the same clock edge as the state change (no 1-cycle gap).
    always @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            state     <= IDLE;
            TX        <= 1'b1;
            Data      <= '0;
            Bit_Count <= '0;
        end else begin
            case (state)

                IDLE: begin
                    TX <= 1'b1;
                    if (tvalid) begin
                        Data  <= tdata;
                        state <= START;
                        TX    <= 1'b0; // start bit begins immediately
                    end
                end

                START: begin
                    TX <= 1'b0;
                    if (Clk_Count_Done) begin
                        state     <= DATA;
                        Bit_Count <= '0;
                        TX        <= Data[0]; // drive LSB when entering DATA
                    end
                end

                DATA: begin
                    TX <= Data[Bit_Count];
                    if (Clk_Count_Done) begin
                        if (Bit_Count_Done) begin
                            Bit_Count <= '0;
                            if (PARITY_BIT != 0) begin
                                state <= PARITY;
                                TX    <= parity_bit;
                            end else begin
                                state <= STOP1;
                                TX    <= 1'b1;
                            end
                        end else begin
                            Bit_Count <= Bit_Count + 1'b1;
                            TX        <= Data[Bit_Count + 1'b1];
                        end
                    end
                end

                PARITY: begin
                    TX <= parity_bit;
                    if (Clk_Count_Done) begin
                        state <= STOP1;
                        TX    <= 1'b1;
                    end
                end

                STOP1: begin
                    TX <= 1'b1;
                    if (Clk_Count_Done) begin
                        if (STOP_BITS_NUM == 2) begin
                            state <= STOP2;
                        end else begin
                            state <= IDLE;
                        end
                    end
                end

                STOP2: begin
                    TX <= 1'b1;
                    if (Clk_Count_Done) begin
                        state <= IDLE;
                    end
                end

                default: begin
                    state <= IDLE;
                    TX    <= 1'b1;
                end

            endcase
        end
    end

endmodule
