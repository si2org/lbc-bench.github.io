// CIC Decimation Filter
// Cascaded Integrator-Comb (CIC) filter for sample-rate reduction.
// Integrators run at input rate; comb stages run at decimated output rate.
module cic_decimator #(
    parameter int WIDTH     = 16,
    parameter int RMAX      = 2,
    parameter int M         = 1,
    parameter int N         = 2,
    parameter int REG_WIDTH = WIDTH + $clog2((RMAX * M) ** N)
) (
    input  logic                       clk,
    input  logic                       rst,

    // Input AXI-Stream interface
    input  logic [WIDTH-1:0]           input_tdata,
    input  logic                       input_tvalid,
    output logic                       input_tready,

    // Output AXI-Stream interface
    output logic [REG_WIDTH-1:0]       output_tdata,
    output logic                       output_tvalid,
    input  logic                       output_tready,

    // Decimation rate: valid range [1, RMAX]
    input  logic [$clog2(RMAX+1)-1:0] rate
);

    // Counter width: enough to represent values 0 .. RMAX-1
    localparam int COUNTER_W = (RMAX > 1) ? $clog2(RMAX) : 1;

    // Internal state
    logic [REG_WIDTH-1:0] integ     [N];
    logic [REG_WIDTH-1:0] comb_out  [N];
    logic [REG_WIDTH-1:0] delay_reg [N][M];

    // Decimation cycle counter
    logic [COUNTER_W-1:0] cycle_reg;
    logic [COUNTER_W-1:0] cycle_limit;

    // cycle_limit = min(RMAX-1, rate-1); clamp out-of-range rate to RMAX
    always_comb begin
        if (rate == '0 || rate > COUNTER_W'(RMAX))
            cycle_limit = COUNTER_W'(RMAX - 1);
        else
            cycle_limit = COUNTER_W'(rate) - 1'b1;
    end

    // Handshaking
    // Input is accepted when output_tready is asserted OR when we are not at
    // a decimation point (cycle_reg != 0), so integrators drain continuously.
    assign input_tready  = output_tready | (cycle_reg != '0);
    assign output_tvalid = input_tvalid  & (cycle_reg == '0);

    // Cycle counter: increments every accepted input sample; resets at limit
    always_ff @(posedge clk) begin
        if (rst) begin
            cycle_reg <= '0;
        end else if (input_tvalid && input_tready) begin
            if (cycle_reg >= cycle_limit)
                cycle_reg <= '0;
            else
                cycle_reg <= cycle_reg + 1'b1;
        end
    end

    // -------------------------------------------------------------------------
    // Integrator section: N cascaded accumulators, clocked at input rate
    // -------------------------------------------------------------------------
    genvar k;
    generate
        for (k = 0; k < N; k++) begin : gen_integrator
            always_ff @(posedge clk) begin
                if (rst) begin
                    integ[k] <= '0;
                end else if (input_tready && input_tvalid) begin
                    if (k == 0)
                        // Sign-extend WIDTH input to REG_WIDTH before accumulating
                        integ[k] <= integ[k] + {{(REG_WIDTH-WIDTH){input_tdata[WIDTH-1]}}, input_tdata};
                    else
                        integ[k] <= integ[k] + integ[k-1];
                end
            end
        end
    endgenerate

    // -------------------------------------------------------------------------
    // Comb section: N differentiator stages with M-sample delay lines,
    // clocked at decimated output rate
    // -------------------------------------------------------------------------
    generate
        for (k = 0; k < N; k++) begin : gen_comb
            logic [REG_WIDTH-1:0] comb_in;

            // First comb stage reads last integrator; subsequent stages chain
            assign comb_in    = (k == 0) ? integ[N-1] : comb_out[k-1];
            // Differentiate: current input minus M-cycle-delayed input
            assign comb_out[k] = comb_in - delay_reg[k][M-1];

            genvar j;
            for (j = 0; j < M; j++) begin : gen_delay
                always_ff @(posedge clk) begin
                    if (rst) begin
                        delay_reg[k][j] <= '0;
                    end else if (output_tready && output_tvalid) begin
                        // Shift delay line; head captures current comb input
                        delay_reg[k][j] <= (j == 0) ? comb_in : delay_reg[k][j-1];
                    end
                end
            end
        end
    endgenerate

    assign output_tdata = comb_out[N-1];

endmodule
