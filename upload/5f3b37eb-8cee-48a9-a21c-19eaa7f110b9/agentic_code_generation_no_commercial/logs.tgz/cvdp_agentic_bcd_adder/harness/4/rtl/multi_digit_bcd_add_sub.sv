module multi_digit_bcd_add_sub #(parameter N = 4) (
    input  [4*N-1:0] A,
    input  [4*N-1:0] B,
    input            add_sub,
    output [4*N-1:0] result,
    output           carry_borrow
);

wire [N:0] carry;

// For subtraction: initial cin=1 to complete 10's complement; for addition: 0
assign carry[0] = ~add_sub;

genvar i;
generate
    for (i = 0; i < N; i = i + 1) begin: digit
        wire [3:0] b_in;
        // For subtraction: 9's complement of each B digit; for addition: pass through
        assign b_in = add_sub ? B[4*i+3:4*i] : (4'd9 - B[4*i+3:4*i]);

        bcd_adder adder(
            .a(A[4*i+3:4*i]),
            .b(b_in),
            .cin(carry[i]),
            .sum(result[4*i+3:4*i]),
            .cout(carry[i+1])
        );
    end
endgenerate

// Addition: carry_borrow is the final carry-out
// Subtraction: carry_borrow=1 means borrow (A < B), which occurs when final carry=0
assign carry_borrow = add_sub ? carry[N] : ~carry[N];

endmodule
