module bcd_adder(
                 input  [3:0] a,
                 input  [3:0] b,
                 input        cin,
                 output [3:0] sum,
                 output       cout
                );

wire [3:0] binary_sum;
wire binary_cout;
wire z1, z2;
wire carry;

four_bit_adder adder1(
                      .a(a),
                      .b(b),
                      .cin(cin),
                      .sum(binary_sum),
                      .cout(binary_cout)
                     );

assign z1 = (binary_sum[3] & binary_sum[2]);
assign z2 = (binary_sum[3] & binary_sum[1]);
assign cout = (z1 | z2 | binary_cout);

four_bit_adder adder2(
                      .a(binary_sum),
                      .b({1'b0, cout, cout, 1'b0}),
                      .cin(1'b0),
                      .sum(sum),
                      .cout(carry)
                     );

endmodule
