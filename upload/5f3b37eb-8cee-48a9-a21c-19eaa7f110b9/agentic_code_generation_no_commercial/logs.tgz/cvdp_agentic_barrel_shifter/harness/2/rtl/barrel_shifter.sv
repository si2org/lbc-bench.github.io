module barrel_shifter (
    input  [7:0] data_in,
    input  [2:0] shift_bits,
    input        left_right,
    input        shift_mode,
    output reg [7:0] data_out
);

    always @(*) begin
        if (left_right) begin
            // Left shift: logical and arithmetic behave identically (zeroes into LSBs)
            data_out = data_in << shift_bits;
        end else begin
            if (shift_mode) begin
                // Arithmetic right shift: replicate sign bit into vacated MSBs
                data_out = $signed(data_in) >>> shift_bits;
            end else begin
                // Logical right shift: zeroes into MSBs
                data_out = data_in >> shift_bits;
            end
        end
    end

endmodule
