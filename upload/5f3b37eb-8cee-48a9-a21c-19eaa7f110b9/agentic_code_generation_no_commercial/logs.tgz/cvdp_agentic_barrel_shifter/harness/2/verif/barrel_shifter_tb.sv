`timescale 1ns / 1ps

module barrel_shifter_tb;

    // Testbench Signals
    reg [7:0] data_in;           // Input data
    reg [2:0] shift_bits;        // Number of bits to shift
    reg left_right;              // Direction of shift: 1 for left, 0 for right
    reg shift_mode;              // Shift mode: 0 = logical, 1 = arithmetic
    wire [7:0] data_out;         // Output data

    // Instantiate the DUT (Device Under Test)
    barrel_shifter uut (
        .data_in(data_in),
        .shift_bits(shift_bits),
        .left_right(left_right),
        .shift_mode(shift_mode),
        .data_out(data_out)
    );

    // Calculate expected output for comparison
    function [7:0] expected_output(input [7:0] data_in, input [2:0] shift_bits, input left_right, input shift_mode);
        begin
            if (left_right) begin
                // Left shift: logical and arithmetic are identical
                expected_output = (data_in << shift_bits) & 8'hFF;
            end else begin
                if (shift_mode) begin
                    // Arithmetic right shift: replicate sign bit
                    expected_output = $signed(data_in) >>> shift_bits;
                end else begin
                    // Logical right shift: zeroes into MSBs
                    expected_output = (data_in >> shift_bits) & 8'hFF;
                end
            end
        end
    endfunction

    // Test procedure
    initial begin
        integer i;
        reg [7:0] expected;

        $display("Starting Testbench for barrel_shifter...");
        $display("------------------------------------------------------------------");
        $display("|  Data_in  |  Shift | Left/Right | ShiftMode |  Output  | Expected |");
        $display("------------------------------------------------------------------");

        // Directed test: Logical Right Shift (LSR) from spec example 1
        data_in    = 8'b10110011;
        shift_bits = 3;
        left_right = 0;
        shift_mode = 0;
        #5;
        expected = expected_output(data_in, shift_bits, left_right, shift_mode);
        $display("| %b |   %0d   |     %0d     |     %0d     | %b | %b |",
            data_in, shift_bits, left_right, shift_mode, data_out, expected);
        if (data_out !== expected) begin
            $display("FAIL: LSR test. Expected=%b, Got=%b", expected, data_out);
            $fatal;
        end

        // Directed test: Arithmetic Left Shift (ALSL) from spec example 2
        data_in    = 8'b10101001;
        shift_bits = 2;
        left_right = 1;
        shift_mode = 1;
        #5;
        expected = expected_output(data_in, shift_bits, left_right, shift_mode);
        $display("| %b |   %0d   |     %0d     |     %0d     | %b | %b |",
            data_in, shift_bits, left_right, shift_mode, data_out, expected);
        if (data_out !== expected) begin
            $display("FAIL: ALSL test. Expected=%b, Got=%b", expected, data_out);
            $fatal;
        end

        // Directed test: Arithmetic Right Shift of negative value (sign bit = 1)
        data_in    = 8'b10110010;
        shift_bits = 3;
        left_right = 0;
        shift_mode = 1;
        #5;
        expected = expected_output(data_in, shift_bits, left_right, shift_mode);
        $display("| %b |   %0d   |     %0d     |     %0d     | %b | %b |",
            data_in, shift_bits, left_right, shift_mode, data_out, expected);
        if (data_out !== expected) begin
            $display("FAIL: ASR negative test. Expected=%b, Got=%b", expected, data_out);
            $fatal;
        end

        // Directed test: Arithmetic Right Shift of positive value (sign bit = 0)
        data_in    = 8'b01001110;
        shift_bits = 2;
        left_right = 0;
        shift_mode = 1;
        #5;
        expected = expected_output(data_in, shift_bits, left_right, shift_mode);
        $display("| %b |   %0d   |     %0d     |     %0d     | %b | %b |",
            data_in, shift_bits, left_right, shift_mode, data_out, expected);
        if (data_out !== expected) begin
            $display("FAIL: ASR positive test. Expected=%b, Got=%b", expected, data_out);
            $fatal;
        end

        // Randomized test cases covering all modes
        for (i = 0; i < 100; i = i + 1) begin
            data_in    = $random % 256;
            shift_bits = $random % 8;
            left_right = $random % 2;
            shift_mode = $random % 2;

            expected = expected_output(data_in, shift_bits, left_right, shift_mode);
            #5;

            $display("| %b |   %0d   |     %0d     |     %0d     | %b | %b |",
                data_in, shift_bits, left_right, shift_mode, data_out, expected);

            if (data_out !== expected) begin
                $display("FAIL: data_in=%b, shift_bits=%0d, left_right=%0d, shift_mode=%0d. Expected=%b, Got=%b",
                    data_in, shift_bits, left_right, shift_mode, expected, data_out);
                $fatal;
            end
        end

        $display("All tests passed!");
        $finish;
    end
endmodule
