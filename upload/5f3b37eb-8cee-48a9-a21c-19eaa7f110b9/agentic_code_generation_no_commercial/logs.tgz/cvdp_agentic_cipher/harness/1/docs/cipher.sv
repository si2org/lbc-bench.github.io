module cipher (
    input  logic        clk,
    input  logic        rst_n,
    input  logic        start,
    input  logic [31:0] data_in,
    input  logic [15:0] key,
    output logic [31:0] data_out,
    output logic        done
);

    // FSM state encoding
    typedef enum logic [1:0] {
        IDLE   = 2'b00,
        ROUND  = 2'b01,
        FINISH = 2'b10
    } state_t;

    state_t       state;
    logic [15:0]  left, right;
    logic [15:0]  round_key;
    logic [3:0]   round_cnt;

    // f_function: XOR with round key, rotate left 4, add round key
    function automatic [15:0] f_function;
        input [15:0] data;
        input [15:0] rkey;
        logic [15:0] tmp;
        begin
            tmp        = data ^ rkey;
            tmp        = {tmp[11:0], tmp[15:12]};  // rotate left by 4
            tmp        = tmp + rkey;
            f_function = tmp;
        end
    endfunction

    // Key schedule: rotate left by 1, XOR with round index
    function automatic [15:0] next_round_key;
        input [15:0] rkey;
        input [3:0]  idx;
        begin
            next_round_key = {rkey[14:0], rkey[15]} ^ {12'b0, idx};
        end
    endfunction

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state     <= IDLE;
            left      <= 16'b0;
            right     <= 16'b0;
            round_key <= 16'b0;
            round_cnt <= 4'b0;
            data_out  <= 32'b0;
            done      <= 1'b0;
        end else begin
            done <= 1'b0;

            case (state)
                IDLE: begin
                    if (start) begin
                        left      <= data_in[31:16];
                        right     <= data_in[15:0];
                        round_key <= key;
                        round_cnt <= 4'b0;
                        state     <= ROUND;
                    end
                end

                ROUND: begin
                    // Feistel step: new_right = left ^ f(right, round_key), new_left = right
                    left      <= right;
                    right     <= left ^ f_function(right, round_key);
                    round_key <= next_round_key(round_key, round_cnt);
                    round_cnt <= round_cnt + 4'b1;

                    if (round_cnt == 4'd7)
                        state <= FINISH;
                end

                FINISH: begin
                    // Final swap before output
                    data_out <= {right, left};
                    done     <= 1'b1;
                    state    <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule
