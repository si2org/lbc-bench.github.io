module continuous_adder #(
    parameter integer DATA_WIDTH       = 32,
    parameter integer ENABLE_THRESHOLD = 0,
    parameter integer THRESHOLD        = 16,
    parameter integer REGISTER_OUTPUT  = 0
)(
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  valid_in,
    input  wire [DATA_WIDTH-1:0] data_in,
    input  wire                  accumulate_enable,
    input  wire                  flush,
    output reg  [DATA_WIDTH-1:0] sum_out,
    output reg                   sum_valid
);

    reg [DATA_WIDTH-1:0] sum_reg;

    // Accumulation register: synchronous update, asynchronous reset
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sum_reg <= '0;
        end else if (flush) begin
            sum_reg <= '0;
        end else if (valid_in && accumulate_enable) begin
            sum_reg <= sum_reg + data_in;
        end
    end

    // Combinational output signals before optional registering
    wire [DATA_WIDTH-1:0] sum_out_next;
    wire                  sum_valid_next;

    generate
        if (ENABLE_THRESHOLD) begin : gen_threshold
            assign sum_valid_next = (sum_reg >= DATA_WIDTH'(THRESHOLD));
            assign sum_out_next   = sum_valid_next ? sum_reg : '0;
        end else begin : gen_no_threshold
            assign sum_out_next   = sum_reg;
            assign sum_valid_next = 1'b1;
        end
    endgenerate

    // Output stage: registered or combinational
    generate
        if (REGISTER_OUTPUT) begin : gen_reg_output
            always_ff @(posedge clk or negedge rst_n) begin
                if (!rst_n) begin
                    sum_out   <= '0;
                    sum_valid <= 1'b0;
                end else begin
                    sum_out   <= sum_out_next;
                    sum_valid <= sum_valid_next;
                end
            end
        end else begin : gen_comb_output
            always_comb begin
                sum_out   = sum_out_next;
                sum_valid = sum_valid_next;
            end
        end
    endgenerate

endmodule
