module top_64b66b_codec (
    input  logic         clk_in,
    input  logic         rst_in,
    input  logic [63:0]  enc_data_in,
    input  logic [7:0]   enc_control_in,
    output logic [65:0]  enc_data_out,
    input  logic         dec_data_valid_in,
    input  logic [65:0]  dec_data_in,
    output logic [63:0]  dec_data_out,
    output logic [7:0]   dec_control_out,
    output logic         dec_sync_error,
    output logic         dec_error_out
);

    logic [65:0] data_enc_out;
    logic [65:0] ctrl_enc_out;

    // Delay enc_control_in by 1 cycle to align mux select with registered encoder outputs
    logic [7:0] enc_control_in_d;

    always_ff @(posedge clk_in or posedge rst_in) begin
        if (rst_in)
            enc_control_in_d <= 8'b0;
        else
            enc_control_in_d <= enc_control_in;
    end

    encoder_data_64b66b u_enc_data (
        .clk_in             (clk_in),
        .rst_in             (rst_in),
        .encoder_data_in    (enc_data_in),
        .encoder_control_in (enc_control_in),
        .encoder_data_out   (data_enc_out)
    );

    encoder_control_64b66b u_enc_ctrl (
        .clk_in             (clk_in),
        .rst_in             (rst_in),
        .encoder_data_in    (enc_data_in),
        .encoder_control_in (enc_control_in),
        .encoder_data_out   (ctrl_enc_out)
    );

    // Select data encoder when no control flags are active, otherwise control encoder
    assign enc_data_out = (enc_control_in_d == 8'b0) ? data_enc_out : ctrl_enc_out;

    decoder_data_control_64b66b u_decoder (
        .clk_in                (clk_in),
        .rst_in                (rst_in),
        .decoder_data_valid_in (dec_data_valid_in),
        .decoder_data_in       (dec_data_in),
        .decoder_data_out      (dec_data_out),
        .decoder_control_out   (dec_control_out),
        .sync_error            (dec_sync_error),
        .decoder_error_out     (dec_error_out)
    );

endmodule
