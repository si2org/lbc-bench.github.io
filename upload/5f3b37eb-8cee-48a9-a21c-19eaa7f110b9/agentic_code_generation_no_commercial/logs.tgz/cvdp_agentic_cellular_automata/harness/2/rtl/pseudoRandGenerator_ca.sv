module pseudoRandGenerator_ca (
    input  logic        clock,
    input  logic        reset,
    input  logic [15:0] CA_seed,
    input  logic [1:0]  rule_sel,
    output logic [15:0] CA_out
);

    logic [15:0] next_CA_out;

    function automatic logic compute_next_bit(
        input logic [15:0] state,
        input int          idx,
        input logic [1:0]  sel
    );
        logic        left, center, right;
        logic [2:0]  neighborhood;

        left         = state[(idx + 15) % 16];
        center       = state[idx];
        right        = state[(idx +  1) % 16];
        neighborhood = {left, center, right};

        case (sel)
            2'b01: begin  // Rule 110
                case (neighborhood)
                    3'b111: compute_next_bit = 1'b0;
                    3'b110: compute_next_bit = 1'b1;
                    3'b101: compute_next_bit = 1'b1;
                    3'b100: compute_next_bit = 1'b0;
                    3'b011: compute_next_bit = 1'b1;
                    3'b010: compute_next_bit = 1'b1;
                    3'b001: compute_next_bit = 1'b1;
                    default: compute_next_bit = 1'b0;
                endcase
            end
            default: begin  // Rule 30 (2'b00) and any unrecognized value
                case (neighborhood)
                    3'b111: compute_next_bit = 1'b0;
                    3'b110: compute_next_bit = 1'b0;
                    3'b101: compute_next_bit = 1'b0;
                    3'b100: compute_next_bit = 1'b1;
                    3'b011: compute_next_bit = 1'b1;
                    3'b010: compute_next_bit = 1'b1;
                    3'b001: compute_next_bit = 1'b1;
                    default: compute_next_bit = 1'b0;
                endcase
            end
        endcase
    endfunction

    always_comb begin
        int i;
        for (i = 0; i < 16; i++) begin
            next_CA_out[i] = compute_next_bit(CA_out, i, rule_sel);
        end
    end

    always_ff @(posedge clock) begin
        if (reset)
            CA_out <= CA_seed;
        else
            CA_out <= next_CA_out;
    end

endmodule
