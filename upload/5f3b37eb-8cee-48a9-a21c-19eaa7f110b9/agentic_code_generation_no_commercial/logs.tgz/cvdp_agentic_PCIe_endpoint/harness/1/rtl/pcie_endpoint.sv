// pcie_endpoint.sv
// PCIe Endpoint module: handles PCIe TLP reception/transmission, DMA engine
// interfacing, and MSI-X interrupt generation via four independent FSMs.

module pcie_endpoint #(
    parameter int ADDR_WIDTH = 64,
    parameter int DATA_WIDTH = 128
) (
    input  logic                  clk,
    input  logic                  rst_n,

    // PCIe RX interface
    input  logic [DATA_WIDTH-1:0] pcie_rx_tlp,
    input  logic                  pcie_rx_valid,
    output logic                  pcie_rx_ready,

    // PCIe TX interface
    output logic [DATA_WIDTH-1:0] pcie_tx_tlp,
    output logic                  pcie_tx_valid,
    input  logic                  pcie_tx_ready,

    // DMA interface
    input  logic                  dma_request,
    output logic                  dma_complete,

    // MSI-X interrupt interface
    output logic                  msix_interrupt
);

    // =========================================================================
    // Internal signals
    // =========================================================================
    logic [DATA_WIDTH-1:0] tlp_decoded_data; // latched copy of received TLP
    logic                  tlp_valid;        // valid TLP available for processing
    logic [ADDR_WIDTH-1:0] dma_address;      // address for DMA operation
    logic [DATA_WIDTH-1:0] dma_data;         // data for DMA write
    logic                  dma_start;        // one-cycle pulse to begin DMA

    // =========================================================================
    // PCIe Transaction FSM
    // Receives incoming TLPs, decodes them, triggers DMA, and prepares response.
    // States: TXN_IDLE -> TXN_RECEIVE -> TXN_PROCESS -> TXN_SEND_RESPONSE -> TXN_IDLE
    // =========================================================================
    typedef enum logic [1:0] {
        TXN_IDLE          = 2'b00,
        TXN_RECEIVE       = 2'b01,
        TXN_PROCESS       = 2'b10,
        TXN_SEND_RESPONSE = 2'b11
    } pcie_txn_state_t;

    pcie_txn_state_t txn_state;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            txn_state        <= TXN_IDLE;
            tlp_decoded_data <= '0;
            tlp_valid        <= 1'b0;
            dma_start        <= 1'b0;
            dma_address      <= '0;
            dma_data         <= '0;
        end else begin
            dma_start <= 1'b0; // default: deasserted each cycle

            case (txn_state)
                TXN_IDLE: begin
                    tlp_valid <= 1'b0;
                    if (pcie_rx_valid)
                        txn_state <= TXN_RECEIVE;
                end

                TXN_RECEIVE: begin
                    // Capture incoming TLP and mark it valid
                    tlp_decoded_data <= pcie_rx_tlp;
                    tlp_valid        <= 1'b1;
                    txn_state        <= TXN_PROCESS;
                end

                TXN_PROCESS: begin
                    // Decode TLP: extract address and data, then kick off DMA
                    dma_address <= tlp_decoded_data[ADDR_WIDTH-1:0];
                    dma_data    <= tlp_decoded_data;
                    dma_start   <= 1'b1;
                    txn_state   <= TXN_SEND_RESPONSE;
                end

                TXN_SEND_RESPONSE: begin
                    tlp_valid <= 1'b0;
                    txn_state <= TXN_IDLE;
                end

                default: txn_state <= TXN_IDLE;
            endcase
        end
    end

    // Ready to receive only when idle
    assign pcie_rx_ready = (txn_state == TXN_IDLE);

    // =========================================================================
    // PCIe Data Link FSM
    // Transmits response TLPs; retries if the host does not acknowledge.
    // States: DLL_IDLE -> TRANSMIT -> WAIT_ACK -> (DLL_IDLE | RETRY -> TRANSMIT)
    // =========================================================================
    typedef enum logic [1:0] {
        DLL_IDLE = 2'b00,
        TRANSMIT = 2'b01,
        WAIT_ACK = 2'b10,
        RETRY    = 2'b11
    } pcie_dll_state_t;

    pcie_dll_state_t dll_state;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dll_state   <= DLL_IDLE;
            pcie_tx_tlp <= '0;
        end else begin
            case (dll_state)
                DLL_IDLE: begin
                    // Begin transmission when the transaction FSM has a response ready
                    if (txn_state == TXN_SEND_RESPONSE) begin
                        pcie_tx_tlp <= tlp_decoded_data;
                        dll_state   <= TRANSMIT;
                    end
                end

                TRANSMIT: begin
                    // Valid is asserted combinationally; advance to await acknowledgment
                    dll_state <= WAIT_ACK;
                end

                WAIT_ACK: begin
                    if (pcie_tx_ready)
                        dll_state <= DLL_IDLE;  // host accepted — done
                    else
                        dll_state <= RETRY;     // not accepted — retry
                end

                RETRY: begin
                    // Re-enter TRANSMIT to re-assert valid and retry handshake
                    dll_state <= TRANSMIT;
                end

                default: dll_state <= DLL_IDLE;
            endcase
        end
    end

    // pcie_tx_valid remains high from TRANSMIT through WAIT_ACK and RETRY until
    // pcie_tx_ready causes a transition back to DLL_IDLE
    assign pcie_tx_valid = (dll_state == TRANSMIT) ||
                           (dll_state == WAIT_ACK)  ||
                           (dll_state == RETRY);

    // =========================================================================
    // DMA FSM
    // Reads descriptors, fetches data, and writes to target memory.
    // States: DMA_IDLE -> READ_DESC -> FETCH_DATA -> WRITE_DMA -> DMA_IDLE
    // dma_complete is a single-cycle pulse on the WRITE_DMA -> DMA_IDLE transition.
    // =========================================================================
    typedef enum logic [1:0] {
        DMA_IDLE   = 2'b00,
        READ_DESC  = 2'b01,
        FETCH_DATA = 2'b10,
        WRITE_DMA  = 2'b11
    } dma_state_t;

    dma_state_t dma_fsm_state;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dma_fsm_state <= DMA_IDLE;
            dma_complete  <= 1'b0;
        end else begin
            dma_complete <= 1'b0; // default: deasserted each cycle

            case (dma_fsm_state)
                DMA_IDLE: begin
                    // Accept both external dma_request and internal dma_start triggers
                    if (dma_request || dma_start)
                        dma_fsm_state <= READ_DESC;
                end

                READ_DESC: begin
                    dma_fsm_state <= FETCH_DATA;
                end

                FETCH_DATA: begin
                    dma_fsm_state <= WRITE_DMA;
                end

                WRITE_DMA: begin
                    // Single-cycle completion pulse on transition back to idle
                    dma_complete  <= 1'b1;
                    dma_fsm_state <= DMA_IDLE;
                end

                default: dma_fsm_state <= DMA_IDLE;
            endcase
        end
    end

    // =========================================================================
    // MSI-X FSM
    // Generates a single-cycle interrupt to the host after DMA completion.
    // States: MSIX_IDLE -> GENERATE_INT -> MSIX_IDLE
    // =========================================================================
    typedef enum logic {
        MSIX_IDLE    = 1'b0,
        GENERATE_INT = 1'b1
    } msix_state_t;

    msix_state_t msix_fsm_state;

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            msix_fsm_state <= MSIX_IDLE;
            msix_interrupt <= 1'b0;
        end else begin
            msix_interrupt <= 1'b0; // default: deasserted each cycle

            case (msix_fsm_state)
                MSIX_IDLE: begin
                    if (dma_complete)
                        msix_fsm_state <= GENERATE_INT;
                end

                GENERATE_INT: begin
                    // Assert interrupt for exactly one clock cycle then return to idle
                    msix_interrupt <= 1'b1;
                    msix_fsm_state <= MSIX_IDLE;
                end

                default: msix_fsm_state <= MSIX_IDLE;
            endcase
        end
    end

endmodule
