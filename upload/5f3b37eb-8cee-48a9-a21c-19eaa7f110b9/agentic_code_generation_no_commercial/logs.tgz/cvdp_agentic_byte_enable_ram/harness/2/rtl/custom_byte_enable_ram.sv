module custom_byte_enable_ram #(
    parameter int XLEN  = 32,
    parameter int LINES = 8192
) (
    input  logic                      clk,
    // Port A
    input  logic [$clog2(LINES)-1:0] addr_a,
    input  logic                      en_a,
    input  logic [XLEN/8-1:0]        be_a,
    input  logic [XLEN-1:0]          data_in_a,
    output logic [XLEN-1:0]          data_out_a,
    // Port B
    input  logic [$clog2(LINES)-1:0] addr_b,
    input  logic                      en_b,
    input  logic [XLEN/8-1:0]        be_b,
    input  logic [XLEN-1:0]          data_in_b,
    output logic [XLEN-1:0]          data_out_b
);

    localparam int ADDR_WIDTH = $clog2(LINES);
    localparam int BYTES      = XLEN / 8;

    logic [XLEN-1:0] ram [LINES-1:0];

    // Stage-1 pipeline registers
    logic [ADDR_WIDTH-1:0] addr_a_reg, addr_b_reg;
    logic                  en_a_reg,   en_b_reg;
    logic [BYTES-1:0]      be_a_reg,   be_b_reg;
    logic [XLEN-1:0]       data_in_a_reg, data_in_b_reg;

    initial begin
        for (int i = 0; i < LINES; i++)
            ram[i] = '0;
        en_a_reg = '0;
        en_b_reg = '0;
    end

    always_ff @(posedge clk) begin
        // Stage 1: register inputs
        addr_a_reg    <= addr_a;
        en_a_reg      <= en_a;
        be_a_reg      <= be_a;
        data_in_a_reg <= data_in_a;

        addr_b_reg    <= addr_b;
        en_b_reg      <= en_b;
        be_b_reg      <= be_b;
        data_in_b_reg <= data_in_b;

        // Stage 2: write using registered values (non-blocking, so old reg values used)
        if (en_a_reg && en_b_reg && (addr_a_reg == addr_b_reg)) begin
            // Collision: Port A has byte-level priority
            for (int i = 0; i < BYTES; i++) begin
                if (be_a_reg[i])
                    ram[addr_a_reg][i*8 +: 8] <= data_in_a_reg[i*8 +: 8];
                else if (be_b_reg[i])
                    ram[addr_a_reg][i*8 +: 8] <= data_in_b_reg[i*8 +: 8];
            end
        end else begin
            if (en_a_reg) begin
                for (int i = 0; i < BYTES; i++)
                    if (be_a_reg[i])
                        ram[addr_a_reg][i*8 +: 8] <= data_in_a_reg[i*8 +: 8];
            end
            if (en_b_reg) begin
                for (int i = 0; i < BYTES; i++)
                    if (be_b_reg[i])
                        ram[addr_b_reg][i*8 +: 8] <= data_in_b_reg[i*8 +: 8];
            end
        end

        // Stage 2: pipelined read outputs (read-before-write semantics)
        data_out_a <= ram[addr_a_reg];
        data_out_b <= ram[addr_b_reg];
    end

endmodule
