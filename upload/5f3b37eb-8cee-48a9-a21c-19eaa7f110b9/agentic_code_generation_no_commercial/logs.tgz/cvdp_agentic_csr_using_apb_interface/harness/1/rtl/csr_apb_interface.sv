// APB CSR interface with DATA, CONTROL, INTERRUPT, and ISR registers.
// ISR_REG is write-protected; INTERRUPT_REG writes clear ISR flags.
module csr_apb_interface (
    input  logic        clk,
    input  logic        rst_n,

    // APB slave interface
    input  logic        pselx,
    input  logic        penable,
    input  logic        pwrite,
    input  logic [31:0] paddr,
    input  logic [31:0] pwdata,
    output logic [31:0] prdata,
    output logic        pready,
    output logic        pslverr,

    // Hardware interrupt set inputs
    input  logic        overflow_set,
    input  logic        sign_set,
    input  logic        parity_set,
    input  logic        zero_set,

    // FSM state debug output
    output logic [1:0]  debug_state
);

    // --------------------------------------------------------------------------
    // Register addresses
    // --------------------------------------------------------------------------
    localparam logic [31:0] DATA_REG_ADDR      = 32'h10;
    localparam logic [31:0] CONTROL_REG_ADDR   = 32'h14;
    localparam logic [31:0] INTERRUPT_REG_ADDR = 32'h18;
    localparam logic [31:0] ISR_REG_ADDR       = 32'h1C;

    // --------------------------------------------------------------------------
    // FSM state encoding
    // --------------------------------------------------------------------------
    typedef enum logic [1:0] {
        IDLE        = 2'b00,
        SETUP       = 2'b01,
        READ_STATE  = 2'b10,
        WRITE_STATE = 2'b11
    } state_t;

    state_t current_state, next_state;

    // --------------------------------------------------------------------------
    // Internal registers
    //   DATA_REG      [31:20] reserved | [19:10] data1 | [9:0] data2
    //   CONTROL_REG   [31:2]  reserved | [1] mode      | [0] enable
    //   INTERRUPT_REG [31:4]  reserved | [3] zero_ie   | [2] parity_ie
    //                                  | [1] sign_ie   | [0] overflow_ie
    //   ISR_REG       [31:4]  reserved | [3] zero_is   | [2] parity_is
    //                                  | [1] sign_is   | [0] overflow_is
    // --------------------------------------------------------------------------
    logic [31:0] data_reg;
    logic [31:0] control_reg;
    logic [31:0] interrupt_reg;
    logic [31:0] isr_reg;

    // --------------------------------------------------------------------------
    // FSM: state register
    // --------------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            current_state <= IDLE;
        else
            current_state <= next_state;
    end

    // --------------------------------------------------------------------------
    // FSM: next-state logic
    // IDLE  → SETUP       : pselx asserted
    // SETUP → READ_STATE  : penable & !pwrite  (APB access phase)
    // SETUP → WRITE_STATE : penable &  pwrite
    // READ_STATE  → IDLE
    // WRITE_STATE → IDLE
    // --------------------------------------------------------------------------
    always_comb begin
        next_state = current_state;
        case (current_state)
            IDLE: begin
                if (pselx)
                    next_state = SETUP;
            end
            SETUP: begin
                if (penable) begin
                    if (pwrite)
                        next_state = WRITE_STATE;
                    else
                        next_state = READ_STATE;
                end
            end
            READ_STATE:  next_state = IDLE;
            WRITE_STATE: next_state = IDLE;
            default:     next_state = IDLE;
        endcase
    end

    // --------------------------------------------------------------------------
    // DATA_REG / CONTROL_REG / INTERRUPT_REG write
    // --------------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            data_reg      <= 32'h0;
            control_reg   <= 32'h0;
            interrupt_reg <= 32'h0;
        end else if (current_state == WRITE_STATE) begin
            case (paddr)
                DATA_REG_ADDR:    data_reg      <= pwdata;
                CONTROL_REG_ADDR: control_reg   <= pwdata;
                // Writing to INTERRUPT_REG updates enable bits; ISR clear
                // is handled in the isr_reg block below.
                INTERRUPT_REG_ADDR: interrupt_reg <= pwdata;
                // ISR_REG is write-protected — no register update here.
                default: ;
            endcase
        end
    end

    // --------------------------------------------------------------------------
    // ISR_REG: set by hardware inputs, cleared by writing 1 to INTERRUPT_REG
    // --------------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            isr_reg <= 32'h0;
        end else begin
            // Hardware sets individual flags
            if (overflow_set) isr_reg[0] <= 1'b1;
            if (sign_set)     isr_reg[1] <= 1'b1;
            if (parity_set)   isr_reg[2] <= 1'b1;
            if (zero_set)     isr_reg[3] <= 1'b1;

            // Software clears flags by writing 1 to matching bits in INTERRUPT_REG
            if (current_state == WRITE_STATE && paddr == INTERRUPT_REG_ADDR) begin
                if (pwdata[0]) isr_reg[0] <= 1'b0;
                if (pwdata[1]) isr_reg[1] <= 1'b0;
                if (pwdata[2]) isr_reg[2] <= 1'b0;
                if (pwdata[3]) isr_reg[3] <= 1'b0;
            end
        end
    end

    // --------------------------------------------------------------------------
    // Read data mux (registered, captured in READ_STATE)
    // --------------------------------------------------------------------------
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            prdata <= 32'h0;
        end else if (current_state == READ_STATE) begin
            case (paddr)
                DATA_REG_ADDR:      prdata <= data_reg;
                CONTROL_REG_ADDR:   prdata <= control_reg;
                INTERRUPT_REG_ADDR: prdata <= interrupt_reg;
                ISR_REG_ADDR:       prdata <= isr_reg;
                default:            prdata <= 32'h0;
            endcase
        end
    end

    // --------------------------------------------------------------------------
    // pready: asserted during ACCESS phase (READ_STATE / WRITE_STATE)
    // --------------------------------------------------------------------------
    assign pready = (current_state == READ_STATE) || (current_state == WRITE_STATE);

    // --------------------------------------------------------------------------
    // pslverr: write-protection violation on ISR_REG
    // --------------------------------------------------------------------------
    assign pslverr = (current_state == WRITE_STATE) && (paddr == ISR_REG_ADDR);

    // --------------------------------------------------------------------------
    // Debug: expose raw FSM state encoding
    // --------------------------------------------------------------------------
    assign debug_state = current_state;

endmodule
