module padding_top #(
    parameter NBW_KEY  = 'd256,
    parameter NBW_DATA = 'd128,
    parameter NBW_MODE = 'd3,
    parameter NBW_CNTR = 'd32,
    parameter NBW_PADD = 'd4,
    parameter NBW_PMOD = 'd2,
    parameter W3C_BYTE = 8'hAF
) (
    input  logic                clk,
    input  logic                rst_async_n,
    input  logic                i_encrypt,
    input  logic                i_update_padding_mode,
    input  logic [NBW_PMOD-1:0] i_padding_mode,
    input  logic [NBW_PADD-1:0] i_padding_bytes,
    input  logic                i_reset_counter,
    input  logic                i_update_iv,
    input  logic [NBW_DATA-1:0] i_iv,
    input  logic                i_update_mode,
    input  logic [NBW_MODE-1:0] i_mode,
    input  logic                i_update_key,
    input  logic [NBW_KEY-1:0]  i_key,
    input  logic                i_start,
    input  logic [NBW_DATA-1:0] i_data,
    output logic                o_done,
    output logic [NBW_DATA-1:0] o_data
);

localparam PKCS         = 2'b00;
localparam ONEANDZEROES = 2'b01;
localparam ANSIX923     = 2'b10;
localparam W3C_MODE     = 2'b11;

logic [NBW_PMOD-1:0] padding_mode_ff;
logic [NBW_DATA-1:0] padded_data;

logic                enc_done;
logic [NBW_DATA-1:0] enc_ciphertext;
logic                dec_done;
logic [NBW_DATA-1:0] dec_plaintext;

wire enc_reset_counter = i_encrypt & i_reset_counter;
wire enc_update_iv     = i_encrypt & i_update_iv;
wire enc_update_mode   = i_encrypt & i_update_mode;
wire enc_update_key    = i_encrypt & i_update_key;
wire enc_start         = i_encrypt & i_start;

wire dec_reset_counter = (~i_encrypt) & i_reset_counter;
wire dec_update_iv     = (~i_encrypt) & i_update_iv;
wire dec_update_mode   = (~i_encrypt) & i_update_mode;
wire dec_update_key    = (~i_encrypt) & i_update_key;
wire dec_start         = (~i_encrypt) & i_start;

assign o_done = i_encrypt ? enc_done : dec_done;
assign o_data = i_encrypt ? enc_ciphertext : dec_plaintext;

always_ff @(posedge clk or negedge rst_async_n) begin
    if (!rst_async_n) begin
        padding_mode_ff <= '0;
    end else if (i_update_padding_mode) begin
        padding_mode_ff <= i_padding_mode;
    end
end

always_comb begin : padding_logic
    padded_data = i_data;
    if (i_padding_bytes != '0) begin
        for (int i = 0; i < NBW_DATA/8; i++) begin
            if (i < int'(i_padding_bytes)) begin
                case (padding_mode_ff)
                    PKCS: begin
                        padded_data[i*8 +: 8] = 8'(i_padding_bytes);
                    end
                    ONEANDZEROES: begin
                        padded_data[i*8 +: 8] = (i == int'(i_padding_bytes) - 1) ? 8'h80 : 8'h00;
                    end
                    ANSIX923: begin
                        padded_data[i*8 +: 8] = (i == 0) ? 8'(i_padding_bytes) : 8'h00;
                    end
                    W3C_MODE: begin
                        padded_data[i*8 +: 8] = (i == 0) ? 8'(i_padding_bytes) : 8'(W3C_BYTE);
                    end
                    default: begin
                        padded_data[i*8 +: 8] = i_data[i*8 +: 8];
                    end
                endcase
            end
        end
    end
end

aes_enc_top #(
    .NBW_KEY (NBW_KEY ),
    .NBW_DATA(NBW_DATA),
    .NBW_MODE(NBW_MODE),
    .NBW_CNTR(NBW_CNTR)
) uu_aes_enc_top (
    .clk            (clk              ),
    .rst_async_n    (rst_async_n      ),
    .i_reset_counter(enc_reset_counter),
    .i_update_iv    (enc_update_iv    ),
    .i_iv           (i_iv             ),
    .i_update_mode  (enc_update_mode  ),
    .i_mode         (i_mode           ),
    .i_update_key   (enc_update_key   ),
    .i_key          (i_key            ),
    .i_start        (enc_start        ),
    .i_plaintext    (padded_data      ),
    .o_done         (enc_done         ),
    .o_ciphertext   (enc_ciphertext   )
);

aes_dec_top #(
    .NBW_KEY (NBW_KEY ),
    .NBW_DATA(NBW_DATA),
    .NBW_MODE(NBW_MODE),
    .NBW_CNTR(NBW_CNTR)
) uu_aes_dec_top (
    .clk            (clk              ),
    .rst_async_n    (rst_async_n      ),
    .i_reset_counter(dec_reset_counter),
    .i_update_iv    (dec_update_iv    ),
    .i_iv           (i_iv             ),
    .i_update_mode  (dec_update_mode  ),
    .i_mode         (i_mode           ),
    .i_update_key   (dec_update_key   ),
    .i_key          (i_key            ),
    .i_start        (dec_start        ),
    .i_ciphertext   (padded_data      ),
    .o_done         (dec_done         ),
    .o_plaintext    (dec_plaintext    )
);

endmodule : padding_top
