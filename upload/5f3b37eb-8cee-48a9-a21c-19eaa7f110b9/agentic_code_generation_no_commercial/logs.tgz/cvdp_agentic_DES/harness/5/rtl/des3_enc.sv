module des3_enc #(
    parameter NBW_DATA = 'd64,
    parameter NBW_KEY  = 'd192
) (
    input  logic              clk,
    input  logic              rst_async_n,
    input  logic              i_valid,
    input  logic [1:NBW_DATA] i_data,
    input  logic [1:NBW_KEY]  i_key,
    output logic              o_valid,
    output logic [1:NBW_DATA] o_data
);

localparam NBW_SUBKEY      = 'd64;
localparam PIPELINE_STAGES = 'd16;

// Key extraction: K1=i_key[1:64], K2=i_key[65:128], K3=i_key[129:192]
logic [1:NBW_SUBKEY] k1, k2, k3;
assign k1 = i_key[1:64];
assign k2 = i_key[65:128];
assign k3 = i_key[129:192];

// Delay K2 by 16 cycles and K3 by 32 cycles to align with pipeline stages
logic [1:NBW_SUBKEY] k2_pipe [0:PIPELINE_STAGES-1];
logic [1:NBW_SUBKEY] k3_pipe [0:2*PIPELINE_STAGES-1];

always_ff @(posedge clk or negedge rst_async_n) begin
    if (!rst_async_n) begin
        for (int i = 0; i < PIPELINE_STAGES; i++)     k2_pipe[i] <= '0;
        for (int i = 0; i < 2*PIPELINE_STAGES; i++)   k3_pipe[i] <= '0;
    end else begin
        k2_pipe[0] <= k2;
        for (int i = 1; i < PIPELINE_STAGES; i++)     k2_pipe[i] <= k2_pipe[i-1];
        k3_pipe[0] <= k3;
        for (int i = 1; i < 2*PIPELINE_STAGES; i++)   k3_pipe[i] <= k3_pipe[i-1];
    end
end

// Stage 1 -> Stage 2 interconnects
logic              s1_valid;
logic [1:NBW_DATA] s1_data;

// Stage 2 -> Stage 3 interconnects
logic              s2_valid;
logic [1:NBW_DATA] s2_data;

// Stage 1: Encrypt with K1
des_enc #(
    .NBW_DATA(NBW_DATA),
    .NBW_KEY (NBW_SUBKEY)
) uu_stage1 (
    .clk        (clk        ),
    .rst_async_n(rst_async_n),
    .i_valid    (i_valid    ),
    .i_data     (i_data     ),
    .i_key      (k1         ),
    .o_valid    (s1_valid   ),
    .o_data     (s1_data    )
);

// Stage 2: Decrypt with K2 (K2 delayed 16 cycles to match s1_valid)
des_dec #(
    .NBW_DATA(NBW_DATA),
    .NBW_KEY (NBW_SUBKEY)
) uu_stage2 (
    .clk        (clk                        ),
    .rst_async_n(rst_async_n                ),
    .i_valid    (s1_valid                   ),
    .i_data     (s1_data                    ),
    .i_key      (k2_pipe[PIPELINE_STAGES-1] ),
    .o_valid    (s2_valid                   ),
    .o_data     (s2_data                    )
);

// Stage 3: Encrypt with K3 (K3 delayed 32 cycles to match s2_valid)
des_enc #(
    .NBW_DATA(NBW_DATA),
    .NBW_KEY (NBW_SUBKEY)
) uu_stage3 (
    .clk        (clk                          ),
    .rst_async_n(rst_async_n                  ),
    .i_valid    (s2_valid                     ),
    .i_data     (s2_data                      ),
    .i_key      (k3_pipe[2*PIPELINE_STAGES-1] ),
    .o_valid    (o_valid                      ),
    .o_data     (o_data                       )
);

endmodule : des3_enc
