module des3_dec #(
    parameter NBW_DATA = 'd64,
    parameter NBW_KEY  = 'd192
) (
    input  logic              clk,
    input  logic              rst_async_n,
    input  logic              i_start,
    input  logic [1:NBW_DATA] i_data,
    input  logic [1:NBW_KEY]  i_key,
    output logic              o_done,
    output logic [1:NBW_DATA] o_data
);

// K1 = i_key[1:64], K2 = i_key[65:128], K3 = i_key[129:192]
// DED: dec(K3) -> enc(K2) -> dec(K1)
localparam LATENCY = 'd48;

logic             busy;
logic [5:0]       counter;
logic [1:NBW_KEY] key_reg;

logic [1:NBW_DATA] stage1_o_data;
logic [1:NBW_DATA] stage2_o_data;
logic [1:NBW_DATA] stage3_o_data;

// stage1_start fires combinationally when accepted so stage1 samples i_data/i_key[K3] at the same posedge
assign stage1_start = i_start & ~busy;
assign stage2_start = busy & (counter == 'd15);
assign stage3_start = busy & (counter == 'd31);

// Stage 1: decrypt with K3
des_dec #(.NBW_DATA(NBW_DATA), .NBW_KEY(64)) uu_stage1 (
    .clk        (clk            ),
    .rst_async_n(rst_async_n    ),
    .i_start    (stage1_start   ),
    .i_data     (i_data         ),
    .i_key      (i_key[129:192] ),
    .o_data     (stage1_o_data  )
);

// Stage 2: encrypt with K2 (uses registered key captured at start)
des_enc #(.NBW_DATA(NBW_DATA), .NBW_KEY(64)) uu_stage2 (
    .clk        (clk            ),
    .rst_async_n(rst_async_n    ),
    .i_start    (stage2_start   ),
    .i_data     (stage1_o_data  ),
    .i_key      (key_reg[65:128]),
    .o_data     (stage2_o_data  )
);

// Stage 3: decrypt with K1 (uses registered key captured at start)
des_dec #(.NBW_DATA(NBW_DATA), .NBW_KEY(64)) uu_stage3 (
    .clk        (clk            ),
    .rst_async_n(rst_async_n    ),
    .i_start    (stage3_start   ),
    .i_data     (stage2_o_data  ),
    .i_key      (key_reg[1:64]  ),
    .o_data     (stage3_o_data  )
);

always_ff @ (posedge clk or negedge rst_async_n) begin
    if (!rst_async_n) begin
        busy    <= 1'b0;
        counter <= 6'd0;
        o_done  <= 1'b0;
        o_data  <= '0;
        key_reg <= '0;
    end else begin
        if (!busy && i_start) begin
            busy    <= 1'b1;
            counter <= 6'd0;
            o_done  <= 1'b0;
            key_reg <= i_key;
        end else if (busy) begin
            if (counter == 6'd47) begin
                busy   <= 1'b0;
                o_done <= 1'b1;
                o_data <= stage3_o_data;
            end else begin
                counter <= counter + 6'd1;
            end
        end
    end
end

endmodule : des3_dec
