import cocotb
from cocotb.triggers import FallingEdge, RisingEdge, Timer
from collections import deque

async def dut_init(dut):
    # iterate all the input signals and initialize with 0
    for signal in dut:
        try:
            signal.value = 0
        except Exception:
            pass

class des:
    def __init__(self):
        self.reset()

    def reset(self):
        self.data_out = 0
        self.enc_out = 0
        self.dec_out = 0
        self.fifo = []

    def permute(self, block, table, n):
        result = 0
        for i in range(len(table)):
            bit = (block >> (n - table[i])) & 1
            result |= (bit << (len(table) - 1 - i))
        return result

    def left_rotate(self, val, n):
        return ((val << n) & 0x0FFFFFFF) | (val >> (28 - n))

    def sbox(self, box, val):
        row = ((val >> 5) & 1) * 2 + (val & 1)
        col = (val >> 1) & 0xF
        return box[row][col]

    def f(self, R, subkey):
        E = [32,1,2,3,4,5,4,5,6,7,8,9,
             8,9,10,11,12,13,12,13,14,15,16,17,
             16,17,18,19,20,21,20,21,22,23,24,25,
             24,25,26,27,28,29,28,29,30,31,32,1]

        P = [16,7,20,21,29,12,28,17,
             1,15,23,26,5,18,31,10,
             2,8,24,14,32,27,3,9,
             19,13,30,6,22,11,4,25]

        SBOXES = self.sboxes

        expanded = self.permute(R << 32, E, 64)
        xored = expanded ^ subkey

        output = 0
        for i in range(8):
            chunk = (xored >> (42 - i*6)) & 0x3F
            sbox_val = self.sbox(SBOXES[i], chunk)
            output = (output << 4) | sbox_val

        return self.permute(output << 32, P, 64)

    def generate_subkeys(self, key):
        PC1 = [57,49,41,33,25,17,9,
               1,58,50,42,34,26,18,
               10,2,59,51,43,35,27,
               19,11,3,60,52,44,36,
               63,55,47,39,31,23,15,
               7,62,54,46,38,30,22,
               14,6,61,53,45,37,29,
               21,13,5,28,20,12,4]

        PC2 = [14,17,11,24,1,5,
               3,28,15,6,21,10,
               23,19,12,4,26,8,
               16,7,27,20,13,2,
               41,52,31,37,47,55,
               30,40,51,45,33,48,
               44,49,39,56,34,53,
               46,42,50,36,29,32]

        rotations = [1, 1, 2, 2, 2, 2, 2, 2,
                     1, 2, 2, 2, 2, 2, 2, 1]

        key56 = self.permute(key, PC1, 64)
        C = (key56 >> 28) & 0xFFFFFFF
        D = key56 & 0xFFFFFFF

        subkeys = []
        for rot in rotations:
            C = self.left_rotate(C, rot)
            D = self.left_rotate(D, rot)
            CD = (C << 28) | D
            subkey = self.permute(CD, PC2, 56)
            subkeys.append(subkey)
        return subkeys
    
    def decrypt(self, data, key):
        IP = [58,50,42,34,26,18,10,2,
              60,52,44,36,28,20,12,4,
              62,54,46,38,30,22,14,6,
              64,56,48,40,32,24,16,8,
              57,49,41,33,25,17,9,1,
              59,51,43,35,27,19,11,3,
              61,53,45,37,29,21,13,5,
              63,55,47,39,31,23,15,7]

        FP = [40,8,48,16,56,24,64,32,
              39,7,47,15,55,23,63,31,
              38,6,46,14,54,22,62,30,
              37,5,45,13,53,21,61,29,
              36,4,44,12,52,20,60,28,
              35,3,43,11,51,19,59,27,
              34,2,42,10,50,18,58,26,
              33,1,41,9,49,17,57,25]

        block = self.permute(data, IP, 64)
        L = (block >> 32) & 0xFFFFFFFF
        R = block & 0xFFFFFFFF

        subkeys = self.generate_subkeys(key)[::-1]  # Reverse subkeys for decryption

        for i in range(16):
            temp = R
            R = L ^ self.f(R, subkeys[i])
            L = temp

        pre_output = (R << 32) | L
        self.dec_out = self.permute(pre_output, FP, 64)

    def encrypt(self, data, key):
        IP = [58,50,42,34,26,18,10,2,
              60,52,44,36,28,20,12,4,
              62,54,46,38,30,22,14,6,
              64,56,48,40,32,24,16,8,
              57,49,41,33,25,17,9,1,
              59,51,43,35,27,19,11,3,
              61,53,45,37,29,21,13,5,
              63,55,47,39,31,23,15,7]

        FP = [40,8,48,16,56,24,64,32,
              39,7,47,15,55,23,63,31,
              38,6,46,14,54,22,62,30,
              37,5,45,13,53,21,61,29,
              36,4,44,12,52,20,60,28,
              35,3,43,11,51,19,59,27,
              34,2,42,10,50,18,58,26,
              33,1,41,9,49,17,57,25]

        block = self.permute(data, IP, 64)
        L = (block >> 32) & 0xFFFFFFFF
        R = block & 0xFFFFFFFF

        subkeys = self.generate_subkeys(key)

        for i in range(16):
            temp = R
            R = L ^ self.f(R, subkeys[i])
            L = temp

        pre_output = (R << 32) | L
        self.enc_out = self.permute(pre_output, FP, 64)
    
    def des3_enc(self, data, key):
        K1 = (key & 0xFFFFFFFFFFFFFFFF00000000000000000000000000000000) >> 128
        K2 = (key & 0x0000000000000000FFFFFFFFFFFFFFFF0000000000000000) >> 64
        K3 = key & 0x00000000000000000000000000000000FFFFFFFFFFFFFFFF
        self.encrypt(data, K1)
        self.decrypt(self.enc_out, K2)
        self.encrypt(self.dec_out, K3)

        self.fifo.append(self.enc_out)
    
    def des3_dec(self, data, key):
        K1 = (key & 0xFFFFFFFFFFFFFFFF00000000000000000000000000000000) >> 128
        K2 = (key & 0x0000000000000000FFFFFFFFFFFFFFFF0000000000000000) >> 64
        K3 =  key & 0x00000000000000000000000000000000FFFFFFFFFFFFFFFF
        self.decrypt(data, K3)
        self.encrypt(self.dec_out, K2)
        self.decrypt(self.enc_out, K1)

        self.fifo.append(self.dec_out)
    
    def read_data(self):
        if self.fifo:
            return self.fifo.pop(0)
        return 0

    # Full DES S-box definitions
    sboxes = [
        [
            [14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7],
            [0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8],
            [4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0],
            [15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13]
        ],
        [
            [15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10],
            [3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5],
            [0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15],
            [13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9]
        ],
        [
            [10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8],
            [13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1],
            [13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7],
            [1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12]
        ],
        [
            [7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15],
            [13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9],
            [10,6,9,0,12,11,7,13,15,1,3,14,5,2,8,4],
            [3,15,0,6,10,1,13,8,9,4,5,11,12,7,2,14]
        ],
        [
            [2,12,4,1,7,10,11,6,8,5,3,15,13,0,14,9],
            [14,11,2,12,4,7,13,1,5,0,15,10,3,9,8,6],
            [4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14],
            [11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3]
        ],
        [
            [12,1,10,15,9,2,6,8,0,13,3,4,14,7,5,11],
            [10,15,4,2,7,12,9,5,6,1,13,14,0,11,3,8],
            [9,14,15,5,2,8,12,3,7,0,4,10,1,13,11,6],
            [4,3,2,12,9,5,15,10,11,14,1,7,6,0,8,13]
        ],
        [
            [4,11,2,14,15,0,8,13,3,12,9,7,5,10,6,1],
            [13,0,11,7,4,9,1,10,14,3,5,12,2,15,8,6],
            [1,4,11,13,12,3,7,14,10,15,6,8,0,5,9,2],
            [6,11,13,8,1,4,10,7,9,5,0,15,14,2,3,12]
        ],
        [
            [13,2,8,4,6,15,11,1,10,9,3,14,5,0,12,7],
            [1,15,13,8,10,3,7,4,12,5,6,11,0,14,9,2],
            [7,11,4,1,9,12,14,2,0,6,10,13,15,3,5,8],
            [2,1,14,7,4,10,8,13,15,12,9,0,3,5,6,11]
        ]
    ]