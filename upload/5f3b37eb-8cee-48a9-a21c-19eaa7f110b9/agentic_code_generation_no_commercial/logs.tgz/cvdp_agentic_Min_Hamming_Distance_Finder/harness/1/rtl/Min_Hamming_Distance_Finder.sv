// Min_Hamming_Distance_Finder
//
// Top-level module that finds the reference vector with the smallest Hamming
// distance to a given query vector.
//
// Hierarchy:
//   Min_Hamming_Distance_Finder
//     └─ Bit_Difference_Counter  (one per reference vector)
//          └─ Data_Reduction     (XOR across the two input vectors)
//               └─ Bitwise_Reduction  (per-bit XOR reduction)

module Min_Hamming_Distance_Finder
#(
    parameter BIT_WIDTH       = 8,  // Number of bits in each vector
    parameter REFERENCE_COUNT = 4   // Number of reference vectors to compare against
)
(
    // Query vector to compare against all references
    input  wire [BIT_WIDTH-1:0]                 input_query,

    // Packed array of reference vectors; reference i occupies bits
    // [i*BIT_WIDTH +: BIT_WIDTH] (reference 0 is at the LSB end)
    input  wire [REFERENCE_COUNT*BIT_WIDTH-1:0] references,

    // Index of the reference vector with the smallest Hamming distance;
    // ties are broken in favour of the lower index
    output reg  [$clog2(REFERENCE_COUNT)-1:0]   best_match_index,

    // The minimum Hamming distance found
    output reg  [$clog2(BIT_WIDTH+1)-1:0]       min_distance
);

    // Width needed to represent any distance in [0, BIT_WIDTH]
    localparam DIST_WIDTH = $clog2(BIT_WIDTH + 1);

    // One distance value per reference vector, produced in parallel
    wire [DIST_WIDTH-1:0] distances [0:REFERENCE_COUNT-1];

    // Instantiate one Bit_Difference_Counter for each reference vector.
    // All distance calculations happen simultaneously (purely combinational).
    genvar ref_idx;
    generate
        for (ref_idx = 0; ref_idx < REFERENCE_COUNT; ref_idx = ref_idx + 1) begin : distance_counters
            Bit_Difference_Counter
            #(
                .BIT_WIDTH (BIT_WIDTH)
            )
            counter_inst
            (
                .input_A             (input_query),
                .input_B             (references[ref_idx*BIT_WIDTH +: BIT_WIDTH]),
                .bit_difference_count(distances[ref_idx])
            );
        end
    endgenerate

    // Sequential scan over all computed distances to find the minimum.
    // best_match_index is updated whenever a strictly smaller distance is
    // found, so the first (lowest-indexed) minimum wins on ties.
    integer i;
    always @(*) begin
        min_distance     = distances[0];
        best_match_index = {$clog2(REFERENCE_COUNT){1'b0}};

        for (i = 1; i < REFERENCE_COUNT; i = i + 1) begin
            if (distances[i] < min_distance) begin
                min_distance     = distances[i];
                best_match_index = i[$clog2(REFERENCE_COUNT)-1:0];
            end
        end
    end

endmodule
