`timescale 1ns/1ps

// AXI4-Lite to PCIe Configuration Space Bridge
// Supports both write and read transactions via AXI4-Lite protocol.
// Write path: IDLE -> ADDR_CAPTURE -> DATA_CAPTURE -> PCIE_WRITE -> SEND_RESPONSE
// Read  path: IDLE -> ADDR_CAPTURE -> PCIE_READ -> SEND_RESPONSE
module axi4lite_to_pcie_cfg_bridge #(

    parameter ADDR_WIDTH = 8,
    parameter DATA_WIDTH = 32
    )(
    // AXI4-Lite Interface
    input  logic        aclk,
    input  logic        aresetn,

    // AXI4-Lite Write Address Channel
    input  logic [ADDR_WIDTH-1:0] awaddr,
    input  logic        awvalid,
    output logic        awready,

    // AXI4-Lite Write Data Channel
    input  logic [DATA_WIDTH-1:0] wdata,
    input  logic [DATA_WIDTH/8-1:0]  wstrb,
    input  logic        wvalid,
    output logic        wready,

    // AXI4-Lite Write Response Channel
    output logic [1:0]  bresp,
    output logic        bvalid,
    input  logic        bready,

    // AXI4-Lite Read Address Channel
    input  logic [ADDR_WIDTH-1:0] araddr,          // Read address from AXI4-Lite master
    input  logic        arvalid,                   // Read address valid signal
    output logic        arready,                   // Read address ready signal

    // AXI4-Lite Read Data Channel
    output logic [DATA_WIDTH-1:0] rdata,            // Read data output
    output logic        rvalid,                    // Read data valid signal
    input  logic        rready,                    // Read data ready signal
    output logic [1:0]  rresp,                     // Read response signal

    // PCIe Configuration Space Interface
    output logic [ADDR_WIDTH/4-1:0]  pcie_cfg_addr,
    output logic [DATA_WIDTH-1:0] pcie_cfg_wdata,
    output logic        pcie_cfg_wr_en,
    input  logic [DATA_WIDTH-1:0] pcie_cfg_rdata,
    input  logic        pcie_cfg_rd_en
);

    // FSM States - shared between write and read transaction paths
    typedef enum logic [2:0] {
        IDLE,           // Waits for valid AXI4-Lite write (awvalid+wvalid) or read (arvalid)
        ADDR_CAPTURE,   // Captures write address (awaddr) or read address (araddr)
        DATA_CAPTURE,   // Captures write data and strobe - write path only
        PCIE_WRITE,     // Initiates PCIe configuration space write
        PCIE_READ,      // Drives PCIe read address and waits for pcie_cfg_rd_en
        SEND_RESPONSE   // Sends write response (bvalid/bresp) or read response (rvalid/rdata/rresp)
    } state_t;

    state_t current_state, next_state;

    // Internal registers for write transaction
    logic [ADDR_WIDTH-1:0] awaddr_reg;
    logic [DATA_WIDTH-1:0] wdata_reg;
    logic [DATA_WIDTH/8-1:0]  wstrb_reg;

    // Internal registers for read transaction
    logic [ADDR_WIDTH-1:0] araddr_reg;  // Captured read address

    // Transaction type flag set in IDLE; 1 = read, 0 = write
    // Valid when current_state >= ADDR_CAPTURE
    logic is_read;

    // FSM State Transition
    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            current_state <= IDLE;
        end else begin
            current_state <= next_state;
        end
    end

    // FSM Next State Logic
    always_comb begin
        next_state = current_state;
        case (current_state)
            IDLE: begin
                if (awvalid && wvalid) begin
                    // Write transaction takes priority when both write and read are pending
                    next_state = ADDR_CAPTURE;
                end else if (arvalid) begin
                    // Read transaction detected
                    next_state = ADDR_CAPTURE;
                end
            end

            ADDR_CAPTURE: begin
                // Branch to read or write path based on transaction type captured in IDLE
                if (is_read)
                    next_state = PCIE_READ;
                else
                    next_state = DATA_CAPTURE;
            end

            DATA_CAPTURE: begin
                next_state = PCIE_WRITE;
            end

            PCIE_WRITE: begin
                next_state = SEND_RESPONSE;
            end

            PCIE_READ: begin
                // Wait for PCIe to signal that read data is valid
                if (pcie_cfg_rd_en)
                    next_state = SEND_RESPONSE;
            end

            SEND_RESPONSE: begin
                // Write: wait for master to accept response via bready
                // Read:  wait for master to accept data via rready
                if (is_read) begin
                    if (rready)
                        next_state = IDLE;
                end else begin
                    if (bready)
                        next_state = IDLE;
                end
            end

            default: begin
                next_state = IDLE;
            end
        endcase
    end

    // FSM Output Logic
    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            awready <= 1'b0;
            wready <= 1'b0;
            bvalid <= 1'b0;
            bresp <= 2'b00; // OKAY response
            arready <= 1'b0;
            rvalid <= 1'b0;
            rresp <= 2'b00; // OKAY response
            rdata <= {DATA_WIDTH{1'b0}};
            pcie_cfg_wr_en <= 1'b0;
            pcie_cfg_wdata <= 32'h0;
            pcie_cfg_addr <= 8'h0;
            awaddr_reg <= 32'h0;
            araddr_reg <= {ADDR_WIDTH{1'b0}};
            wdata_reg <= 32'h0;
            wstrb_reg <= 4'h0;
            is_read <= 1'b0;
        end else begin
            case (current_state)
                IDLE: begin
                    // Deassert all handshake signals and record incoming transaction type
                    awready <= 1'b0;
                    wready <= 1'b0;
                    bvalid <= 1'b0;
                    arready <= 1'b0;
                    rvalid <= 1'b0;
                    pcie_cfg_wr_en <= 1'b0;
                    // Set is_read so ADDR_CAPTURE can route to the correct next state
                    if (awvalid && wvalid)
                        is_read <= 1'b0;
                    else if (arvalid)
                        is_read <= 1'b1;
                end

                ADDR_CAPTURE: begin
                    if (is_read) begin
                        // Read path: capture read address and assert arready
                        arready <= 1'b1;
                        araddr_reg <= araddr;
                    end else begin
                        // Write path: capture write address and assert awready
                        awready <= 1'b1;
                        awaddr_reg <= awaddr;
                    end
                end

                DATA_CAPTURE: begin
                    // Capture write data and byte strobes, assert wready
                    wready <= 1'b1;
                    wdata_reg <= wdata;
                    wstrb_reg <= wstrb;
                end

                PCIE_WRITE: begin
                    pcie_cfg_wr_en <= 1'b1;
                    pcie_cfg_addr <= awaddr_reg[7:0]; // 8-bit PCIe address

                    // Apply wstrb to write only the selected bytes
                    for (int i = 0; i < (DATA_WIDTH/8); i++) begin
                        pcie_cfg_wdata[(i*8)+:8] <= (wstrb_reg[i]) ? wdata_reg[(i*8)+:8] : pcie_cfg_rdata[(i*8)+:8];
                    end
                end

                PCIE_READ: begin
                    // Drive read address to PCIe configuration space
                    pcie_cfg_addr <= araddr_reg[7:0];
                    // Capture read data when PCIe asserts pcie_cfg_rd_en (data valid)
                    if (pcie_cfg_rd_en)
                        rdata <= pcie_cfg_rdata;
                end

                SEND_RESPONSE: begin
                    pcie_cfg_wr_en <= 1'b0;
                    if (is_read) begin
                        // Read response: assert rvalid with OKAY; rdata already captured in PCIE_READ
                        rvalid <= 1'b1;
                        rresp <= 2'b00; // OKAY
                    end else begin
                        // Write response: assert bvalid with OKAY
                        bvalid <= 1'b1;
                    end
                end

                default: begin
                    // Default outputs
                end
            endcase
        end
    end

endmodule
