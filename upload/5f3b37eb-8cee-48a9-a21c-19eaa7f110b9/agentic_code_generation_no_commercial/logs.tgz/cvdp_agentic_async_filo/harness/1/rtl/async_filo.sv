module async_filo #(
    parameter DATA_WIDTH = 16,
    parameter DEPTH      = 8
) (
    input  logic                  w_clk,
    input  logic                  w_rst,
    input  logic                  push,
    input  logic                  r_clk,
    input  logic                  r_rst,
    input  logic                  pop,
    input  logic [DATA_WIDTH-1:0] w_data,
    output logic [DATA_WIDTH-1:0] r_data,
    output logic                  r_empty,
    output logic                  w_full
);

    localparam ADDR_WIDTH = $clog2(DEPTH);
    localparam PTR_WIDTH  = ADDR_WIDTH + 1;

    logic [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    // Write domain
    logic [PTR_WIDTH-1:0] w_count_bin;  // binary write counter (increments on push)
    logic [PTR_WIDTH-1:0] w_ptr;        // Gray-coded write pointer
    logic [PTR_WIDTH-1:0] wq1_rptr;     // synchronizer stage 1: r_ptr -> write domain
    logic [PTR_WIDTH-1:0] wq2_rptr;     // synchronizer stage 2: r_ptr -> write domain

    // Read domain
    logic [PTR_WIDTH-1:0] r_count_bin;  // binary read counter (decrements on pop)
    logic [PTR_WIDTH-1:0] r_ptr;        // Gray-coded read pointer
    logic [PTR_WIDTH-1:0] rq1_wptr;     // synchronizer stage 1: w_ptr -> read domain
    logic [PTR_WIDTH-1:0] rq2_wptr;     // synchronizer stage 2: w_ptr -> read domain

    // ---------------------------------------------------------------------------
    // Gray code helpers
    // ---------------------------------------------------------------------------
    function automatic [PTR_WIDTH-1:0] bin2gray(input [PTR_WIDTH-1:0] b);
        return b ^ (b >> 1);
    endfunction

    function automatic [PTR_WIDTH-1:0] gray2bin(input [PTR_WIDTH-1:0] g);
        logic [PTR_WIDTH-1:0] b;
        b[PTR_WIDTH-1] = g[PTR_WIDTH-1];
        for (int i = PTR_WIDTH-2; i >= 0; i--)
            b[i] = b[i+1] ^ g[i];
        return b;
    endfunction

    // ---------------------------------------------------------------------------
    // Next-state combinatorial signals
    // ---------------------------------------------------------------------------
    logic [PTR_WIDTH-1:0] w_count_next;
    logic [PTR_WIDTH-1:0] r_count_next;

    // w_count increments on valid push; r_count decrements on valid pop
    assign w_count_next = (!w_full  && push) ? w_count_bin + 1'b1 : w_count_bin;
    assign r_count_next = (!r_empty && pop)  ? r_count_bin - 1'b1 : r_count_bin;

    // ---------------------------------------------------------------------------
    // Write domain: push and synchronize r_ptr
    // ---------------------------------------------------------------------------
    always_ff @(posedge w_clk) begin
        if (w_rst) begin
            w_count_bin <= '0;
            w_ptr       <= '0;
            wq1_rptr    <= '0;
            wq2_rptr    <= '0;
            w_full      <= 1'b0;
        end else begin
            // Two-stage synchronizer for read pointer
            wq1_rptr <= r_ptr;
            wq2_rptr <= wq1_rptr;

            // Push: write data and advance write counter
            if (!w_full && push)
                mem[w_count_bin[ADDR_WIDTH-1:0]] <= w_data;

            w_count_bin <= w_count_next;
            w_ptr       <= bin2gray(w_count_next);

            // Full when stack depth (w_count + r_count, modular) reaches DEPTH.
            // r_count_bin decrements on pop so it contributes its 2's-complement
            // negative value; the sum equals DEPTH only when items_in_stack == DEPTH.
            w_full <= (w_count_next + gray2bin(wq2_rptr) == PTR_WIDTH'(DEPTH));
        end
    end

    // ---------------------------------------------------------------------------
    // Read domain: pop and synchronize w_ptr
    // ---------------------------------------------------------------------------

    // Top of stack = address (w_count + r_count - 1), all in PTR_WIDTH-bit modular
    // arithmetic.  r_count_bin is 0 at start and goes negative (wraps) on each pop,
    // so it acts as a negative offset from the synchronized write pointer.
    assign r_data = mem[(gray2bin(rq2_wptr) + r_count_bin - 1'b1)[ADDR_WIDTH-1:0]];

    always_ff @(posedge r_clk) begin
        if (r_rst) begin
            r_count_bin <= '0;
            r_ptr       <= '0;
            rq1_wptr    <= '0;
            rq2_wptr    <= '0;
            r_empty     <= 1'b1;
        end else begin
            // Two-stage synchronizer for write pointer
            rq1_wptr <= w_ptr;
            rq2_wptr <= rq1_wptr;

            r_count_bin <= r_count_next;
            r_ptr       <= bin2gray(r_count_next);

            // Empty when stack depth (w_count + r_count, modular) equals zero.
            r_empty <= (r_count_next + gray2bin(rq2_wptr) == '0);
        end
    end

endmodule
