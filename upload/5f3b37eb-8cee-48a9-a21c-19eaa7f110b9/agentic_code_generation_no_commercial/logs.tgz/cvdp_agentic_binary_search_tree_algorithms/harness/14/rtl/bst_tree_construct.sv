module bst_tree_construct #(
    parameter DATA_WIDTH = 16,
    parameter ARRAY_SIZE = 5
) (
    input  clk,
    input  reset,
    input  start,
    input  [ARRAY_SIZE*DATA_WIDTH-1:0] data_in,
    output reg [ARRAY_SIZE*DATA_WIDTH-1:0] keys,
    output reg [ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0] left_child,
    output reg [ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0] right_child,
    output reg [$clog2(ARRAY_SIZE):0] root,
    output reg done,
    output reg build_invalid
);

    localparam PTR_WIDTH = $clog2(ARRAY_SIZE) + 1;
    localparam [PTR_WIDTH-1:0]  INVALID_PTR = {PTR_WIDTH{1'b1}};
    localparam [DATA_WIDTH-1:0] INVALID_KEY = {DATA_WIDTH{1'b1}};

    parameter IDLE       = 2'b00,
              BUILD_TREE = 2'b01;

    parameter INIT     = 2'b00,
              INSERT   = 2'b01,
              TRAVERSE = 2'b10,
              COMPLETE = 2'b11;

    reg [1:0] top_state, build_state;

    reg [ARRAY_SIZE*DATA_WIDTH-1:0] data_in_copy;
    reg [$clog2(ARRAY_SIZE):0] next_free_node;
    reg [$clog2(ARRAY_SIZE):0] current_node;
    reg [$clog2(ARRAY_SIZE):0] input_index;
    reg [DATA_WIDTH-1:0] temp_data;

    integer i;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            top_state      <= IDLE;
            build_state    <= INIT;
            root           <= INVALID_PTR;
            next_free_node <= 0;
            input_index    <= 0;
            done           <= 0;
            build_invalid  <= 0;
            for (i = 0; i < ARRAY_SIZE; i = i + 1) begin
                keys[i*DATA_WIDTH +: DATA_WIDTH]         <= INVALID_KEY;
                left_child[i*PTR_WIDTH +: PTR_WIDTH]     <= INVALID_PTR;
                right_child[i*PTR_WIDTH +: PTR_WIDTH]    <= INVALID_PTR;
            end
        end else begin
            case (top_state)
                IDLE: begin
                    done          <= 0;
                    build_invalid <= 0;
                    if (start) begin
                        // Clear tree state for a fresh build
                        root           <= INVALID_PTR;
                        next_free_node <= 0;
                        input_index    <= 0;
                        for (i = 0; i < ARRAY_SIZE; i = i + 1) begin
                            keys[i*DATA_WIDTH +: DATA_WIDTH]      <= INVALID_KEY;
                            left_child[i*PTR_WIDTH +: PTR_WIDTH]  <= INVALID_PTR;
                            right_child[i*PTR_WIDTH +: PTR_WIDTH] <= INVALID_PTR;
                        end
                        data_in_copy <= data_in;
                        top_state    <= BUILD_TREE;
                        build_state  <= INIT;
                    end
                end

                BUILD_TREE: begin
                    case (build_state)
                        INIT: begin
                            if (input_index < ARRAY_SIZE) begin
                                temp_data   <= data_in_copy[input_index*DATA_WIDTH +: DATA_WIDTH];
                                input_index <= input_index + 1;
                                build_state <= INSERT;
                            end else begin
                                build_state <= COMPLETE;
                            end
                        end

                        INSERT: begin
                            if (temp_data == INVALID_KEY) begin
                                // Invalid input key detected – abort build
                                build_invalid <= 1;
                                done          <= 1;
                                top_state     <= IDLE;
                            end else if (root == INVALID_PTR) begin
                                root          <= next_free_node;
                                keys[next_free_node*DATA_WIDTH +: DATA_WIDTH] <= temp_data;
                                next_free_node <= next_free_node + 1;
                                build_state   <= INIT;
                            end else begin
                                current_node <= root;
                                build_state  <= TRAVERSE;
                            end
                        end

                        TRAVERSE: begin
                            if (temp_data < keys[current_node*DATA_WIDTH +: DATA_WIDTH]) begin
                                if (left_child[current_node*PTR_WIDTH +: PTR_WIDTH] == INVALID_PTR) begin
                                    left_child[current_node*PTR_WIDTH +: PTR_WIDTH] <= next_free_node;
                                    keys[next_free_node*DATA_WIDTH +: DATA_WIDTH]   <= temp_data;
                                    next_free_node <= next_free_node + 1;
                                    build_state    <= INIT;
                                end else begin
                                    current_node <= left_child[current_node*PTR_WIDTH +: PTR_WIDTH];
                                end
                            end else begin
                                if (right_child[current_node*PTR_WIDTH +: PTR_WIDTH] == INVALID_PTR) begin
                                    right_child[current_node*PTR_WIDTH +: PTR_WIDTH] <= next_free_node;
                                    keys[next_free_node*DATA_WIDTH +: DATA_WIDTH]    <= temp_data;
                                    next_free_node <= next_free_node + 1;
                                    build_state    <= INIT;
                                end else begin
                                    current_node <= right_child[current_node*PTR_WIDTH +: PTR_WIDTH];
                                end
                            end
                        end

                        COMPLETE: begin
                            done      <= 1;
                            top_state <= IDLE;
                        end

                        default: build_state <= INIT;
                    endcase
                end

                default: top_state <= IDLE;
            endcase
        end
    end
endmodule
