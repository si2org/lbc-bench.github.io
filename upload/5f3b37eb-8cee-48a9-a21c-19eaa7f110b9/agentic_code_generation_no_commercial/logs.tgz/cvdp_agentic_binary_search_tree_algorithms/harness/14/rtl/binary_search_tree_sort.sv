module binary_search_tree_sort #(
    parameter DATA_WIDTH = 16,
    parameter ARRAY_SIZE = 5
) (
    input  clk,
    input  reset,
    input  start,
    input  [ARRAY_SIZE*DATA_WIDTH-1:0] keys,
    input  [ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0] left_child,
    input  [ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0] right_child,
    input  [$clog2(ARRAY_SIZE):0] root,
    output reg [ARRAY_SIZE*DATA_WIDTH-1:0] sorted_out,
    output reg done,
    output reg sort_invalid
);

    localparam PTR_WIDTH = $clog2(ARRAY_SIZE) + 1;
    localparam [PTR_WIDTH-1:0]  INVALID_PTR = {PTR_WIDTH{1'b1}};
    localparam [DATA_WIDTH-1:0] INVALID_KEY = {DATA_WIDTH{1'b1}};

    parameter S_IDLE           = 2'b00,
              S_TRAVERSE_LEFT  = 2'b01,
              S_PROCESS_NODE   = 2'b10,
              S_TRAVERSE_RIGHT = 2'b11;

    reg [1:0] sort_state;

    reg [ARRAY_SIZE*PTR_WIDTH-1:0] stack;
    reg [$clog2(ARRAY_SIZE):0] sp;
    reg [$clog2(ARRAY_SIZE):0] current_node;
    reg [$clog2(ARRAY_SIZE):0] output_index;
    reg [ARRAY_SIZE*DATA_WIDTH-1:0] temp_out;

    integer i;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            sort_state   <= S_IDLE;
            sp           <= 0;
            output_index <= 0;
            done         <= 0;
            sort_invalid <= 0;
            for (i = 0; i < ARRAY_SIZE; i = i + 1) begin
                stack[i*PTR_WIDTH +: PTR_WIDTH]      <= INVALID_PTR;
                sorted_out[i*DATA_WIDTH +: DATA_WIDTH] <= INVALID_KEY;
                temp_out[i*DATA_WIDTH +: DATA_WIDTH]   <= INVALID_KEY;
            end
        end else begin
            case (sort_state)
                S_IDLE: begin
                    done         <= 0;
                    sort_invalid <= 0;
                    if (start) begin
                        output_index <= 0;
                        sp           <= 0;
                        for (i = 0; i < ARRAY_SIZE; i = i + 1) begin
                            stack[i*PTR_WIDTH +: PTR_WIDTH]        <= INVALID_PTR;
                            temp_out[i*DATA_WIDTH +: DATA_WIDTH]   <= INVALID_KEY;
                            sorted_out[i*DATA_WIDTH +: DATA_WIDTH] <= INVALID_KEY;
                        end
                        if (root != INVALID_PTR) begin
                            current_node <= root;
                            sort_state   <= S_TRAVERSE_LEFT;
                        end else begin
                            sort_invalid <= 1;
                            done         <= 1;
                        end
                    end
                end

                S_TRAVERSE_LEFT: begin
                    if (current_node != INVALID_PTR) begin
                        stack[sp*PTR_WIDTH +: PTR_WIDTH] <= current_node;
                        sp           <= sp + 1;
                        current_node <= left_child[current_node*PTR_WIDTH +: PTR_WIDTH];
                    end else begin
                        sort_state <= S_PROCESS_NODE;
                    end
                end

                S_PROCESS_NODE: begin
                    if (sp > 0) begin
                        sp           <= sp - 1;
                        current_node <= stack[(sp-1)*PTR_WIDTH +: PTR_WIDTH];
                        temp_out[output_index*DATA_WIDTH +: DATA_WIDTH] <=
                            keys[stack[(sp-1)*PTR_WIDTH +: PTR_WIDTH]*DATA_WIDTH +: DATA_WIDTH];
                        output_index <= output_index + 1;
                        sort_state   <= S_TRAVERSE_RIGHT;
                    end else begin
                        sorted_out <= temp_out;
                        done       <= 1;
                        sort_state <= S_IDLE;
                    end
                end

                S_TRAVERSE_RIGHT: begin
                    current_node <= right_child[current_node*PTR_WIDTH +: PTR_WIDTH];
                    sort_state   <= S_TRAVERSE_LEFT;
                end

                default: sort_state <= S_IDLE;
            endcase
        end
    end
endmodule
