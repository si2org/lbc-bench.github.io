module bst_operations #(
    parameter DATA_WIDTH = 16,
    parameter ARRAY_SIZE = 5
) (
    input  clk,
    input  reset,
    input  start,
    input  [DATA_WIDTH-1:0]            operation_key,
    input  [ARRAY_SIZE*DATA_WIDTH-1:0] data_in,
    input  operation,          // 0=Search, 1=Delete
    input  sort_after_operation,

    output reg [$clog2(ARRAY_SIZE):0]                   key_position,
    output reg                                           complete_operation,
    output reg                                           operation_invalid,
    output reg [ARRAY_SIZE*DATA_WIDTH-1:0]               out_sorted_data,
    output reg [ARRAY_SIZE*DATA_WIDTH-1:0]               out_keys,
    output reg [ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0]   out_left_child,
    output reg [ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0]   out_right_child
);

    localparam PTR_WIDTH = $clog2(ARRAY_SIZE) + 1;
    localparam [PTR_WIDTH-1:0]  INVALID_PTR = {PTR_WIDTH{1'b1}};
    localparam [DATA_WIDTH-1:0] INVALID_KEY = {DATA_WIDTH{1'b1}};

    // Top-level FSM states
    parameter IDLE          = 4'd0,
              TRIGGER_BUILD = 4'd1,
              WAIT_BUILD    = 4'd2,
              TRIGGER_OP    = 4'd3,
              WAIT_OP       = 4'd4,
              LATCH         = 4'd5,
              TRIGGER_SORT  = 4'd6,
              WAIT_SORT     = 4'd7,
              FINALIZE      = 4'd8;

    reg [3:0] state;

    // Latched inputs captured at start
    reg                        operation_reg;
    reg                        sort_after_op_reg;
    reg [DATA_WIDTH-1:0]       latched_op_key;

    // Submodule start strobes
    reg build_start;
    reg op_start;
    reg sort_start;

    // Internal flags
    reg invalid_flag;
    reg complete_flag;

    // -----------------------------------------------------------------------
    // bst_tree_construct outputs
    // -----------------------------------------------------------------------
    wire [ARRAY_SIZE*DATA_WIDTH-1:0]             construct_keys;
    wire [ARRAY_SIZE*PTR_WIDTH-1:0]              construct_left;
    wire [ARRAY_SIZE*PTR_WIDTH-1:0]              construct_right;
    wire [PTR_WIDTH-1:0]                         construct_root;
    wire                                         construct_done;
    wire                                         build_invalid_w;

    // -----------------------------------------------------------------------
    // search_binary_search_tree outputs
    // -----------------------------------------------------------------------
    wire [PTR_WIDTH-1:0] search_key_pos_w;
    wire                 complete_found_w;
    wire                 search_invalid_w;

    // -----------------------------------------------------------------------
    // delete_node_binary_search_tree outputs
    // -----------------------------------------------------------------------
    wire [ARRAY_SIZE*DATA_WIDTH-1:0]  del_keys_w;
    wire [ARRAY_SIZE*PTR_WIDTH-1:0]   del_left_w;
    wire [ARRAY_SIZE*PTR_WIDTH-1:0]   del_right_w;
    wire                              complete_deletion_w;
    wire                              delete_invalid_w;

    // -----------------------------------------------------------------------
    // binary_search_tree_sort outputs
    // -----------------------------------------------------------------------
    wire [ARRAY_SIZE*DATA_WIDTH-1:0] sort_out_w;
    wire                             sort_done_w;
    wire                             sort_invalid_w;

    // -----------------------------------------------------------------------
    // Latched delete outputs (delete module resets its outputs in IDLE)
    // -----------------------------------------------------------------------
    reg [ARRAY_SIZE*DATA_WIDTH-1:0]  latched_del_keys;
    reg [ARRAY_SIZE*PTR_WIDTH-1:0]   latched_del_left;
    reg [ARRAY_SIZE*PTR_WIDTH-1:0]   latched_del_right;

    // -----------------------------------------------------------------------
    // Sort input mux: after delete use modified BST, after search use original
    // -----------------------------------------------------------------------
    wire [ARRAY_SIZE*DATA_WIDTH-1:0] sort_in_keys;
    wire [ARRAY_SIZE*PTR_WIDTH-1:0]  sort_in_left;
    wire [ARRAY_SIZE*PTR_WIDTH-1:0]  sort_in_right;

    assign sort_in_keys  = (operation_reg == 1'b1) ? latched_del_keys  : construct_keys;
    assign sort_in_left  = (operation_reg == 1'b1) ? latched_del_left  : construct_left;
    assign sort_in_right = (operation_reg == 1'b1) ? latched_del_right : construct_right;

    // -----------------------------------------------------------------------
    // Submodule instantiations
    // -----------------------------------------------------------------------
    bst_tree_construct #(
        .DATA_WIDTH(DATA_WIDTH),
        .ARRAY_SIZE(ARRAY_SIZE)
    ) u_construct (
        .clk         (clk),
        .reset       (reset),
        .start       (build_start),
        .data_in     (data_in),
        .keys        (construct_keys),
        .left_child  (construct_left),
        .right_child (construct_right),
        .root        (construct_root),
        .done        (construct_done),
        .build_invalid(build_invalid_w)
    );

    search_binary_search_tree #(
        .DATA_WIDTH(DATA_WIDTH),
        .ARRAY_SIZE(ARRAY_SIZE)
    ) u_search (
        .clk          (clk),
        .reset        (reset),
        .start        (op_start & ~operation_reg),
        .search_key   (latched_op_key),
        .root         (construct_root),
        .keys         (construct_keys),
        .left_child   (construct_left),
        .right_child  (construct_right),
        .key_position (search_key_pos_w),
        .complete_found(complete_found_w),
        .search_invalid(search_invalid_w)
    );

    delete_node_binary_search_tree #(
        .DATA_WIDTH(DATA_WIDTH),
        .ARRAY_SIZE(ARRAY_SIZE)
    ) u_delete (
        .clk                 (clk),
        .reset               (reset),
        .start               (op_start & operation_reg),
        .delete_key          (latched_op_key),
        .root                (construct_root),
        .keys                (construct_keys),
        .left_child          (construct_left),
        .right_child         (construct_right),
        .modified_keys       (del_keys_w),
        .modified_left_child (del_left_w),
        .modified_right_child(del_right_w),
        .complete_deletion   (complete_deletion_w),
        .delete_invalid      (delete_invalid_w)
    );

    binary_search_tree_sort #(
        .DATA_WIDTH(DATA_WIDTH),
        .ARRAY_SIZE(ARRAY_SIZE)
    ) u_sort (
        .clk        (clk),
        .reset      (reset),
        .start      (sort_start),
        .keys       (sort_in_keys),
        .left_child (sort_in_left),
        .right_child(sort_in_right),
        .root       (construct_root),
        .sorted_out (sort_out_w),
        .done       (sort_done_w),
        .sort_invalid(sort_invalid_w)
    );

    // -----------------------------------------------------------------------
    // Top-level FSM
    // -----------------------------------------------------------------------
    integer i;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            state             <= IDLE;
            build_start       <= 1'b0;
            op_start          <= 1'b0;
            sort_start        <= 1'b0;
            complete_operation <= 1'b0;
            operation_invalid  <= 1'b0;
            invalid_flag      <= 1'b0;
            complete_flag     <= 1'b0;
            key_position      <= INVALID_PTR;
            operation_reg     <= 1'b0;
            sort_after_op_reg <= 1'b0;
            latched_op_key    <= INVALID_KEY;
            for (i = 0; i < ARRAY_SIZE; i = i + 1) begin
                out_sorted_data[i*DATA_WIDTH +: DATA_WIDTH]      <= INVALID_KEY;
                out_keys[i*DATA_WIDTH +: DATA_WIDTH]             <= INVALID_KEY;
                out_left_child[i*PTR_WIDTH +: PTR_WIDTH]         <= INVALID_PTR;
                out_right_child[i*PTR_WIDTH +: PTR_WIDTH]        <= INVALID_PTR;
                latched_del_keys[i*DATA_WIDTH +: DATA_WIDTH]     <= INVALID_KEY;
                latched_del_left[i*PTR_WIDTH +: PTR_WIDTH]       <= INVALID_PTR;
                latched_del_right[i*PTR_WIDTH +: PTR_WIDTH]      <= INVALID_PTR;
            end
        end else begin
            // Default: de-assert all one-cycle strobes
            build_start <= 1'b0;
            op_start    <= 1'b0;
            sort_start  <= 1'b0;

            case (state)
                // ----------------------------------------------------------
                IDLE: begin
                    complete_operation <= 1'b0;
                    operation_invalid  <= 1'b0;
                    invalid_flag       <= 1'b0;
                    complete_flag      <= 1'b0;
                    key_position       <= INVALID_PTR;
                    if (start) begin
                        operation_reg     <= operation;
                        sort_after_op_reg <= sort_after_operation;
                        latched_op_key    <= operation_key;
                        state             <= TRIGGER_BUILD;
                    end
                end

                // ----------------------------------------------------------
                // Overhead cycle 1 (construction): assert build_start for 1
                // clock, then wait for construction to complete.
                // ----------------------------------------------------------
                TRIGGER_BUILD: begin
                    build_start <= 1'b1;
                    state       <= WAIT_BUILD;
                end

                WAIT_BUILD: begin
                    // construct_done is a 1-cycle pulse from bst_tree_construct
                    if (construct_done) begin
                        if (build_invalid_w) begin
                            invalid_flag <= 1'b1;
                            state        <= FINALIZE;
                        end else begin
                            state <= TRIGGER_OP;
                        end
                    end
                end

                // ----------------------------------------------------------
                // Overhead cycle 2 (operation): assert op_start for 1 clock,
                // then wait for search or delete to complete.
                // ----------------------------------------------------------
                TRIGGER_OP: begin
                    op_start <= 1'b1;
                    state    <= WAIT_OP;
                end

                WAIT_OP: begin
                    if (operation_reg == 1'b0) begin
                        // Search path
                        if (complete_found_w || search_invalid_w) begin
                            if (search_invalid_w) begin
                                invalid_flag  <= 1'b1;
                            end else begin
                                key_position  <= search_key_pos_w;
                                complete_flag <= 1'b1;
                            end
                            // With sort and valid result → overhead cycle 3 is sort
                            if (sort_after_op_reg && !search_invalid_w) begin
                                state <= TRIGGER_SORT;
                            end else begin
                                state <= LATCH; // extra cycle to satisfy 3-cycle overhead
                            end
                        end
                    end else begin
                        // Delete path
                        if (complete_deletion_w || delete_invalid_w) begin
                            if (delete_invalid_w) begin
                                invalid_flag  <= 1'b1;
                            end else begin
                                // Capture delete outputs before module resets them
                                latched_del_keys  <= del_keys_w;
                                latched_del_left  <= del_left_w;
                                latched_del_right <= del_right_w;
                                complete_flag     <= 1'b1;
                            end
                            if (sort_after_op_reg && !delete_invalid_w) begin
                                state <= TRIGGER_SORT;
                            end else begin
                                state <= LATCH;
                            end
                        end
                    end
                end

                // ----------------------------------------------------------
                // Extra latch cycle used when sort is skipped (or op invalid)
                // to maintain consistent 3-cycle overhead with the sort path.
                // ----------------------------------------------------------
                LATCH: begin
                    state <= FINALIZE;
                end

                // ----------------------------------------------------------
                // Overhead cycle 3 (sort): assert sort_start for 1 clock.
                // ----------------------------------------------------------
                TRIGGER_SORT: begin
                    sort_start <= 1'b1;
                    state      <= WAIT_SORT;
                end

                WAIT_SORT: begin
                    if (sort_done_w || sort_invalid_w) begin
                        if (sort_invalid_w) begin
                            invalid_flag  <= 1'b1;
                            complete_flag <= 1'b0;
                        end
                        state <= FINALIZE;
                    end
                end

                // ----------------------------------------------------------
                // Assert final outputs for one cycle, then return to IDLE.
                // ----------------------------------------------------------
                FINALIZE: begin
                    if (invalid_flag) begin
                        operation_invalid  <= 1'b1;
                        complete_operation <= 1'b0;
                        for (i = 0; i < ARRAY_SIZE; i = i + 1)
                            out_sorted_data[i*DATA_WIDTH +: DATA_WIDTH] <= INVALID_KEY;
                        // BST outputs remain as INVALID when build itself failed
                        if (!complete_flag) begin
                            for (i = 0; i < ARRAY_SIZE; i = i + 1) begin
                                out_keys[i*DATA_WIDTH +: DATA_WIDTH]      <= INVALID_KEY;
                                out_left_child[i*PTR_WIDTH +: PTR_WIDTH]  <= INVALID_PTR;
                                out_right_child[i*PTR_WIDTH +: PTR_WIDTH] <= INVALID_PTR;
                            end
                        end
                    end else begin
                        complete_operation <= 1'b1;
                        operation_invalid  <= 1'b0;
                        if (sort_after_op_reg) begin
                            out_sorted_data <= sort_out_w;
                        end else begin
                            for (i = 0; i < ARRAY_SIZE; i = i + 1)
                                out_sorted_data[i*DATA_WIDTH +: DATA_WIDTH] <= INVALID_KEY;
                        end
                    end

                    // BST structure outputs: use modified tree for delete,
                    // original tree for search
                    if (complete_flag) begin
                        if (operation_reg == 1'b1) begin
                            out_keys       <= latched_del_keys;
                            out_left_child <= latched_del_left;
                            out_right_child<= latched_del_right;
                        end else begin
                            out_keys       <= construct_keys;
                            out_left_child <= construct_left;
                            out_right_child<= construct_right;
                        end
                    end

                    state <= IDLE;
                end

                default: state <= IDLE;
            endcase
        end
    end
endmodule
