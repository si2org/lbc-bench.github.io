## Specification

The BST is a structure formed where each node contains a key, with its `left_child` containing `keys` less than the node, and its `right_child` containing `keys` greater than the node. The module deletes the `delete_key` in the input BST. The BST is constructed in a way that traversing to the nodes results in a sorted array. The module doesn't wait for the complete BST to be traversed. As soon as the `delete_key` is found, the module stops its search and transitions to the stage where the key is deleted based on the number of possible children (no, one or two children). Additionally, it is expected that the keys are not duplicated.

---

### Invalid Key and Pointer Values
- **Invalid key value:** `(2^DATA_WIDTH) - 1`
- **Invalid pointer value for left_child and right_child:** `(2^(clog2(ARRAY_SIZE) + 1) - 1`

---
### Parameters:
- DATA_WIDTH (default 31): Width of a single element, greater than 0.
- ARRAY_SIZE (default 16): Number of elements in the array, will be greater than 0 

### Inputs:
- `[ARRAY_SIZE*DATA_WIDTH-1:0] keys`: A packed array containing the node values of the BST. 
- `[ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0] left_child`: A packed array containing the left child pointers for each node in the BST.
- `[ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0] right_child`: A packed array containing the right child pointers for each node in the BST.
- `[$clog2(ARRAY_SIZE):0] root`: The index of the root node (always 0 except for an empty BST, assuming the BST is constructed such that the first element in the arrays corresponds to the root node). For an empty BST, `root` is assigned an invalid index where all bits are set to 1; Eg, 15 (for ARRAY_SIZE = 7).
- `[DATA_WIDTH-1:0] delete_key`: The key to delete in the BST.
- `start`: 1-bit active high signal to initiate the deletion (1 clock cycle in duration).
- `clk`: Clock Signal. The design is synchronized to the positive edge of this clock.
- `reset`: Asynchronous active high reset to reset all control signal outputs to zero and `modified_keys`, `modified_left_child`, and `modified_right_child` to null (invalid) values.

### Outputs:
- `complete_deletion`: 1-bit active high signal that is asserted once the deletion is complete, indicating that the key was deleted successfully (1 clock cycle in duration). If the `delete_key` is not found and could not be deleted in the constructed BST, or if the tree is empty, `complete_deletion` remains at 0.
- `delete_invalid`: 1-bit Active high signal that is asserted when the BST is empty or when the `delete_key` doesn't exist in the given BST (1 clock cycle in duration). 
- `[ARRAY_SIZE*DATA_WIDTH-1:0] modified_keys`: Updated array of node keys after deletion. The values are valid for one clock cycle following the completion of the deletion, after which they are reset to an invalid pointer value.
- `[ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0] modified_left_child`: Updated array of left child pointers after deletion. The values are valid for one clock cycle following the completion of the deletion, after which they are reset to an invalid pointer value.
- `[ARRAY_SIZE*($clog2(ARRAY_SIZE)+1)-1:0] modified_right_child`: Updated array of right child pointers after deletion. The values are valid for one clock cycle following the completion of the deletion, after which they are reset to an invalid pointer value.

---

### Deletion Scenarios
1. **Node with Both Left and Right Children:**
   - Find the inorder successor (the leftmost node in the right subtree).
   - Replace the node's key with the in-order successor's key.
   - Delete or replace the inorder successor node with its immediate right node if it exists.

2. **Node with Only Left Child:**
   - Replace the node's key and pointers with those of its left child.
   - Mark the left child's original position as invalid.

3. **Node with Only Right Child:**
   - Replace the node's key and pointers with those of its right child.
   - Mark the right child's original position as invalid.

4. **Node with No Children**
   - Mark the node's key and pointers as invalid.

---

### Implementation details 

**FSM (Finite State Machine) Design**:
The delete processes must be controlled by an FSM. 

- **S_IDLE**: The system resets intermediate variables and the outputs and waits for the `start` signal.
- **S_INIT**: The search begins by comparing the `delete_key` with the root node and decides the direction of traversal (left or right).
- **S_SEARCH_LEFT**: The FSM traverses the left subtree if the `delete_key` is less than the `root` node.
- **S_SEARCH_RIGHT**: The FSM traverses the right subtree if the `delete_key` is greater than the `root` node.
- **S_DELETE**:  The FSM deletes the key based on the number of children and different combinations. It traverses to `S_DELETE_COMPLETE` for completion. But when the `delete_key` has both children, it first traverses to `S_FIND_INORDER_SUCCESSOR`.
-  **S_DELETE_COMPLETE**: The FSM outputs the signals `complete_deletion`, `delete_invalid`, and the keys and pointer of the modified tree.
-  **S_FIND_INORDER_SUCCESSOR**: The FSM finds the in-order successor of the `delete_key`. It traverses to the right child and stays in the same state until it encounters a left child with no key, then traverses to `S_DELETE_COMPLETE`.

---
**Latency Analysis**:

- **Example 1**:  The worst-case scenario is to delete the largest node in a right-skewed tree (a BST where every node only consists of a right child and no left child).
   - **Process**:
     - The FSM traverses the entire depth of the tree (`ARRAY_SIZE-1`) to locate the largest key.
     - Except for the target node (largest node), the FSM traverses twice before moving to the next node. Hence it takes **`(ARRAY_SIZE-2) * 2` clock cycles**.
     - The largest node will take **1 clock cycle**
     - After finding the node, the deletion process `S_DELETE` takes **1 clock cycle**.
     - The `S_INIT` and `S_DELETE_COMPLETE` states each take **1 clock cycle**.
     - To transition from `S_IDLE` to `S_INIT` when `start` is asserted, it takes **1 clock cycle**
   - **Total Latency**: `1` (Start) + `1` (Initialization) + {`(ARRAY_SIZE-2) * 2`} (Traversal except the largest node)+ `1` (Traversal of largest node) + `1` (Delete) + `1` (Completion).

     
- **Example 2**: The best case scenario is to delete the largest node in a left-skewed BST (a BST where every node only consists of a left child and no right child) and the smallest node in a right-skewed tree (a BST where every node only consists of a right child and no left child)
   - **Process**:
     - The FSM finds the `delete_key` at the root (largest node in a left-skewed BST or smallest node in right-skewed tree) in **1 clock cycle**, and since the position of the `delete_key` is not to be found, there is no need to traverse further to the left tree or right tree, reducing the latency significantly. 
     - The deletion process takes **1 clock cycle**.
     - The `S_INIT` and `S_DELETE_COMPLETE` states each take **1 clock cycle**.
     - To transition from `S_IDLE` to `S_INIT` when `start` is asserted, it takes **1 clock cycle**
   -  **Total latency** = `1` (Start) + `1` (Initialization) + `1` (Deletion) + `1` (Completion) = `4 clock cycles`.


- **Example 3**: To delete a node (15) in the given Binary Search Tree (BST) below that has both left and right children, consider the following example: 

  - **BST Structure**:  
      - `keys = [10, 5, 15, 3, 12, 20]`  
      - `left_child = [1, 3, 4, 15, 15, 15]`  
      - `right_child = [2, 15, 5, 15, 15, 15]`  

  - **Delete Operation**:  
      - The node to delete has the key `delete_key = 15`, which has a right child at index 6 (key = 20) and a left child at index 5 (key = 12).  

  - **Process**:
       - **Traversal Process**:  
           - Searching for the node with `key = 15` takes **1 clock cycle**.  

       - **Deletion Process**:  
           - Deleting the node involves finding its in-order successor (the leftmost node in the right subtree). This process takes **2 clock cycles**:  
               1. **1 clock cycle** to assign the right child of `delete_key` in the `S_DELETE` state.  
               2. **1 clock cycle** to traverse to the leftmost child of the right child of `delete_key` in the `S_FIND_INORDER_SUCCESSOR` state and replace the node with its in-order successor.  

       - **State Transitions**:  
            - Similar to other cases, the `S_INIT` and `S_DELETE_COMPLETE` states each take **2 clock cycles**.  
            - An additional 1 clock cycle is needed to transition from `S_IDLE` to `S_INIT` when the start is asserted.
  
   - **Total latency** = `1` (Start) + `1` (Initialization) + `1` (Traversal) + `2` (Deletion) + `1` (Completion) = `6 clock cycles`.
 
- **Other Latency Scenarios**:  
  - Latency to delete the smallest node in a left-skewed tree: (ARRAY_SIZE - 1) + 4;
  - Latency for an empty tree (key, left_child, right_child are invalid): 2