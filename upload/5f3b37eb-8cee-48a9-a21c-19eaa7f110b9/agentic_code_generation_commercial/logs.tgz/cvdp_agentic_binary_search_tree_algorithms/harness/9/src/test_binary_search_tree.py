import cocotb
from cocotb.triggers import RisingEdge, Timer
import random
import math

def create_balanced_array(sorted_array):
    # Recursive function to create a balanced array
    if not sorted_array:
        return []
    mid = len(sorted_array) // 2
    return [sorted_array[mid]] + create_balanced_array(sorted_array[:mid]) + create_balanced_array(sorted_array[mid + 1:])


@cocotb.test()
async def test_bst_sorter(dut):
    left_child = []
    right_child = []
    packed_left_child = 0
    packed_right_child = 0
    packed_arr = 0

    ARRAY_SIZE = int(dut.ARRAY_SIZE.value)
    DATA_WIDTH = int(dut.DATA_WIDTH.value)

    clk_period = 10  # ns
    random.seed(0)  # For reproducibility

    cocotb.start_soon(clock(dut, clk_period))

    await reset_dut(dut, 5)
    dut.start.value = 0

    # Test Case: Non-empty BST
    if (ARRAY_SIZE == 10 and DATA_WIDTH == 16):
        arr = [58514, 50092, 48887, 48080, 5485, 5967, 19599, 23938, 34328, 42874]
        right_child = [31, 31, 31, 31, 5, 6, 7, 8, 9, 31]
        left_child = [1, 2, 3, 4, 31, 31, 31, 31, 31, 31]
    elif (ARRAY_SIZE == 15 and DATA_WIDTH == 6):
        arr = [9, 14, 15, 17, 19, 21, 30, 32, 35, 40, 46, 47, 48, 49, 50]
        left_child = [31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31]
        right_child = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 31]
    elif (ARRAY_SIZE == 15 and DATA_WIDTH == 32):
        arr = [200706183, 259064287, 811616460, 956305578, 987713153, 1057458493, 1425113391, 1512400858, 2157180141, 2322902151, 2683058769, 2918411874, 2982472603, 3530595430, 3599316877]
        arr = sorted(arr, reverse=True)
        right_child = [31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31, 31]
        left_child = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 31]
    elif (ARRAY_SIZE == 5 and DATA_WIDTH == 6):
        arr = [1, 20, 0, 61, 5]
        left_child = [2,4,15,15,15]
        right_child = [1,3,15,15,15]

    for idx, val in enumerate(arr):
        packed_arr |= (val << (idx * DATA_WIDTH))
 
    for idx, val in enumerate(left_child):
        packed_left_child |= (val << (idx * (math.ceil(math.log2(ARRAY_SIZE)) + 1)))

    for idx, val in enumerate(right_child):
        packed_right_child |= (val << (idx * (math.ceil(math.log2(ARRAY_SIZE)) + 1)))

    # Run the test
    dut.data_in.value = packed_arr
    
    await RisingEdge(dut.clk)
    dut.start.value = 1
    await RisingEdge(dut.clk)
    dut.start.value = 0

    cycle_count = 0
    while True:
        await RisingEdge(dut.clk)
        cycle_count += 1
        if dut.done.value == 1:
            break

    cocotb.log.debug(f"Total Latency {cycle_count}")
    op_keys = int(dut.keys.value)
    op_left_child = int(dut.left_child.value)
    op_right_child = int(dut.right_child.value)

    unpacked_key = [ (op_keys >> (i * DATA_WIDTH)) & ((1 << DATA_WIDTH) - 1) for i in range(ARRAY_SIZE)]
    unpacked_left_child = [ (op_left_child >> (i * (math.ceil(math.log2(ARRAY_SIZE)) + 1))) & ((1 << (math.ceil(math.log2(ARRAY_SIZE)) + 1)) - 1) for i in range(ARRAY_SIZE)]
    unpacked_right_child = [ (op_right_child >> (i * (math.ceil(math.log2(ARRAY_SIZE)) + 1))) & ((1 << (math.ceil(math.log2(ARRAY_SIZE)) + 1)) - 1) for i in range(ARRAY_SIZE)]
    
    assert unpacked_key == arr, f"[Key incorrect. Got: {unpacked_key}, Expected: {arr}"
    assert unpacked_left_child == left_child, f"[left_child incorrect. Got: {unpacked_left_child}, Expected: {left_child}"
    assert unpacked_right_child == right_child, f"right_child incorrect. Got: {unpacked_right_child}, Expected: {right_child}"

    cocotb.log.info(f"Test passed.")


async def reset_dut(dut, duration):
    dut.reset.value = 1
    for _ in range(duration):
        await RisingEdge(dut.clk)
    dut.reset.value = 0
    await RisingEdge(dut.clk)

async def clock(dut, clk_period):
        while True:
            dut.clk.value = 0
            await Timer(clk_period/2, unit='ns')
            dut.clk.value = 1
            await Timer(clk_period/2, unit='ns')

