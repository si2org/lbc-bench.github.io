module decoder_8b10b (
    input  logic        clk_in,
    input  logic        reset_in,
    input  logic        control_in,
    input  logic [9:0]  decoder_in,
    input  logic        decoder_valid_in,
    output logic [7:0]  decoder_out,
    output logic        decoder_valid_out,
    output logic        control_out
);

    // -----------------------------------------------------------------------
    // Control symbol combinational lookup
    // -----------------------------------------------------------------------
    logic [7:0] ctrl_decoded;
    logic       ctrl_is_ctrl;

    always_comb begin
        ctrl_decoded = 8'h00;
        ctrl_is_ctrl = 1'b0;
        case (decoder_in)
            // K.28.0
            10'b0011110100, 10'b1100001011: begin ctrl_decoded = 8'h1C; ctrl_is_ctrl = 1'b1; end
            // K.28.1
            10'b0011111001, 10'b1100000110: begin ctrl_decoded = 8'h3C; ctrl_is_ctrl = 1'b1; end
            // K.28.2
            10'b0011110101, 10'b1100001010: begin ctrl_decoded = 8'h5C; ctrl_is_ctrl = 1'b1; end
            // K.28.3
            10'b0011110011, 10'b1100001100: begin ctrl_decoded = 8'h7C; ctrl_is_ctrl = 1'b1; end
            // K.28.4
            10'b0011110010, 10'b1100001101: begin ctrl_decoded = 8'h9C; ctrl_is_ctrl = 1'b1; end
            // K.28.5
            10'b0011111010, 10'b1100000101: begin ctrl_decoded = 8'hBC; ctrl_is_ctrl = 1'b1; end
            // K.28.6
            10'b0011110110, 10'b1100001001: begin ctrl_decoded = 8'hDC; ctrl_is_ctrl = 1'b1; end
            // K.28.7
            10'b0011111000, 10'b1100000111: begin ctrl_decoded = 8'hFC; ctrl_is_ctrl = 1'b1; end
            // K.23.7
            10'b1110101000, 10'b0001010111: begin ctrl_decoded = 8'hF7; ctrl_is_ctrl = 1'b1; end
            // K.27.7
            10'b1101101000, 10'b0010010111: begin ctrl_decoded = 8'hFB; ctrl_is_ctrl = 1'b1; end
            // K.29.7
            10'b1011101000, 10'b0100010111: begin ctrl_decoded = 8'hFD; ctrl_is_ctrl = 1'b1; end
            // K.30.7
            10'b0111101000, 10'b1000010111: begin ctrl_decoded = 8'hFE; ctrl_is_ctrl = 1'b1; end
            default: begin ctrl_decoded = 8'h00; ctrl_is_ctrl = 1'b0; end
        endcase
    end

    // -----------------------------------------------------------------------
    // Data symbol decoding: 5b/6b path (decoder_in[9:4] -> EDCBA)
    // -----------------------------------------------------------------------
    logic [4:0] decoded_edcba;

    always_comb begin
        case (decoder_in[9:4])
            6'b100111, 6'b011000: decoded_edcba = 5'b00000;
            6'b011101, 6'b100010: decoded_edcba = 5'b00001;
            6'b101101, 6'b010010: decoded_edcba = 5'b00010;
            6'b110001:            decoded_edcba = 5'b00011;
            6'b110101, 6'b001010: decoded_edcba = 5'b00100;
            6'b101001:            decoded_edcba = 5'b00101;
            6'b011001:            decoded_edcba = 5'b00110;
            6'b111000, 6'b000111: decoded_edcba = 5'b00111;
            6'b111001, 6'b000110: decoded_edcba = 5'b01000;
            6'b100101:            decoded_edcba = 5'b01001;
            6'b010101:            decoded_edcba = 5'b01010;
            6'b110100:            decoded_edcba = 5'b01011;
            6'b001101:            decoded_edcba = 5'b01100;
            6'b101100:            decoded_edcba = 5'b01101;
            6'b011100:            decoded_edcba = 5'b01110;
            6'b010111, 6'b101000: decoded_edcba = 5'b01111;
            6'b011011, 6'b100100: decoded_edcba = 5'b10000;
            6'b100011:            decoded_edcba = 5'b10001;
            6'b010011:            decoded_edcba = 5'b10010;
            6'b110010:            decoded_edcba = 5'b10011;
            6'b001011:            decoded_edcba = 5'b10100;
            6'b101010:            decoded_edcba = 5'b10101;
            6'b011010:            decoded_edcba = 5'b10110;
            6'b111010, 6'b000101: decoded_edcba = 5'b10111;
            6'b110011, 6'b001100: decoded_edcba = 5'b11000;
            6'b100110:            decoded_edcba = 5'b11001;
            6'b010110:            decoded_edcba = 5'b11010;
            6'b110110, 6'b001001: decoded_edcba = 5'b11011;
            6'b001110:            decoded_edcba = 5'b11100;
            6'b101110, 6'b010001: decoded_edcba = 5'b11101;
            6'b011110, 6'b100001: decoded_edcba = 5'b11110;
            6'b101011, 6'b010100: decoded_edcba = 5'b11111;
            default:              decoded_edcba = 5'b00000;
        endcase
    end

    // -----------------------------------------------------------------------
    // Data symbol decoding: 3b/4b path (decoder_in[3:0] -> HGF)
    // -----------------------------------------------------------------------
    logic [2:0] decoded_hgf;

    always_comb begin
        case (decoder_in[3:0])
            4'b0100, 4'b1011: decoded_hgf = 3'b000;
            4'b1001:          decoded_hgf = 3'b001;
            4'b0101:          decoded_hgf = 3'b010;
            4'b0011, 4'b1100: decoded_hgf = 3'b011;
            4'b0010, 4'b1101: decoded_hgf = 3'b100;
            4'b1010:          decoded_hgf = 3'b101;
            4'b0110:          decoded_hgf = 3'b110;
            4'b1110, 4'b0001: decoded_hgf = 3'b111;
            default:          decoded_hgf = 3'b000;
        endcase
    end

    // data_decoded is {HGF[2:0], EDCBA[4:0]} = bits [7:5] HGF, bits [4:0] EDCBA
    logic [7:0] data_decoded;
    assign data_decoded = {decoded_hgf, decoded_edcba};

    // -----------------------------------------------------------------------
    // Output register: 1-cycle latency, async reset
    // -----------------------------------------------------------------------
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) begin
            decoder_out       <= 8'h00;
            decoder_valid_out <= 1'b0;
            control_out       <= 1'b0;
        end else begin
            decoder_valid_out <= decoder_valid_in;
            if (control_in) begin
                decoder_out <= ctrl_decoded;
                control_out <= ctrl_is_ctrl;
            end else begin
                decoder_out <= data_decoded;
                control_out <= 1'b0;
            end
        end
    end

endmodule
