`timescale 1ns/1ps

module tb_decoder_8b10b;

    // -----------------------------------------------------------------------
    // DUT signals
    // -----------------------------------------------------------------------
    logic        clk_in;
    logic        reset_in;
    logic        control_in;
    logic [9:0]  decoder_in;
    logic        decoder_valid_in;
    logic [7:0]  decoder_out;
    logic        decoder_valid_out;
    logic        control_out;

    // -----------------------------------------------------------------------
    // DUT instantiation
    // -----------------------------------------------------------------------
    decoder_8b10b dut (
        .clk_in           (clk_in),
        .reset_in         (reset_in),
        .control_in       (control_in),
        .decoder_in       (decoder_in),
        .decoder_valid_in (decoder_valid_in),
        .decoder_out      (decoder_out),
        .decoder_valid_out(decoder_valid_out),
        .control_out      (control_out)
    );

    // -----------------------------------------------------------------------
    // Clock generation: 10 ns period
    // -----------------------------------------------------------------------
    initial clk_in = 0;
    always #5 clk_in = ~clk_in;

    // -----------------------------------------------------------------------
    // Task: apply one encoded word and wait for output
    // -----------------------------------------------------------------------
    task automatic apply_word(
        input logic [9:0] enc,
        input logic       ctrl
    );
        @(negedge clk_in);
        decoder_in        = enc;
        control_in        = ctrl;
        decoder_valid_in  = 1'b1;
        @(posedge clk_in); #1;
        // output now stable; caller can sample decoder_out / control_out / decoder_valid_out
        decoder_valid_in  = 1'b0;
    endtask

    // -----------------------------------------------------------------------
    // Task: assert reset for 2 cycles
    // -----------------------------------------------------------------------
    task automatic do_reset();
        @(negedge clk_in);
        reset_in = 1'b1;
        @(posedge clk_in); #1;
        @(posedge clk_in); #1;
        @(negedge clk_in);
        reset_in = 1'b0;
    endtask

    // -----------------------------------------------------------------------
    // Stimulus
    // -----------------------------------------------------------------------
    initial begin
        // Initialise all inputs
        reset_in         = 1'b0;
        control_in       = 1'b0;
        decoder_in       = 10'h000;
        decoder_valid_in = 1'b0;

        // ----------------------------------------------------------------
        // 1. Power-on reset
        // ----------------------------------------------------------------
        do_reset();
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 2. Control symbol decoding – positive and negative disparity
        //    variants for every K-code in the specification
        // ----------------------------------------------------------------

        // K.28.0  (expected out = 0x1C, control_out = 1)
        apply_word(10'b0011110100, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1100001011, 1'b1);
        @(negedge clk_in);

        // K.28.1  (0x3C)
        apply_word(10'b0011111001, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1100000110, 1'b1);
        @(negedge clk_in);

        // K.28.2  (0x5C)
        apply_word(10'b0011110101, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1100001010, 1'b1);
        @(negedge clk_in);

        // K.28.3  (0x7C)
        apply_word(10'b0011110011, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1100001100, 1'b1);
        @(negedge clk_in);

        // K.28.4  (0x9C)
        apply_word(10'b0011110010, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1100001101, 1'b1);
        @(negedge clk_in);

        // K.28.5  (0xBC)
        apply_word(10'b0011111010, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1100000101, 1'b1);
        @(negedge clk_in);

        // K.28.6  (0xDC)
        apply_word(10'b0011110110, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1100001001, 1'b1);
        @(negedge clk_in);

        // K.28.7  (0xFC)
        apply_word(10'b0011111000, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1100000111, 1'b1);
        @(negedge clk_in);

        // K.23.7  (0xF7)
        apply_word(10'b1110101000, 1'b1);
        @(negedge clk_in);
        apply_word(10'b0001010111, 1'b1);
        @(negedge clk_in);

        // K.27.7  (0xFB)
        apply_word(10'b1101101000, 1'b1);
        @(negedge clk_in);
        apply_word(10'b0010010111, 1'b1);
        @(negedge clk_in);

        // K.29.7  (0xFD)
        apply_word(10'b1011101000, 1'b1);
        @(negedge clk_in);
        apply_word(10'b0100010111, 1'b1);
        @(negedge clk_in);

        // K.30.7  (0xFE)
        apply_word(10'b0111101000, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1000010111, 1'b1);
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 3. Data symbol decoding – representative D.x.y values
        // ----------------------------------------------------------------

        // D.0.0 = 0x00  (6b=100111, 4b=0100 -> +disp encoding)
        apply_word(10'b1001110100, 1'b0);
        @(negedge clk_in);
        // D.0.0 alternate disparity (6b=011000, 4b=1011)
        apply_word(10'b0110001011, 1'b0);
        @(negedge clk_in);

        // D.1.0 = 0x01  (6b=011101, 4b=0100)
        apply_word(10'b0111010100, 1'b0);
        @(negedge clk_in);
        // D.1.0 alternate (6b=100010, 4b=1011)
        apply_word(10'b1000101011, 1'b0);
        @(negedge clk_in);

        // D.2.0 = 0x02  (6b=101101, 4b=0100)
        apply_word(10'b1011010100, 1'b0);
        @(negedge clk_in);

        // D.3.0 = 0x03  (6b=110001, 4b=0100)
        apply_word(10'b1100010100, 1'b0);
        @(negedge clk_in);

        // D.4.0 = 0x04  (6b=110101, 4b=0100)
        apply_word(10'b1101010100, 1'b0);
        @(negedge clk_in);

        // D.5.0 = 0x05  (6b=101001, 4b=0100)
        apply_word(10'b1010010100, 1'b0);
        @(negedge clk_in);

        // D.6.0 = 0x06  (6b=011001, 4b=0100)
        apply_word(10'b0110010100, 1'b0);
        @(negedge clk_in);

        // D.7.0 = 0x07  (6b=111000, 4b=0100)
        apply_word(10'b1110000100, 1'b0);
        @(negedge clk_in);

        // D.8.0 = 0x08  (6b=111001, 4b=0100)
        apply_word(10'b1110010100, 1'b0);
        @(negedge clk_in);

        // D.16.0 = 0x10  (6b=011011, 4b=0100)
        apply_word(10'b0110110100, 1'b0);
        @(negedge clk_in);

        // D.31.7 = 0xFF  (6b=101011, 4b=1110)
        apply_word(10'b1010111110, 1'b0);
        @(negedge clk_in);
        // D.31.7 alternate (6b=010100, 4b=0001)
        apply_word(10'b0101000001, 1'b0);
        @(negedge clk_in);

        // D.0.7 = 0xE0  (6b=100111, 4b=1110)
        apply_word(10'b1001111110, 1'b0);
        @(negedge clk_in);

        // D.28.0 = 0x1C  (6b=001110, 4b=0100)
        apply_word(10'b0011100100, 1'b0);
        @(negedge clk_in);

        // D.0.1 = 0x20  (6b=100111, 4b=1001)
        apply_word(10'b1001111001, 1'b0);
        @(negedge clk_in);

        // D.0.2 = 0x40  (6b=100111, 4b=0101)
        apply_word(10'b1001110101, 1'b0);
        @(negedge clk_in);

        // D.0.3 = 0x60  (6b=100111, 4b=0011)
        apply_word(10'b1001110011, 1'b0);
        @(negedge clk_in);

        // D.0.4 = 0x80  (6b=100111, 4b=0010)
        apply_word(10'b1001110010, 1'b0);
        @(negedge clk_in);

        // D.0.5 = 0xA0  (6b=100111, 4b=1010)
        apply_word(10'b1001111010, 1'b0);
        @(negedge clk_in);

        // D.0.6 = 0xC0  (6b=100111, 4b=0110)
        apply_word(10'b1001110110, 1'b0);
        @(negedge clk_in);

        // D.5.6 = 0xC5  (6b=101001, 4b=0110)
        apply_word(10'b1010010110, 1'b0);
        @(negedge clk_in);

        // D.21.5 = 0xB5  (6b=101010, 4b=1010) -> EDCBA=10101 HGF=101
        apply_word(10'b1010101010, 1'b0);
        @(negedge clk_in);

        // D.11.3 = 0x6B  (6b=110100, 4b=0011) -> EDCBA=01011 HGF=011
        apply_word(10'b1101000011, 1'b0);
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 4. valid_in de-asserted – output should not update (hold)
        // ----------------------------------------------------------------
        @(negedge clk_in);
        decoder_valid_in = 1'b0;
        decoder_in       = 10'b1111111111;
        control_in       = 1'b0;
        @(posedge clk_in); #1;
        @(posedge clk_in); #1;
        @(posedge clk_in); #1;
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 5. Mid-stream reset: start sending, assert reset, verify clear
        // ----------------------------------------------------------------
        apply_word(10'b1001110100, 1'b0); // D.0.0
        @(negedge clk_in);
        // Assert reset asynchronously between valid pulses
        reset_in = 1'b1;
        #3;
        reset_in = 1'b0;
        @(posedge clk_in); #1;
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 6. Back-to-back valid words (no idle gap)
        // ----------------------------------------------------------------
        @(negedge clk_in);
        control_in       = 1'b1;
        decoder_valid_in = 1'b1;
        // K.28.5 positive
        decoder_in = 10'b0011111010; @(posedge clk_in); #1;
        // K.28.5 negative
        decoder_in = 10'b1100000101; @(posedge clk_in); #1;
        // K.28.7
        decoder_in = 10'b0011111000; @(posedge clk_in); #1;
        // K.28.1
        decoder_in = 10'b0011111001; @(posedge clk_in); #1;
        decoder_valid_in = 1'b0;
        @(posedge clk_in); #1;
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 7. Interleaved control and data symbols
        // ----------------------------------------------------------------
        // Data: D.7.0
        apply_word(10'b1110000100, 1'b0);
        @(negedge clk_in);
        // Control: K.28.5
        apply_word(10'b0011111010, 1'b1);
        @(negedge clk_in);
        // Data: D.0.0
        apply_word(10'b1001110100, 1'b0);
        @(negedge clk_in);
        // Control: K.23.7
        apply_word(10'b1110101000, 1'b1);
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 8. control_in=1 but unrecognised code (not in K-table)
        // ----------------------------------------------------------------
        apply_word(10'b0000000000, 1'b1);
        @(negedge clk_in);
        apply_word(10'b1111111111, 1'b1);
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 9. All 5b/6b alternate disparity codes for EDCBA sweep
        // ----------------------------------------------------------------
        // EDCBA=01111 alternates: 6b=010111 and 6b=101000 with 4b=0100
        apply_word(10'b0101110100, 1'b0);
        @(negedge clk_in);
        apply_word(10'b1010000100, 1'b0);
        @(negedge clk_in);

        // EDCBA=10000: 6b=011011, 4b=0100
        apply_word(10'b0110110100, 1'b0);
        @(negedge clk_in);
        // EDCBA=10000 alternate: 6b=100100, 4b=0100
        apply_word(10'b1001000100, 1'b0);
        @(negedge clk_in);

        // EDCBA=11111 alternates: 6b=101011, 4b=0100
        apply_word(10'b1010110100, 1'b0);
        @(negedge clk_in);
        // EDCBA=11111 alternate: 6b=010100, 4b=0100
        apply_word(10'b0101000100, 1'b0);
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 10. All 3b/4b codes exercised
        // ----------------------------------------------------------------
        // HGF=001 (4b=1001), EDCBA=00000 (6b=100111)
        apply_word(10'b1001111001, 1'b0);
        @(negedge clk_in);
        // HGF=010 (4b=0101)
        apply_word(10'b1001110101, 1'b0);
        @(negedge clk_in);
        // HGF=011 (4b=0011)
        apply_word(10'b1001110011, 1'b0);
        @(negedge clk_in);
        // HGF=011 alternate (4b=1100)
        apply_word(10'b1001111100, 1'b0);
        @(negedge clk_in);
        // HGF=100 (4b=0010)
        apply_word(10'b1001110010, 1'b0);
        @(negedge clk_in);
        // HGF=100 alternate (4b=1101)
        apply_word(10'b1001111101, 1'b0);
        @(negedge clk_in);
        // HGF=101 (4b=1010)
        apply_word(10'b1001111010, 1'b0);
        @(negedge clk_in);
        // HGF=110 (4b=0110)
        apply_word(10'b1001110110, 1'b0);
        @(negedge clk_in);
        // HGF=111 (4b=1110)
        apply_word(10'b1001111110, 1'b0);
        @(negedge clk_in);
        // HGF=111 alternate (4b=0001)
        apply_word(10'b1001110001, 1'b0);
        @(negedge clk_in);

        // ----------------------------------------------------------------
        // 11. Final reset then idle
        // ----------------------------------------------------------------
        do_reset();
        @(negedge clk_in);
        repeat(4) @(posedge clk_in);

        $display("Stimulus complete at time %0t", $time);
        $finish;
    end

endmodule
