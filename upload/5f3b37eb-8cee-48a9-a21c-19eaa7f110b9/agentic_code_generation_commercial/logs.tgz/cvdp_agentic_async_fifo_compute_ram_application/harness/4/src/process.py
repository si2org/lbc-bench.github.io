import os
import re
import subprocess
import pytest

# ----------------------------------------
# - Simulate
# ----------------------------------------

@pytest.mark.usefixtures(scope='session')
def test_simulate():

    cmd = "xrun -coverage all /src/async_fifo.sv /code/verif/tb_async_fifo.sv -covtest test -seed random -covoverwrite"
    assert(subprocess.run(cmd, shell=True)), "Simulation didn't ran correctly."

# ----------------------------------------
# - Generate Coverage
# ----------------------------------------

@pytest.mark.usefixtures(scope='test_simulate')
def test_coverage():

    cmd = "imc -load /code/rundir/cov_work/scope/test -exec /src/coverage.cmd"
    assert(subprocess.run(cmd, shell=True)), "Coverage merge didn't ran correctly."

# ----------------------------------------
# - Report
# ----------------------------------------

@pytest.mark.usefixtures(scope='test_coverage')
def test_report():

    metrics = {}
    try:
        with open("/code/rundir/coverage.log") as f:
            lines = f.readlines()
    except FileNotFoundError:
        raise FileNotFoundError("Couldn't find the coverage.log file.")
    # ----------------------------------------
    # - Evaluate Report
    # ----------------------------------------
    column = re.split(r'\s{2,}', lines[0].strip())
    for line in lines[2:]:
        info = re.split(r'\s{2,}', line.strip())
        inst = info[0].lstrip('|-')
        metrics [inst] = {column[i]: info[i].split('%')[0] for i in range(1, len(column))}

    print("Metrics:")
    print(metrics)

    if "Overall Average" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Overall Average"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    elif "Assertion" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Assertion"]) >= 100.00, "Didn't achieved the required coverage result."
    elif "Toggle" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Toggle"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    elif "Block" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Block"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    else:
        assert False, "Couldn't find the required coverage result."