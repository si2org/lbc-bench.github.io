module async_fifo
    #(
        parameter p_data_width = 32,   // Parameter to define the width of the data
        parameter p_addr_width = 16    // Parameter to define the width of the address
    )(
        input  wire             i_wr_clk,           // Write clock
        input  wire             i_wr_rst_n,         // Write reset (active low)
        input  wire             i_wr_en,            // Write enable
        input  wire [p_data_width-1:0] i_wr_data,   // Data to be written to the FIFO
        output wire             o_fifo_full,        // FIFO full flag
        input  wire             i_rd_clk,           // Read clock
        input  wire             i_rd_rst_n,         // Read reset (active low)
        input  wire             i_rd_en,            // Read enable
        output wire [p_data_width-1:0] o_rd_data,   // Data read from the FIFO
        output wire             o_fifo_empty        // FIFO empty flag
    );

    // Internal signals for address synchronization
    wire [p_addr_width-1:0] w_wr_bin_addr, w_rd_bin_addr; // Binary addresses for write and read
    wire [p_addr_width  :0] w_wr_grey_addr, w_rd_grey_addr; // Gray-coded addresses for write and read
    wire [p_addr_width  :0] w_rd_ptr_sync, w_wr_ptr_sync;   // Synchronized pointers

    // Synchronize the read pointer from read domain to write domain
    read_to_write_pointer_sync
    #(p_addr_width)
    read_to_write_pointer_sync_inst (
        .o_rd_ptr_sync (w_rd_ptr_sync),    // Output synchronized read pointer
        .i_rd_grey_addr (w_rd_grey_addr),  // Input Gray-coded read address
        .i_wr_clk     (i_wr_clk),          // Write clock
        .i_wr_rst_n   (i_wr_rst_n)         // Write reset (active low)
    );

    // Synchronize the write pointer from write domain to read domain
    write_to_read_pointer_sync
    #(p_addr_width)
    write_to_read_pointer_sync_inst (
        .i_rd_clk     (i_rd_clk),          // Read clock
        .i_rd_rst_n   (i_rd_rst_n),        // Read reset (active low)
        .i_wr_grey_addr (w_wr_grey_addr),  // Input Gray-coded write address
        .o_wr_ptr_sync (w_wr_ptr_sync)     // Output synchronized write pointer
    );

    // Handle the write requests and manage the write pointer
    wptr_full
    #(p_addr_width)
    wptr_full_inst (
        .i_wr_clk     (i_wr_clk),          // Write clock
        .i_wr_rst_n   (i_wr_rst_n),        // Write reset (active low)
        .i_wr_en     (i_wr_en),            // Write enable
        .i_rd_ptr_sync (w_rd_ptr_sync),    // Synchronized read pointer
        .o_fifo_full    (o_fifo_full),     // FIFO full flag
        .o_wr_bin_addr    (w_wr_bin_addr), // Binary write address
        .o_wr_grey_addr     (w_wr_grey_addr) // Gray-coded write address
    );

    // Dual-port RAM for FIFO memory
    fifo_memory
    #(p_data_width, p_addr_width)
    fifo_memory_inst (
        .i_wr_clk   (i_wr_clk),            // Write clock
        .i_wr_clk_en (i_wr_en),            // Write clock enable
        .i_wr_addr  (w_wr_bin_addr),       // Write address
        .i_wr_data  (i_wr_data),           // Write data
        .i_wr_full  (o_fifo_full),         // FIFO full flag (write side)
        .i_rd_clk   (i_rd_clk),            // Read clock
        .i_rd_clk_en (i_rd_en),            // Read clock enable
        .i_rd_addr  (w_rd_bin_addr),       // Read address
        .o_rd_data  (o_rd_data)            // Read data output
    );

    // Handle the read requests and manage the read pointer
    rptr_empty
    #(p_addr_width)
    rptr_empty_inst (
        .i_rd_clk     (i_rd_clk),          // Read clock
        .i_rd_rst_n   (i_rd_rst_n),        // Read reset (active low)
        .i_rd_en     (i_rd_en),            // Read enable
        .i_wr_ptr_sync (w_wr_ptr_sync),    // Synchronized write pointer
        .o_fifo_empty   (o_fifo_empty),    // FIFO empty flag
        .o_rd_bin_addr    (w_rd_bin_addr), // Binary read address
        .o_rd_grey_addr     (w_rd_grey_addr) // Gray-coded read address
    );

endmodule

module fifo_memory
    #(
        parameter p_data_width = 32,    // Memory data word width
        parameter p_addr_width = 16     // Number of memory address bits
    ) (
        input  wire                i_wr_clk,       // Write clock
        input  wire                i_wr_clk_en,    // Write clock enable
        input  wire [p_addr_width-1:0] i_wr_addr,    // Write address
        input  wire [p_data_width-1:0] i_wr_data,    // Write data
        input  wire                i_wr_full,      // Write full flag
        input  wire                i_rd_clk,       // Read clock
        input  wire                i_rd_clk_en,    // Read clock enable
        input  wire [p_addr_width-1:0] i_rd_addr,    // Read address
        output wire [p_data_width-1:0] o_rd_data     // Read data output
    );

    // Calculate the depth of the memory based on the address size
    localparam p_depth = 1 << p_addr_width;

    // Define the memory array with depth p_depth and data width p_data_width
    reg [p_data_width-1:0] r_memory [0:p_depth-1];
    reg [p_data_width-1:0] r_rd_data;  // Register to hold read data

    // Write operation
    always @(posedge i_wr_clk) begin
        if (i_wr_clk_en && !i_wr_full)          // If write is enabled and FIFO is not full
            r_memory[i_wr_addr] <= i_wr_data;   // Write data to memory at specified address
    end

    // Read operation
    always @(posedge i_rd_clk) begin
        if (i_rd_clk_en)                        // If read is enabled
            r_rd_data <= r_memory[i_rd_addr];   // Read data from memory at specified address
    end

    // Assign the read data register to the output
    assign o_rd_data = r_rd_data;

endmodule

module read_to_write_pointer_sync 
    #(
        parameter p_addr_width = 16  // Parameter to define the address width of the FIFO
    )(
        input  wire              i_wr_clk,           // Write clock
        input  wire              i_wr_rst_n,         // Write reset (active low)
        input  wire [p_addr_width:0] i_rd_grey_addr, // Gray-coded read address from the read clock domain
        output reg  [p_addr_width:0] o_rd_ptr_sync   // Synchronized read pointer in the write clock domain
    );

    // Internal register to hold the intermediate synchronized read pointer
    reg [p_addr_width:0] r_rd_ptr_ff;

    // Always block for synchronizing the read pointer to the write clock domain
    always @(posedge i_wr_clk or negedge i_wr_rst_n) 
    begin
        if (!i_wr_rst_n) begin
            // If reset is asserted (active low), reset the synchronized pointers to 0
            o_rd_ptr_sync <= {p_addr_width+1{1'b0}};
            r_rd_ptr_ff <= {p_addr_width+1{1'b0}};
        end else begin
            // If reset is not asserted, synchronize the read pointer to the write clock domain
            r_rd_ptr_ff <= i_rd_grey_addr;  // First stage of synchronization
            o_rd_ptr_sync <= r_rd_ptr_ff;   // Second stage of synchronization
        end
    end

endmodule

module rptr_empty 
    #(
        parameter p_addr_width = 16  // Parameter to define the address width of the FIFO
    )(
        input  wire                i_rd_clk,         // Read clock
        input  wire                i_rd_rst_n,       // Read reset (active low)
        input  wire                i_rd_en,          // Read enable signal
        input  wire [p_addr_width  :0] i_wr_ptr_sync, // Synchronized write pointer from the write clock domain
        output reg                 o_fifo_empty,     // Output flag indicating if the FIFO is empty
        output wire [p_addr_width-1:0] o_rd_bin_addr, // Output binary read address
        output reg  [p_addr_width  :0] o_rd_grey_addr // Output Gray-coded read address
    );

    // Internal registers and wires
    reg  [p_addr_width:0] r_rd_bin_addr_pointer; // Register to store the current binary read address
    wire [p_addr_width:0] w_rd_next_grey_addr_pointer; // Wire for the next Gray-coded read address
    wire [p_addr_width:0] w_rd_next_bin_addr_pointer; // Wire for the next binary read address
    wire                  w_rd_empty;             // Wire indicating if the FIFO is empty

    //-------------------
    // GRAYSTYLE2 pointer
    //-------------------
    always @(posedge i_rd_clk or negedge i_rd_rst_n) 
    begin
        if (!i_rd_rst_n) begin
            // Reset the read address pointers to 0 on reset
            r_rd_bin_addr_pointer <= {p_addr_width+1{1'b0}};
            o_rd_grey_addr <= {p_addr_width+1{1'b0}};
        end else begin
            // Update the read address pointers on each clock edge
            r_rd_bin_addr_pointer <= w_rd_next_bin_addr_pointer;
            o_rd_grey_addr <= w_rd_next_grey_addr_pointer;
        end
    end
    
    // Memory read-address pointer (binary addressing for memory access)
    assign o_rd_bin_addr = r_rd_bin_addr_pointer[p_addr_width-1:0];

    // Calculate the next binary read address, increment only if read enable is active and FIFO is not empty
    assign w_rd_next_bin_addr_pointer = r_rd_bin_addr_pointer + (i_rd_en & ~o_fifo_empty);

    // Convert the next binary read address to Gray code
    assign w_rd_next_grey_addr_pointer = (w_rd_next_bin_addr_pointer >> 1) ^ w_rd_next_bin_addr_pointer;

    //---------------------------------------------------------------
    // FIFO is empty when the next Gray-coded read address matches the synchronized write pointer or on reset
    //---------------------------------------------------------------
    assign w_rd_empty = (w_rd_next_grey_addr_pointer == i_wr_ptr_sync);

    // Always block for updating the FIFO empty flag
    always @(posedge i_rd_clk or negedge i_rd_rst_n) begin
        if (!i_rd_rst_n) begin
            // Reset the FIFO empty flag to 1 on reset
            o_fifo_empty <= 1'b1;
        end else begin
            // Update the FIFO empty flag based on the calculated empty condition
            o_fifo_empty <= w_rd_empty;
        end
    end

endmodule

module wptr_full 
    #(
        parameter p_addr_width = 16  // Parameter to define the address width of the FIFO
    )(
        input  wire                     i_wr_clk,         // Write clock
        input  wire                     i_wr_rst_n,       // Write reset (active low)
        input  wire                     i_wr_en,          // Write enable signal
        input  wire [p_addr_width  :0]  i_rd_ptr_sync,    // Synchronized read pointer from the read clock domain
        output reg                      o_fifo_full,      // Output flag indicating if the FIFO is full
        output wire [p_addr_width-1:0]  o_wr_bin_addr,    // Output binary write address
        output reg  [p_addr_width  :0]  o_wr_grey_addr    // Output Gray-coded write address
    );

    // Internal registers and wires
    reg  [p_addr_width:0] r_wr_bin_addr_pointer;  // Register to store the current binary write address
    wire [p_addr_width:0] w_wr_next_bin_addr_pointer; // Wire for the next binary write address
    wire [p_addr_width:0] w_wr_next_grey_addr_pointer; // Wire for the next Gray-coded write address
    wire                  w_wr_full;             // Wire indicating if the FIFO is full

    // Always block for updating the write address pointers
    // GRAYSTYLE2 pointer update mechanism
    always @(posedge i_wr_clk or negedge i_wr_rst_n) begin
        if (!i_wr_rst_n) begin
            // Reset the write address pointers to 0 on reset
            r_wr_bin_addr_pointer <= {p_addr_width{1'b0}};
            o_wr_grey_addr <= {p_addr_width{1'b0}};
        end else begin
            // Update the write address pointers on each clock edge
            r_wr_bin_addr_pointer <= w_wr_next_bin_addr_pointer;
            o_wr_grey_addr <= w_wr_next_grey_addr_pointer;
        end
    end

    // Assign the binary write address for addressing the memory
    assign o_wr_bin_addr = r_wr_bin_addr_pointer[p_addr_width-1:0];

    // Calculate the next binary write address, only increment if write enable is active and FIFO is not full
    assign w_wr_next_bin_addr_pointer  = r_wr_bin_addr_pointer + (i_wr_en & ~o_fifo_full);

    // Convert the next binary write address to Gray code
    assign w_wr_next_grey_addr_pointer = (w_wr_next_bin_addr_pointer >> 1) ^ w_wr_next_bin_addr_pointer;

    // Check if the FIFO is full by comparing the next Gray-coded write address with the synchronized read pointer
    // FIFO is full if the next write address matches the read pointer with the MSB inverted
    assign w_wr_full = (w_wr_next_grey_addr_pointer == {~i_rd_ptr_sync[p_addr_width:p_addr_width-1], i_rd_ptr_sync[p_addr_width-2:0]});

    // Always block for updating the FIFO full flag
    always @(posedge i_wr_clk or negedge i_wr_rst_n) begin
        if (!i_wr_rst_n) begin
            // Reset the FIFO full flag to 0 on reset
            o_fifo_full <= 1'b0;
        end else begin
            // Update the FIFO full flag based on the calculated full condition
            o_fifo_full <= w_wr_full;
        end
    end

endmodule

module write_to_read_pointer_sync 
    #(
        parameter p_addr_width = 16  // Parameter to define the address width of the FIFO
    )(
        input  wire              i_rd_clk,         // Read clock
        input  wire              i_rd_rst_n,       // Read reset (active low)
        input  wire [p_addr_width:0] i_wr_grey_addr, // Input Gray-coded write address
        output reg  [p_addr_width:0] o_wr_ptr_sync // Output synchronized write pointer
        
    );

    // Internal register to hold the intermediate synchronized write pointer
    reg [p_addr_width:0] r_wr_ptr_ff;

    // Always block for synchronizing the write pointer to the read clock domain
    always @(posedge i_rd_clk or negedge i_rd_rst_n) 
    begin
        if (!i_rd_rst_n) begin
            // If reset is asserted (active low), reset the synchronized pointers to 0
            o_wr_ptr_sync <= {p_addr_width+1{1'b0}};
            r_wr_ptr_ff <= {p_addr_width+1{1'b0}};
        end else begin
            // If reset is not asserted, synchronize the write pointer to the read clock domain
            r_wr_ptr_ff <= i_wr_grey_addr;  // First stage of synchronization
            o_wr_ptr_sync <= r_wr_ptr_ff;   // Second stage of synchronization
        end
    end

endmodule
