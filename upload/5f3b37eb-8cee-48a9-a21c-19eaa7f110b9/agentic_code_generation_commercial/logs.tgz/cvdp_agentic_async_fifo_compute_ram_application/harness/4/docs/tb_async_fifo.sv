`timescale 1ns/1ps

module tb_async_fifo;

    // Parameters
    localparam P_DATA_WIDTH = 8;
    localparam P_ADDR_WIDTH = 4;
    localparam FIFO_DEPTH   = 1 << P_ADDR_WIDTH; // 16

    // Clock periods
    localparam WR_CLK_PERIOD = 10;
    localparam RD_CLK_PERIOD = 12;

    // DUT signals
    logic                    i_wr_clk;
    logic                    i_wr_rst_n;
    logic                    i_wr_en;
    logic [P_DATA_WIDTH-1:0] i_wr_data;
    logic                    o_fifo_full;

    logic                    i_rd_clk;
    logic                    i_rd_rst_n;
    logic                    i_rd_en;
    logic [P_DATA_WIDTH-1:0] o_rd_data;
    logic                    o_fifo_empty;

    // Test tracking
    int  test_num;
    int  pass_count;
    int  fail_count;

    // Expected data queue (FIFO order)
    logic [P_DATA_WIDTH-1:0] exp_queue[$];

    // -----------------------------------------------------------------------
    // DUT instantiation
    // -----------------------------------------------------------------------
    async_fifo #(
        .p_data_width(P_DATA_WIDTH),
        .p_addr_width(P_ADDR_WIDTH)
    ) dut (
        .i_wr_clk    (i_wr_clk),
        .i_wr_rst_n  (i_wr_rst_n),
        .i_wr_en     (i_wr_en),
        .i_wr_data   (i_wr_data),
        .o_fifo_full (o_fifo_full),
        .i_rd_clk    (i_rd_clk),
        .i_rd_rst_n  (i_rd_rst_n),
        .i_rd_en     (i_rd_en),
        .o_rd_data   (o_rd_data),
        .o_fifo_empty(o_fifo_empty)
    );

    // -----------------------------------------------------------------------
    // Clock generation
    // -----------------------------------------------------------------------
    initial i_wr_clk = 0;
    always #(WR_CLK_PERIOD/2) i_wr_clk = ~i_wr_clk;

    initial i_rd_clk = 0;
    always #(RD_CLK_PERIOD/2) i_rd_clk = ~i_rd_clk;

    // -----------------------------------------------------------------------
    // Tasks
    // -----------------------------------------------------------------------

    // Full reset of both domains
    task automatic apply_reset();
        i_wr_rst_n = 0;
        i_rd_rst_n = 0;
        i_wr_en    = 0;
        i_rd_en    = 0;
        i_wr_data  = '0;
        repeat(4) @(posedge i_wr_clk);
        repeat(4) @(posedge i_rd_clk);
        @(posedge i_wr_clk); i_wr_rst_n = 1;
        @(posedge i_rd_clk); i_rd_rst_n = 1;
        repeat(4) @(posedge i_wr_clk);
        repeat(4) @(posedge i_rd_clk);
        exp_queue.delete();
    endtask

    // Write one word (skip if FIFO is full)
    task automatic write_word(input logic [P_DATA_WIDTH-1:0] data);
        @(posedge i_wr_clk);
        if (!o_fifo_full) begin
            i_wr_en   = 1;
            i_wr_data = data;
            exp_queue.push_back(data);
        end else begin
            i_wr_en = 0;
            $display("[WARN] TC%0d: write dropped – FIFO full (data=0x%02h)", test_num, data);
        end
        @(posedge i_wr_clk);
        i_wr_en = 0;
    endtask

    // Write one word, blocking until FIFO has space
    task automatic write_word_wait(input logic [P_DATA_WIDTH-1:0] data);
        while (o_fifo_full) @(posedge i_wr_clk);
        @(posedge i_wr_clk);
        i_wr_en   = 1;
        i_wr_data = data;
        exp_queue.push_back(data);
        @(posedge i_wr_clk);
        i_wr_en = 0;
    endtask

    // Read one word and compare against the expected queue
    task automatic read_and_check();
        logic [P_DATA_WIDTH-1:0] expected;
        @(posedge i_rd_clk);
        if (!o_fifo_empty) begin
            i_rd_en = 1;
            @(posedge i_rd_clk);
            i_rd_en = 0;
            @(posedge i_rd_clk); // wait one extra cycle for registered output
            if (exp_queue.size() > 0) begin
                expected = exp_queue.pop_front();
                if (o_rd_data === expected) begin
                    pass_count++;
                    $display("[PASS] TC%0d: read 0x%02h == expected 0x%02h",
                             test_num, o_rd_data, expected);
                end else begin
                    fail_count++;
                    $display("[FAIL] TC%0d: read 0x%02h != expected 0x%02h",
                             test_num, o_rd_data, expected);
                end
            end else begin
                $display("[INFO] TC%0d: read 0x%02h (queue empty)", test_num, o_rd_data);
                pass_count++;
            end
        end else begin
            @(posedge i_rd_clk);
            i_rd_en = 0;
            $display("[WARN] TC%0d: read skipped – FIFO empty", test_num);
        end
    endtask

    // Drain FIFO until empty
    task automatic drain_fifo();
        int timeout;
        timeout = FIFO_DEPTH * 6;
        while (!o_fifo_empty && timeout > 0) begin
            read_and_check();
            timeout--;
        end
        repeat(6) @(posedge i_rd_clk);
    endtask

    // Check o_fifo_full
    task automatic check_full(input logic exp);
        repeat(4) @(posedge i_wr_clk);
        if (o_fifo_full === exp) begin
            pass_count++;
            $display("[PASS] TC%0d: o_fifo_full=%0b (expected %0b)", test_num, o_fifo_full, exp);
        end else begin
            fail_count++;
            $display("[FAIL] TC%0d: o_fifo_full=%0b (expected %0b)", test_num, o_fifo_full, exp);
        end
    endtask

    // Check o_fifo_empty
    task automatic check_empty(input logic exp);
        repeat(4) @(posedge i_rd_clk);
        if (o_fifo_empty === exp) begin
            pass_count++;
            $display("[PASS] TC%0d: o_fifo_empty=%0b (expected %0b)", test_num, o_fifo_empty, exp);
        end else begin
            fail_count++;
            $display("[FAIL] TC%0d: o_fifo_empty=%0b (expected %0b)", test_num, o_fifo_empty, exp);
        end
    endtask

    // -----------------------------------------------------------------------
    // Main stimulus
    // -----------------------------------------------------------------------
    initial begin
        pass_count = 0;
        fail_count = 0;
        i_wr_rst_n = 0; i_rd_rst_n = 0;
        i_wr_en    = 0; i_rd_en    = 0;
        i_wr_data  = '0;

        // =================================================================
        // TC1 – Basic Write-Read
        // =================================================================
        test_num = 1;
        $display("\n=== TC1: Basic Write-Read ===");
        apply_reset();

        for (int i = 0; i < 8; i++)
            write_word(8'(i + 1));

        repeat(6) @(posedge i_rd_clk); // let pointers cross domains
        drain_fifo();
        check_empty(1'b1);

        // =================================================================
        // TC2 – Fill-and-Drain (Full/Empty Flag Test)
        // =================================================================
        test_num = 2;
        $display("\n=== TC2: Fill-and-Drain ===");
        apply_reset();

        for (int i = 0; i < FIFO_DEPTH; i++)
            write_word(8'(8'hA0 + i));

        check_full(1'b1);

        repeat(6) @(posedge i_rd_clk);
        drain_fifo();
        check_empty(1'b1);

        // =================================================================
        // TC3 – Pointer Wrap-Around
        // =================================================================
        test_num = 3;
        $display("\n=== TC3: Pointer Wrap-Around ===");
        apply_reset();

        fork
            // Writer: 20 items (will stall at depth 16 until reader frees space)
            begin : wr3
                for (int i = 0; i < 20; i++)
                    write_word_wait(8'(8'hC0 + i));
            end
            // Reader: starts after a short delay, reads slowly
            begin : rd3
                repeat(16) @(posedge i_rd_clk);
                repeat(20) begin
                    if (!o_fifo_empty)
                        read_and_check();
                    else
                        repeat(3) @(posedge i_rd_clk);
                end
            end
        join

        repeat(6) @(posedge i_rd_clk);
        drain_fifo();

        // =================================================================
        // TC4 – Write Domain Reset
        // =================================================================
        test_num = 4;
        $display("\n=== TC4: Write Domain Reset ===");
        apply_reset();

        // Fill FIFO
        for (int i = 0; i < FIFO_DEPTH; i++)
            write_word(8'(8'hD0 + i));

        check_full(1'b1);

        // Reset write side only
        @(posedge i_wr_clk);
        i_wr_rst_n = 0;
        repeat(4) @(posedge i_wr_clk);
        i_wr_rst_n = 1;
        repeat(4) @(posedge i_wr_clk);

        exp_queue.delete(); // write pointer reset; memory contents may be stale

        // Drain read side
        repeat(4) @(posedge i_rd_clk);
        begin : drain4
            int t = FIFO_DEPTH * 4;
            while (!o_fifo_empty && t > 0) begin
                @(posedge i_rd_clk); i_rd_en = 1;
                @(posedge i_rd_clk); i_rd_en = 0;
                t--;
            end
        end

        repeat(8) @(posedge i_rd_clk);
        check_empty(1'b1);

        // Verify normal operation after wr reset
        for (int i = 0; i < 4; i++)
            write_word(8'(8'hE0 + i));

        repeat(6) @(posedge i_rd_clk);
        drain_fifo();
        check_empty(1'b1);

        // =================================================================
        // TC5 – Read Domain Reset
        // =================================================================
        test_num = 5;
        $display("\n=== TC5: Read Domain Reset ===");
        apply_reset();

        // Write 8 items
        for (int i = 0; i < 8; i++)
            write_word(8'(8'hF0 + i));

        repeat(4) @(posedge i_rd_clk);

        // Reset read side only
        @(posedge i_rd_clk);
        i_rd_rst_n = 0;
        exp_queue.delete();
        repeat(4) @(posedge i_rd_clk);
        i_rd_rst_n = 1;
        repeat(6) @(posedge i_rd_clk);

        // Verify empty flag is not X/Z after reset
        if (o_fifo_empty === 1'bx || o_fifo_empty === 1'bz) begin
            fail_count++;
            $display("[FAIL] TC%0d: o_fifo_empty is X/Z after rd reset", test_num);
        end else begin
            pass_count++;
            $display("[PASS] TC%0d: o_fifo_empty=%0b (valid) after rd reset", test_num, o_fifo_empty);
        end

        // Write more data and read back to confirm normal operation
        for (int i = 0; i < 6; i++)
            write_word(8'(8'h20 + i));

        repeat(6) @(posedge i_rd_clk);
        drain_fifo();
        check_empty(1'b1);

        // =================================================================
        // TC6 – Simultaneous Reset
        // =================================================================
        test_num = 6;
        $display("\n=== TC6: Simultaneous Reset ===");
        apply_reset();

        // Write and read some data
        for (int i = 0; i < 6; i++)
            write_word(8'(8'h30 + i));

        repeat(4) @(posedge i_rd_clk);
        for (int i = 0; i < 3; i++)
            read_and_check();

        // Assert both resets simultaneously
        i_wr_en = 0; i_rd_en = 0;
        @(posedge i_wr_clk); i_wr_rst_n = 0;
        @(posedge i_rd_clk); i_rd_rst_n = 0;
        exp_queue.delete();

        repeat(6) @(posedge i_wr_clk);
        repeat(6) @(posedge i_rd_clk);

        i_wr_rst_n = 1;
        @(posedge i_rd_clk); i_rd_rst_n = 1;
        repeat(6) @(posedge i_wr_clk);
        repeat(6) @(posedge i_rd_clk);

        // Both flags should be in a valid state
        check_empty(1'b1);
        check_full(1'b0);

        // Normal operation after dual reset
        for (int i = 0; i < 8; i++)
            write_word(8'(8'h40 + i));

        repeat(6) @(posedge i_rd_clk);
        drain_fifo();
        check_empty(1'b1);

        // =================================================================
        // Summary
        // =================================================================
        $display("\n========================================");
        $display("  TEST COMPLETE  PASS=%0d  FAIL=%0d", pass_count, fail_count);
        $display("========================================");
        if (fail_count == 0)
            $display("ALL TESTS PASSED");
        else
            $display("SOME TESTS FAILED");

        $finish;
    end

    // -----------------------------------------------------------------------
    // Watchdog
    // -----------------------------------------------------------------------
    initial begin
        #500_000;
        $display("[ERROR] Simulation watchdog timeout");
        $finish;
    end

    // -----------------------------------------------------------------------
    // Waveform dump
    // -----------------------------------------------------------------------
    initial begin
        $dumpfile("tb_async_fifo.vcd");
        $dumpvars(0, tb_async_fifo);
    end

endmodule
