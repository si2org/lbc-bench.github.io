module write_to_read_pointer_sync
    #(
        parameter p_addr_width = 16  // Parameter to define the address width of the FIFO
    )(
        input  wire                  i_rd_clk,        // Read clock
        input  wire                  i_rd_rst_n,      // Read reset (active low)
        input  wire [p_addr_width:0] i_wr_grey_addr,  // Gray-coded write address from write clock domain
        output reg  [p_addr_width:0] o_wr_ptr_sync    // Synchronized write pointer in read clock domain
    );

    reg [p_addr_width:0] r_wr_ptr_ff;  // First synchronization stage

    always @(posedge i_rd_clk or negedge i_rd_rst_n) begin
        if (!i_rd_rst_n) begin
            r_wr_ptr_ff   <= {p_addr_width+1{1'b0}};
            o_wr_ptr_sync <= {p_addr_width+1{1'b0}};
        end else begin
            r_wr_ptr_ff   <= i_wr_grey_addr;  // First stage
            o_wr_ptr_sync <= r_wr_ptr_ff;     // Second stage
        end
    end

endmodule
