`timescale 1ns/1ps

// =============================================================================
// Self-checking testbench for async_fifo
// Parameters: p_data_width=8, p_addr_width=4 (depth=16)
// Write clock: 10 ns period   Read clock: 12 ns period
// =============================================================================
module async_fifo_tb;

    // =========================================================================
    // Parameters
    // =========================================================================
    localparam P_DATA_WIDTH = 8;
    localparam P_ADDR_WIDTH = 4;
    localparam FIFO_DEPTH   = 1 << P_ADDR_WIDTH;  // 16

    localparam WR_CLK_HALF  = 5;   // half-period → 10 ns write clock
    localparam RD_CLK_HALF  = 6;   // half-period → 12 ns read clock

    // =========================================================================
    // DUT signals
    // =========================================================================
    reg                     i_wr_clk;
    reg                     i_wr_rst_n;
    reg                     i_wr_en;
    reg  [P_DATA_WIDTH-1:0] i_wr_data;
    wire                    o_fifo_full;

    reg                     i_rd_clk;
    reg                     i_rd_rst_n;
    reg                     i_rd_en;
    wire [P_DATA_WIDTH-1:0] o_rd_data;
    wire                    o_fifo_empty;

    // =========================================================================
    // Test tracking
    // =========================================================================
    integer pass_count;
    integer fail_count;

    // Reference model – ordered queue backed by an array
    reg [P_DATA_WIDTH-1:0] ref_queue [0:511];
    integer                ref_wr_ptr;
    integer                ref_rd_ptr;

    // Scratch variables used in the main initial block
    integer                i;
    reg [P_DATA_WIDTH-1:0] rd_data;

    // =========================================================================
    // DUT instantiation
    // =========================================================================
    async_fifo #(
        .p_data_width (P_DATA_WIDTH),
        .p_addr_width (P_ADDR_WIDTH)
    ) dut (
        .i_wr_clk    (i_wr_clk),
        .i_wr_rst_n  (i_wr_rst_n),
        .i_wr_en     (i_wr_en),
        .i_wr_data   (i_wr_data),
        .o_fifo_full (o_fifo_full),
        .i_rd_clk    (i_rd_clk),
        .i_rd_rst_n  (i_rd_rst_n),
        .i_rd_en     (i_rd_en),
        .o_rd_data   (o_rd_data),
        .o_fifo_empty(o_fifo_empty)
    );

    // =========================================================================
    // Clock generation
    // =========================================================================
    initial i_wr_clk = 1'b0;
    always  #WR_CLK_HALF i_wr_clk = ~i_wr_clk;

    initial i_rd_clk = 1'b0;
    always  #RD_CLK_HALF i_rd_clk = ~i_rd_clk;

    // =========================================================================
    // Tasks
    // =========================================================================

    // Wait N write-clock positive edges
    task automatic wait_wr_clks(input integer n);
        integer k;
        for (k = 0; k < n; k = k + 1)
            @(posedge i_wr_clk);
    endtask

    // Wait N read-clock positive edges
    task automatic wait_rd_clks(input integer n);
        integer k;
        for (k = 0; k < n; k = k + 1)
            @(posedge i_rd_clk);
    endtask

    // Write one word (write-clock domain).
    // Skips and warns if FIFO is full.
    task automatic do_write(input [P_DATA_WIDTH-1:0] data);
        @(negedge i_wr_clk);
        if (!o_fifo_full) begin
            i_wr_en   = 1'b1;
            i_wr_data = data;
            ref_queue[ref_wr_ptr] = data;
            ref_wr_ptr = ref_wr_ptr + 1;
            @(posedge i_wr_clk);
            #1;
            i_wr_en = 1'b0;
        end else begin
            $display("  [WARN] Write skipped – FIFO full at time %0t ns", $time);
            @(posedge i_wr_clk);
        end
    endtask

    // Read one word (read-clock domain).
    // The memory is registered: data appears on o_rd_data after the posedge
    // where i_rd_en=1 causes the capture.  Empty flag prevents phantom reads.
    task automatic do_read(output [P_DATA_WIDTH-1:0] data);
        @(negedge i_rd_clk);
        if (!o_fifo_empty) begin
            i_rd_en = 1'b1;
            @(posedge i_rd_clk);   // memory captures on this edge
            #1;
            data    = o_rd_data;
            i_rd_en = 1'b0;
        end else begin
            $display("  [WARN] Read skipped – FIFO empty at time %0t ns", $time);
            data = {P_DATA_WIDTH{1'b0}};
            @(posedge i_rd_clk);
        end
    endtask

    // 1-bit flag checker
    task automatic check_flag(
        input integer tc,
        input string  label,
        input logic   actual,
        input logic   expected
    );
        if (actual === expected) begin
            $display("  [PASS] TC%0d %-40s : %0b", tc, label, actual);
            pass_count = pass_count + 1;
        end else begin
            $display("  [FAIL] TC%0d %-40s : expected=%0b got=%0b (t=%0t ns)",
                     tc, label, expected, actual, $time);
            fail_count = fail_count + 1;
        end
    endtask

    // Data-word checker
    task automatic check_data(
        input integer             tc,
        input string              label,
        input [P_DATA_WIDTH-1:0]  actual,
        input [P_DATA_WIDTH-1:0]  expected
    );
        if (actual === expected) begin
            $display("  [PASS] TC%0d %-40s : 0x%02h", tc, label, actual);
            pass_count = pass_count + 1;
        end else begin
            $display("  [FAIL] TC%0d %-40s : expected=0x%02h got=0x%02h (t=%0t ns)",
                     tc, label, expected, actual, $time);
            fail_count = fail_count + 1;
        end
    endtask

    // Assert both resets and clear the reference model
    task automatic do_full_reset();
        i_wr_rst_n = 1'b0;
        i_rd_rst_n = 1'b0;
        i_wr_en    = 1'b0;
        i_rd_en    = 1'b0;
        i_wr_data  = {P_DATA_WIDTH{1'b0}};
        repeat(4) @(posedge i_wr_clk);
        repeat(4) @(posedge i_rd_clk);
        @(negedge i_wr_clk);
        i_wr_rst_n = 1'b1;
        i_rd_rst_n = 1'b1;
        repeat(2) @(posedge i_wr_clk);
        repeat(2) @(posedge i_rd_clk);
        ref_wr_ptr = 0;
        ref_rd_ptr = 0;
    endtask

    // =========================================================================
    // Main stimulus
    // =========================================================================
    initial begin
        // Initialise
        pass_count = 0;
        fail_count = 0;
        ref_wr_ptr = 0;
        ref_rd_ptr = 0;
        i_wr_rst_n = 1'b0;
        i_rd_rst_n = 1'b0;
        i_wr_en    = 1'b0;
        i_rd_en    = 1'b0;
        i_wr_data  = {P_DATA_WIDTH{1'b0}};

        // =======================================================================
        // TC1 : Basic Write-Read
        // Write 8 sequential values, read them back; verify order, empty flag.
        // =======================================================================
        $display("\n=== TC1: Basic Write-Read ===");
        do_full_reset();

        for (i = 0; i < 8; i = i + 1)
            do_write(8'hA0 + i[P_DATA_WIDTH-1:0]);

        // Allow wr_ptr to propagate through 2-stage synchroniser to rd domain
        wait_rd_clks(4);

        for (i = 0; i < 8; i = i + 1) begin
            do_read(rd_data);
            check_data(1, "read_data_in_order", rd_data, ref_queue[ref_rd_ptr]);
            ref_rd_ptr = ref_rd_ptr + 1;
        end

        // Allow flags to settle
        wait_rd_clks(4);
        check_flag(1, "empty_after_all_reads",     o_fifo_empty, 1'b1);
        wait_wr_clks(4);
        check_flag(1, "full_never_asserted",        o_fifo_full,  1'b0);

        // =======================================================================
        // TC2 : Fill-and-Drain (Full/Empty Flag Test)
        // Fill FIFO completely; verify full flag; drain; verify empty flag.
        // =======================================================================
        $display("\n=== TC2: Fill-and-Drain ===");
        do_full_reset();

        for (i = 0; i < FIFO_DEPTH; i = i + 1)
            do_write(8'hB0 + i[P_DATA_WIDTH-1:0]);

        // Full flag is in the write domain – sample after a few write clocks
        wait_wr_clks(4);
        check_flag(2, "full_after_16_writes",       o_fifo_full,  1'b1);

        // Allow wr_ptr to reach rd domain before reading
        wait_rd_clks(4);

        for (i = 0; i < FIFO_DEPTH; i = i + 1) begin
            do_read(rd_data);
            check_data(2, "data_preserved_in_order", rd_data, ref_queue[ref_rd_ptr]);
            ref_rd_ptr = ref_rd_ptr + 1;
        end

        wait_rd_clks(4);
        check_flag(2, "empty_after_full_drain",     o_fifo_empty, 1'b1);

        // Allow rd_ptr to sync back to wr domain → full deasserts
        wait_wr_clks(6);
        check_flag(2, "full_deasserted_after_drain", o_fifo_full,  1'b0);

        // =======================================================================
        // TC3 : Pointer Wrap-Around
        // Fill FIFO, partially drain, then write more so the write pointer wraps
        // through the depth boundary (memory address wraps mod FIFO_DEPTH).
        //
        // Pointer trace (p_addr_width=4, 5-bit pointers, 16 memory slots):
        //   After 16 writes  : wr_bin=16, memory[0..15]=C0..CF
        //   After  4 reads   : rd_bin=4,  memory[0..3] freed
        //   After  4 writes  : wr_bin=20, memory[0..3]=D0..D3  <-- wrap
        //   After 16 reads   : rd_bin=20, reads C4..CF then D0..D3
        // =======================================================================
        $display("\n=== TC3: Pointer Wrap-Around ===");
        do_full_reset();

        // Phase A – fill FIFO with 16 items
        for (i = 0; i < FIFO_DEPTH; i = i + 1)
            do_write(8'hC0 + i[P_DATA_WIDTH-1:0]);

        wait_wr_clks(4);
        check_flag(3, "full_after_initial_fill",    o_fifo_full,  1'b1);

        // Phase B – partial drain: read 4 items slowly
        wait_rd_clks(4);
        for (i = 0; i < 4; i = i + 1) begin
            do_read(rd_data);
            check_data(3, "partial_drain_data",      rd_data, ref_queue[ref_rd_ptr]);
            ref_rd_ptr = ref_rd_ptr + 1;
        end

        // Phase C – wait for rd_ptr to sync to wr domain; full should deassert
        wait_wr_clks(6);
        check_flag(3, "full_deasserted_mid_drain",  o_fifo_full,  1'b0);

        // Phase D – write 4 more; addresses wrap: wr_bin 16..19 → mem[0..3]
        for (i = 0; i < 4; i = i + 1)
            do_write(8'hD0 + i[P_DATA_WIDTH-1:0]);

        // Phase E – drain 12 remaining items from original fill (C4..CF)
        wait_rd_clks(4);
        for (i = 4; i < FIFO_DEPTH; i = i + 1) begin
            do_read(rd_data);
            check_data(3, "original_tail_no_corruption", rd_data, ref_queue[ref_rd_ptr]);
            ref_rd_ptr = ref_rd_ptr + 1;
        end

        // Phase F – drain 4 wrap-around items (D0..D3)
        wait_rd_clks(4);
        for (i = 0; i < 4; i = i + 1) begin
            do_read(rd_data);
            check_data(3, "wrap_around_data_correct", rd_data, ref_queue[ref_rd_ptr]);
            ref_rd_ptr = ref_rd_ptr + 1;
        end

        wait_rd_clks(4);
        check_flag(3, "empty_after_wrap_drain",     o_fifo_empty, 1'b1);

        // =======================================================================
        // TC4 : Write Domain Reset
        // Fill FIFO, then reset only the write side.
        // wr_ptr resets to 0; as rd_ptr is also 0, FIFO appears empty in the
        // read domain once the synchronised wr_ptr propagates.
        // =======================================================================
        $display("\n=== TC4: Write Domain Reset ===");
        do_full_reset();

        for (i = 0; i < FIFO_DEPTH; i = i + 1)
            do_write(8'hE0 + i[P_DATA_WIDTH-1:0]);

        wait_wr_clks(4);
        check_flag(4, "full_before_wr_reset",        o_fifo_full,  1'b1);

        // Assert write-side reset only
        @(negedge i_wr_clk);
        i_wr_rst_n = 1'b0;
        repeat(4) @(posedge i_wr_clk);
        @(negedge i_wr_clk);
        i_wr_rst_n = 1'b1;
        #1;

        // wr_ptr=0 → full condition cannot hold → o_fifo_full deasserts
        wait_wr_clks(4);
        check_flag(4, "full_deasserted_after_wr_rst", o_fifo_full,  1'b0);

        // Synchronised wr_ptr(=0) reaches rd domain; rd_ptr=0 → empty asserts
        wait_rd_clks(6);
        check_flag(4, "empty_asserted_after_wr_rst",  o_fifo_empty, 1'b1);

        // Confirm reads are blocked by the empty flag (all should read 0)
        for (i = 0; i < 4; i = i + 1) begin
            @(negedge i_rd_clk);
            check_flag(4, "read_blocked_by_empty",    o_fifo_empty, 1'b1);
            @(posedge i_rd_clk);
        end

        // =======================================================================
        // TC5 : Read Domain Reset
        // Write data, then reset only the read side.
        // rd_ptr and wr_ptr_sync both reset to 0 → FIFO appears empty.
        // =======================================================================
        $display("\n=== TC5: Read Domain Reset ===");
        do_full_reset();

        for (i = 0; i < 8; i = i + 1)
            do_write(8'hF0 + i[P_DATA_WIDTH-1:0]);

        wait_rd_clks(4);
        check_flag(5, "not_empty_before_rd_reset",   o_fifo_empty, 1'b0);

        // Assert read-side reset only
        @(negedge i_rd_clk);
        i_rd_rst_n = 1'b0;
        repeat(4) @(posedge i_rd_clk);
        @(negedge i_rd_clk);
        i_rd_rst_n = 1'b1;
        #1;

        // rd_ptr resets; wr_ptr_sync resets through synchroniser → empty asserts
        wait_rd_clks(4);
        check_flag(5, "empty_after_rd_reset",         o_fifo_empty, 1'b1);

        // Confirm reads are blocked (all should read 0)
        for (i = 0; i < 4; i = i + 1) begin
            @(negedge i_rd_clk);
            check_flag(5, "read_blocked_by_empty",    o_fifo_empty, 1'b1);
            @(posedge i_rd_clk);
        end

        // =======================================================================
        // TC6 : Simultaneous Reset
        // Write and partially read data, assert both resets together.
        // Verify FIFO is fully reset (empty asserts, full deasserts).
        // Verify full functionality is restored after reset.
        // =======================================================================
        $display("\n=== TC6: Simultaneous Reset ===");
        do_full_reset();

        // Pre-reset: write 8, read 4 to establish non-zero pointer state
        for (i = 0; i < 8; i = i + 1)
            do_write(8'h10 + i[P_DATA_WIDTH-1:0]);

        wait_rd_clks(4);

        for (i = 0; i < 4; i = i + 1) begin
            do_read(rd_data);
            check_data(6, "pre_reset_read_data",      rd_data, ref_queue[ref_rd_ptr]);
            ref_rd_ptr = ref_rd_ptr + 1;
        end

        // Assert both resets simultaneously
        @(negedge i_wr_clk);
        i_wr_rst_n = 1'b0;
        i_rd_rst_n = 1'b0;
        repeat(6) @(posedge i_wr_clk);
        repeat(6) @(posedge i_rd_clk);
        @(negedge i_wr_clk);
        i_wr_rst_n = 1'b1;
        i_rd_rst_n = 1'b1;
        #1;

        wait_rd_clks(4);
        wait_wr_clks(4);
        check_flag(6, "full_deasserted_after_dual_rst",  o_fifo_full,  1'b0);
        check_flag(6, "empty_asserted_after_dual_rst",   o_fifo_empty, 1'b1);

        // Verify full functionality restored after reset
        ref_wr_ptr = 0;
        ref_rd_ptr = 0;

        for (i = 0; i < 8; i = i + 1)
            do_write(8'h20 + i[P_DATA_WIDTH-1:0]);

        wait_rd_clks(4);

        for (i = 0; i < 8; i = i + 1) begin
            do_read(rd_data);
            check_data(6, "post_reset_data_correct",  rd_data, ref_queue[ref_rd_ptr]);
            ref_rd_ptr = ref_rd_ptr + 1;
        end

        wait_rd_clks(4);
        check_flag(6, "empty_after_post_reset_drain", o_fifo_empty, 1'b1);

        // =======================================================================
        // Summary
        // =======================================================================
        $display("\n=================================================");
        $display("RESULTS : %0d passed, %0d failed", pass_count, fail_count);
        $display("=================================================");
        if (fail_count == 0)
            $display("** ALL TESTS PASSED **");
        else
            $display("** %0d TEST(S) FAILED **", fail_count);

        $finish;
    end

    // Timeout watchdog – catches infinite loops or stuck logic
    initial begin
        #2_000_000;
        $display("[TIMEOUT] Simulation exceeded 2 ms limit!");
        $finish;
    end

endmodule
