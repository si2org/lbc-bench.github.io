module blake2s_core_finish_and_update_sanity_check (
                    input wire            clk,
                    input wire            reset_n,

                    input wire            init,
                    input wire            update,
                    input wire            finish,

                    input wire [511 : 0]  block,
                    input wire [6 : 0]    blocklen,

                    output wire [255 : 0] digest,
                    output wire           ready
                  );

    blake2s_core dut(
        .clk(clk),
        .reset_n(reset_n),
        .init(init),
        .update(update),
        .finish(finish),
        .block(block),
        .blocklen(blocklen),
        .digest(digest),
        .ready(ready)
    );

    // Helper assumptions: constrain inputs to correct usage patterns

    // Control inputs must be mutually exclusive
    assume_ops_mutually_exclusive:
        assume property (@(posedge clk) disable iff (!reset_n)
            $onehot0({init, update, finish}));

    // No new operation may be started while the module is not ready
    assume_no_new_op_while_busy:
        assume property (@(posedge clk) disable iff (!reset_n)
            !dut.ready_reg |-> !(init || update || finish));

    // update is only valid with a full 64-byte block (BLOCK_BYTES); otherwise the FSM
    // ignores the update command and ready stays high
    assume_update_full_block:
        assume property (@(posedge clk) disable iff (!reset_n)
            update |-> (blocklen == 7'd64));

    // Assertion 1: Module must not be ready immediately after an update operation starts
    assert_update_not_ready_immediately:
        assert property (@(posedge clk) disable iff (!reset_n)
            (dut.ready_reg && update) |=> !dut.ready_reg);

    // Assertion 2: Module must be ready 24 cycles after an update operation starts
    assert_update_ready_after_24:
        assert property (@(posedge clk) disable iff (!reset_n)
            (dut.ready_reg && update) |-> ##24 dut.ready_reg);

    // Assertion 3: Module must not be ready immediately after a finish operation starts
    assert_finish_not_ready_immediately:
        assert property (@(posedge clk) disable iff (!reset_n)
            (dut.ready_reg && finish) |=> !dut.ready_reg);

    // Assertion 4: Module must be ready 24 cycles after a finish operation starts
    assert_finish_ready_after_24:
        assert property (@(posedge clk) disable iff (!reset_n)
            (dut.ready_reg && finish) |-> ##24 dut.ready_reg);

endmodule : blake2s_core_finish_and_update_sanity_check
