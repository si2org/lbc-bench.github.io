module blake2s_not_readable_addresses_check(
               input wire           clk,
               input wire           reset_n,

               input wire           cs,
               input wire           we,

               input wire  [7 : 0]  address,
               input wire  [31 : 0] write_data,
               output wire [31 : 0] read_data
              );

    // Mirror address constants from the DUT for use in properties.
    localparam ADDR_CTRL     = 8'h08;
    localparam ADDR_BLOCKLEN = 8'h0a;
    localparam ADDR_BLOCK0   = 8'h10;
    localparam ADDR_BLOCK15  = 8'h1f;

    blake2s dut(
        .clk(clk),
        .reset_n(reset_n),
        .cs(cs),
        .we(we),
        .address(address),
        .write_data(write_data),
        .read_data(read_data)
    );

    // ADDR_CTRL (0x08) is write-only; a read attempt must return the default 0.
    property p_ctrl_not_readable;
        @(posedge clk)
        (cs && !we && (address == ADDR_CTRL)) |-> (dut.tmp_read_data == 32'h0);
    endproperty
    assert property (p_ctrl_not_readable)
        else $error("ADDR_CTRL (0x08) returned non-zero on read: 0x%08h", dut.tmp_read_data);

    // ADDR_BLOCKLEN (0x0a) is write-only; a read attempt must return the default 0.
    property p_blocklen_not_readable;
        @(posedge clk)
        (cs && !we && (address == ADDR_BLOCKLEN)) |-> (dut.tmp_read_data == 32'h0);
    endproperty
    assert property (p_blocklen_not_readable)
        else $error("ADDR_BLOCKLEN (0x0a) returned non-zero on read: 0x%08h", dut.tmp_read_data);

    // ADDR_BLOCK0–ADDR_BLOCK15 (0x10–0x1f) are write-only; any read in this
    // contiguous range must return the default 0.
    property p_block_range_not_readable;
        @(posedge clk)
        (cs && !we && (address >= ADDR_BLOCK0) && (address <= ADDR_BLOCK15))
            |-> (dut.tmp_read_data == 32'h0);
    endproperty
    assert property (p_block_range_not_readable)
        else $error("ADDR_BLOCK range (0x%02h) returned non-zero on read: 0x%08h",
                    address, dut.tmp_read_data);

endmodule : blake2s_not_readable_addresses_check
