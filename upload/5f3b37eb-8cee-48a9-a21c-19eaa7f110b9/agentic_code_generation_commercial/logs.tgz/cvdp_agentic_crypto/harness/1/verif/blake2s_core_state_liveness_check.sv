module blake2s_core_state_liveness_check (
                    input wire            clk,
                    input wire            reset_n,

                    input wire            init,
                    input wire            update,
                    input wire            finish,

                    input wire [511 : 0]  block,
                    input wire [6 : 0]    blocklen,

                    output wire [255 : 0] digest,
                    output wire           ready
                  );

    blake2s_core dut(
        .clk(clk),
        .reset_n(reset_n),
        .init(init),
        .update(update),
        .finish(finish),
        .block(block),
        .blocklen(blocklen),
        .digest(digest),
        .ready(ready)
    );

    // Mirror the FSM state encoding and key constants from blake2s_core
    localparam [2:0] CTRL_IDLE       = 3'h0;
    localparam [2:0] CTRL_INIT_ROUND = 3'h1;
    localparam [2:0] CTRL_G_ROW      = 3'h2;
    localparam [2:0] CTRL_G_DIAGONAL = 3'h3;
    localparam [2:0] CTRL_COMP_DONE  = 3'h4;
    localparam [2:0] CTRL_FINISH     = 3'h5;
    localparam       NUM_ROUNDS      = 10;
    localparam [6:0] BLOCK_BYTES     = 7'd64;

    // ----------------------------------------------------------------
    // Liveness properties: each state is reachable from its expected
    // predecessor under the valid trigger conditions.
    // ----------------------------------------------------------------

    // CTRL_IDLE is reachable: CTRL_FINISH unconditionally advances to CTRL_IDLE.
    property p_finish_to_idle;
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_FINISH)
        |-> ##1 (dut.blake2s_ctrl_reg == CTRL_IDLE);
    endproperty
    liveness_finish_to_idle: assert property (p_finish_to_idle);

    // CTRL_FINISH is reachable from CTRL_IDLE via init.
    // Condition excludes finish and (update && full block) because those
    // assignments in the FSM combinational block override init's target.
    property p_idle_init_to_finish;
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_IDLE &&
         init && !finish && !(update && blocklen == BLOCK_BYTES))
        |-> ##1 (dut.blake2s_ctrl_reg == CTRL_FINISH);
    endproperty
    liveness_idle_init_to_finish: assert property (p_idle_init_to_finish);

    // CTRL_INIT_ROUND is reachable from CTRL_IDLE when update presents a
    // full 64-byte block (finish, if also asserted, targets the same state).
    property p_idle_update_to_init_round;
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_IDLE &&
         update && blocklen == BLOCK_BYTES && !finish)
        |-> ##1 (dut.blake2s_ctrl_reg == CTRL_INIT_ROUND);
    endproperty
    liveness_idle_update_to_init_round: assert property (p_idle_update_to_init_round);

    // CTRL_INIT_ROUND is reachable from CTRL_IDLE when finish is asserted
    // (finish has highest priority among the three IDLE-exit conditions).
    property p_idle_finish_to_init_round;
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_IDLE && finish)
        |-> ##1 (dut.blake2s_ctrl_reg == CTRL_INIT_ROUND);
    endproperty
    liveness_idle_finish_to_init_round: assert property (p_idle_finish_to_init_round);

    // CTRL_G_ROW is reachable: CTRL_INIT_ROUND unconditionally advances to CTRL_G_ROW.
    property p_init_round_to_g_row;
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_INIT_ROUND)
        |-> ##1 (dut.blake2s_ctrl_reg == CTRL_G_ROW);
    endproperty
    liveness_init_round_to_g_row: assert property (p_init_round_to_g_row);

    // CTRL_G_DIAGONAL is reachable: CTRL_G_ROW unconditionally advances to CTRL_G_DIAGONAL.
    property p_g_row_to_g_diagonal;
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_G_ROW)
        |-> ##1 (dut.blake2s_ctrl_reg == CTRL_G_DIAGONAL);
    endproperty
    liveness_g_row_to_g_diagonal: assert property (p_g_row_to_g_diagonal);

    // CTRL_G_ROW is reachable (again) from CTRL_G_DIAGONAL while rounds remain.
    property p_g_diagonal_to_g_row;
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_G_DIAGONAL &&
         dut.round_ctr_reg != (NUM_ROUNDS - 1))
        |-> ##1 (dut.blake2s_ctrl_reg == CTRL_G_ROW);
    endproperty
    liveness_g_diagonal_to_g_row: assert property (p_g_diagonal_to_g_row);

    // CTRL_COMP_DONE is reachable from CTRL_G_DIAGONAL after the final round.
    property p_g_diagonal_to_comp_done;
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_G_DIAGONAL &&
         dut.round_ctr_reg == (NUM_ROUNDS - 1))
        |-> ##1 (dut.blake2s_ctrl_reg == CTRL_COMP_DONE);
    endproperty
    liveness_g_diagonal_to_comp_done: assert property (p_g_diagonal_to_comp_done);

    // CTRL_FINISH is reachable: CTRL_COMP_DONE unconditionally advances to CTRL_FINISH.
    property p_comp_done_to_finish;
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_COMP_DONE)
        |-> ##1 (dut.blake2s_ctrl_reg == CTRL_FINISH);
    endproperty
    liveness_comp_done_to_finish: assert property (p_comp_done_to_finish);

endmodule : blake2s_core_state_liveness_check
