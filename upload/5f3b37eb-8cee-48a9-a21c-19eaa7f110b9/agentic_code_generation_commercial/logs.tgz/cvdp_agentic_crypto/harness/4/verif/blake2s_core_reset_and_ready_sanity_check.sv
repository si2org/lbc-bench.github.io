module blake2s_core_reset_and_ready_sanity_check (
                    input wire            clk,
                    input wire            reset_n,

                    input wire            init,
                    input wire            update,
                    input wire            finish,

                    input wire [511 : 0]  block,
                    input wire [6 : 0]    blocklen,

                    output wire [255 : 0] digest,
                    output wire           ready
                  );

    blake2s_core dut(
        .clk(clk),
        .reset_n(reset_n),
        .init(init),
        .update(update),
        .finish(finish),
        .block(block),
        .blocklen(blocklen),
        .digest(digest),
        .ready(ready)
    );

    localparam CTRL_IDLE = 3'h0;

    // ---------------------------------------------------------------
    // Helper Assumptions
    // Constrain inputs to model correct/intended usage patterns.
    // ---------------------------------------------------------------

    // init must not be triggered alongside update or finish
    assume_init_exclusive: assume property (
        @(posedge clk)
        !(init && (update || finish))
    );

    // No new operation may be started while the module is not ready;
    // an operation is considered ongoing from the cycle ready goes low
    // until it returns high.
    assume_no_op_when_not_ready: assume property (
        @(posedge clk)
        !ready |-> !(init || update || finish)
    );

    // ---------------------------------------------------------------
    // Assertion Properties
    // ---------------------------------------------------------------

    // 1. The module becomes ready after reset.
    //    Synchronous reset sets ready_reg=1 on the active clock edge,
    //    so ready must be high on the very next cycle after reset_n=0.
    assert_ready_after_reset: assert property (
        @(posedge clk)
        !reset_n |=> ready
    );

    // 2. The CTRL_IDLE state indicates that the module is ready.
    //    ready_reg and ctrl_reg are updated in the same clock edge when
    //    leaving CTRL_FINISH, so CTRL_IDLE and ready=1 are always coincident.
    assert_idle_means_ready: assert property (
        @(posedge clk) disable iff (!reset_n)
        dut.blake2s_ctrl_reg == CTRL_IDLE |-> ready
    );

    // 3. The init operation takes exactly two cycles to complete, after
    //    which the module is ready again.
    //    Cycle 1 (CTRL_IDLE → CTRL_FINISH): ready deasserts.
    //    Cycle 2 (CTRL_FINISH → CTRL_IDLE): ready reasserts.
    assert_init_two_cycles: assert property (
        @(posedge clk) disable iff (!reset_n)
        (dut.blake2s_ctrl_reg == CTRL_IDLE && init) |=> (!ready ##1 ready)
    );

endmodule : blake2s_core_reset_and_ready_sanity_check
