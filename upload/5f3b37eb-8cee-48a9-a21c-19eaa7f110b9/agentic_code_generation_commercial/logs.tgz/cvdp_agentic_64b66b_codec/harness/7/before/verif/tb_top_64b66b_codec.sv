module tb_top_64b66b_codec;

    localparam CLK_PERIOD = 10;

    logic         clk_in;
    logic         rst_in;
    logic         decoder_data_valid_in;
    logic [65:0]  decoder_data_in;
    logic [63:0]  decoder_data_out;
    logic [7:0]   decoder_control_out;
    logic         sync_error;
    logic         decoder_error_out;
    logic         done;
    logic         invalid_data_in;

    logic [63:0] encoder_data_in;
    logic [7:0]  encoder_control_in;
    logic [65:0] encoder_data_out;

    top_64b66b_codec uut (
        .clk_in(clk_in),
        .rst_in(rst_in),
        .enc_data_in(encoder_data_in),
        .enc_control_in(encoder_control_in),
        .enc_data_out(encoder_data_out),
        .dec_data_valid_in(decoder_data_valid_in),
        .dec_data_in(decoder_data_in),
        .dec_data_out(decoder_data_out),
        .dec_control_out(decoder_control_out),
        .dec_sync_error(sync_error),
        .dec_error_out(decoder_error_out)
    );

    initial begin
        clk_in = 1;
        forever #(CLK_PERIOD / 2) clk_in = ~clk_in;
    end

    task apply_test_vector(
        input logic [63:0] data,
        input logic [7:0] control
    );
        begin
            encoder_data_in = data;
            encoder_control_in = control;
            #10;
        end
    endtask


    initial begin
        $display("Starting Encoder Test...");

        encoder_data_in = 64'b0;
        encoder_control_in = 8'b0;
        @(negedge rst_in);
        @(posedge clk_in);

        $display("Encoder Test Case 1");
        apply_test_vector(64'hA5A5A5A5A5A5A5A5, 8'b00000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000000);

        $display("Encoder Test Case 2");
        apply_test_vector(64'hFFFFFFFFFFFFFFFF, 8'b00000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000000);

        $display("Encoder Test Case 3");
        apply_test_vector(64'h0000000000000000, 8'b00000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000000);

        $display("Encoder Test Case 4");
        apply_test_vector(64'hAAAAAAAAAAAAAAAA, 8'b00000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000000);

        $display("Encoder Test Case 5");
        apply_test_vector(64'h5555555555555555, 8'b00000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000000);

        $display("Encoder Test Case 6");
        apply_test_vector(64'h0123456789ABCDEF, 8'b00000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000000);

        $display("Encoder Test Case 7");
        apply_test_vector(64'hFEDCBA9876543210, 8'b00000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000000);
        
        $display("Encoder Test Case 8");
        apply_test_vector(64'hA5A5A5A5A5A5A5A5, 8'b00000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000000);

        $display("Encoder Test Case 9");
        apply_test_vector(64'hFFFFFFFFFFFFFFFF, 8'b00001111);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00001111);

        $display("Encoder Test Case 10");
        apply_test_vector(64'h123456789ABCDEF0, 8'b10000001);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b10000001);

        $display("Encoder Test Case 11");
        apply_test_vector(64'hA5A5A5A5A5A5A5A5, 8'b11111111);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111111);

        $display("Encoder Test Case 12");
        apply_test_vector(64'h55555555AAAAAAAA, 8'b01010101);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b01010101);

        $display("Encoder Test Case 13");
        apply_test_vector(64'h0707070707070707, 8'b11111111);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111111);

        $display("Encoder Test Case 14");
        apply_test_vector(64'h070707070707FDAE, 8'b11111110);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111110);

        $display("Encoder Test Case 15");
        apply_test_vector(64'h0707070707FDA5A5, 8'b11111100);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111100);

        $display("Encoder Test Case 16");
        apply_test_vector(64'h07070707FDFEED55, 8'b11111000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111000);

        $display("Encoder Test Case 17");
        apply_test_vector(64'h070707FD99887766, 8'b11110000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11110000);

        $display("Encoder Test Case 18");
        apply_test_vector(64'h0707FDAABBCCDDEE, 8'b11100000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11100000);

        $display("Encoder Test Case 19");
        apply_test_vector(64'h07FDAAAAAA555555, 8'b11000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11000000);

        $display("Encoder Test Case 20");
        apply_test_vector(64'hFD773388229911AA, 8'b10000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b10000000);

        $display("Encoder Test Case 21");
        apply_test_vector(64'hDDCCBBFB07070707, 8'b00011111);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00011111);

        $display("Encoder Test Case 22");
        apply_test_vector(64'h0707079C0707079C, 8'b00010001);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00010001);

        $display("Encoder Test Case 23");
        apply_test_vector(64'h3456789ABCDEF0FB, 8'b00000001);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000001);

        $display("Encoder Test Case 24");
        apply_test_vector(64'h777777FBDEEDDE9C, 8'b00010001);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00010001);

        $display("Encoder Test Case 25");
        apply_test_vector(64'h07070707ABCDEF9C, 8'b11110001);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11110001);

        $display("Encoder Test Case 26");
        apply_test_vector(64'hAAAAAA9C07070707, 8'b00011111);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00011111);

        $display("Encoder Test Case 27");
        apply_test_vector(64'hFEFEFEFEFEFEFEFE, 8'b11111111);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111111);

        $display("Encoder Test Case 28");
        apply_test_vector(64'h07070707070707FD, 8'b11111111);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111111);
        
        $display("Encoder Test Case 29");
        apply_test_vector(64'hDDCCBB0007070707, 8'b00011111);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00011111);
        
        $display("Encoder Test Case 30");
        apply_test_vector(64'h3456789ABCDEF000, 8'b00000001);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00000001);
        
        $display("Encoder Test Case 31");
        apply_test_vector(64'h07070707070700AE, 8'b11111110);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111110);

        $display("Encoder Test Case 32");
        apply_test_vector(64'h070707070700A5A5, 8'b11111100);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111100);

        $display("Encoder Test Case 33");
        apply_test_vector(64'h0707070700FEED55, 8'b11111000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11111000);

        $display("Encoder Test Case 34");
        apply_test_vector(64'h0707070099887766, 8'b11110000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11110000);

        $display("Encoder Test Case 35");
        apply_test_vector(64'h070700AABBCCDDEE, 8'b11100000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11100000);

        $display("Encoder Test Case 36");
        apply_test_vector(64'h0700AAAAAA555555, 8'b11000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b11000000);

        $display("Encoder Test Case 37");
        apply_test_vector(64'h00773388229911AA, 8'b10000000);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b10000000);
        
        $display("Encoder Test Case 38");
        apply_test_vector(64'h777777FBDEEDDE00, 8'b00010001);
        #10;
        $display("encoder_data_in:%h, encoder_data_out: %h, control_in: %h",encoder_data_in, encoder_data_out, 8'b00010001);

        $display("Test Encoder Tests Complete.");
    end

    logic [1:0] sync_headers[0:3];

    initial begin
        sync_headers[0] = 2'b01;
        sync_headers[1] = 2'b10;
        sync_headers[2] = 2'b00;
        sync_headers[3] = 2'b11;
    end

    task automatic generate_stimulus();
        decoder_data_in       <= 66'b0;
        invalid_data_in       <= 1'b0;
        done                  <= 0;
        decoder_data_valid_in <= 0;
        rst_in                = 1'b1;
        repeat (4) @(posedge clk_in);
        rst_in                = 1'b0;

        decoder_data_in       <= {2'b11, 64'hA5A5A5A5A5A5A5A5};
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 64'hFFFFFFFFFFFFFFFF};
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b11, 64'h123456789ABCDEF0};
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        // test cases for control-only and mixed modes
        generate_control_only_testcases();
        generate_mixed_mode_testcases();
        generate_mixed_mode_invalid_testcases();
        generate_mixed_mode_invalid_type();
        repeat (40) @(posedge clk_in);
        reset_check_state();

        done                  <= 1;
        decoder_data_valid_in <= 0;

        @(posedge clk_in);
        @(posedge clk_in);
        @(posedge clk_in);
        $display("All test cases completed. Ending simulation.");
        $finish;
    endtask

    task automatic generate_control_only_testcases();
        // Control-only mode test cases
        decoder_data_in       <= {2'b10, 8'h1E, {8{7'h00}}}; // All control characters
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h1E, {8{7'h1E}}};
        decoder_data_valid_in <= 1;
        @(posedge clk_in);
    endtask

    task automatic reset_check_state();
        // Control-only mode test cases
        decoder_data_in       <= 66'b0;
        done                  <= 0;
        decoder_data_valid_in <= 0;
        rst_in                = 1'b1;
        repeat (4) @(posedge clk_in);
        rst_in                = 1'b0;
        @(posedge clk_in);
    endtask

    task automatic generate_mixed_mode_testcases();
        // Mixed mode test cases
        decoder_data_in       <= {2'b10, 8'h33, 56'hddccbb00000000}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h78, 56'h3456789abcdef0}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h87, 56'h00000000000000}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h99, 56'h000000000000AE}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hAA, 56'h0000000000A5A5}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hB4, 56'h00000000FEED55}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hCC, 56'h00000099887766}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hD2, 56'h00001234567890}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hE1, 56'h00FFEEDDCCBBAA}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hFF, 56'h773388229911AA}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h55, 56'h070707FF070707}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h66, 56'h7777770FDEEDDE}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h4B, 56'h0000000ABCDEFF}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h2D, 56'hAAAAAAF0000000}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h1E, 56'h3c78f1e3c78f1e}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h1E, 56'h00000000000000}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);
    endtask

    task automatic generate_mixed_mode_invalid_testcases();
        // Mixed mode test cases
        invalid_data_in       <= 1'b1;
        decoder_data_in       <= {2'b10, 8'h33, 56'hddccbb00000012}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h87, 56'h000000000000FF}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h99, 56'h0000000FF000AE}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hAA, 56'hFF00000000A5A5}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hB4, 56'hFF000000FEED55}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hCC, 56'hAA000099887766}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hD2, 56'hFE001234567890}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'hE1, 56'h11FFEEDDCCBBAA}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h55, 56'h07070700070707}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h66, 56'h77777711DEEDDE}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h4B, 56'h2200000ABCDE00}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h2D, 56'hAAAAAAF0000BC0}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h1E, 56'h1E1E1E00000000}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);

        decoder_data_in       <= {2'b10, 8'h77, 56'h3c78f1e3c78f1e}; // Mixed mode example
        decoder_data_valid_in <= 1;
        @(posedge clk_in);
    endtask

    task automatic generate_mixed_mode_invalid_type();
        decoder_data_in       <= {2'b10, 8'h77, 56'h3c78f1e3c78f1e}; // Mixed mode example
        @(posedge clk_in);
        decoder_data_valid_in <= 0;
    endtask

    initial begin
        generate_stimulus();
    end

    initial begin
        logic [1:0] sync_header;
        logic [63:0] data;

        @(negedge rst_in);
        @(posedge clk_in);
        while (!done && !rst_in) begin
            sync_header = decoder_data_in[65:64];
            data = decoder_data_in[63:0];
            @(posedge clk_in);
            $display("Input: decoder_data_in = %h", {sync_header, data});
            $display("Output: decoder_data_out = %h, decoder_control_out = %h, sync_error = %b, decoder_error_out = %b",
                     decoder_data_out, decoder_control_out, sync_error, decoder_error_out);
        end
    end

endmodule
