import os
from pathlib import Path
from cocotb_tools.runner import get_runner
import pytest
import random
import harness_library as hrs_lb

verilog_sources = os.getenv("VERILOG_SOURCES").split()
toplevel_lang   = os.getenv("TOPLEVEL_LANG")
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = os.getenv("WAVE")

def call_runner():
    parameter = {}
    plusargs = []
    try:
        args = []
        if sim == "xcelium":
            args = ("-coverage all", " -covoverwrite", "-sv", "-covtest test", "-svseed random")

        hrs_lb.runner(
            wave=wave,
            toplevel=toplevel,
            plusargs=plusargs,
            module=module,
            src=verilog_sources,
            sim=sim,
            args=args,
            parameter=parameter
        )
        hrs_lb.coverage_report("assertion")
        hrs_lb.covt_report_check()
    except SystemExit:
        raise SystemError("simulation failed due to assertion failed in your test")


def test_data():
    # Run the simulation with specified parameters
    call_runner()

