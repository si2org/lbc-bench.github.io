module aes_enc_top #(
    parameter NBW_KEY  = 'd256,
    parameter NBW_DATA = 'd128,
    parameter NBW_MODE = 'd3,
    parameter NBW_CNTR = 'd32
) (
    input  logic                clk,
    input  logic                rst_async_n,
    input  logic                i_reset_counter,
    input  logic                i_update_iv,
    input  logic [NBW_DATA-1:0] i_iv,
    input  logic                i_update_mode,
    input  logic [NBW_MODE-1:0] i_mode,
    input  logic                i_update_key,
    input  logic [NBW_KEY-1:0]  i_key,
    input  logic                i_start,
    input  logic [NBW_DATA-1:0] i_plaintext,
    output logic                o_done,
    output logic [NBW_DATA-1:0] o_ciphertext
);

// ----------------------------------------
// - Wires/Registers creation
// ----------------------------------------
logic [NBW_MODE-1:0] mode_ff;
logic [NBW_DATA-1:0] plaintext_ff;
logic [NBW_DATA-1:0] iv_ff;
logic [NBW_DATA-1:0] iv_nx;
logic [NBW_DATA-1:0] ciphertext;
logic [NBW_DATA-1:0] enc_in;
logic [NBW_DATA-1:0] enc_out;
logic                update_key_ff;
logic                start_ff;
logic                enc_done;
logic [NBW_KEY-1:0]  key_ff;
logic [NBW_CNTR-1:0] counter_ff;

// Possible operation modes
localparam ECB  = 3'd0;
localparam CBC  = 3'd1;
localparam PCBC = 3'd2;
localparam CFB  = 3'd3;
localparam OFB  = 3'd4;
localparam CTR  = 3'd5;

// Operation modes logic
always_comb begin
    case(mode_ff)
        ECB: begin
            enc_in     = plaintext_ff;
            iv_nx      = iv_ff;
            ciphertext = enc_out;
        end
        CBC: begin
            enc_in     = plaintext_ff ^ iv_ff;
            iv_nx      = enc_out;
            ciphertext = enc_out;
        end
        PCBC: begin
            enc_in     = plaintext_ff ^ iv_ff;
            iv_nx      = plaintext_ff ^ enc_out;
            ciphertext = enc_out;
        end
        CFB: begin
            enc_in     = iv_ff;
            iv_nx      = plaintext_ff ^ enc_out;
            ciphertext = plaintext_ff ^ enc_out;
        end
        OFB: begin
            enc_in     = iv_ff;
            iv_nx      = enc_out;
            ciphertext = plaintext_ff ^ enc_out;
        end
        CTR: begin
            enc_in     = {counter_ff[NBW_CNTR-1:NBW_CNTR/2], iv_ff[NBW_DATA-(NBW_CNTR/2)-1:(NBW_CNTR/2)], counter_ff[NBW_CNTR/2-1:0]};
            iv_nx      = iv_ff;
            ciphertext = plaintext_ff ^ enc_out;
        end
        default: begin
            enc_in     = plaintext_ff;
            iv_nx      = iv_ff;
            ciphertext = enc_out;
        end
    endcase
end

// Registers
always_ff @ (posedge clk) begin : data_regs
    if(i_start & o_done) begin
        plaintext_ff <= i_plaintext;
    end
end

always_ff @ (posedge clk or negedge rst_async_n) begin : reset_regs
    if(!rst_async_n) begin
        iv_ff        <= 128'd0;
        mode_ff      <= 3'd0;
        o_done       <= 1'b1;
        o_ciphertext <= 128'd0;
        counter_ff   <= 0;
    end else begin
        if(i_update_iv) begin
            iv_ff <= i_iv;
        end else begin
            if(enc_done) begin
                iv_ff <= iv_nx;
            end
        end

        if(i_update_mode) begin
            mode_ff <= i_mode;
        end

        if(enc_done) begin
            o_done <= 1'b1;
        end else begin
            if(i_start & o_done) begin
                o_done <= 1'b0;
            end
        end

        if(enc_done) begin
            o_ciphertext <= ciphertext;
        end

        if(i_reset_counter) begin
            counter_ff <= 0;
        end else if(enc_done & mode_ff == CTR) begin
            counter_ff <= counter_ff + 1'b1;
        end

        start_ff <= (i_start & o_done);
        update_key_ff <= (i_start & i_update_key & o_done);
        if(i_start & i_update_key & o_done) begin
            key_ff <= i_key;
        end
    end
end

// Encryption module instantiation
aes_encrypt #(
    .NBW_KEY (NBW_KEY ),
    .NBW_DATA(NBW_DATA)
) uu_aes_encrypt (
    .clk         (clk          ),
    .rst_async_n (rst_async_n  ),
    .i_update_key(update_key_ff),
    .i_key       (key_ff       ),
    .i_start     (start_ff     ),
    .i_data      (enc_in       ),
    .o_done      (enc_done     ),
    .o_data      (enc_out      )
);


// ============================================================
// SVA Assertions
// ============================================================

// 1. Reset Behavior: On reset, all outputs and internal registers must be cleared
property p_reset_clears_top;
    @(posedge clk)
    (!rst_async_n) |-> (o_done       == 1'b1)             &&
                       (o_ciphertext  == {NBW_DATA{1'b0}}) &&
                       (counter_ff    == {NBW_CNTR{1'b0}}) &&
                       (iv_ff         == {NBW_DATA{1'b0}}) &&
                       (mode_ff       == {NBW_MODE{1'b0}});
endproperty
a_reset_clears_top: assert property (p_reset_clears_top)
    else $error("[ASSERT FAIL] a_reset_clears_top: On reset, expected o_done=1, o_ciphertext=0, counter_ff=0, iv_ff=0, mode_ff=0. Got o_done=%0b o_ciphertext=%0h counter_ff=%0h iv_ff=%0h mode_ff=%0h.",
                o_done, o_ciphertext, counter_ff, iv_ff, mode_ff);

// 2. Ciphertext Update Timing: o_ciphertext must update only when encryption is completed (enc_done)
property p_ciphertext_stable_without_enc_done;
    @(posedge clk) disable iff (!rst_async_n)
    (!enc_done) |=> $stable(o_ciphertext);
endproperty
a_ciphertext_stable_without_enc_done: assert property (p_ciphertext_stable_without_enc_done)
    else $error("[ASSERT FAIL] a_ciphertext_stable_without_enc_done: o_ciphertext changed when enc_done was not asserted. o_ciphertext must update only on encryption completion.");

// 3. Done Signal Validity: o_done must deassert only on new i_start
property p_done_deasserts_only_on_start;
    @(posedge clk) disable iff (!rst_async_n)
    $fell(o_done) |-> $past(i_start && o_done);
endproperty
a_done_deasserts_only_on_start: assert property (p_done_deasserts_only_on_start)
    else $error("[ASSERT FAIL] a_done_deasserts_only_on_start: o_done deasserted without i_start being asserted when o_done was high. o_done must only deassert on a valid i_start.");

// 4. Key Register Update: key_ff must update only on valid key write (i_start & i_update_key & o_done)
property p_key_ff_captures_i_key_on_valid_write;
    @(posedge clk) disable iff (!rst_async_n)
    (i_start && i_update_key && o_done) |=> (key_ff == $past(i_key));
endproperty
a_key_ff_captures_i_key_on_valid_write: assert property (p_key_ff_captures_i_key_on_valid_write)
    else $error("[ASSERT FAIL] a_key_ff_captures_i_key_on_valid_write: key_ff did not capture i_key when i_start & i_update_key & o_done all asserted. Expected key_ff=%0h, Got key_ff=%0h.", $past(i_key), key_ff);

property p_key_ff_stable_without_valid_write;
    @(posedge clk) disable iff (!rst_async_n)
    !(i_start && i_update_key && o_done) |=> $stable(key_ff);
endproperty
a_key_ff_stable_without_valid_write: assert property (p_key_ff_stable_without_valid_write)
    else $error("[ASSERT FAIL] a_key_ff_stable_without_valid_write: key_ff changed without a valid key write condition (i_start & i_update_key & o_done). key_ff must remain stable otherwise.");

// 5. CTR Counter Control: counter_ff must increment only in CTR mode after enc_done
property p_counter_increments_in_ctr_mode;
    @(posedge clk) disable iff (!rst_async_n)
    (enc_done && (mode_ff == CTR) && !i_reset_counter) |=> (counter_ff == ($past(counter_ff) + 1'b1));
endproperty
a_counter_increments_in_ctr_mode: assert property (p_counter_increments_in_ctr_mode)
    else $error("[ASSERT FAIL] a_counter_increments_in_ctr_mode: counter_ff did not increment after enc_done in CTR mode. Expected counter_ff=%0h, Got counter_ff=%0h.", ($past(counter_ff) + 1), counter_ff);

property p_counter_stable_outside_ctr_mode;
    @(posedge clk) disable iff (!rst_async_n)
    ((!enc_done) || (mode_ff != CTR)) && (!i_reset_counter) |=> $stable(counter_ff);
endproperty
a_counter_stable_outside_ctr_mode: assert property (p_counter_stable_outside_ctr_mode)
    else $error("[ASSERT FAIL] a_counter_stable_outside_ctr_mode: counter_ff changed outside CTR mode or without enc_done assertion. counter_ff must only increment in CTR mode on enc_done.");

endmodule : aes_enc_top