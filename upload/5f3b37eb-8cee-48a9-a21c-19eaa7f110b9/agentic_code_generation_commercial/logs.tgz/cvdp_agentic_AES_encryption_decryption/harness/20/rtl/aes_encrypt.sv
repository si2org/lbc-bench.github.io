module aes_encrypt #(
    parameter NBW_KEY  = 'd256,
    parameter NBW_DATA = 'd128
) (
    input  logic                clk,
    input  logic                rst_async_n,
    input  logic                i_update_key,
    input  logic [NBW_KEY-1:0]  i_key,
    input  logic                i_start,
    input  logic [NBW_DATA-1:0] i_data,
    output logic                o_done,
    output logic [NBW_DATA-1:0] o_data
);

// ----------------------------------------
// - Internal Parameters
// ----------------------------------------
localparam NBW_BYTE   = 'd8;
localparam STEPS      = 'd14;
localparam NBW_WORD   = 'd32;
localparam NBW_EX_KEY = 'd1920;
localparam NBW_STEP   = NBW_KEY/2;

// ----------------------------------------
// - Wires/Registers creation
// ----------------------------------------
logic [NBW_BYTE-1:0]   Rcon   [STEPS/2];
logic [NBW_KEY-1:0]    valid_key;
logic [NBW_STEP-1:0]   step_key[STEPS];
logic [NBW_EX_KEY-1:0] expanded_key_nx;
logic [NBW_EX_KEY-1:0] expanded_key_ff;
logic [NBW_BYTE-1:0]   current_data_nx[4][4];
logic [NBW_BYTE-1:0]   current_data_ff[4][4];
logic [NBW_BYTE-1:0]   SubBytes[4][4];
logic [NBW_BYTE-1:0]   ShiftRows[4][4];
logic [NBW_BYTE-1:0]   xtimes02[4][4];
logic [NBW_BYTE-1:0]   xtimes03[4][4];
logic [NBW_BYTE-1:0]   MixColumns[4][4];
logic [3:0] round_ff;

// ----------------------------------------
// - Output assignment
// ----------------------------------------
always_ff @ (posedge clk or negedge rst_async_n) begin : done_assignment
    if(!rst_async_n) begin
        o_done <= 1'b0;
    end else begin
        o_done <= (round_ff == 4'd14);
    end
end

generate
    for(genvar i = 0; i < 4; i++) begin : out_row
        for(genvar j = 0; j < 4; j++) begin : out_col
            assign o_data[NBW_DATA-(4*j+i)*NBW_BYTE-1-:NBW_BYTE] = current_data_ff[i][j];
        end
    end
endgenerate

always_ff @(posedge clk or negedge rst_async_n) begin : cypher_regs
    if(!rst_async_n) begin
        round_ff <= 4'd0;
        for(int i = 0; i < 4; i++) begin
            for(int j = 0; j < 4; j++) begin
                current_data_ff[i][j] <= 8'd0;
            end
        end
    end else begin
        if(i_start || (round_ff > 4'd0 && round_ff < 4'd14)) begin
            round_ff <= round_ff + 1'b1;
        end else begin
            round_ff <= 4'd0;
        end

        for(int i = 0; i < 4; i++) begin
            for(int j = 0; j < 4; j++) begin
                current_data_ff[i][j] <= current_data_nx[i][j];
            end
        end
    end
end

always_comb begin : next_data
    for(int i = 0; i < 4; i++) begin
        for(int j = 0; j < 4; j++) begin
            if(i_start) begin
                if(i_update_key) begin
                    current_data_nx[i][j] = i_data[NBW_DATA-(4*j+i)*NBW_BYTE-1-:NBW_BYTE] ^ i_key[NBW_KEY-(4*j+i)*NBW_BYTE-1-:NBW_BYTE];
                end else begin
                    current_data_nx[i][j] = i_data[NBW_DATA-(4*j+i)*NBW_BYTE-1-:NBW_BYTE] ^ expanded_key_ff[NBW_EX_KEY-(4*j+i)*NBW_BYTE-1-:NBW_BYTE];
                end
            end else begin
                if(round_ff != 4'd0) begin
                    if(round_ff != 4'd14) begin
                        current_data_nx[i][j] = MixColumns[i][j] ^ expanded_key_ff[NBW_EX_KEY-round_ff*NBW_STEP-(4*j+i)*NBW_BYTE-1-:NBW_BYTE];
                    end else begin
                        current_data_nx[i][j] = ShiftRows[i][j] ^ expanded_key_ff[NBW_EX_KEY-round_ff*NBW_STEP-(4*j+i)*NBW_BYTE-1-:NBW_BYTE];
                    end
                end else begin
                    current_data_nx[i][j] = current_data_ff[i][j];
                end
            end
        end
    end
end

generate
    for(genvar i = 0; i < 4; i++) begin : row
        for(genvar j = 0; j < 4; j++) begin : col
            sbox uu_sbox0 (
                .i_data(current_data_ff[i][j]),
                .o_data(SubBytes[i][j])
            );
        end
    end
endgenerate

always_comb begin : cypher_logic
    // Shift Rows logic
    // Line 0: No shift
    ShiftRows[0][0] = SubBytes[0][0];
    ShiftRows[0][1] = SubBytes[0][1];
    ShiftRows[0][2] = SubBytes[0][2];
    ShiftRows[0][3] = SubBytes[0][3];

    // Line 1: Shift 1 left
    ShiftRows[1][0] = SubBytes[1][1];
    ShiftRows[1][1] = SubBytes[1][2];
    ShiftRows[1][2] = SubBytes[1][3];
    ShiftRows[1][3] = SubBytes[1][0];

    // Line 2: Shift 2 left
    ShiftRows[2][0] = SubBytes[2][2];
    ShiftRows[2][1] = SubBytes[2][3];
    ShiftRows[2][2] = SubBytes[2][0];
    ShiftRows[2][3] = SubBytes[2][1];

    // Line 3: Shift 3 left
    ShiftRows[3][0] = SubBytes[3][3];
    ShiftRows[3][1] = SubBytes[3][0];
    ShiftRows[3][2] = SubBytes[3][1];
    ShiftRows[3][3] = SubBytes[3][2];

    // Mix Columns logic
    for(int i = 0; i < 4; i++) begin
        for(int j = 0; j < 4; j++) begin
            if(ShiftRows[i][j][NBW_BYTE-1]) begin
                xtimes02[i][j] = {ShiftRows[i][j][NBW_BYTE-2:0], 1'b0} ^ 8'h1B;
                xtimes03[i][j] = {ShiftRows[i][j][NBW_BYTE-2:0], 1'b0} ^ 8'h1B ^ ShiftRows[i][j];
            end else begin
                xtimes02[i][j] = {ShiftRows[i][j][NBW_BYTE-2:0], 1'b0};
                xtimes03[i][j] = {ShiftRows[i][j][NBW_BYTE-2:0], 1'b0} ^ ShiftRows[i][j];
            end
        end
    end

    for(int i = 0; i < 4; i++) begin
        MixColumns[0][i] = xtimes02[0][i] ^ xtimes03[1][i] ^ ShiftRows[2][i] ^ ShiftRows[3][i];
        MixColumns[1][i] = xtimes02[1][i] ^ xtimes03[2][i] ^ ShiftRows[3][i] ^ ShiftRows[0][i];
        MixColumns[2][i] = xtimes02[2][i] ^ xtimes03[3][i] ^ ShiftRows[0][i] ^ ShiftRows[1][i];
        MixColumns[3][i] = xtimes02[3][i] ^ xtimes03[0][i] ^ ShiftRows[1][i] ^ ShiftRows[2][i];
    end
end

// ****************************************
// - Key Expansion logic
// ****************************************

// ----------------------------------------
// - Registers
// ----------------------------------------
always_ff @(posedge clk or negedge rst_async_n) begin : reset_regs
    if(~rst_async_n) begin
        expanded_key_ff <= {NBW_EX_KEY{1'b0}};
    end else begin
        expanded_key_ff <= expanded_key_nx;
    end
end


// ----------------------------------------
// - Operation logic
// ----------------------------------------
assign Rcon[0] = 8'h01;
assign Rcon[1] = 8'h02;
assign Rcon[2] = 8'h04;
assign Rcon[3] = 8'h08;
assign Rcon[4] = 8'h10;
assign Rcon[5] = 8'h20;
assign Rcon[6] = 8'h40;

generate
    for(genvar i = 0; i < STEPS; i++) begin : steps
        if(i%2 == 0) begin
            logic [NBW_WORD-1:0] RotWord;
            logic [NBW_WORD-1:0] SubWord;
            logic [NBW_WORD-1:0] RconXor;

            sbox uu_sbox0 (
                .i_data(RotWord[NBW_WORD-1-:NBW_BYTE]),
                .o_data(SubWord[NBW_WORD-1-:NBW_BYTE])
            );

            sbox uu_sbox1 (
                .i_data(RotWord[NBW_WORD-NBW_BYTE-1-:NBW_BYTE]),
                .o_data(SubWord[NBW_WORD-NBW_BYTE-1-:NBW_BYTE])
            );

            sbox uu_sbox2 (
                .i_data(RotWord[NBW_WORD-2*NBW_BYTE-1-:NBW_BYTE]),
                .o_data(SubWord[NBW_WORD-2*NBW_BYTE-1-:NBW_BYTE])
            );

            sbox uu_sbox3 (
                .i_data(RotWord[NBW_WORD-3*NBW_BYTE-1-:NBW_BYTE]),
                .o_data(SubWord[NBW_WORD-3*NBW_BYTE-1-:NBW_BYTE])
            );

            always_comb begin : main_operation
                RotWord = {expanded_key_ff[NBW_EX_KEY-NBW_KEY-i*NBW_STEP+NBW_WORD-NBW_BYTE-1-:(NBW_WORD-NBW_BYTE)], expanded_key_ff[NBW_EX_KEY-NBW_KEY-i*NBW_STEP+NBW_WORD-1-:NBW_BYTE]};
                RconXor = {SubWord[NBW_WORD-1-:NBW_BYTE]^Rcon[i/2], SubWord[NBW_WORD-NBW_BYTE-1-:(NBW_WORD-NBW_BYTE)]};

                step_key[i][NBW_STEP-1-:NBW_WORD]            = expanded_key_ff[NBW_EX_KEY-(4*i  )*NBW_WORD-1-:NBW_WORD] ^ RconXor;
                step_key[i][NBW_STEP-NBW_WORD-1-:NBW_WORD]   = expanded_key_ff[NBW_EX_KEY-(4*i+1)*NBW_WORD-1-:NBW_WORD] ^ step_key[i][NBW_STEP-1-:NBW_WORD];
                step_key[i][NBW_STEP-2*NBW_WORD-1-:NBW_WORD] = expanded_key_ff[NBW_EX_KEY-(4*i+2)*NBW_WORD-1-:NBW_WORD] ^ step_key[i][NBW_STEP-NBW_WORD-1-:NBW_WORD];
                step_key[i][NBW_STEP-3*NBW_WORD-1-:NBW_WORD] = expanded_key_ff[NBW_EX_KEY-(4*i+3)*NBW_WORD-1-:NBW_WORD] ^ step_key[i][NBW_STEP-2*NBW_WORD-1-:NBW_WORD];
            end
        end else begin
            logic [NBW_WORD-1:0] SubWord;

            sbox uu_sbox0 (
                .i_data(expanded_key_ff[NBW_EX_KEY-NBW_KEY+NBW_WORD-i*NBW_STEP-1-:NBW_BYTE]),
                .o_data(SubWord[NBW_WORD-1-:NBW_BYTE])
            );

            sbox uu_sbox1 (
                .i_data(expanded_key_ff[NBW_EX_KEY-NBW_KEY+NBW_WORD-i*NBW_STEP-NBW_BYTE-1-:NBW_BYTE]),
                .o_data(SubWord[NBW_WORD-NBW_BYTE-1-:NBW_BYTE])
            );

            sbox uu_sbox2 (
                .i_data(expanded_key_ff[NBW_EX_KEY-NBW_KEY+NBW_WORD-i*NBW_STEP-2*NBW_BYTE-1-:NBW_BYTE]),
                .o_data(SubWord[NBW_WORD-2*NBW_BYTE-1-:NBW_BYTE])
            );

            sbox uu_sbox3 (
                .i_data(expanded_key_ff[NBW_EX_KEY-NBW_KEY+NBW_WORD-i*NBW_STEP-3*NBW_BYTE-1-:NBW_BYTE]),
                .o_data(SubWord[NBW_WORD-3*NBW_BYTE-1-:NBW_BYTE])
            );

            always_comb begin : main_operation
                step_key[i][NBW_STEP-1-:NBW_WORD]            = expanded_key_ff[NBW_EX_KEY-(4*i  )*NBW_WORD-1-:NBW_WORD] ^ SubWord;
                step_key[i][NBW_STEP-NBW_WORD-1-:NBW_WORD]   = expanded_key_ff[NBW_EX_KEY-(4*i+1)*NBW_WORD-1-:NBW_WORD] ^ step_key[i][NBW_STEP-1-:NBW_WORD];
                step_key[i][NBW_STEP-2*NBW_WORD-1-:NBW_WORD] = expanded_key_ff[NBW_EX_KEY-(4*i+2)*NBW_WORD-1-:NBW_WORD] ^ step_key[i][NBW_STEP-NBW_WORD-1-:NBW_WORD];
                step_key[i][NBW_STEP-3*NBW_WORD-1-:NBW_WORD] = expanded_key_ff[NBW_EX_KEY-(4*i+3)*NBW_WORD-1-:NBW_WORD] ^ step_key[i][NBW_STEP-2*NBW_WORD-1-:NBW_WORD];
            end
        end
    end
endgenerate

assign expanded_key_nx = {valid_key   , step_key[0 ], step_key[1 ], step_key[2 ],
                          step_key[3 ], step_key[4 ], step_key[5 ], step_key[6 ],
                          step_key[7 ], step_key[8 ], step_key[9 ], step_key[10],
                          step_key[11], step_key[12]};

always_comb begin : input_data
    if (i_update_key) begin
        valid_key = i_key;
    end else begin
        valid_key = expanded_key_ff[NBW_EX_KEY-1-:NBW_KEY];
    end
end


// ============================================================
// SVA Assertions
// ============================================================

// 1. Reset Behavior: On reset, all aes_encrypt outputs and registers must be cleared
property p_reset_clears_encrypt;
    @(posedge clk)
    (!rst_async_n) |-> (o_done         == 1'b0)              &&
                       (round_ff        == 4'd0)              &&
                       (o_data          == {NBW_DATA{1'b0}})  &&
                       (expanded_key_ff == {NBW_EX_KEY{1'b0}});
endproperty
a_reset_clears_encrypt: assert property (p_reset_clears_encrypt)
    else $error("[ASSERT FAIL] a_reset_clears_encrypt: On reset, expected o_done=0, round_ff=0, o_data=0, expanded_key_ff=0. Got o_done=%0b round_ff=%0d.", o_done, round_ff);

// 6. Encryption Round Progression: round_ff must increment on every active encryption cycle
property p_round_increments_when_active;
    @(posedge clk) disable iff (!rst_async_n)
    (i_start || (round_ff > 4'd0 && round_ff < 4'd14)) |=> (round_ff == ($past(round_ff) + 4'd1));
endproperty
a_round_increments_when_active: assert property (p_round_increments_when_active)
    else $error("[ASSERT FAIL] a_round_increments_when_active: round_ff did not increment during active encryption. Expected round_ff=%0d, Got round_ff=%0d.", ($past(round_ff) + 1), round_ff);

// o_done must assert exactly one cycle after round_ff reaches 14
property p_done_asserts_after_round14;
    @(posedge clk) disable iff (!rst_async_n)
    (round_ff == 4'd14) |=> (o_done == 1'b1);
endproperty
a_done_asserts_after_round14: assert property (p_done_asserts_after_round14)
    else $error("[ASSERT FAIL] a_done_asserts_after_round14: o_done did not assert one cycle after round_ff reached 14. Expected o_done=1, Got o_done=%0b.", o_done);

// 7. Key Expansion Handling: when i_update_key, expanded_key_ff top NBW_KEY bits must load i_key
property p_expanded_key_loads_i_key_on_update;
    @(posedge clk) disable iff (!rst_async_n)
    (i_update_key) |=> (expanded_key_ff[NBW_EX_KEY-1-:NBW_KEY] == $past(i_key));
endproperty
a_expanded_key_loads_i_key_on_update: assert property (p_expanded_key_loads_i_key_on_update)
    else $error("[ASSERT FAIL] a_expanded_key_loads_i_key_on_update: expanded_key_ff top bits did not load i_key when i_update_key=1. Expected=%0h, Got=%0h.", $past(i_key), expanded_key_ff[NBW_EX_KEY-1-:NBW_KEY]);

// 8. Initial XOR Logic: first-round current_data_ff must equal i_data XOR key (i_key or expanded_key_ff)
property p_first_round_xor_uses_i_key;
    @(posedge clk) disable iff (!rst_async_n)
    (i_start && i_update_key) |=>
        (o_data == ($past(i_data) ^ $past(i_key[NBW_KEY-1-:NBW_DATA])));
endproperty
a_first_round_xor_uses_i_key: assert property (p_first_round_xor_uses_i_key)
    else $error("[ASSERT FAIL] a_first_round_xor_uses_i_key: Initial XOR with i_key mismatch after i_start with i_update_key=1. Expected o_data=%0h, Got o_data=%0h.",
                ($past(i_data) ^ $past(i_key[NBW_KEY-1-:NBW_DATA])), o_data);

property p_first_round_xor_uses_expanded_key;
    @(posedge clk) disable iff (!rst_async_n)
    (i_start && !i_update_key) |=>
        (o_data == ($past(i_data) ^ $past(expanded_key_ff[NBW_EX_KEY-1-:NBW_DATA])));
endproperty
a_first_round_xor_uses_expanded_key: assert property (p_first_round_xor_uses_expanded_key)
    else $error("[ASSERT FAIL] a_first_round_xor_uses_expanded_key: Initial XOR with expanded_key_ff mismatch after i_start with i_update_key=0. Expected o_data=%0h, Got o_data=%0h.",
                ($past(i_data) ^ $past(expanded_key_ff[NBW_EX_KEY-1-:NBW_DATA])), o_data);

endmodule : aes_encrypt