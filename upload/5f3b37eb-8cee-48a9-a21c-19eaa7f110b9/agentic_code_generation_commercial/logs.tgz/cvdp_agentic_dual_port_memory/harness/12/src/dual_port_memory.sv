module dual_port_memory #(
    parameter DATA_WIDTH = 4,              // Data width
    parameter ECC_WIDTH = 3,               // ECC bits for Hamming(7,4)
    parameter ADDR_WIDTH = 5,              // Address width
    parameter MEM_DEPTH = (1 << ADDR_WIDTH)  // Memory depth
)(
    input clk,
    input rst_n,                                     // Active-low synchronous reset
    input we,                                        // Write enable
    input [ADDR_WIDTH-1:0] addr_a,                  // Write address (Port A)
    input [ADDR_WIDTH-1:0] addr_b,                  // Read address (Port B)
    input [DATA_WIDTH-1:0] data_in,                 // Input data
    output reg [DATA_WIDTH-1:0] data_out,           // Output data
    output reg ecc_error                             // ECC error flag
);

    // Memory arrays for data and ECC
    reg [DATA_WIDTH-1:0] ram_data [MEM_DEPTH-1:0];
    reg [ECC_WIDTH-1:0] ram_ecc  [MEM_DEPTH-1:0];

    // Function to generate ECC bits using Hamming(7,4)
    function [ECC_WIDTH-1:0] calc_ecc(input [DATA_WIDTH-1:0] d);
        reg p1, p2, p3;
        begin
            // Hamming(7,4): d[3:0] mapped to bits 3,5,6,7 (1-based index)
            p1 = d[0] ^ d[1] ^ d[3];        // Covers positions 1, 3, 5, 7
            p2 = d[0] ^ d[2] ^ d[3];        // Covers positions 2, 3, 6, 7
            p3 = d[1] ^ d[2] ^ d[3];        // Covers positions 4, 5, 6, 7
            calc_ecc = {p3, p2, p1};        // Ordered [P3 P2 P1]
        end
    endfunction

    // Function to check ECC
    function [ECC_WIDTH-1:0] check_ecc(
        input [DATA_WIDTH-1:0] d,
        input [ECC_WIDTH-1:0] ecc
    );
        reg [ECC_WIDTH-1:0] expected_ecc;
        begin
            expected_ecc = calc_ecc(d);
            check_ecc = expected_ecc ^ ecc;  // Syndrome
        end
    endfunction

    always @(posedge clk) begin
        if (!rst_n) begin
            data_out  <= 0;
            ecc_error <= 0;
        end else begin
            if (we) begin
                ram_data[addr_a] <= data_in;
                ram_ecc[addr_a]  <= calc_ecc(data_in);
            end else begin
                data_out <= ram_data[addr_b];
                if (check_ecc(ram_data[addr_b], ram_ecc[addr_b]) != 0) begin
                    ecc_error <= 1;
                end else begin
                    ecc_error <= 0;
                end
            end
        end
    end
endmodule