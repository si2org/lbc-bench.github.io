`timescale 1ns/1ps

module tb_dual_port_memory;

    // -----------------------------------------------------------------------
    // Configurable parameters (must match DUT defaults or override at top)
    // -----------------------------------------------------------------------
    parameter DATA_WIDTH = 4;
    parameter ECC_WIDTH  = 3;
    parameter ADDR_WIDTH = 5;
    parameter MEM_DEPTH  = (1 << ADDR_WIDTH);

    // -----------------------------------------------------------------------
    // DUT port signals
    // -----------------------------------------------------------------------
    logic                  clk;
    logic                  rst_n;
    logic                  we;
    logic [ADDR_WIDTH-1:0] addr_a;
    logic [ADDR_WIDTH-1:0] addr_b;
    logic [DATA_WIDTH-1:0] data_in;
    logic [DATA_WIDTH-1:0] data_out;
    logic                  ecc_error;

    // -----------------------------------------------------------------------
    // DUT instantiation
    // -----------------------------------------------------------------------
    dual_port_memory #(
        .DATA_WIDTH(DATA_WIDTH),
        .ECC_WIDTH (ECC_WIDTH),
        .ADDR_WIDTH(ADDR_WIDTH),
        .MEM_DEPTH (MEM_DEPTH)
    ) dut (
        .clk      (clk),
        .rst_n    (rst_n),
        .we       (we),
        .addr_a   (addr_a),
        .addr_b   (addr_b),
        .data_in  (data_in),
        .data_out (data_out),
        .ecc_error(ecc_error)
    );

    // -----------------------------------------------------------------------
    // Clock generation: 10 ns period
    // -----------------------------------------------------------------------
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // -----------------------------------------------------------------------
    // $monitor: track key signal changes
    // -----------------------------------------------------------------------
    initial begin
        $monitor("%4t | clk=%b rst_n=%b we=%b addr_a=%0d addr_b=%0d data_in=%b | data_out=%b ecc_error=%b",
                 $time, clk, rst_n, we, addr_a, addr_b, data_in, data_out, ecc_error);
    end

    // -----------------------------------------------------------------------
    // Loop and timeout variables (module-level; no tasks/functions per spec)
    // -----------------------------------------------------------------------
    integer i;
    integer timeout_cnt;

    // -----------------------------------------------------------------------
    // Main stimulus
    // -----------------------------------------------------------------------
    initial begin

        // -------------------------------------------------------------------
        // Initialise all inputs and apply active-low reset
        // -------------------------------------------------------------------
        rst_n   = 1'b0;
        we      = 1'b0;
        addr_a  = '0;
        addr_b  = '0;
        data_in = '0;

        repeat(2) @(posedge clk);
        #1;
        rst_n = 1'b1;
        @(posedge clk); #1;

        // ===================================================================
        // Test 1: Write and read from the same address
        // ===================================================================
        $display("\n[Test 1] Write and read from the same address");
        we = 1'b1; addr_a = 5'd3; data_in = 4'hA;
        @(posedge clk); #1;
        we = 1'b0; addr_b = 5'd3;
        // Wait for data_out / ecc_error to settle (timeout = 50 cycles)
        timeout_cnt = 0;
        while (timeout_cnt < 50) begin
            @(posedge clk); #1;
            timeout_cnt = timeout_cnt + 1;
            if (data_out !== 'x && ecc_error !== 1'bx) break;
        end

        // ===================================================================
        // Test 2: Back-to-back sequential writes and reads
        // ===================================================================
        $display("\n[Test 2] Back-to-back sequential writes and reads");
        we = 1'b1;
        for (i = 0; i < 4; i = i + 1) begin
            addr_a = ADDR_WIDTH'(i);
            data_in = DATA_WIDTH'(i + 1);
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < 4; i = i + 1) begin
            addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 3: Sequential read-after-write hazard (write to i, read i-1)
        // ===================================================================
        $display("\n[Test 3] Sequential read-after-write hazard");
        for (i = 1; i < 8; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i - 1);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 4: Same data (4'b1111) to different addresses
        // ===================================================================
        $display("\n[Test 4] Same data (4'b1111) to different addresses");
        we = 1'b1; data_in = 4'b1111;
        for (i = 0; i < 8; i = i + 1) begin
            addr_a = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;

        // ===================================================================
        // Test 5: Inject single-bit DATA corruption after a valid write
        // ===================================================================
        $display("\n[Test 5] ECC Error - Single-bit data corruption");
        we = 1'b1; addr_a = 5'd10; data_in = 4'b1010;
        @(posedge clk); #1;
        we = 1'b0;
        // Corrupt bit 0 of stored data word at address 10
        force dut.data_mem[10][0] = ~dut.data_mem[10][0];
        @(posedge clk); #1;
        release dut.data_mem[10][0];
        addr_b = 5'd10;
        timeout_cnt = 0;
        while (timeout_cnt < 50) begin
            @(posedge clk); #1;
            timeout_cnt = timeout_cnt + 1;
            if (ecc_error !== 1'bx) break;
        end

        // ===================================================================
        // Test 6: Inject single-bit ECC corruption while data remains intact
        // ===================================================================
        $display("\n[Test 6] ECC Error - Single-bit ECC parity flip");
        we = 1'b1; addr_a = 5'd11; data_in = 4'b1100;
        @(posedge clk); #1;
        we = 1'b0;
        // Corrupt ECC bit 0 at address 11
        force dut.ecc_mem[11][0] = ~dut.ecc_mem[11][0];
        @(posedge clk); #1;
        release dut.ecc_mem[11][0];
        addr_b = 5'd11;
        timeout_cnt = 0;
        while (timeout_cnt < 50) begin
            @(posedge clk); #1;
            timeout_cnt = timeout_cnt + 1;
            if (ecc_error !== 1'bx) break;
        end

        // ===================================================================
        // Test 7: Write to minimum (0) and maximum (MEM_DEPTH-1) addresses
        // ===================================================================
        $display("\n[Test 7] Min/max address boundary test");
        we = 1'b1; addr_a = 5'd0; data_in = 4'hF;
        @(posedge clk); #1;
        addr_a = ADDR_WIDTH'(MEM_DEPTH - 1); data_in = 4'h5;
        @(posedge clk); #1;
        we = 1'b0;
        addr_b = 5'd0;
        @(posedge clk); #1;
        addr_b = ADDR_WIDTH'(MEM_DEPTH - 1);
        timeout_cnt = 0;
        while (timeout_cnt < 50) begin
            @(posedge clk); #1;
            timeout_cnt = timeout_cnt + 1;
            if (data_out !== 'x && ecc_error !== 1'bx) break;
        end

        // ===================================================================
        // Test 8: Write and read walking 1s pattern
        // ===================================================================
        $display("\n[Test 8] Walking 1s data pattern");
        for (i = 0; i < DATA_WIDTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(1 << i);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 9: Fill memory with all 0s and read back
        // ===================================================================
        $display("\n[Test 9] Fill memory with zeros and read back");
        we = 1'b1; data_in = 4'b0000;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_a = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 10: Write valid data; corrupt ECC at every 4th address
        // ===================================================================
        $display("\n[Test 10] Corrupt ECC at every 4th address");
        we = 1'b1;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH; i = i + 4) begin
            force dut.ecc_mem[i][0] = ~dut.ecc_mem[i][0];
            @(posedge clk); #1;
            release dut.ecc_mem[i][0];
            addr_b = ADDR_WIDTH'(i);
            timeout_cnt = 0;
            while (timeout_cnt < 50) begin
                @(posedge clk); #1;
                timeout_cnt = timeout_cnt + 1;
                if (ecc_error !== 1'bx) break;
            end
        end

        // ===================================================================
        // Test 11: Simultaneous read and write to the same address
        // ===================================================================
        $display("\n[Test 11] Simultaneous read/write to the same address");
        we = 1'b1; addr_a = 5'd15; addr_b = 5'd15; data_in = 4'b0101;
        @(posedge clk); #1;
        @(posedge clk); #1;
        we = 1'b0;

        // ===================================================================
        // Test 12: One-hot addressing pattern (1, 2, 4, 8, 16)
        // ===================================================================
        $display("\n[Test 12] One-hot addressing pattern");
        for (i = 0; i < ADDR_WIDTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(1 << i); data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(1 << i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 13: Write all possible 4-bit patterns (0 to 15) to same address
        // ===================================================================
        $display("\n[Test 13] All 4-bit data patterns (0-15) to same address");
        for (i = 0; i < 16; i = i + 1) begin
            we = 1'b1; addr_a = 5'd20; data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
            we = 1'b0; addr_b = 5'd20;
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 14: Invert a value read from memory, write to new address
        // ===================================================================
        $display("\n[Test 14] Feedback-based inversion write");
        we = 1'b1; addr_a = 5'd5; data_in = 4'b1010;
        @(posedge clk); #1;
        we = 1'b0; addr_b = 5'd5;
        @(posedge clk); #1;
        @(posedge clk); #1;          // allow data_out to settle
        we = 1'b1; addr_a = 5'd6; data_in = ~data_out;
        @(posedge clk); #1;
        we = 1'b0; addr_b = 5'd6;
        @(posedge clk); #1;

        // ===================================================================
        // Test 15: Read-modify-write
        // ===================================================================
        $display("\n[Test 15] Read-modify-write");
        we = 1'b1; addr_a = 5'd7; data_in = 4'b0011;
        @(posedge clk); #1;
        we = 1'b0; addr_b = 5'd7;
        @(posedge clk); #1;
        @(posedge clk); #1;          // allow data_out to settle
        we = 1'b1; addr_a = 5'd7; data_in = data_out | 4'b1100;
        @(posedge clk); #1;
        we = 1'b0; addr_b = 5'd7;
        @(posedge clk); #1;

        // ===================================================================
        // Test 16: Full corruption: invert both data and ECC bits
        // ===================================================================
        $display("\n[Test 16] Full corruption: invert data + ECC bits");
        we = 1'b1; addr_a = 5'd12; data_in = 4'b1010;
        @(posedge clk); #1;
        we = 1'b0;
        force dut.data_mem[12] = ~dut.data_mem[12];
        force dut.ecc_mem[12]  = ~dut.ecc_mem[12];
        @(posedge clk); #1;
        release dut.data_mem[12];
        release dut.ecc_mem[12];
        addr_b = 5'd12;
        timeout_cnt = 0;
        while (timeout_cnt < 50) begin
            @(posedge clk); #1;
            timeout_cnt = timeout_cnt + 1;
            if (ecc_error !== 1'bx) break;
        end

        // ===================================================================
        // Test 17: Flip each ECC bit individually and verify error detection
        // ===================================================================
        $display("\n[Test 17] Flip each ECC bit individually");
        we = 1'b1; addr_a = 5'd13; data_in = 4'b1100;
        @(posedge clk); #1;
        we = 1'b0;
        for (i = 0; i < ECC_WIDTH; i = i + 1) begin
            force dut.ecc_mem[13][i] = ~dut.ecc_mem[13][i];
            @(posedge clk); #1;
            release dut.ecc_mem[13][i];
            addr_b = 5'd13;
            timeout_cnt = 0;
            while (timeout_cnt < 50) begin
                @(posedge clk); #1;
                timeout_cnt = timeout_cnt + 1;
                if (ecc_error !== 1'bx) break;
            end
            // Restore via re-write so next bit flip is clean
            we = 1'b1; addr_a = 5'd13; data_in = 4'b1100;
            @(posedge clk); #1;
            we = 1'b0;
        end

        // ===================================================================
        // Test 18: Flip each data bit individually and verify error detection
        // ===================================================================
        $display("\n[Test 18] Flip each data bit individually");
        we = 1'b1; addr_a = 5'd14; data_in = 4'b1010;
        @(posedge clk); #1;
        we = 1'b0;
        for (i = 0; i < DATA_WIDTH; i = i + 1) begin
            force dut.data_mem[14][i] = ~dut.data_mem[14][i];
            @(posedge clk); #1;
            release dut.data_mem[14][i];
            addr_b = 5'd14;
            timeout_cnt = 0;
            while (timeout_cnt < 50) begin
                @(posedge clk); #1;
                timeout_cnt = timeout_cnt + 1;
                if (ecc_error !== 1'bx) break;
            end
            // Restore via re-write
            we = 1'b1; addr_a = 5'd14; data_in = 4'b1010;
            @(posedge clk); #1;
            we = 1'b0;
        end

        // ===================================================================
        // Test 19: Toggle between writing to min and max addresses
        // ===================================================================
        $display("\n[Test 19] Toggle write between min and max addresses");
        for (i = 0; i < 8; i = i + 1) begin
            we = 1'b1;
            addr_a  = i[0] ? ADDR_WIDTH'(MEM_DEPTH - 1) : 5'd0;
            data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;
        addr_b = 5'd0;
        @(posedge clk); #1;
        addr_b = ADDR_WIDTH'(MEM_DEPTH - 1);
        @(posedge clk); #1;

        // ===================================================================
        // Test 20: Write and read even addresses
        // ===================================================================
        $display("\n[Test 20] Write to even addresses");
        we = 1'b1;
        for (i = 0; i < MEM_DEPTH; i = i + 2) begin
            addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH; i = i + 2) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 21: Write and read odd addresses
        // ===================================================================
        $display("\n[Test 21] Write to odd addresses");
        we = 1'b1;
        for (i = 1; i < MEM_DEPTH; i = i + 2) begin
            addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 1; i < MEM_DEPTH; i = i + 2) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 22: Address gaps — write/read every 3rd address
        // ===================================================================
        $display("\n[Test 22] Address gaps - every 3rd address");
        we = 1'b1;
        for (i = 0; i < MEM_DEPTH; i = i + 3) begin
            addr_a = ADDR_WIDTH'(i); data_in = ~DATA_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH; i = i + 3) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 23: Wraparound — write near max, read from extremes
        // ===================================================================
        $display("\n[Test 23] Wraparound address sequence");
        we = 1'b1;
        for (i = MEM_DEPTH - 4; i < MEM_DEPTH; i = i + 1) begin
            addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;
        addr_b = 5'd0;                     @(posedge clk); #1;
        addr_b = ADDR_WIDTH'(MEM_DEPTH-1); @(posedge clk); #1;

        // ===================================================================
        // Test 24: Random pattern — scattered addresses
        // ===================================================================
        $display("\n[Test 24] Random pattern 1 - scattered addresses");
        we = 1'b1;
        addr_a = 5'd17; data_in = 4'hB; @(posedge clk); #1;
        addr_a = 5'd9;  data_in = 4'h3; @(posedge clk); #1;
        addr_a = 5'd24; data_in = 4'hE; @(posedge clk); #1;
        addr_a = 5'd31; data_in = 4'h6; @(posedge clk); #1;
        we = 1'b0;
        addr_b = 5'd17; @(posedge clk); #1;
        addr_b = 5'd9;  @(posedge clk); #1;
        addr_b = 5'd24; @(posedge clk); #1;
        addr_b = 5'd31; @(posedge clk); #1;

        // ===================================================================
        // Test 25: Address reuse — write same address three times
        // ===================================================================
        $display("\n[Test 25] Address reuse pattern");
        we = 1'b1;
        addr_a = 5'd8; data_in = 4'h1; @(posedge clk); #1;
        addr_a = 5'd8; data_in = 4'h2; @(posedge clk); #1;
        addr_a = 5'd8; data_in = 4'h3; @(posedge clk); #1;
        we = 1'b0; addr_b = 5'd8; @(posedge clk); #1;

        // ===================================================================
        // Test 26: All-ones data to all addresses
        // ===================================================================
        $display("\n[Test 26] All-ones data to all addresses");
        we = 1'b1; data_in = 4'hF;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_a = ADDR_WIDTH'(i); @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 27: Alternating 0101 / 1010 data pattern across all addresses
        // ===================================================================
        $display("\n[Test 27] Alternating 0101/1010 data pattern");
        we = 1'b1;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_a  = ADDR_WIDTH'(i);
            data_in = i[0] ? 4'b1010 : 4'b0101;
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 28: Random writes then sweep-read all addresses
        // ===================================================================
        $display("\n[Test 28] Random writes then read all addresses");
        we = 1'b1;
        addr_a = 5'd2;  data_in = 4'h7; @(posedge clk); #1;
        addr_a = 5'd18; data_in = 4'hC; @(posedge clk); #1;
        addr_a = 5'd27; data_in = 4'h5; @(posedge clk); #1;
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 29: Descending address write
        // ===================================================================
        $display("\n[Test 29] Descending address write");
        we = 1'b1;
        for (i = MEM_DEPTH - 1; i >= 0; i = i - 1) begin
            addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 30: Alternating all-zeros / all-ones fill
        // ===================================================================
        $display("\n[Test 30] Alternating zero/one fill");
        we = 1'b1;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_a  = ADDR_WIDTH'(i);
            data_in = i[0] ? 4'b1111 : 4'b0000;
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 31: Near-maximum data values (0xC – 0xE)
        // ===================================================================
        $display("\n[Test 31] Near-max data values");
        we = 1'b1;
        addr_a = 5'd4; data_in = 4'hE; @(posedge clk); #1;
        addr_a = 5'd5; data_in = 4'hD; @(posedge clk); #1;
        addr_a = 5'd6; data_in = 4'hC; @(posedge clk); #1;
        we = 1'b0;
        addr_b = 5'd4; @(posedge clk); #1;
        addr_b = 5'd5; @(posedge clk); #1;
        addr_b = 5'd6; @(posedge clk); #1;

        // ===================================================================
        // Test 32: Interleaved same-address write/read (addr_a == addr_b)
        // ===================================================================
        $display("\n[Test 32] Interleaved same-address write/read");
        we = 1'b1; addr_a = 5'd16; addr_b = 5'd16; data_in = 4'h9;
        @(posedge clk); #1;
        we = 1'b0;
        @(posedge clk); #1;

        // ===================================================================
        // Test 33: Walking 0s data pattern
        // ===================================================================
        $display("\n[Test 33] Walking 0s data pattern");
        for (i = 0; i < DATA_WIDTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = ~DATA_WIDTH'(1 << i);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 34: Burst write then burst read (addresses 8 – 15)
        // ===================================================================
        $display("\n[Test 34] Burst write then burst read (addr 8-15)");
        we = 1'b1;
        for (i = 8; i < 16; i = i + 1) begin
            addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i * 3);
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 8; i < 16; i = i + 1) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 35: Write upper half of address space; read lower half
        // ===================================================================
        $display("\n[Test 35] Write upper half, read lower half");
        we = 1'b1;
        for (i = MEM_DEPTH / 2; i < MEM_DEPTH; i = i + 1) begin
            addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
        end
        we = 1'b0;
        for (i = 0; i < MEM_DEPTH / 2; i = i + 1) begin
            addr_b = ADDR_WIDTH'(i); @(posedge clk); #1;
        end

        // ===================================================================
        // Test 36: Random multi-pattern stress
        // ===================================================================
        $display("\n[Test 36] Random multi-pattern stress");
        we = 1'b1;
        addr_a = 5'd19; data_in = 4'hA; @(posedge clk); #1;
        addr_a = 5'd23; data_in = 4'h5; @(posedge clk); #1;
        addr_a = 5'd28; data_in = 4'hF; @(posedge clk); #1;
        addr_a = 5'd0;  data_in = 4'h0; @(posedge clk); #1;
        we = 1'b0;
        addr_b = 5'd19; @(posedge clk); #1;
        addr_b = 5'd23; @(posedge clk); #1;
        addr_b = 5'd28; @(posedge clk); #1;
        addr_b = 5'd0;  @(posedge clk); #1;

        // ===================================================================
        // Test 37: Write-read cycles pass 1 — data equals address
        // ===================================================================
        $display("\n[Test 37] Write-read cycles pass 1 (data = addr)");
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 38: Write-read cycles pass 2 — data equals address + 1
        // ===================================================================
        $display("\n[Test 38] Write-read cycles pass 2 (data = addr + 1)");
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i + 1);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 39: Write-read cycles pass 3 — data equals address + 2
        // ===================================================================
        $display("\n[Test 39] Write-read cycles pass 3 (data = addr + 2)");
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i + 2);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 40: Write-read cycles pass 4 — data equals address × 2
        // ===================================================================
        $display("\n[Test 40] Write-read cycles pass 4 (data = addr * 2)");
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i * 2);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 41: Write-read cycles — XOR pattern (data = addr ^ 0xA)
        // ===================================================================
        $display("\n[Test 41] Write-read cycles - XOR pattern (data = addr ^ 0xA)");
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i ^ 4'hA);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 42: Write-read cycles — AND pattern (data = addr & 0xC)
        // ===================================================================
        $display("\n[Test 42] Write-read cycles - AND pattern (data = addr & 0xC)");
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i & 4'hC);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 43: Write-read cycles — OR pattern (data = addr | 0x3)
        // ===================================================================
        $display("\n[Test 43] Write-read cycles - OR pattern (data = addr | 0x3)");
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = DATA_WIDTH'(i | 4'h3);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 44: Write-read cycles — NOT pattern (data = ~addr)
        // ===================================================================
        $display("\n[Test 44] Write-read cycles - NOT pattern (data = ~addr)");
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = ~DATA_WIDTH'(i);
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        // ===================================================================
        // Test 45: Full stress — toggle 0xF then 0x0 at every address
        // ===================================================================
        $display("\n[Test 45] Full stress - toggle 0xF/0x0 at every address");
        for (i = 0; i < MEM_DEPTH; i = i + 1) begin
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = 4'hF;
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
            we = 1'b1; addr_a = ADDR_WIDTH'(i); data_in = 4'h0;
            @(posedge clk); #1;
            we = 1'b0; addr_b = ADDR_WIDTH'(i);
            @(posedge clk); #1;
        end

        $display("\n[All Tests Complete]");
        #20;
        $finish;
    end

endmodule
