module tb_custom_byte_enable_ram;

  parameter XLEN  = 32;
  parameter LINES = 8192;
  localparam ADDR_WIDTH = $clog2(LINES);

  logic                     clk;
  logic [ADDR_WIDTH-1:0]    addr_a, addr_b;
  logic                     en_a, en_b;
  logic [XLEN/8-1:0]        be_a, be_b;
  logic [XLEN-1:0]          data_in_a, data_in_b;
  logic [XLEN-1:0]          data_out_a, data_out_b;

  custom_byte_enable_ram #(
    .XLEN(XLEN),
    .LINES(LINES)
  ) uut (
    .clk(clk),
    .addr_a(addr_a),
    .en_a(en_a),
    .be_a(be_a),
    .data_in_a(data_in_a),
    .data_out_a(data_out_a),
    .addr_b(addr_b),
    .en_b(en_b),
    .be_b(be_b),
    .data_in_b(data_in_b),
    .data_out_b(data_out_b)
  );

  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  // Generic checker: compares actual vs expected and reports pass/fail
  task automatic check_output;
    input string     test_label;
    input [XLEN-1:0] actual;
    input [XLEN-1:0] expected;
    if (actual !== expected)
      $display("FAIL %s at time %0t: actual = 32'h%08h, expected = 32'h%08h",
               test_label, $time, actual, expected);
    else
      $display("PASS %s: output = 32'h%08h matches expected = 32'h%08h",
               test_label, actual, expected);
  endtask

  // Test 1: Port A full write 32'hDEADBEEF to addr 0; read back on Port A
  task check_test1;
    check_output("Test 1 (Port A read addr 0)", data_out_a, 32'hDEADBEEF);
  endtask

  // Test 2: Port B partial write (be=1100) 32'hCAFEBABE to addr 1;
  //         bytes 3,2 written → 32'hCAFE0000
  task check_test2;
    check_output("Test 2 (Port B partial write addr 1)", data_out_b, 32'hCAFE0000);
  endtask

  // Test 3: Simultaneous writes at addr 2 — Port A be=0011 writes bytes 1,0 (32'h1234),
  //         Port B be=1100 writes bytes 3,2 (32'hABCD); no overlap → 32'hABCD1234
  task check_test3;
    check_output("Test 3 (Port A read addr 2)", data_out_a, 32'hABCD1234);
    check_output("Test 3 (Port B read addr 2)", data_out_b, 32'hABCD1234);
  endtask

  // Test 4: Sequential Port A writes at addr 3 — be=0011 then be=1100 → 32'hABCD1234
  task check_test4;
    check_output("Test 4 (sequential write Port A addr 3)", data_out_a, 32'hABCD1234);
  endtask

  // Test 5: Port A full write 32'hAAAAAAAA at addr 5; Port B full write 32'h55555555 at addr 6
  task check_test5;
    check_output("Test 5 (Port A addr 5)", data_out_a, 32'hAAAAAAAA);
    check_output("Test 5 (Port B addr 6)", data_out_b, 32'h55555555);
  endtask

  // Test 6: Dual full write collision at addr 4; Port A priority → 32'h11111111
  task check_test6;
    check_output("Test 6 (dual port full write addr 4)", data_out_a, 32'h11111111);
  endtask

  // Test 7: Overlapping partial writes at addr 7 — Port A be=0101 (bytes 2,0 = AA),
  //         Port B be=1010 (bytes 3,1 = BB); no overlap → 32'hBBAABBAA
  task check_test7;
    check_output("Test 7 (overlapping partial writes addr 7)", data_out_a, 32'hBBAABBAA);
  endtask

  // Test 8: Port A be=0 (no write), Port B full write 32'h33333333 at addr 9 → 32'h33333333
  task check_test8;
    check_output("Test 8 (Port A be=0 addr 9)", data_out_a, 32'h33333333);
  endtask

  // Test 9: Port A full write AAAA at addr 10, then Port B be=0011 writes bytes 1,0 (5555)
  //         → 32'hAAAA5555
  task check_test9;
    check_output("Test 9 (sequential writes addr 10)", data_out_a, 32'hAAAA5555);
  endtask

  // Test 10: Port A full write 32'h12345678 at addr 11; subsequent writes with be=0000
  //          → no update; output remains 32'h12345678
  task check_test10;
    check_output("Test 10 (no-update addr 11)", data_out_a, 32'h12345678);
  endtask

  // Test 11: Only Port B enabled at addr 25; Port B full write 32'hFACECAFE
  //          → both outputs at addr 25 = 32'hFACECAFE
  task check_test11;
    check_output("Test 11 (Port B only addr 25, data_out_a)", data_out_a, 32'hFACECAFE);
    check_output("Test 11 (Port B only addr 25, data_out_b)", data_out_b, 32'hFACECAFE);
  endtask

  // Test 12: Both ports disabled; one pipeline stage still in flight from addr 25
  //          → outputs remain 32'hFACECAFE
  task check_test12;
    check_output("Test 12 (both disabled, data_out_a)", data_out_a, 32'hFACECAFE);
    check_output("Test 12 (both disabled, data_out_b)", data_out_b, 32'hFACECAFE);
  endtask

  // Test 13: Port A be=0010 (byte 1 = CC from 32'hAABBCCDD) at addr 12 → 32'h0000CC00;
  //          Port B be=0100 (byte 2 = 33 from 32'h11334455) at addr 13 → 32'h00330000
  task check_test13;
    check_output("Test 13 (partial write Port A addr 12)", data_out_a, 32'h0000CC00);
    check_output("Test 13 (partial write Port B addr 13)", data_out_b, 32'h00330000);
  endtask

  initial begin
    addr_a   = 0;
    addr_b   = 0;
    en_a     = 0;
    en_b     = 0;
    be_a     = 4'b0000;
    be_b     = 4'b0000;
    data_in_a = 32'h0;
    data_in_b = 32'h0;

    #10;
    addr_a    = 0;
    en_a      = 1;
    be_a      = 4'b1111;
    data_in_a = 32'hDEADBEEF;
    #10;
    en_a      = 0;
    #30;

    $display("Test 1: Port A read at addr 0 = %h", data_out_a);
    check_test1;

    addr_b    = 1;
    en_b      = 1;
    be_b      = 4'b1100;
    data_in_b = 32'hCAFEBABE;
    #10;
    en_b      = 0;
    #30;
    $display("Test 2: Port B read at addr 1 = %h", data_out_b);
    check_test2;

    addr_a    = 2;
    addr_b    = 2;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0011;
    data_in_a = 32'h00001234;
    be_b      = 4'b1100;
    data_in_b = 32'hABCD0000;
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 3: Port A read at addr 2 = %h ", data_out_a);
    $display("Test 3: Port B read at addr 2 = %h ", data_out_b);
    check_test3;

    addr_a    = 3;
    en_a      = 1;
    be_a      = 4'b0011;
    data_in_a = 32'h00001234;
    #10;
    en_a      = 0;
    #30;
    addr_a    = 3;
    en_a      = 1;
    be_a      = 4'b1100;
    data_in_a = 32'hABCD0000;
    #10;
    en_a      = 0;
    #30;
    $display("Test 4: Port A read at addr 3 = %h ", data_out_a);
    check_test4;

    addr_a   = 5;
    en_a     = 1;
    be_a     = 4'b1111;
    data_in_a = 32'hAAAAAAAA;
    addr_b   = 6;
    en_b     = 1;
    be_b     = 4'b1111;
    data_in_b = 32'h55555555;
    #10;
    en_a     = 0;
    en_b     = 0;
    #30;
    $display("Test 5: Port A read at addr 5 = %h ", data_out_a);
    $display("Test 5: Port B read at addr 6 = %h ", data_out_b);
    check_test5;

    addr_a    = 4;
    addr_b    = 4;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b1111;
    be_b      = 4'b1111;
    data_in_a = 32'h11111111;
    data_in_b = 32'h22222222;
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 6: Dual port full write at addr 4 = %h ", data_out_a);
    check_test6;

    addr_a    = 7;
    addr_b    = 7;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0101;
    be_b      = 4'b1010;
    data_in_a = 32'hAAAAAAAA;
    data_in_b = 32'hBBBBBBBB;
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 7: Dual port overlapping partial write at addr 7 = %h ", data_out_a);
    check_test7;

    addr_a    = 9;
    addr_b    = 9;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0000;
    be_b      = 4'b1111;
    data_in_a = 32'hXXXXXXXX;
    data_in_b = 32'h33333333;
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 8: Dual port same addr 9 with A be=0 read = %h ", data_out_a);
    check_test8;

    addr_a    = 10;
    en_a      = 1;
    be_a      = 4'b1111;
    data_in_a = 32'hAAAAAAAA;
    #10;
    en_a      = 0;
    #30;
    addr_b    = 10;
    en_b      = 1;
    be_b      = 4'b0011;
    data_in_b = 32'h00005555;
    #10;
    en_b      = 0;
    #30;
    $display("Test 9: Sequential writes at addr 10 read = %h ", data_out_a);
    check_test9;

    addr_a    = 11;
    en_a      = 1;
    be_a      = 4'b1111;
    data_in_a = 32'h12345678;
    #10;
    en_a      = 0;
    #30;
    addr_a    = 11;
    addr_b    = 11;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0000;
    be_b      = 4'b0000;
    data_in_a = 32'hAAAAAAAA;
    data_in_b = 32'hBBBBBBBB;
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 10: No-update at addr 11 read = %h ", data_out_a);
    check_test10;

    addr_a    = 25;
    addr_b    = 25;
    en_a      = 0;
    en_b      = 1;
    be_b      = 4'b1111;
    data_in_b = 32'hFACECAFE;
    #10;
    en_b      = 0;
    #30;
    $display("Test 11: Only Port B enabled at addr 25, data_out_a = %h, data_out_b = %h ", data_out_a, data_out_b);
    check_test11;

    addr_a    = 100;
    addr_b    = 101;
    en_a      = 0;
    en_b      = 0;
    #10;
    $display("Test 12: Both ports disabled, data_out_a = %h, data_out_b = %h ", data_out_a, data_out_b);
    check_test12;

    addr_a    = 12;
    addr_b    = 13;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0010;
    data_in_a = 32'hAABBCCDD;
    be_b      = 4'b0100;
    data_in_b = 32'h11334455;
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 13: Partial else branch, data_out_a (addr 12) = %h ", data_out_a);
    $display("Test 13: Partial else branch, data_out_b (addr 13) = %h ", data_out_b);
    check_test13;

    #50;
    $finish;
  end
endmodule
