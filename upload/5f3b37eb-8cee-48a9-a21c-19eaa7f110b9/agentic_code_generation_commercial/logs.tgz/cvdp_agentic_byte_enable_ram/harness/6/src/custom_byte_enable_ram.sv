module custom_byte_enable_ram 
  #(
    parameter XLEN  = 32,
    parameter LINES = 8192
  )
  (
    input  logic                     clk,
    input  logic[$clog2(LINES)-1:0]  addr_a,
    input  logic                     en_a,
    input  logic[XLEN/8-1:0]         be_a,
    input  logic[XLEN-1:0]           data_in_a,
    output logic[XLEN-1:0]           data_out_a,
    input  logic[$clog2(LINES)-1:0]  addr_b,
    input  logic                     en_b,
    input  logic[XLEN/8-1:0]         be_b,
    input  logic[XLEN-1:0]           data_in_b,
    output logic[XLEN-1:0]           data_out_b
  );
  
  `ifdef BUG_0
    initial begin
      $display("BUG_0 is ACTIVE");
    end
  `else
    initial begin
      $display("BUG_0 is NOT ACTIVE");
    end
  `endif

  `ifdef BUG_1
    initial begin
      $display("BUG_1 is ACTIVE");
    end
  `else
    initial begin
      $display("BUG_1 is NOT ACTIVE");
    end
  `endif

  `ifdef BUG_2
    initial begin
      $display("BUG_2 is ACTIVE");
    end
  `else
    initial begin
      $display("BUG_2 is NOT ACTIVE");
    end
  `endif

  `ifdef BUG_3
    initial begin
      $display("BUG_3 is ACTIVE");
    end
  `else
    initial begin
      $display("BUG_3 is NOT ACTIVE");
    end
  `endif

  `ifdef BUG_4
    initial begin
      $display("BUG_4 is ACTIVE");
    end
  `else
    initial begin
      $display("BUG_4 is NOT ACTIVE");
    end
  `endif

  `ifdef BUG_5
    initial begin
      $display("BUG_5 is ACTIVE");
    end
  `else
    initial begin
      $display("BUG_5 is NOT ACTIVE");
    end
  `endif

  `ifdef BUG_6
    initial begin
      $display("BUG_6 is ACTIVE");
    end
  `else
    initial begin
      $display("BUG_6 is NOT ACTIVE");
    end
  `endif

  `ifdef BUG_7
    initial begin
      $display("BUG_7 is ACTIVE");
    end
  `else
    initial begin
      $display("BUG_7 is NOT ACTIVE");
    end
  `endif

  `ifdef BUG_8
    initial begin
      $display("BUG_8 is ACTIVE");
    end
  `else
    initial begin
      $display("BUG_8 is NOT ACTIVE");
    end
  `endif

  localparam ADDR_WIDTH = $clog2(LINES);

  logic [XLEN-1:0] ram [LINES-1:0];

  logic [ADDR_WIDTH-1:0] addr_a_reg;
  logic                  en_a_reg;
  logic [XLEN/8-1:0]     be_a_reg;
  logic [XLEN-1:0]       data_in_a_reg;

  logic [ADDR_WIDTH-1:0] addr_b_reg;
  logic                  en_b_reg;
  logic [XLEN/8-1:0]     be_b_reg;
  logic [XLEN-1:0]       data_in_b_reg;
  
  initial begin
    `ifndef BUG_0
      for (int i = 0; i < LINES; i++) begin
        ram[i] <= '0;
      end
    `else
      for (int i = 0; i < LINES; i++) begin
        ram[i] <= i+1;
      end
    `endif
  end

  always_ff @(posedge clk) begin
    `ifndef BUG_1
      addr_a_reg    <= addr_a;
      en_a_reg      <= en_a;
      be_a_reg      <= be_a;
      data_in_a_reg <= data_in_a;
    `else
      addr_a_reg    <= addr_b;
      en_a_reg      <= en_b;
      be_a_reg      <= be_b;
      data_in_a_reg <= data_in_b;
    `endif

    `ifndef BUG_2
      addr_b_reg    <= addr_b;
      en_b_reg      <= en_b;
      be_b_reg      <= be_b;
      data_in_b_reg <= data_in_b;
    `else
      addr_b_reg    <= addr_a;
      en_b_reg      <= en_a;
      be_b_reg      <= be_a;
      data_in_b_reg <= data_in_a;
    `endif
  end

  always_ff @(posedge clk) begin
    if (en_a_reg && en_b_reg && (addr_a_reg == addr_b_reg)) begin
      `ifndef BUG_3
        if (be_a_reg[0])
          ram[addr_a_reg][7:0] <= data_in_a_reg[7:0];
        else if (be_b_reg[0])
          ram[addr_a_reg][7:0] <= data_in_b_reg[7:0];
      `else
        if (be_a_reg[0])
          ram[addr_a_reg][7:0] <= data_in_a_reg[7:3];
        else if (be_b_reg[0])
          ram[addr_a_reg][7:0] <= data_in_b_reg[7:3];
      `endif

      `ifndef BUG_4
        if (be_a_reg[1])
          ram[addr_a_reg][15:8] <= data_in_a_reg[15:8];
        else if (be_b_reg[1])
          ram[addr_a_reg][15:8] <= data_in_b_reg[15:8];
      `else
        if (be_a_reg[1])
          ram[addr_a_reg][15:8] <= data_in_a_reg[15:12];
        else if (be_b_reg[1])
          ram[addr_a_reg][15:8] <= data_in_b_reg[15:12];
      `endif
     
      `ifndef BUG_5
        if (be_a_reg[2])
          ram[addr_a_reg][23:16] <= data_in_a_reg[23:16];
        else if (be_b_reg[2])
          ram[addr_a_reg][23:16] <= data_in_b_reg[23:16];
      `else
        if (be_a_reg[2])
          ram[addr_a_reg][23:16] <= data_in_a_reg[23:20];
        else if (be_b_reg[2])
          ram[addr_a_reg][23:16] <= data_in_b_reg[23:20];
      `endif

      `ifndef BUG_6 
        if (be_a_reg[3])
          ram[addr_a_reg][31:24] <= data_in_a_reg[31:24];
        else if (be_b_reg[3])
          ram[addr_a_reg][31:24] <= data_in_b_reg[31:24];
      `else
        if (be_a_reg[3])
          ram[addr_a_reg][31:24] <= data_in_a_reg[31:29];
        else if (be_b_reg[3])
          ram[addr_a_reg][31:24] <= data_in_b_reg[31:29];
      `endif
    end else begin
      `ifndef BUG_7
        if (en_a_reg) begin
          if (be_a_reg[0])
            ram[addr_a_reg][7:0] <= data_in_a_reg[7:0];
          if (be_a_reg[1])
            ram[addr_a_reg][15:8] <= data_in_a_reg[15:8];
          if (be_a_reg[2])
            ram[addr_a_reg][23:16] <= data_in_a_reg[23:16];
          if (be_a_reg[3])
            ram[addr_a_reg][31:24] <= data_in_a_reg[31:24];
        end
      `else
        if (en_a_reg) begin
          if (be_a_reg[0])
            ram[addr_a_reg][7:0] <= data_in_a_reg[7:5];
          if (be_a_reg[1])
            ram[addr_a_reg][15:8] <= data_in_a_reg[15:11];
          if (be_a_reg[2])
            ram[addr_a_reg][23:16] <= data_in_a_reg[23:20];
          if (be_a_reg[3])
            ram[addr_a_reg][31:24] <= data_in_a_reg[31:29];
        end
      `endif

      `ifndef BUG_8
        if (en_b_reg) begin
          if (be_b_reg[0])
            ram[addr_b_reg][7:0] <= data_in_b_reg[7:0];
          if (be_b_reg[1])
            ram[addr_b_reg][15:8] <= data_in_b_reg[15:8];
          if (be_b_reg[2])
            ram[addr_b_reg][23:16] <= data_in_b_reg[23:16];
          if (be_b_reg[3])
            ram[addr_b_reg][31:24] <= data_in_b_reg[31:24];
        end
      `else
        if (en_b_reg) begin
          if (be_b_reg[0])
            ram[addr_b_reg][7:0] <= data_in_b_reg[7:5];
          if (be_b_reg[1])
            ram[addr_b_reg][15:8] <= data_in_b_reg[15:12];
          if (be_b_reg[2])
            ram[addr_b_reg][23:16] <= data_in_b_reg[23:20];
          if (be_b_reg[3])
            ram[addr_b_reg][31:24] <= data_in_b_reg[31:28];
        end
      `endif      
    end

    data_out_a <= ram[addr_a_reg];
    data_out_b <= ram[addr_b_reg];
  end

endmodule

