import os
import re
import subprocess
import pytest

# ----------------------------------------
# - Simulate
# ----------------------------------------

sim = f"xrun /src/*.sv /code/verif/*.sv -seed random"

def check_log(filename = "sim.log", expected = 0):

    # ----------------------------------------
    # - Check for errors in the log
    # ----------------------------------------

    with open(filename) as f:
        lines = f.readlines()

    errors = []
    for line in lines[3:]:
        errors.append(re.findall(r'*E', line))

    # ----------------------------------------
    # - Evaluate Report
    # ----------------------------------------

    assert len(errors) == expected, "Simulation ended with error."

@pytest.mark.usefixtures(scope='session')
def test_sanity():

    res = subprocess.run(f"{sim} -l /code/rundir/sanity.log", shell=True)
    assert(res.returncode == 0), "Simulation ended with error."

# ----------------------------------------
# - Generate Bug Simulations
# ----------------------------------------

@pytest.mark.usefixtures(scope='test_sanity')
def test_errors():

    num_bugs = int(os.getenv("NUM_BUGS"))

    for i in range(num_bugs):
        bug = f"-define BUG_{i}=1"
        cmd = f"{sim} {bug}"

        res = subprocess.run(f"{cmd} -l /code/rundir/bug_{i}.log", shell=True)
        assert(res.returncode != 0), "Simulation ended without error."

# ----------------------------------------
# - Simulate
# ----------------------------------------

@pytest.mark.usefixtures(scope='session')
def test_simulate():

    cmd = "xrun -coverage all /src/*.sv /code/verif/*.sv -covtest test -seed random -covoverwrite"
    assert(subprocess.run(cmd, shell=True)), "Simulation didn't ran correctly."

# ----------------------------------------
# - Generate Coverage
# ----------------------------------------

@pytest.mark.usefixtures(scope='test_simulate')
def test_coverage():

    cmd = "imc -load /code/rundir/cov_work/scope/test -exec /src/coverage.cmd"
    assert(subprocess.run(cmd, shell=True)), "Coverage merge didn't ran correctly."

# ----------------------------------------
# - Report
# ----------------------------------------

@pytest.mark.usefixtures(scope='test_coverage')
def test_report():

    metrics = {}

    with open("/code/rundir/coverage.log") as f:
        lines = f.readlines()

    # ----------------------------------------
    # - Evaluate Report
    # ----------------------------------------

    for line in lines[2:]:
        info = line.split()

        inst = info [0]
        avg  = info [1]
        cov  = info [2]

        inst = re.sub(r'[\W]', '', inst)

        metrics [inst] = {
            "Average" : float(avg[:-1]),
            "Covered" : float(cov[:-1])
        }
        

    assert metrics ["uut"]["Average"] >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
