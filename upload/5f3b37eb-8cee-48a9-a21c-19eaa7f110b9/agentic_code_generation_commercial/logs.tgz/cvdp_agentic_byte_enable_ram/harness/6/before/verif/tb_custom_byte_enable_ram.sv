module tb_custom_byte_enable_ram;
  
  parameter XLEN  = 32;
  parameter LINES = 8192;
  localparam ADDR_WIDTH = $clog2(LINES);

  logic                     clk;
  logic [ADDR_WIDTH-1:0]    addr_a, addr_b;
  logic                     en_a, en_b;
  logic [XLEN/8-1:0]        be_a, be_b;
  logic [XLEN-1:0]          data_in_a, data_in_b;
  logic [XLEN-1:0]          data_out_a, data_out_b;

  custom_byte_enable_ram #(
    .XLEN(XLEN),
    .LINES(LINES)
  ) uut (
    .clk(clk),
    .addr_a(addr_a),
    .en_a(en_a),
    .be_a(be_a),
    .data_in_a(data_in_a),
    .data_out_a(data_out_a),
    .addr_b(addr_b),
    .en_b(en_b),
    .be_b(be_b),
    .data_in_b(data_in_b),
    .data_out_b(data_out_b)
  );

  initial begin
    clk = 0;
    forever #5 clk = ~clk;
  end

  initial begin
    addr_a   = 0;
    addr_b   = 0;
    en_a     = 0;
    en_b     = 0;
    be_a     = 4'b0000;
    be_b     = 4'b0000;
    data_in_a = 32'h0;
    data_in_b = 32'h0;
    
    #10;
    addr_a    = 0;
    en_a      = 1;
    be_a      = 4'b1111;
    data_in_a = 32'hDEADBEEF;
    #10;  
    en_a      = 0;
    #30;  
    
    $display("Test 1: Port A read at addr 0 = %h", data_out_a);
    
    addr_b    = 1;
    en_b      = 1;
    be_b      = 4'b1100;  
    data_in_b = 32'hCAFEBABE;
    #10;
    en_b      = 0;
    #30;
    $display("Test 2: Port B read at addr 1 = %h", data_out_b); 
    
    addr_a    = 2;
    addr_b    = 2;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0011;  
    data_in_a = 32'h00001234;  
    be_b      = 4'b1100;  
    data_in_b = 32'hABCD0000;  
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 3: Port A read at addr 2 = %h ", data_out_a);
    $display("Test 3: Port B read at addr 2 = %h ", data_out_b);
    
    addr_a    = 3;
    en_a      = 1;
    be_a      = 4'b0011;  
    data_in_a = 32'h00001234; 
    #10;
    en_a      = 0;
    #30;
    addr_a    = 3;
    en_a      = 1;
    be_a      = 4'b1100;  
    data_in_a = 32'hABCD0000; 
    #10;
    en_a      = 0;
    #30;
    $display("Test 4: Port A read at addr 3 = %h ", data_out_a);
    
    addr_a   = 5;
    en_a     = 1;
    be_a     = 4'b1111;
    data_in_a = 32'hAAAAAAAA;
    addr_b   = 6;
    en_b     = 1;
    be_b     = 4'b1111;
    data_in_b = 32'h55555555;
    #10;
    en_a     = 0;
    en_b     = 0;
    #30;
    $display("Test 5: Port A read at addr 5 = %h ", data_out_a);
    $display("Test 5: Port B read at addr 6 = %h ", data_out_b);
        
    addr_a    = 4;
    addr_b    = 4;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b1111;
    be_b      = 4'b1111;
    data_in_a = 32'h11111111;
    data_in_b = 32'h22222222;
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 6: Dual port full write at addr 4 = %h ", data_out_a);
    
    addr_a    = 7;
    addr_b    = 7;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0101;
    be_b      = 4'b1010;
    data_in_a = 32'hAAAAAAAA;
    data_in_b = 32'hBBBBBBBB;
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 7: Dual port overlapping partial write at addr 7 = %h ", data_out_a);
    
    addr_a    = 9;
    addr_b    = 9;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0000;       
    be_b      = 4'b1111;       
    data_in_a = 32'hXXXXXXXX;  
    data_in_b = 32'h33333333;
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 8: Dual port same addr 9 with A be=0 read = %h ", data_out_a);
    
    addr_a    = 10;
    en_a      = 1;
    be_a      = 4'b1111;
    data_in_a = 32'hAAAAAAAA;
    #10;
    en_a      = 0;
    #30;
    addr_b    = 10;
    en_b      = 1;
    be_b      = 4'b0011;
    data_in_b = 32'h00005555;
    #10;
    en_b      = 0;
    #30;
    $display("Test 9: Sequential writes at addr 10 read = %h ", data_out_a);
    
    addr_a    = 11;
    en_a      = 1;
    be_a      = 4'b1111;
    data_in_a = 32'h12345678;
    #10;
    en_a      = 0;
    #30;
    addr_a    = 11;
    addr_b    = 11;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0000;
    be_b      = 4'b0000;
    data_in_a = 32'hAAAAAAAA;  
    data_in_b = 32'hBBBBBBBB;  
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 10: No-update at addr 11 read = %h ", data_out_a);
    
    addr_a    = 25;
    addr_b    = 25;
    en_a      = 0;
    en_b      = 1;
    be_b      = 4'b1111;
    data_in_b = 32'hFACECAFE;
    #10;
    en_b      = 0;
    #30;
    $display("Test 11: Only Port B enabled at addr 25, data_out_a = %h, data_out_b = %h ", data_out_a, data_out_b);
    
    addr_a    = 100;
    addr_b    = 101;
    en_a      = 0;
    en_b      = 0;
    #10;
    $display("Test 12: Both ports disabled, data_out_a = %h, data_out_b = %h ", data_out_a, data_out_b);
    
    addr_a    = 12;
    addr_b    = 13;
    en_a      = 1;
    en_b      = 1;
    be_a      = 4'b0010;      
    data_in_a = 32'hAABBCCDD;  
    be_b      = 4'b0100;      
    data_in_b = 32'h11334455;  
    #10;
    en_a      = 0;
    en_b      = 0;
    #30;
    $display("Test 13: Partial else branch, data_out_a (addr 12) = %h ", data_out_a);
    $display("Test 13: Partial else branch, data_out_b (addr 13) = %h ", data_out_b);
    
    #50;
    $finish;
  end
endmodule