module custom_byte_enable_ram 
  #(
    parameter XLEN  = 32,
    parameter LINES = 8192
  )
  (
    input  logic                     clk,
    input  logic[$clog2(LINES)-1:0]  addr_a,
    input  logic                     en_a,
    input  logic[XLEN/8-1:0]         be_a,
    input  logic[XLEN-1:0]           data_in_a,
    output logic[XLEN-1:0]           data_out_a,
    input  logic[$clog2(LINES)-1:0]  addr_b,
    input  logic                     en_b,
    input  logic[XLEN/8-1:0]         be_b,
    input  logic[XLEN-1:0]           data_in_b,
    output logic[XLEN-1:0]           data_out_b
  );

  localparam ADDR_WIDTH = $clog2(LINES);

  logic [XLEN-1:0] ram [LINES-1:0];

  logic [ADDR_WIDTH-1:0] addr_a_reg;
  logic                  en_a_reg;
  logic [XLEN/8-1:0]     be_a_reg;
  logic [XLEN-1:0]       data_in_a_reg;

  logic [ADDR_WIDTH-1:0] addr_b_reg;
  logic                  en_b_reg;
  logic [XLEN/8-1:0]     be_b_reg;
  logic [XLEN-1:0]       data_in_b_reg;
  
  initial begin
    for (int i = 0; i < LINES; i++) begin
      ram[i] <= '0;
    end
  end

  always_ff @(posedge clk) begin
    addr_a_reg    <= addr_a;
    en_a_reg      <= en_a;
    be_a_reg      <= be_a;
    data_in_a_reg <= data_in_a;

    addr_b_reg    <= addr_b;
    en_b_reg      <= en_b;
    be_b_reg      <= be_b;
    data_in_b_reg <= data_in_b;
  end

  always_ff @(posedge clk) begin
    if (en_a_reg && en_b_reg && (addr_a_reg == addr_b_reg)) begin
      if (be_a_reg[0])
        ram[addr_a_reg][7:0] <= data_in_a_reg[7:0];
      else if (be_b_reg[0])
        ram[addr_a_reg][7:0] <= data_in_b_reg[7:0];

      if (be_a_reg[1])
        ram[addr_a_reg][15:8] <= data_in_a_reg[15:8];
      else if (be_b_reg[1])
        ram[addr_a_reg][15:8] <= data_in_b_reg[15:8];

      if (be_a_reg[2])
        ram[addr_a_reg][23:16] <= data_in_a_reg[23:16];
      else if (be_b_reg[2])
        ram[addr_a_reg][23:16] <= data_in_b_reg[23:16];

      if (be_a_reg[3])
        ram[addr_a_reg][31:24] <= data_in_a_reg[31:24];
      else if (be_b_reg[3])
        ram[addr_a_reg][31:24] <= data_in_b_reg[31:24];
    end else begin
      if (en_a_reg) begin
        if (be_a_reg[0])
          ram[addr_a_reg][7:0] <= data_in_a_reg[7:0];
        if (be_a_reg[1])
          ram[addr_a_reg][15:8] <= data_in_a_reg[15:8];
        if (be_a_reg[2])
          ram[addr_a_reg][23:16] <= data_in_a_reg[23:16];
        if (be_a_reg[3])
          ram[addr_a_reg][31:24] <= data_in_a_reg[31:24];
      end

      if (en_b_reg) begin
        if (be_b_reg[0])
          ram[addr_b_reg][7:0] <= data_in_b_reg[7:0];
        if (be_b_reg[1])
          ram[addr_b_reg][15:8] <= data_in_b_reg[15:8];
        if (be_b_reg[2])
          ram[addr_b_reg][23:16] <= data_in_b_reg[23:16];
        if (be_b_reg[3])
          ram[addr_b_reg][31:24] <= data_in_b_reg[31:24];
      end
    end

    data_out_a <= ram[addr_a_reg];
    data_out_b <= ram[addr_b_reg];
  end

  // -------------------------------------------------------------------------
  // SystemVerilog Assertions
  // -------------------------------------------------------------------------

  // 1. No Write Stability on Port A:
  //    When port A was not enabled (en_a_reg==0 means en_a was deasserted one
  //    cycle ago), data_out_a must equal the value previously held in the RAM
  //    at addr_a_reg (no spurious write should have occurred).
  no_write_stability_A: assert property (
      @(posedge clk)
      !en_a_reg |-> (data_out_a == $past(ram[addr_a_reg])))
    else $error("Assertion no_write_stability_A FAILED: data_out_a changed despite en_a being deasserted");

  // 2. No Write Stability on Port B:
  //    Same check for port B.
  no_write_stability_B: assert property (
      @(posedge clk)
      !en_b_reg |-> (data_out_b == $past(ram[addr_b_reg])))
    else $error("Assertion no_write_stability_B FAILED: data_out_b changed despite en_b being deasserted");

  // 3. Same Address Read Consistency:
  //    If both ports targeted the same address in the previous pipeline stage
  //    (i.e. $past(addr_a_reg)==$past(addr_b_reg)) with neither port writing,
  //    then the two read outputs must be identical.
  same_addr_read: assert property (
      @(posedge clk)
      ($past(addr_a_reg) == $past(addr_b_reg) &&
       !$past(en_a_reg)                        &&
       !$past(en_b_reg))
      |-> (data_out_a == data_out_b))
    else $error("Assertion same_addr_read FAILED: data_out_a != data_out_b for same-address no-write read");

  // 4. Output Consistency on Port A (checked from cycle 30 onward):
  //    data_out_a must always reflect the value that was in the RAM at
  //    addr_a_reg one cycle ago (the registered read address).
  output_consistency_A: assert property (
      @(posedge clk)
      ##30 (data_out_a == $past(ram[addr_a_reg])))
    else $error("Assertion output_consistency_A FAILED: data_out_a does not match RAM contents at addr_a_reg");

  // 5. Output Consistency on Port B (checked from cycle 30 onward):
  output_consistency_B: assert property (
      @(posedge clk)
      ##30 (data_out_b == $past(ram[addr_b_reg])))
    else $error("Assertion output_consistency_B FAILED: data_out_b does not match RAM contents at addr_b_reg");

  // 6. Simultaneous Write Priority for Port A – Lower Byte:
  //    When both ports are enabled and target the same address and port A's
  //    byte-enable 0 is set, the RAM's lower byte at that address must equal
  //    data_in_a_reg[7:0] exactly 15 cycles later.
  simul_write_A_byte0_update: assert property (
      @(posedge clk)
      (en_a_reg && en_b_reg && (addr_a_reg == addr_b_reg) && be_a_reg[0])
      |-> ##15 (ram[$past(addr_a_reg, 15)][7:0] == ($past(data_in_a_reg, 15))[7:0]))
    else $error("Assertion simul_write_A_byte0_update FAILED: RAM byte0 not updated with data_in_a during simultaneous write");

  // 7. Simultaneous Write Priority for Port A – Second Byte:
  simul_write_A_byte1_update: assert property (
      @(posedge clk)
      (en_a_reg && en_b_reg && (addr_a_reg == addr_b_reg) && be_a_reg[1])
      |-> ##15 (ram[$past(addr_a_reg, 15)][15:8] == ($past(data_in_a_reg, 15))[15:8]))
    else $error("Assertion simul_write_A_byte1_update FAILED: RAM byte1 not updated with data_in_a during simultaneous write");

  // 8. Single-Port Write Behavior for Port A – Lower Byte:
  //    When only port A is writing (addresses differ, or port B is disabled),
  //    byte-enable 0 asserted → RAM lower byte updated 15 cycles later.
  single_write_A_byte0_update: assert property (
      @(posedge clk)
      (en_a_reg && (!en_b_reg || (addr_a_reg != addr_b_reg)) && be_a_reg[0])
      |-> ##15 (ram[$past(addr_a_reg, 15)][7:0] == ($past(data_in_a_reg, 15))[7:0]))
    else $error("Assertion single_write_A_byte0_update FAILED: RAM byte0 not updated correctly for port A single-port write");

  // 9. Single-Port Write Behavior for Port A – Second Byte:
  single_write_A_byte1_update: assert property (
      @(posedge clk)
      (en_a_reg && (!en_b_reg || (addr_a_reg != addr_b_reg)) && be_a_reg[1])
      |-> ##15 (ram[$past(addr_a_reg, 15)][15:8] == ($past(data_in_a_reg, 15))[15:8]))
    else $error("Assertion single_write_A_byte1_update FAILED: RAM byte1 not updated correctly for port A single-port write");

endmodule