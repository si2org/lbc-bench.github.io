`timescale 1ns/1ps

module tb_custom_byte_enable_ram;

    localparam integer XLEN       = 32;
    localparam integer LINES      = 8192;
    localparam integer ADDR_WIDTH = $clog2(LINES); // 13

    // DUT interface signals
    logic                  clk;
    logic [ADDR_WIDTH-1:0] addr_a;
    logic                  en_a;
    logic [XLEN/8-1:0]     be_a;
    logic [XLEN-1:0]       data_in_a;
    logic [XLEN-1:0]       data_out_a;
    logic [ADDR_WIDTH-1:0] addr_b;
    logic                  en_b;
    logic [XLEN/8-1:0]     be_b;
    logic [XLEN-1:0]       data_in_b;
    logic [XLEN-1:0]       data_out_b;

    // DUT instantiation
    custom_byte_enable_ram #(
        .XLEN  (XLEN),
        .LINES (LINES)
    ) uut (
        .clk       (clk),
        .addr_a    (addr_a),
        .en_a      (en_a),
        .be_a      (be_a),
        .data_in_a (data_in_a),
        .data_out_a(data_out_a),
        .addr_b    (addr_b),
        .en_b      (en_b),
        .be_b      (be_b),
        .data_in_b (data_in_b),
        .data_out_b(data_out_b)
    );

    // Clock: 10ns period (5ns half-period), starting low
    initial clk = 1'b0;
    always #5 clk = ~clk;

    initial begin
        // Initialize all inputs
        addr_a    = '0; en_a = 1'b0; be_a = 4'h0; data_in_a = 32'h0;
        addr_b    = '0; en_b = 1'b0; be_b = 4'h0; data_in_b = 32'h0;

        // Allow pipeline to initialize
        repeat (4) @(posedge clk);

        // ===========================================================
        // Test 1: Full write via port A at address 0, read-back
        //         be_a=4'hF writes all four bytes of data_in_a
        // ===========================================================
        $display("[%0t] Test 1 START: Full write via port A at addr=0 (data=0xDEADBEEF)", $time);
        @(posedge clk); #1;
        addr_a = 13'd0; en_a = 1'b1; be_a = 4'hF; data_in_a = 32'hDEADBEEF;
        addr_b = 13'd0; en_b = 1'b0; be_b = 4'h0; data_in_b = 32'h00000000;
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 1 READBACK: addr_a=0 data_out_a=0x%h | addr_b=0 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 2: Partial write via port B at address 1, read-back
        //         be_b=4'hC enables bytes 2 and 3 (upper half)
        //         data_in_b=0xAABBCCDD: byte3=AA, byte2=BB written; byte1=CC, byte0=DD not written
        // ===========================================================
        $display("[%0t] Test 2 START: Partial write via port B at addr=1 (be_b=4'hC, data=0xAABBCCDD)", $time);
        @(posedge clk); #1;
        addr_a = 13'd1; en_a = 1'b0; be_a = 4'h0; data_in_a = 32'h00000000;
        addr_b = 13'd1; en_b = 1'b1; be_b = 4'hC; data_in_b = 32'hAABBCCDD;
        @(posedge clk); #1;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 2 READBACK: addr_a=1 data_out_a=0x%h | addr_b=1 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 3: Dual-port simultaneous write at address 2
        //         Port A: be=4'h3 writes lower bytes (byte1=0x12, byte0=0x34)
        //         Port B: be=4'hC writes upper bytes (byte3=0x56, byte2=0x78)
        //         Collision arbitration: A owns bytes 0-1, B owns bytes 2-3
        //         Expected: 0x56781234
        // ===========================================================
        $display("[%0t] Test 3 START: Dual-port simultaneous write at addr=2 (A:lower, B:upper)", $time);
        @(posedge clk); #1;
        addr_a = 13'd2; en_a = 1'b1; be_a = 4'h3; data_in_a = 32'h00001234;
        addr_b = 13'd2; en_b = 1'b1; be_b = 4'hC; data_in_b = 32'h56780000;
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 3 READBACK: addr_a=2 data_out_a=0x%h | addr_b=2 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 4: Sequential partial writes on port A at address 3
        //         First write:  be_a=4'h5 (bytes 0,2) data_in_a=0x00AA00BB
        //                       writes byte0=0xBB, byte2=0xAA
        //         Second write: be_a=4'hA (bytes 1,3) data_in_a=0xCC00DD00
        //                       writes byte1=0xDD, byte3=0xCC
        //         Expected after both: 0xCCAADDBB
        // ===========================================================
        $display("[%0t] Test 4 START: Sequential partial writes via port A at addr=3", $time);
        @(posedge clk); #1;
        addr_a = 13'd3; en_a = 1'b1; be_a = 4'h5; data_in_a = 32'h00AA00BB;
        addr_b = 13'd3; en_b = 1'b0; be_b = 4'h0; data_in_b = 32'h00000000;
        $display("[%0t] Test 4: First partial write be_a=4'h5 data_in_a=0x%h", $time, data_in_a);
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        repeat (3) @(posedge clk); #1;
        addr_a = 13'd3; en_a = 1'b1; be_a = 4'hA; data_in_a = 32'hCC00DD00;
        $display("[%0t] Test 4: Second partial write be_a=4'hA data_in_a=0x%h", $time, data_in_a);
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 4 READBACK: addr_a=3 data_out_a=0x%h | addr_b=3 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 5: Independent full writes on port A (addr=5) and port B (addr=6)
        //         No address collision; both ports write to separate locations
        // ===========================================================
        $display("[%0t] Test 5 START: Independent full writes A@addr=5 (0x11223344) B@addr=6 (0x55667788)", $time);
        @(posedge clk); #1;
        addr_a = 13'd5; en_a = 1'b1; be_a = 4'hF; data_in_a = 32'h11223344;
        addr_b = 13'd6; en_b = 1'b1; be_b = 4'hF; data_in_b = 32'h55667788;
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        // Read addr=5 from both ports
        addr_a = 13'd5; addr_b = 13'd5;
        repeat (3) @(posedge clk); #1;
        $display("[%0t] Test 5 READBACK@addr=5: data_out_a=0x%h | data_out_b=0x%h",
                 $time, data_out_a, data_out_b);
        // Read addr=6 from both ports
        addr_a = 13'd6; addr_b = 13'd6;
        repeat (3) @(posedge clk); #1;
        $display("[%0t] Test 5 READBACK@addr=6: data_out_a=0x%h | data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 6: Dual-port full write at same address (addr=4), port A priority
        //         Collision with all bytes contested; port A wins every byte
        //         Port A writes 0xAAAAAAAA, port B writes 0xBBBBBBBB
        //         Expected: 0xAAAAAAAA
        // ===========================================================
        $display("[%0t] Test 6 START: Dual-port full write at addr=4 (A:0xAAAAAAAA B:0xBBBBBBBB, A priority)", $time);
        @(posedge clk); #1;
        addr_a = 13'd4; en_a = 1'b1; be_a = 4'hF; data_in_a = 32'hAAAAAAAA;
        addr_b = 13'd4; en_b = 1'b1; be_b = 4'hF; data_in_b = 32'hBBBBBBBB;
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 6 READBACK: addr_a=4 data_out_a=0x%h | addr_b=4 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 7: Dual-port overlapping partial write at address 7
        //         Port A: be=4'h5 (bytes 0,2) data_in_a=0x00AA00BB -> byte0=0xBB, byte2=0xAA
        //         Port B: be=4'hA (bytes 1,3) data_in_b=0xCC00DD00 -> byte1=0xDD, byte3=0xCC
        //         Interleaved enables, no contested bytes; collision resolves cleanly
        //         Expected: 0xCCAADDBB
        // ===========================================================
        $display("[%0t] Test 7 START: Dual-port overlapping partial write at addr=7 (interleaved BE)", $time);
        @(posedge clk); #1;
        addr_a = 13'd7; en_a = 1'b1; be_a = 4'h5; data_in_a = 32'h00AA00BB;
        addr_b = 13'd7; en_b = 1'b1; be_b = 4'hA; data_in_b = 32'hCC00DD00;
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 7 READBACK: addr_a=7 data_out_a=0x%h | addr_b=7 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 8: Dual-port write at addr=9
        //         Port A: en=1 but be_a=4'h0 (no bytes active)
        //         Port B: en=1, be_b=4'hF (full write, data=0x12345678)
        //         Collision detected; port A has no active BE so port B wins all bytes
        //         Expected: 0x12345678
        // ===========================================================
        $display("[%0t] Test 8 START: Dual-port write at addr=9 (A:be=0, B:full write 0x12345678)", $time);
        @(posedge clk); #1;
        addr_a = 13'd9; en_a = 1'b1; be_a = 4'h0; data_in_a = 32'hFFFFFFFF;
        addr_b = 13'd9; en_b = 1'b1; be_b = 4'hF; data_in_b = 32'h12345678;
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 8 READBACK: addr_a=9 data_out_a=0x%h | addr_b=9 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 9: Sequential writes at address 10
        //         First: full write via port A (data=0xABCDEF01)
        //         Then:  partial update via port B, be_b=4'h3 (bytes 0,1)
        //                data_in_b=0x000099AA -> byte0=0xAA, byte1=0x99
        //         Expected: byte3=0xAB, byte2=0xCD unchanged, byte1=0x99, byte0=0xAA -> 0xABCD99AA
        // ===========================================================
        $display("[%0t] Test 9 START: Sequential writes at addr=10", $time);
        @(posedge clk); #1;
        addr_a = 13'd10; en_a = 1'b1; be_a = 4'hF; data_in_a = 32'hABCDEF01;
        addr_b = 13'd10; en_b = 1'b0; be_b = 4'h0; data_in_b = 32'h00000000;
        $display("[%0t] Test 9: Full write via A data_in_a=0x%h", $time, data_in_a);
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        repeat (3) @(posedge clk); #1;
        addr_b = 13'd10; en_b = 1'b1; be_b = 4'h3; data_in_b = 32'h000099AA;
        $display("[%0t] Test 9: Partial update via B be_b=4'h3 data_in_b=0x%h", $time, data_in_b);
        @(posedge clk); #1;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 9 READBACK: addr_a=10 data_out_a=0x%h | addr_b=10 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 10: No-update scenario at address 11
        //          Initial full write via port A (data=0xDECAFBAD)
        //          Then cycle with both ports enabled but zero byte enables
        //          Expected: 0xDECAFBAD unchanged
        // ===========================================================
        $display("[%0t] Test 10 START: No-update scenario at addr=11", $time);
        @(posedge clk); #1;
        addr_a = 13'd11; en_a = 1'b1; be_a = 4'hF; data_in_a = 32'hDECAFBAD;
        addr_b = 13'd11; en_b = 1'b0; be_b = 4'h0; data_in_b = 32'h00000000;
        $display("[%0t] Test 10: Initial full write data_in_a=0x%h", $time, data_in_a);
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        repeat (3) @(posedge clk); #1;
        // Both ports enabled but zero byte enables — no bytes should change
        addr_a = 13'd11; en_a = 1'b1; be_a = 4'h0; data_in_a = 32'hFFFFFFFF;
        addr_b = 13'd11; en_b = 1'b1; be_b = 4'h0; data_in_b = 32'hEEEEEEEE;
        $display("[%0t] Test 10: Zero-BE cycle applied (en_a=1 be_a=0, en_b=1 be_b=0)", $time);
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 10 READBACK: addr_a=11 data_out_a=0x%h | addr_b=11 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 11: Write at address 25 with only port B enabled, read from both ports
        //          Port A disabled; port B: be_b=4'hF, data=0xFACEBEEF
        //          Both ports should read 0xFACEBEEF at addr=25
        // ===========================================================
        $display("[%0t] Test 11 START: Write at addr=25 via port B only (data=0xFACEBEEF)", $time);
        @(posedge clk); #1;
        addr_a = 13'd25; en_a = 1'b0; be_a = 4'h0; data_in_a = 32'h00000000;
        addr_b = 13'd25; en_b = 1'b1; be_b = 4'hF; data_in_b = 32'hFACEBEEF;
        @(posedge clk); #1;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 11 READBACK: addr_a=25 data_out_a=0x%h | addr_b=25 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 12: Read at addr=100 and addr=101 with both ports disabled
        //          Neither address was ever written; memory initialized to 0
        //          Expected: 0x00000000 from both ports
        // ===========================================================
        $display("[%0t] Test 12 START: Read at addr=100/101 with both ports disabled (expect 0)", $time);
        @(posedge clk); #1;
        addr_a = 13'd100; en_a = 1'b0; be_a = 4'h0; data_in_a = 32'h00000000;
        addr_b = 13'd101; en_b = 1'b0; be_b = 4'h0; data_in_b = 32'h00000000;
        repeat (4) @(posedge clk); #1;
        $display("[%0t] Test 12 READBACK: addr_a=100 data_out_a=0x%h | addr_b=101 data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        // ===========================================================
        // Test 13: Separate partial writes at distinct addresses
        //          Port A: addr=12, be_a=4'h3 (bytes 0,1), data_in_a=0x00005A5A
        //                  writes byte0=0x5A, byte1=0x5A; Expected at 12: 0x00005A5A
        //          Port B: addr=13, be_b=4'hC (bytes 2,3), data_in_b=0xA5A50000
        //                  writes byte2=0xA5, byte3=0xA5; Expected at 13: 0xA5A50000
        // ===========================================================
        $display("[%0t] Test 13 START: Separate partial writes A@addr=12 (be=4'h3) B@addr=13 (be=4'hC)", $time);
        @(posedge clk); #1;
        addr_a = 13'd12; en_a = 1'b1; be_a = 4'h3; data_in_a = 32'h00005A5A;
        addr_b = 13'd13; en_b = 1'b1; be_b = 4'hC; data_in_b = 32'hA5A50000;
        @(posedge clk); #1;
        en_a = 1'b0; be_a = 4'h0;
        en_b = 1'b0; be_b = 4'h0;
        repeat (4) @(posedge clk); #1;
        // Read addr=12 from both ports
        addr_a = 13'd12; addr_b = 13'd12;
        repeat (3) @(posedge clk); #1;
        $display("[%0t] Test 13 READBACK@addr=12: data_out_a=0x%h | data_out_b=0x%h",
                 $time, data_out_a, data_out_b);
        // Read addr=13 from both ports
        addr_a = 13'd13; addr_b = 13'd13;
        repeat (3) @(posedge clk); #1;
        $display("[%0t] Test 13 READBACK@addr=13: data_out_a=0x%h | data_out_b=0x%h",
                 $time, data_out_a, data_out_b);

        $display("[%0t] All 13 tests complete.", $time);
        $finish;
    end

endmodule
