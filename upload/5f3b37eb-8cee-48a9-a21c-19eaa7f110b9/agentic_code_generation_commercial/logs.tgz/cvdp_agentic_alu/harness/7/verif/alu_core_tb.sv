`timescale 1ns/1ps

module tb_alu_core;
  parameter DATA_WIDTH = 32;
  reg [3:0] opcode;
  reg signed [DATA_WIDTH-1:0] operand1;
  reg signed [DATA_WIDTH-1:0] operand2;
  reg signed [DATA_WIDTH-1:0] operand3;
  wire signed [DATA_WIDTH-1:0] result;

  integer fail_count;

  alu_core #(DATA_WIDTH) dut (
    .opcode(opcode),
    .operand1(operand1),
    .operand2(operand2),
    .operand3(operand3),
    .result(result)
  );

  function automatic signed [DATA_WIDTH-1:0] golden;
    input [3:0] op;
    input signed [DATA_WIDTH-1:0] a, b, c;
    case (op)
      4'h0: golden = a + b + c;
      4'h1: golden = a - b - c;
      4'h2: golden = a * b * c;
      4'h3: golden = (a / b) / c;
      4'h4: golden = a & b & c;
      4'h5: golden = a | b | c;
      4'h6: golden = a ^ b ^ c;
      default: golden = 0;
    endcase
  endfunction

  task run_test;
    input [3:0] op;
    input signed [DATA_WIDTH-1:0] a, b, c;
    reg signed [DATA_WIDTH-1:0] expected;
    begin
      opcode   = op;
      operand1 = a;
      operand2 = b;
      operand3 = c;
      #1;
      expected = golden(op, a, b, c);
      if (result === expected)
        $display("PASS: OP=%0h A=%0d B=%0d C=%0d OUT=%0d EXP=%0d", op, a, b, c, result, expected);
      else begin
        $display("FAIL: OP=%0h A=%0d B=%0d C=%0d OUT=%0d EXP=%0d", op, a, b, c, result, expected);
        fail_count = fail_count + 1;
      end
    end
  endtask

  initial begin
    fail_count = 0;

    // Deterministic test cases
    run_test(4'h0, 10,            5,            2           );
    run_test(4'h0, -1,            1,            0           );
    run_test(4'h1, 20,            10,           5           );
    run_test(4'h1, 0,             0,            0           );
    run_test(4'h2, 2,             3,            4           );
    run_test(4'h2, -2,            -3,           1           );
    run_test(4'h3, 100,           5,            2           );
    run_test(4'h3, 50,            2,            5           );
    run_test(4'h4, 16'hFFFF,      16'h0FFF,     16'h00FF    );
    run_test(4'h4, 1,             3,            7           );
    run_test(4'h5, 16'hAAAA,      16'h5555,     16'hFFFF    );
    run_test(4'h5, 1,             4,            8           );
    run_test(4'h6, 16'hF0F0,      16'h0F0F,     16'hAAAA    );
    run_test(4'h6, 2,             1,            3           );
    run_test(4'h0, 100,           -50,          25          );
    run_test(4'h1, -10,           -5,           3           );
    run_test(4'h2, 10,            10,           0           );
    run_test(4'h3, -100,          -5,           -2          );
    run_test(4'h4, 32'hFFFFFFFF,  32'h00000001, 32'h00000002);
    run_test(4'h5, 32'hFFFFFFFF,  32'h80000000, 32'h7FFFFFFF);

    run_test(4'h0, 32'h7FFFFFFF,  32'h7FFFFFFF, 32'h7FFFFFFF);
    run_test(4'h1, 32'h80000000,  32'hFFFFFFFF, 32'hFFFFFFFF);
    run_test(4'h2, 32'h00000000,  32'h80000000, 32'h00000000);
    run_test(4'h3, 100,           1,            0           );
    run_test(4'h3, -128,          -1,           -1          );
    run_test(4'h4, 32'hFFFFFFFF,  32'hFFFFFFFF, 32'hFFFFFFFF);
    run_test(4'h5, 32'h00000000,  32'hFFFFFFFF, 32'h00000001);
    run_test(4'h6, 32'h00000000,  32'h00000000, 32'h00000000);
    run_test(4'h2, 32'h7FFFFFFF,  1,            2           );
    run_test(4'h2, -1,            32'h7FFFFFFF, -1          );
    run_test(4'h6, 32'hF0F0F0F0,  32'h0F0F0F0F, 32'hFFFF0000);
    run_test(4'h5, 32'hAAAA5555,  32'h0000FFFF, 32'hFFFF0000);
    run_test(4'h4, 0,             0,            32'hFFFFFFFF);
    run_test(4'h3, 32'hFFFF0000,  -1,           -1          );
    run_test(4'h1, 32'h7FFFFFFF,  -1,           32'h7FFFFFFF);
    run_test(4'h0, 32'h80000000,  32'h80000000, 32'h80000000);
    run_test(4'h1, 32'h00000001,  32'h00000001, 32'h7FFFFFFF);
    run_test(4'h3, 32'h00000001,  32'h00000001, 1           );
    run_test(4'h2, 32'hFFFFFFFE,  32'hFFFFFFFF, 32'h2       );
    run_test(4'h2, 1,             -1,           -1          );

    // Random test vectors
    repeat(30) begin
      run_test($urandom_range(0,7), $urandom, $urandom, $urandom);
    end

    // Unsupported opcode and additional cases
    run_test(4'h7, 0,            0,            0           );
    run_test(4'h7, -1,           -2,           -3          );
    run_test(4'h3, 32'h00010000, 32'h00000010, 32'h00000001);
    run_test(4'h2, 32'h00000003, 32'h00000003, 32'h00000003);
    run_test(4'h0, 12,           10,           3           );
    run_test(4'hF, 10,           20,           5           );
    run_test(4'h8, 30,           40,           50          );
    run_test(4'h0, 15,           15,           15          );

    // Final summary
    if (fail_count != 0)
      $display("TEST FAILED: %0d mismatch(es) found.", fail_count);
    else
      $display("ALL TESTS PASSED.");

    $finish;
  end
endmodule
