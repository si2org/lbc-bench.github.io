module alu_core #(
    parameter DATA_WIDTH = 32
)(
    input  logic [3:0]                         opcode,
    input  logic signed [DATA_WIDTH-1:0]       operand1,
    input  logic signed [DATA_WIDTH-1:0]       operand2,
    input  logic signed [DATA_WIDTH-1:0]       operand3,
    output logic signed [DATA_WIDTH-1:0]       result
);

// Signed boundary constants for DATA_WIDTH-bit range
localparam signed [DATA_WIDTH-1:0]   INT_MIN    = {1'b1, {(DATA_WIDTH-1){1'b0}}};
localparam signed [DATA_WIDTH-1:0]   INT_MAX    = {1'b0, {(DATA_WIDTH-1){1'b1}}};

// Same boundaries sign-extended to 2x and 3x width for overflow comparisons
localparam signed [2*DATA_WIDTH-1:0] INT_MIN_2W = {{DATA_WIDTH{1'b1}},         {(DATA_WIDTH-1){1'b0}}};
localparam signed [2*DATA_WIDTH-1:0] INT_MAX_2W = {{DATA_WIDTH{1'b0}},         {(DATA_WIDTH-1){1'b1}}};
localparam signed [3*DATA_WIDTH-1:0] INT_MIN_3W = {{(2*DATA_WIDTH){1'b1}},     {(DATA_WIDTH-1){1'b0}}};
localparam signed [3*DATA_WIDTH-1:0] INT_MAX_3W = {{(2*DATA_WIDTH){1'b0}},     {(DATA_WIDTH-1){1'b1}}};

function automatic signed [DATA_WIDTH-1:0] do_add(
    input signed [DATA_WIDTH-1:0] a,
    input signed [DATA_WIDTH-1:0] b,
    input signed [DATA_WIDTH-1:0] c
);
    do_add = a + b + c;
endfunction

function automatic signed [DATA_WIDTH-1:0] do_sub(
    input signed [DATA_WIDTH-1:0] a,
    input signed [DATA_WIDTH-1:0] b,
    input signed [DATA_WIDTH-1:0] c
);
    do_sub = a - b - c;
endfunction

function automatic signed [DATA_WIDTH-1:0] do_mul(
    input signed [DATA_WIDTH-1:0] a,
    input signed [DATA_WIDTH-1:0] b,
    input signed [DATA_WIDTH-1:0] c
);
    do_mul = a * b * c;
endfunction

function automatic signed [DATA_WIDTH-1:0] do_div(
    input signed [DATA_WIDTH-1:0] a,
    input signed [DATA_WIDTH-1:0] b,
    input signed [DATA_WIDTH-1:0] c
);
    do_div = a / b / c;
endfunction

function automatic signed [DATA_WIDTH-1:0] do_and(
    input signed [DATA_WIDTH-1:0] a,
    input signed [DATA_WIDTH-1:0] b,
    input signed [DATA_WIDTH-1:0] c
);
    do_and = a & b & c;
endfunction

function automatic signed [DATA_WIDTH-1:0] do_or(
    input signed [DATA_WIDTH-1:0] a,
    input signed [DATA_WIDTH-1:0] b,
    input signed [DATA_WIDTH-1:0] c
);
    do_or = a | b | c;
endfunction

function automatic signed [DATA_WIDTH-1:0] do_xor(
    input signed [DATA_WIDTH-1:0] a,
    input signed [DATA_WIDTH-1:0] b,
    input signed [DATA_WIDTH-1:0] c
);
    do_xor = a ^ b ^ c;
endfunction

always_comb begin
    result = 0;
    case (opcode)
        4'h0: result = do_add(operand1, operand2, operand3);
        4'h1: result = do_sub(operand1, operand2, operand3);
        4'h2: result = do_mul(operand1, operand2, operand3);
        4'h3: result = do_div(operand1, operand2, operand3);
        4'h4: result = do_and(operand1, operand2, operand3);
        4'h5: result = do_or(operand1, operand2, operand3);
        4'h6: result = do_xor(operand1, operand2, operand3);
        default: result = 0;
    endcase
end

// -----------------------------------------------------------------------
// Extended-precision signals for overflow detection
// -----------------------------------------------------------------------

// Addition/subtraction: sign-extend each operand to 2*DATA_WIDTH then compute
logic signed [2*DATA_WIDTH-1:0] add_full;
logic signed [2*DATA_WIDTH-1:0] sub_full;

assign add_full = $signed({{DATA_WIDTH{operand1[DATA_WIDTH-1]}}, operand1})
                + $signed({{DATA_WIDTH{operand2[DATA_WIDTH-1]}}, operand2})
                + $signed({{DATA_WIDTH{operand3[DATA_WIDTH-1]}}, operand3});

assign sub_full = $signed({{DATA_WIDTH{operand1[DATA_WIDTH-1]}}, operand1})
                - $signed({{DATA_WIDTH{operand2[DATA_WIDTH-1]}}, operand2})
                - $signed({{DATA_WIDTH{operand3[DATA_WIDTH-1]}}, operand3});

// Multiplication: first product in 2*DATA_WIDTH bits, then full product in 3*DATA_WIDTH bits
// This avoids intermediate truncation for the three-operand product.
logic signed [2*DATA_WIDTH-1:0] mul_ab;
logic signed [3*DATA_WIDTH-1:0] mul_full;

assign mul_ab   = $signed({{DATA_WIDTH{operand1[DATA_WIDTH-1]}}, operand1})
                * $signed({{DATA_WIDTH{operand2[DATA_WIDTH-1]}}, operand2});

assign mul_full = $signed({{DATA_WIDTH{mul_ab[2*DATA_WIDTH-1]}}, mul_ab})
                * $signed({{(2*DATA_WIDTH){operand3[DATA_WIDTH-1]}}, operand3});

// -----------------------------------------------------------------------
// Assertions
// -----------------------------------------------------------------------
always_comb begin

    // 1. Opcode valid range check: only opcodes 0–7 are valid
    assert (opcode <= 4'h7)
        else $error("Invalid opcode: opcode = %0d is outside valid range [0:7]", opcode);

    // 2a. Addition overflow check (opcode 0)
    if (opcode == 4'h0)
        assert (add_full >= INT_MIN_2W && add_full <= INT_MAX_2W)
            else $error("Addition overflow: operand1+operand2+operand3 exceeds signed %0d-bit range",
                        DATA_WIDTH);

    // 2b. Subtraction overflow check (opcode 1)
    if (opcode == 4'h1)
        assert (sub_full >= INT_MIN_2W && sub_full <= INT_MAX_2W)
            else $error("Subtraction overflow: operand1-operand2-operand3 exceeds signed %0d-bit range",
                        DATA_WIDTH);

    // 2c. Multiplication overflow check (opcode 2)
    if (opcode == 4'h2)
        assert (mul_full >= INT_MIN_3W && mul_full <= INT_MAX_3W)
            else $error("Multiplication overflow: operand1*operand2*operand3 exceeds signed %0d-bit range",
                        DATA_WIDTH);

    // 2d. Division by zero check (opcode 3)
    if (opcode == 4'h3)
        assert (operand2 != '0 && operand3 != '0)
            else $error("Division by zero: operand2 = %0d, operand3 = %0d", operand2, operand3);

    // 3. Result bounds check: final result must be within the valid signed range
    assert ($signed(result) >= INT_MIN && $signed(result) <= INT_MAX)
        else $error("Result out of valid signed %0d-bit range: result = %0d", DATA_WIDTH, result);

end

endmodule
