`timescale 1ns / 1ps
//------------------------------------------------------------------------------
// Module: axis_to_uart_tx
// Description: This module converts AXI-Stream data into UART serial output.
//              It supports configurable clock frequency, bit rate, word size,
//              optional parity (none, odd, or even), and configurable stop bits.
//              The design includes a state machine to transmit the start bit,
//              data bits, optional parity bit, and stop bit(s).
//------------------------------------------------------------------------------
module axis_to_uart_tx
#(
    parameter int CLK_FREQ      = 100,    // Clock frequency in MHz
    parameter int BIT_RATE      = 115200, // UART bit rate (bits per second)
    parameter int BIT_PER_WORD  = 8,      // Number of bits in one data word
    parameter int PARITY_BIT    = 0,      // Parity bit mode: 0-none, 1-odd, 2-even
    parameter int STOP_BITS_NUM  = 1       // Number of stop bits: 1 or 2
)
(
    // AXI-Stream interface
    input  logic        aclk,
    input  logic        aresetn,
    input  logic [7:0]  tdata,
    input  logic        tvalid,
    output logic        tready,

    // UART interface
    output logic        TX
);

    //--------------------------------------------------------------------------
    // State Definitions
    //--------------------------------------------------------------------------
    typedef enum logic [2:0] {
        IDLE,   // Wait for valid data
        START,  // Transmit start bit (low)
        DATA,   // Transmit data bits
        PARITY, // Transmit parity bit (if enabled)
        STOP1,  // Transmit first stop bit (high)
        STOP2   // Transmit second stop bit if required
    } tx_state_t;

    tx_state_t State, Next_State;

    //--------------------------------------------------------------------------
    // Calculation of clock cycles per bit period
    // Note: Multiply MHz by 1,000,000 to get Hz.
    //--------------------------------------------------------------------------
    localparam int Cycle_per_Period = CLK_FREQ * 1_000_000 / BIT_RATE;

    //--------------------------------------------------------------------------
    // Internal signals
    //--------------------------------------------------------------------------
    // Clock period counter: counts clock cycles for the duration of one UART bit.
    logic [17:0] Clk_Count;
    logic        Clk_Count_En, Clk_Count_Done;

    // Data bit counter: counts bits transmitted in DATA state.
    logic [3:0]  Bit_Count;
    logic        Bit_Count_Done;

    // Shift register for holding the data byte to be transmitted.
    logic [BIT_PER_WORD-1:0] Data;

    // Parity bit computed for the data.
    logic Parity_Value;

    // Combinational output to drive the TX line.
    logic Uart_Out;

    //--------------------------------------------------------------------------
    // Load Data from AXI-Stream when valid and ready
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if (!aresetn) begin
            Data <= '0;
        end
        else if (tvalid && tready) begin
            Data <= tdata;
        end
    end

    //--------------------------------------------------------------------------
    // Parity Bit Computation (combinational)
    // 0 : No parity
    // 1 : Odd parity (invert even parity result)
    // 2 : Even parity
    //--------------------------------------------------------------------------
    always_comb begin
        case(PARITY_BIT)
            0: Parity_Value = 1'b0;                              // No parity
            1: Parity_Value = ~(^Data[BIT_PER_WORD-1:0]);        // Odd parity
            2: Parity_Value =  ^Data[BIT_PER_WORD-1:0];          // Even parity
            default: Parity_Value = 1'b0;
        endcase
    end

    //--------------------------------------------------------------------------
    // Clock Counter Logic (Bug Fix Applied)
    // The counter now counts from 0 to (Cycle_per_Period - 1) so that the
    // Clk_Count_Done signal is correctly asserted.
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if (!aresetn) begin
            Clk_Count <= '0;
        end
        else if (Clk_Count_En) begin
            if (Clk_Count == (Cycle_per_Period - 1)) begin
                Clk_Count <= '0;
            end
            else begin
                Clk_Count <= Clk_Count + 1;
            end
        end
        else begin
            Clk_Count <= '0;
        end
    end

    // When Clk_Count reaches (Cycle_per_Period - 1) it indicates one bit period is complete.
    assign Clk_Count_Done = (Clk_Count == (Cycle_per_Period - 1));

    //--------------------------------------------------------------------------
    // Data Bit Counter Logic
    // This counter increments in the DATA state when the clock counter indicates a
    // complete bit period. When all data bits are transmitted, Bit_Count_Done is asserted.
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if (!aresetn) begin
            Bit_Count <= '0;
        end
        else if (Clk_Count_Done && (State == DATA)) begin
            if (Bit_Count == (BIT_PER_WORD - 1))
                Bit_Count <= '0;
            else
                Bit_Count <= Bit_Count + 1;
        end
    end

    assign Bit_Count_Done = ((Bit_Count == (BIT_PER_WORD - 1)) && Clk_Count_Done);

    //--------------------------------------------------------------------------
    // UART TX Output Register
    // TX line is updated based on the combinational Uart_Out value.
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if (!aresetn) begin
            TX <= 1'b1; // Idle state for UART (line high)
        end
        else begin
            TX <= Uart_Out;
        end
    end

    // tready signal is asserted when in IDLE state, meaning the module is ready to
    // accept new data.
    assign tready = (State == IDLE);

    //--------------------------------------------------------------------------
    // State Machine: Current State Register
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if (!aresetn) begin
            State <= IDLE;
        end
        else begin
            State <= Next_State;
        end
    end

    //--------------------------------------------------------------------------
    // Output Logic: Generate UART output and clock counter enable signal based on state.
    //--------------------------------------------------------------------------
    always_comb begin
        // Default assignments
        Clk_Count_En = 1'b0;
        Uart_Out     = 1'b1; // Default line idle (high)

        case(State)
            IDLE: begin
                // No transmission; waiting for valid data.
                Clk_Count_En = 1'b0;
                Uart_Out     = 1'b1;
            end
            START: begin
                // Transmit start bit (logic low) for one bit period.
                Clk_Count_En = 1'b1;
                Uart_Out     = 1'b0;
            end
            DATA: begin
                // Transmit data bits (use the data bit at current Bit_Count)
                Clk_Count_En = 1'b1;
                Uart_Out     = Data[Bit_Count];
            end
            PARITY: begin
                // Transmit the computed parity bit.
                Clk_Count_En = 1'b1;
                Uart_Out     = Parity_Value;
            end
            STOP1,
            STOP2: begin
                // Transmit stop bit(s): logic high.
                Clk_Count_En = 1'b1;
                Uart_Out     = 1'b1;
            end
        endcase
    end

    //--------------------------------------------------------------------------
    // Next State Logic
    //--------------------------------------------------------------------------
    always_comb begin
        // Default to remain in current state if no conditions met.
        Next_State = State;
        case(State)
            IDLE: begin
                // If valid data is available, move to START state.
                if (tvalid)
                    Next_State = START;
            end
            START: begin
                // After one bit period of start bit, move to DATA state.
                if (Clk_Count_Done)
                    Next_State = DATA;
            end
            DATA: begin
                // Transmit data bits; when the last bit is done, transition out.
                if (Bit_Count_Done) begin
                    if (PARITY_BIT != 0)
                        Next_State = PARITY;
                    else
                        Next_State = STOP1;
                end
            end
            PARITY: begin
                // After parity bit period, move to first stop bit.
                if (Clk_Count_Done)
                    Next_State = STOP1;
            end
            STOP1: begin
                // After the first stop bit, if only one stop bit is required, return to IDLE.
                // Else, move to second stop bit.
                if (Clk_Count_Done) begin
                    if (STOP_BITS_NUM == 1)
                        Next_State = IDLE;
                    else
                        Next_State = STOP2;
                end
            end
            STOP2: begin
                // After second stop bit, return to IDLE.
                if (Clk_Count_Done)
                    Next_State = IDLE;
            end
        endcase
    end

endmodule