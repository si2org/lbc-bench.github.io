import cocotb
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock
import random

#--------------------------------------------------------------------
# Local constants (using expected DUT defaults):
#   CLK_FREQ   = 100 MHz, BIT_RATE = 115200
#   Bit period = (100e6 / 115200) * CLK_PERIOD_NS  where CLK_PERIOD_NS = 10 ns 
#              ≈ 8680 ns.
#--------------------------------------------------------------------
CLK_PERIOD_NS      = 10      # Clock period of 10 ns (100 MHz)
BIT_PERIOD_NS      = 8680    # Derived bit period based on DUT defaults.
NUM_FRAMES_TX      = 5       # Number of TX frames to send
NUM_FRAMES_RX      = 5       # Number of RX frames to send
RESET_CYCLES       = 5       # Reset duration in clock cycles
IDLE_WAIT_CYCLES   = 10      # Wait cycles after reset

@cocotb.test()
async def test_axis_to_uart(dut):
    """
    Top-level test flow:
      1) Reset.
      2) Enhanced TX-only test: drive AXI input and decode TX output fully.
      3) Reinitialize and reset.
      4) Enhanced RX-only test: drive proper UART frames on RX.
    """
    dut._log.info("Starting enhanced cocotb test for 100% assertion coverage.")

    # Create and start clock
    clock = Clock(dut.aclk, CLK_PERIOD_NS, unit="ns", period_high=(CLK_PERIOD_NS+1)//2 if CLK_PERIOD_NS%2 else CLK_PERIOD_NS//2)
    cocotb.start_soon(clock.start())

    # Apply reset
    dut.aresetn.value   = 0
    dut.in_tvalid.value = 0
    dut.in_tdata.value  = 0
    dut.out_tready.value= 0
    dut.RX.value        = 1  # UART idle is high

    for _ in range(RESET_CYCLES):
        await RisingEdge(dut.aclk)
    dut.aresetn.value = 1

    # Stabilize
    for _ in range(IDLE_WAIT_CYCLES):
        await RisingEdge(dut.aclk)

    # --- Enhanced TX-Only Test ---
    await tx_only_test(dut)

    # Wait between tests
    for _ in range(IDLE_WAIT_CYCLES):
        await RisingEdge(dut.aclk)

    # Re-assert reset before RX test
    dut._log.info("Applying second reset before RX-only test")
    dut.aresetn.value   = 0
    dut.in_tvalid.value = 0
    dut.in_tdata.value  = 0
    dut.RX.value        = 1
    dut.out_tready.value= 0

    for _ in range(RESET_CYCLES * 2):
        await RisingEdge(dut.aclk)
    dut.aresetn.value = 1

    for _ in range(IDLE_WAIT_CYCLES):
        await RisingEdge(dut.aclk)

    # --- Enhanced RX-Only Test ---
    await rx_only_test(dut)

    # Finish test
    for _ in range(20):
        await RisingEdge(dut.aclk)
    dut._log.info("All tests completed successfully.")

async def tx_only_test(dut):
    """
    Enhanced TX-only test that correctly handles an optional PARITY bit.
    """
    dut._log.info("=== Enhanced TX-Only Test Start ===")

    # We can probe the actual PARITY_BIT parameter inside the DUT at runtime
    # if the simulator supports it. Otherwise, read from an env variable, etc.
    parity_mode = int(dut.PARITY_BIT)  # 0=no parity, 1=odd, 2=even

    random_frames = [random.randint(0, 255) for _ in range(NUM_FRAMES_TX)]
    for i, val in enumerate(random_frames):
        dut._log.info(f"TX test: Frame {i}, data = 0x{val:02X}")

    for i, val in enumerate(random_frames):
        # Wait for tready
        while not dut.in_tready.value:
            await RisingEdge(dut.aclk)

        # Drive input and assert valid
        dut.in_tdata.value  = val
        dut.in_tvalid.value = 1
        while not (dut.in_tvalid.value and dut.in_tready.value):
            await RisingEdge(dut.aclk)
        # Completed handshake
        await RisingEdge(dut.aclk)
        dut.in_tvalid.value = 0
        dut._log.info(f"Frame {i}: AXI handshake complete, data = 0x{val:02X}")

        # --- Wait for TX falling edge (start bit) ---
        while dut.TX.value != 0:
            await RisingEdge(dut.aclk)
        dut._log.info(f"Frame {i}: Detected falling edge (start bit).")

        # Check START bit at mid‐bit
        await Timer(BIT_PERIOD_NS / 2, unit='ns')
        if dut.TX.value != 0:
            dut._log.error(f"Frame {i}: START bit not low at mid‐bit sample (TX = {dut.TX.value}).")
        else:
            dut._log.info(f"Frame {i}: START bit verified low at mid‐bit sample.")

        # --- Sample DATA bits (LSB first) ---
        for bit_idx in range(8):
            await Timer(BIT_PERIOD_NS, unit='ns')
            expected_bit = (val >> bit_idx) & 1
            actual_bit   = int(dut.TX.value)
            dut._log.info(f"Frame {i}: Data bit {bit_idx} expected {expected_bit}, got {actual_bit}")
            if actual_bit != expected_bit:
                dut._log.error(
                    f"Frame {i}: Data bit {bit_idx} mismatch: expected {expected_bit}, got {actual_bit}"
                )

        # --- If parity is enabled, sample the PARITY bit here ---
        if parity_mode != 0:
            await Timer(BIT_PERIOD_NS, unit='ns')
            parity_bit = int(dut.TX.value)
            dut._log.info(f"Frame {i}: PARITY bit read as {parity_bit}")
            # Optionally, compute the expected parity in Python and compare.
            # For example:
            #
            #   computed = reduce(xor, [(val >> b) & 1 for b in range(8)])
            #   if parity_mode == 1:  # odd
            #       expected_parity = 1 - computed
            #   else:  # parity_mode == 2 => even
            #       expected_parity = computed
            #
            #   if parity_bit != expected_parity:
            #       dut._log.error(f"Frame {i}: PARITY bit mismatch: expected {expected_parity}, got {parity_bit}")

        # --- Finally, check the STOP bit(s) ---
        # (Assuming 1 stop bit in the code below — if your module has STOP_BITS_NUM=2, loop twice)
        await Timer(BIT_PERIOD_NS, unit='ns')
        if dut.TX.value != 1:
            dut._log.error(f"Frame {i}: STOP bit not high (TX = {dut.TX.value}).")
        else:
            dut._log.info(f"Frame {i}: STOP bit verified high.")

    dut._log.info("=== Enhanced TX-Only Test Complete ===")



async def rx_only_test(dut):
    """
    Enhanced RX-only test:
      - For each random byte, construct a proper UART frame:
          * Start bit (low) for BIT_PERIOD_NS.
          * 8 data bits (LSB-first) for BIT_PERIOD_NS each.
          * (No parity, as default parity is disabled.)
          * 1 stop bit (high) for BIT_PERIOD_NS.
      - After driving the frame on RX, wait for out_tvalid and log the received data.
    """
    dut._log.info("=== Enhanced RX-Only Test Start ===")
    random_frames = [random.randint(0, 255) for _ in range(NUM_FRAMES_RX)]
    for i, val in enumerate(random_frames):
        dut._log.info(f"RX test: Frame {i}, data = 0x{val:02X}")

    for i, val in enumerate(random_frames):
        await send_uart_frame(dut, val)
        # Allow time for DUT to process the frame
        await Timer(BIT_PERIOD_NS, unit='ns')
        # Wait for out_tvalid and capture tdata
        output_valid = False
        for _ in range(2000):
            await RisingEdge(dut.aclk)
            if dut.out_tvalid.value:
                out_data = int(dut.out_tdata.value)
                out_tuser = int(dut.out_tuser.value)
                dut._log.info(f"RX test: Frame {i} => out_tvalid high, data = 0x{out_data:02X} (tuser={out_tuser})")
                # Pulse out_tready for one cycle to acknowledge
                dut.out_tready.value = 1
                await RisingEdge(dut.aclk)
                dut.out_tready.value = 0
                output_valid = True
                break
        if not output_valid:
            dut._log.warning(f"RX test: Frame {i} timed out waiting for out_tvalid.")
    dut._log.info("=== Enhanced RX-Only Test Complete ===")


async def send_uart_frame(dut, data):
    """
    Drive a complete UART frame on RX:
      - Start bit: drive low for BIT_PERIOD_NS.
      - Data bits (LSB-first): drive each bit for BIT_PERIOD_NS.
      - Stop bit: drive high for BIT_PERIOD_NS.
      (Assumes no parity, one stop bit.)
    """
    dut._log.info(f"Sending UART frame for data 0x{data:02X}: START bit")
    dut.RX.value = 0
    await Timer(BIT_PERIOD_NS, unit='ns')

    # Data bits: LSB-first
    for bit_idx in range(8):
        bit_val = (data >> bit_idx) & 1
        dut._log.info(f"Sending UART frame: Data bit {bit_idx} = {bit_val}")
        dut.RX.value = bit_val
        await Timer(BIT_PERIOD_NS, unit='ns')

    # Stop bit (high)
    dut._log.info("Sending UART frame: STOP bit (high)")
    dut.RX.value = 1
    await Timer(BIT_PERIOD_NS, unit='ns')
