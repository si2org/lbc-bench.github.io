
from cocotb.triggers import FallingEdge, RisingEdge, Timer
from cocotb_tools.runner import get_runner
import random
import struct
import os
import aes
import subprocess
import re

def runner(module, toplevel, src:list, plusargs:list =[], args:tuple = (), parameter:dict={},
           wave:bool = False, sim:str = "icarus"):
    runner = get_runner(sim)
    runner.build(
        sources=src,
        hdl_toplevel=toplevel,
        # Arguments
        parameters=parameter,
        # compiler args
        build_args=args,
        always=True,
        clean=True,
        verbose=True,
        timescale=("1ns", "1ns"),
        log_file="build.log")
    runner.test(hdl_toplevel=toplevel, test_module=module, waves=wave, plusargs=plusargs, log_file="sim.log")

def coverage_report(asrt_type:str):
    '''asrt_type: assertion, toggle, overall'''
    cmd = f"imc -load /code/rundir/sim_build/cov_work/scope/test -execcmd \"report -metrics {asrt_type} -all -aspect sim -assertionStatus -overwrite -text -out coverage.log\""
    assert(subprocess.run(cmd, shell=True)), "Coverage merge didn't ran correctly."

def covt_report_check():

    metrics = {}

    with open("/code/rundir/coverage.log") as f:
        lines = f.readlines()

    # ----------------------------------------
    # - Evaluate Report
    # ----------------------------------------
    column = re.split(r'\s{2,}', lines[0].strip())
    for line in lines[2:]:
        info = re.split(r'\s{2,}', line.strip())
        inst = info[0].lstrip('|-')
        metrics [inst] = {column[i]: info[i].split('%')[0] for i in range(1, len(column))}

    print("Metrics:")
    print(metrics)

    if "Overall Average" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Overall Average"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    elif "Assertion" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Assertion"]) >= 100.00, "Didn't achieved the required coverage result."
    elif "Toggle" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Toggle"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    elif "Block" in metrics[os.getenv("TOPLEVEL")]:
        assert float(metrics[os.getenv("TOPLEVEL")]["Block"]) >= float(os.getenv("TARGET")), "Didn't achieved the required coverage result."
    else:
        assert False, "Couldn't find the required coverage result."

def save_vcd(wave:bool, toplevel:str, new_name:str):
    if wave:
        os.makedirs("vcd", exist_ok=True)
        os.rename(f'./sim_build/{toplevel}.fst', f'./vcd/{new_name}.fst')

async def reset(dut):
    await FallingEdge(dut.clock)
    dut.reset.value = 1

    await FallingEdge(dut.clock)
    dut.reset.value = 0
    print("[DEBUG] Reset complete")


async def access_hit(dut, index_a, way_select_a):
    await FallingEdge(dut.clock)
    dut.access.value = 1
    dut.hit.value = 1
    dut.index.value = index_a
    dut.way_select.value = way_select_a

    await FallingEdge(dut.clock)
    print(f"[DEBUG] way_replace: {dut.way_replace.value}")
    dut.access.value = 0
    dut.hit.value = 0


async def access_miss(dut, index_a, way_select_a):
    await FallingEdge(dut.clock)
    dut.access.value = 1
    dut.hit.value = 0
    dut.index.value = index_a
    dut.way_select.value = way_select_a

    await FallingEdge(dut.clock)
    print(f"[DEBUG] way_replace: 0b{int(dut.way_replace.value):04b}")
    dut.access.value = 0
    dut.hit.value = 0


async def dut_init(dut):
    # iterate all the input signals and initialize with 0
    for signal in dut:
        try:
            signal.value = 0
        except Exception:
            pass