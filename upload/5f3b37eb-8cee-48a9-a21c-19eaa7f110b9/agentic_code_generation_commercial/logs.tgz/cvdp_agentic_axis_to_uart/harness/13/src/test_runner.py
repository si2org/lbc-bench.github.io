import cocotb
import os
import harness_library as hrs_lb  # Use hrs_lb instead of cocotb.runner.get_runner
import random
import pytest

# Environment configuration
verilog_sources = os.getenv("VERILOG_SOURCES").split()
toplevel_lang   = os.getenv("TOPLEVEL_LANG", "verilog")
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = bool(os.getenv("WAVE"))

def run_sim(PARITY_BIT: int = 0, BIT_RATE: int = 115200, STOP_BITS_NUM: int = 1):
    """Configure simulation parameters, build, and run the simulation using hrs_lb.runner."""
    # Set simulation parameters
    parameters = {
        "PARITY_BIT": PARITY_BIT,
        "BIT_RATE": BIT_RATE,
        "STOP_BITS_NUM": STOP_BITS_NUM
    }

    print("[DEBUG] Running simulation with parameters:")
    for k, v in parameters.items():
        print(f"  {k} = {v}")

    # Setup simulation-specific arguments.
    args = []
    if sim == "xcelium":
        args = ("-coverage all", "-covoverwrite", "-sv", "-covtest test", "-svseed random")

    # Call the hrs_lb runner; note that we now pass the simulation parameters using the keyword 'parameter'
    hrs_lb.runner(
        wave=wave,
        toplevel=toplevel,
        module=module,
        src=verilog_sources,
        sim=sim,
        args=args,
        parameter=parameters  # Changed from 'parameters=parameters' to 'parameter=parameters'
    )

    # Run coverage reporting
    hrs_lb.coverage_report("assertion")
    hrs_lb.covt_report_check()


# Define example sets of parameter values
#parity_values   = [0, 1, 2]         # 0 = no parity, 1 = odd parity, 2 = even parity
#bit_rate_values = [115200, 57600]
#stop_bits_list  = [1, 2]

parity_values   = [2]         # 0 = no parity, 1 = odd parity, 2 = even parity
bit_rate_values = [115200]
stop_bits_list  = [1]

@pytest.mark.parametrize("parity", parity_values)
@pytest.mark.parametrize("baud", bit_rate_values)
@pytest.mark.parametrize("stops", stop_bits_list)
def test_axis_to_uart(parity, baud, stops):
    """
    Pytest test that calls `run_sim()` for different combinations of
    (PARITY_BIT, BIT_RATE, STOP_BITS_NUM).
    """
    run_sim(PARITY_BIT=parity, BIT_RATE=baud, STOP_BITS_NUM=stops)
