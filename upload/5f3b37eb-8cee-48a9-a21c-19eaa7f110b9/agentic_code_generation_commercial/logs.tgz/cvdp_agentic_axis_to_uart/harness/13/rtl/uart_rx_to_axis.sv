`timescale 1ns / 1ps
module uart_rx_to_axis
#(
    parameter CLK_FREQ      = 100,       // Clock frequency in MHz
    parameter BIT_RATE      = 115200,    // UART bit rate (bits per second)
    parameter BIT_PER_WORD  = 8,         // Number of bits in one data word
    parameter PARITY_BIT    = 0,         // Parity bit mode: 0=none, 1=odd, 2=even
    parameter STOP_BITS_NUM = 1          // Number of stop bits: 1 or 2
)
(
    // AXI-Stream interface
    input  wire         aclk,      // System clock
    input  wire         aresetn,   // Active-low reset signal
    output wire [7:0]   tdata,     // Output data (reconstructed from UART frame)
    output wire         tuser,     // Indicates a parity error if set (when parity is enabled)
    output wire         tvalid,    // AXI-Stream valid: asserts when data is ready
    input  wire         tready,    // AXI-Stream ready: the receiver can accept data

    // UART interface
    input  wire         RX         // Serial UART input line
);

    //--------------------------------------------------------------------------
    // FSM State Encoding
    //--------------------------------------------------------------------------
    typedef enum logic [2:0] {
        IDLE    = 3'b000,
        START   = 3'b001,
        DATA    = 3'b010,
        PARITY  = 3'b011,
        STOP1   = 3'b100,
        STOP2   = 3'b101,
        OUT_RDY = 3'b110
    } rx_state_t;

    // Current and next state variables for the FSM
    rx_state_t State, Next_State;

    //--------------------------------------------------------------------------
    // Compute Clock Cycles per Bit
    //--------------------------------------------------------------------------
    localparam integer Cycle_per_Period      = CLK_FREQ * 1000000 / BIT_RATE;
    localparam integer Cycle_per_Period_Half = Cycle_per_Period / 2;

    //--------------------------------------------------------------------------
    // Synchronize the RX Input and Detect Falling Edge
    //--------------------------------------------------------------------------
    logic [2:0] RX_Sync;      // 3-stage synchronizer for 'RX'
    logic       RX_Falling;   // Indicates a falling edge on 'RX'
    always_ff @(posedge aclk) begin
        if (!aresetn) begin
            RX_Sync <= 3'b111;  // Initialize to idle high
        end
        else begin
            RX_Sync <= {RX_Sync[1:0], RX};
        end
    end
    assign RX_Falling = RX_Sync[2] & ~RX_Sync[1]; // High->Low transition detection

    //--------------------------------------------------------------------------
    // Internal Signals for Counting
    //--------------------------------------------------------------------------
    logic [17:0] Clk_Count;      // Clock counter for bit timing
    logic [17:0] Clk_Count_Max;  // The max count we compare with
    logic        Clk_Count_En;   // Enables counting
    logic        Clk_Count_Done; // Asserts when Clk_Count == Clk_Count_Max

    logic [3:0]  Bit_Count;      // Counts how many data bits received
    logic        Bit_Count_Done; // True when we've received all data bits

    //--------------------------------------------------------------------------
    // Data Shift Register (LSB-first)
    //--------------------------------------------------------------------------
    logic [BIT_PER_WORD-1:0] Data_Shift_Reg;

    //--------------------------------------------------------------------------
    // Parity Error Flag
    //--------------------------------------------------------------------------
    logic Parity_Err;

    //--------------------------------------------------------------------------
    // Clock Counter Logic
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if(!aresetn) begin
            Clk_Count <= 18'b0;
        end
        else if(Clk_Count_En) begin
            if(Clk_Count == Clk_Count_Max) begin
                Clk_Count <= 18'b0;
            end
            else begin
                Clk_Count <= Clk_Count + 1'b1;
            end
        end
        else begin
            Clk_Count <= 18'b0;
        end
    end
    assign Clk_Count_Done = (Clk_Count == Clk_Count_Max);

    //--------------------------------------------------------------------------
    // Bit Counter for DATA State
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if(!aresetn) begin
            Bit_Count <= 4'b0;
        end
        else if(Clk_Count_Done && (State == DATA)) begin
            if(Bit_Count == (BIT_PER_WORD - 1))
                Bit_Count <= 4'b0;
            else
                Bit_Count <= Bit_Count + 1'b1;
        end
    end
    assign Bit_Count_Done = ((Bit_Count == (BIT_PER_WORD - 1)) && Clk_Count_Done);

    //--------------------------------------------------------------------------
    // Data Shift Register
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if (!aresetn) begin
            Data_Shift_Reg <= {BIT_PER_WORD{1'b0}};
        end
        else if (Clk_Count_Done && (State == DATA)) begin
            // SHIFT RIGHT: The bit from RX_Sync[0] becomes the left side.
            // If your design or testbench is truly LSB-first, you might SHIFT LEFT.
            // Make sure testbench matches this approach.
            Data_Shift_Reg <= {RX_Sync[0], Data_Shift_Reg[BIT_PER_WORD-1:1]};
        end
    end

    //--------------------------------------------------------------------------
    // AXI-Stream Outputs
    //--------------------------------------------------------------------------
    assign tdata  = Data_Shift_Reg;
    assign tuser  = Parity_Err;
    assign tvalid = (State == OUT_RDY);

    //--------------------------------------------------------------------------
    // Parity Checking
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if(!aresetn) begin
            Parity_Err <= 1'b0;
        end
        else if(Clk_Count_Done && (State == PARITY)) begin
            case(PARITY_BIT)
                0: Parity_Err <= 1'b0;
                1: Parity_Err <= ( ~(^Data_Shift_Reg) != RX_Sync[0] ); // Odd parity
                2: Parity_Err <= (  (^Data_Shift_Reg) != RX_Sync[0] ); // Even parity
                default: Parity_Err <= 1'b0;
            endcase
        end
        else if (State == OUT_RDY && Next_State == IDLE) begin
            // Optionally clear parity error when going back to IDLE
            Parity_Err <= 1'b0;
        end
    end

    //--------------------------------------------------------------------------
    // RX FSM: Current State Register
    //--------------------------------------------------------------------------
    always_ff @(posedge aclk) begin
        if(!aresetn) begin
            State <= IDLE;
        end
        else begin
            State <= Next_State;
        end
    end

    //--------------------------------------------------------------------------
    // Clock Counter Control
    //--------------------------------------------------------------------------
    always_comb begin
        Clk_Count_En  = 1'b0;
        Clk_Count_Max = Cycle_per_Period;

        case(State)
            IDLE,
            OUT_RDY: begin
                Clk_Count_En  = 1'b0;
                Clk_Count_Max = Cycle_per_Period;
            end
            START: begin
                Clk_Count_En  = 1'b1;
                Clk_Count_Max = Cycle_per_Period_Half;  // half bit for center-sampling start
            end
            DATA,
            PARITY,
            STOP1,
            STOP2: begin
                Clk_Count_En  = 1'b1;
                Clk_Count_Max = Cycle_per_Period;       // full bit for data, parity, stops
            end
            default: begin
                Clk_Count_En  = 1'b0;
                Clk_Count_Max = Cycle_per_Period;
            end
        endcase
    end

    //--------------------------------------------------------------------------
    // Next State Logic
    //--------------------------------------------------------------------------
    always_comb begin
        Next_State = State; // Default: remain in current state
        case(State)
            IDLE: begin
                // If the synchronized RX line had a falling edge,
                // that signals a potential start bit. Move to START state.
                if(RX_Falling) Next_State = START;
            end

            START: begin
                // After half a bit time, we move to the DATA state.
                // The idea is that this "center-samples" the start bit.
                if(Clk_Count_Done) Next_State = DATA;
            end

            DATA: begin
                // Once we’ve received 'BIT_PER_WORD' bits (Bit_Count_Done),
                // we move to PARITY if it’s enabled, otherwise STOP1.
                if(Bit_Count_Done) begin
                    if(PARITY_BIT != 0) Next_State = PARITY;
                    else                Next_State = STOP1;
                end
            end

            PARITY: begin
                // Sample the parity bit for one bit period,
                // then proceed to STOP1.
                if(Clk_Count_Done) Next_State = STOP1;
            end

            STOP1: begin
                // Wait for one stop bit. If only one is required, go to OUT_RDY.
                // If STOP_BITS_NUM=2, proceed to STOP2.
                if(Clk_Count_Done) begin
                    if(STOP_BITS_NUM == 1) Next_State = OUT_RDY;
                    else                   Next_State = STOP2;
                end
            end

            STOP2: begin
                // Same logic for the second stop bit; after that, go to OUT_RDY.
                if(Clk_Count_Done) Next_State = OUT_RDY;
            end

            OUT_RDY: begin
                // tvalid is asserted in this state, presenting the data word on tdata.
                // We stay here until 'tready' is asserted by the downstream consumer.
                // Once accepted, we return to IDLE to look for the next frame.
                if (tready) Next_State = IDLE;
                else        Next_State = OUT_RDY;
            end

            default: Next_State = IDLE;
        endcase
    end

    //--------------------------------------------------------------------------
    // SystemVerilog Assertions (SVA)
    //--------------------------------------------------------------------------

    // IDLE: tvalid must be low (no data ready)
    property idle_tvalid_low;
        @(posedge aclk) disable iff (!aresetn)
        (State == IDLE) |-> (tvalid == 1'b0);
    endproperty
    assert property (idle_tvalid_low)
        else $error("RX_ASSERT: In IDLE state, tvalid must be low");

    // OUT_RDY: tvalid must be high (data ready for downstream)
    property out_rdy_tvalid_high;
        @(posedge aclk) disable iff (!aresetn)
        (State == OUT_RDY) |-> (tvalid == 1'b1);
    endproperty
    assert property (out_rdy_tvalid_high)
        else $error("RX_ASSERT: In OUT_RDY state, tvalid must be high");

    // PARITY: one cycle after Clk_Count_Done in PARITY state, Parity_Err must correctly
    //         reflect the comparison between the received parity bit and computed parity
    property parity_err_correct;
        logic [BIT_PER_WORD-1:0] captured_data;
        logic                    captured_rx;
        @(posedge aclk) disable iff (!aresetn)
        (State == PARITY && Clk_Count_Done,
         captured_data = Data_Shift_Reg,
         captured_rx   = RX_Sync[0]) |=>
        (PARITY_BIT == 1 ? (Parity_Err == (~(^captured_data) != captured_rx)) :
         PARITY_BIT == 2 ? (Parity_Err == ( (^captured_data) != captured_rx)) :
                           (Parity_Err == 1'b0));
    endproperty
    assert property (parity_err_correct)
        else $error("RX_ASSERT: Parity_Err does not correctly reflect parity comparison");

    // OUT_RDY: when tready is asserted, FSM must transition to IDLE on next cycle
    property out_rdy_ack_to_idle;
        @(posedge aclk) disable iff (!aresetn)
        (State == OUT_RDY && tready) |=> (State == IDLE);
    endproperty
    assert property (out_rdy_ack_to_idle)
        else $error("RX_ASSERT: When in OUT_RDY and tready asserted, FSM must transition to IDLE");

endmodule