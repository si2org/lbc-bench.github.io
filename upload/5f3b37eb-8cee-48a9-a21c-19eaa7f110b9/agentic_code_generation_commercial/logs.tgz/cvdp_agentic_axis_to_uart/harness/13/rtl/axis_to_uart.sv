`timescale 1ns / 1ps

module axis_to_uart
#(
    parameter CLK_FREQ      = 100,       // Clock frequency in MHz
    parameter BIT_RATE      = 115200,    // UART bit rate (bits per second)
    parameter BIT_PER_WORD  = 8,         // Number of bits in one data word
    parameter PARITY_BIT    = 0,         // Parity bit: 0-none, 1-odd, 2-even
    parameter STOP_BITS_NUM = 1          // Number of stop bits: 1 or 2
)
(
    input  logic        aclk,
    input  logic        aresetn,

    // Input AXI-Stream interface (TX Path)
    input  logic [7:0]  in_tdata,
    input  logic        in_tvalid,
    output logic        in_tready,

    // Output AXI-Stream interface (RX Path)
    output logic [7:0]  out_tdata,
    output logic        out_tuser,
    output logic        out_tvalid,
    input  logic        out_tready,

    // UART interface (physical pins)
    input  logic        RX,
    output logic        TX
);

    // Instantiate the AXI-Stream to UART TX block
    axis_to_uart_tx #(
        .CLK_FREQ     (CLK_FREQ),
        .BIT_RATE     (BIT_RATE),
        .BIT_PER_WORD (BIT_PER_WORD),
        .PARITY_BIT   (PARITY_BIT),
        .STOP_BITS_NUM(STOP_BITS_NUM)
    ) TX_Block (
        // AXI-Stream interface
        .aclk   (aclk),
        .aresetn(aresetn),
        .tdata  (in_tdata),
        .tvalid (in_tvalid),
        .tready (in_tready),

        // UART Tx line
        .TX     (TX)
    );

    // Instantiate the UART RX to AXI-Stream block
    uart_rx_to_axis #(
        .CLK_FREQ     (CLK_FREQ),
        .BIT_RATE     (BIT_RATE),
        .BIT_PER_WORD (BIT_PER_WORD),
        .PARITY_BIT   (PARITY_BIT),
        .STOP_BITS_NUM(STOP_BITS_NUM)
    ) RX_Block (
        // AXI-Stream interface
        .aclk   (aclk),
        .aresetn(aresetn),
        .tdata  (out_tdata),
        .tuser  (out_tuser),
        .tvalid (out_tvalid),
        .tready (out_tready),

        // UART Rx line
        .RX     (RX)
    );

    //--------------------------------------------------------------------------
    // SystemVerilog Assertions (SVA)
    //--------------------------------------------------------------------------

    // RESET: during reset, TX must be high (idle) and out_tvalid must be low
    property reset_idle_outputs;
        @(posedge aclk)
        (!aresetn) |-> (TX == 1'b1 && out_tvalid == 1'b0);
    endproperty
    assert property (reset_idle_outputs)
        else $error("TOP_ASSERT: During reset, TX must be high and out_tvalid must be low");

endmodule