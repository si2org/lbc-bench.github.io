`timescale 1ns / 1ps
module bcd_to_excess_3_tb;

    // Inputs
    reg [3:0] bcd;

    // Outputs
    wire [3:0] excess3;
    wire error;
    wire valid;

    // Expected outputs
    reg [3:0] expected_excess3;
    reg       expected_error;
    reg       expected_valid;

    integer failed;

    bcd_to_excess_3 dut (
        .bcd(bcd),
        .excess3(excess3),
        .error(error),
        .valid(valid)
    );

    // Task to compute expected outputs based on spec
    task compute_expected;
        input [3:0] bcd_in;
        begin
            if (bcd_in <= 9) begin
                expected_excess3 = bcd_in + 3;
                expected_valid   = 1'b1;
                expected_error   = 1'b0;
            end else begin
                expected_excess3 = 4'b0000;
                expected_valid   = 1'b0;
                expected_error   = 1'b1;
            end
        end
    endtask

    initial begin
        failed = 0;
        bcd = 0;
        #10;

        $display("-------------------------------------------------------------");
        $display("BCD | Excess-3 (DUT) | Excess-3 (EXP) | valid | error | RESULT");
        $display("-------------------------------------------------------------");

        for (bcd = 0; bcd <= 15; bcd = bcd + 1) begin
            #10;
            compute_expected(bcd);

            if (excess3 === expected_excess3 &&
                valid   === expected_valid   &&
                error   === expected_error) begin
                $display("BCD=%0d (%b) | excess3=%b | exp=%b | valid=%b | error=%b | PASS",
                         bcd, bcd, excess3, expected_excess3, valid, error);
            end else begin
                $display("BCD=%0d (%b) | excess3=%b | exp=%b | valid=%b (exp %b) | error=%b (exp %b) | FAIL -- MISMATCH",
                         bcd, bcd,
                         excess3, expected_excess3,
                         valid,   expected_valid,
                         error,   expected_error);
                failed = failed + 1;
            end
        end

        $display("-------------------------------------------------------------");

        if (failed > 0) begin
            $display("SIMULATION FAILED: %0d test case(s) did not match expected output.", failed);
            $finish(1);
        end else begin
            $display("SIMULATION PASSED: All test cases matched expected output.");
            $finish(0);
        end
    end

    initial begin
        $dumpfile("test.vcd");
        $dumpvars(0, bcd_to_excess_3_tb);
    end

endmodule
