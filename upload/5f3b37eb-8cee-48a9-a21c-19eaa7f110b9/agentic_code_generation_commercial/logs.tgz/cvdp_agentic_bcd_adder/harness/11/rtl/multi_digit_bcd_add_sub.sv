module multi_digit_bcd_add_sub #(parameter N = 4)(
    input  [4*N-1:0] A,           // N-digit BCD number
    input  [4*N-1:0] B,           // N-digit BCD number
    input            add_sub,     // 1 for addition, 0 for subtraction
    output [4*N-1:0] result,      // Result (sum or difference)
    output           carry_borrow // Carry-out for addition or Borrow-out for subtraction
);
    wire [N:0] carry;          // Carry or borrow chain between digits
    wire [4*N-1:0] B_comp;     // 9's complement of B for subtraction
    wire [4*N-1:0] operand_B;  // Actual operand B fed to BCD adders

    // For addition, the initial carry is 0
    // For subtraction, the initial carry is 1 (because of 9's-complement +1 trick)
    assign carry[0] = add_sub ? 1'b0 : 1'b1;

    // Generate 9's complement of B for subtraction
    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : COMP_LOOP
            assign B_comp[4*i+3:4*i] = 4'b1001 - B[4*i+3:4*i];
        end
    endgenerate

    assign operand_B = add_sub ? B : B_comp;

    // Instantiate an N-digit chain of BCD adders
    generate
        for (i = 0; i < N; i = i + 1) begin : BCD_ADDERS
            bcd_adder bcd_adder_inst(
                .a   (A[4*i+3:4*i]),
                .b   (operand_B[4*i+3:4*i]),
                .cin (carry[i]),
                .sum (result[4*i+3:4*i]),
                .cout(carry[i+1])
            );
        end
    endgenerate

    // The final carry_borrow bit
    assign carry_borrow = carry[N];

    // check_done: pulses high after combinational outputs have settled.
    // Resets to 0 on any input change, then rises to 1 after #1 propagation delay.
    reg check_done;
    always @(*) begin
        check_done = 1'b0;
        #1 check_done = 1'b1;
    end

    // SVA: evaluate BCD digit validity only after outputs have stabilized
    integer k;
    always @(posedge check_done) begin
        for (k = 0; k < N; k = k + 1) begin
            // Input A digit validity
            input_A_valid: assert (A[4*k +: 4] <= 4'd9)
                else $error("[multi_digit_bcd_add_sub] Invalid BCD digit in A[digit %0d]: value=%0d exceeds 9. Full A=0x%0h",
                            k, A[4*k +: 4], A);

            // Input B digit validity
            input_B_valid: assert (B[4*k +: 4] <= 4'd9)
                else $error("[multi_digit_bcd_add_sub] Invalid BCD digit in B[digit %0d]: value=%0d exceeds 9. Full B=0x%0h",
                            k, B[4*k +: 4], B);

            // Result digit validity
            result_valid: assert (result[4*k +: 4] <= 4'd9)
                else $error("[multi_digit_bcd_add_sub] Invalid BCD digit in result[digit %0d]: value=%0d exceeds 9. Full result=0x%0h A=0x%0h B=0x%0h add_sub=%b",
                            k, result[4*k +: 4], result, A, B, add_sub);
        end
    end

endmodule
