//module of bcd_adder
module bcd_adder(
                 input  [3:0] a,             // 4-bit BCD input
                 input  [3:0] b,             // 4-bit BCD input
                 input        cin,           // Carry-in
                 output [3:0] sum,           // The corrected 4-bit BCD result of the addition
                 output       cout           // Carry-out to indicate overflow beyond BCD range (i.e., when the result exceeds 9)
                );

wire [3:0] binary_sum;
wire binary_cout;
wire z1, z2;
wire carry;

four_bit_adder adder1(
                      .a(a),
                      .b(b),
                      .cin(cin),
                      .sum(binary_sum),
                      .cout(binary_cout)
                     );

assign z1 = (binary_sum[3] & binary_sum[2]);
assign z2 = (binary_sum[3] & binary_sum[1]);
assign cout = (z1 | z2 | binary_cout);

four_bit_adder adder2(
                      .a(binary_sum),
                      .b({1'b0, cout, cout, 1'b0}),
                      .cin(1'b0),
                      .sum(sum),
                      .cout(carry)
                     );

    // check_done: pulses high after combinational outputs have settled.
    // Resets to 0 on any input change, then rises to 1 after #1 propagation delay.
    reg check_done;
    always @(*) begin
        check_done = 1'b0;
        #1 check_done = 1'b1;
    end

    // SVA: evaluate only after outputs have stabilized
    always @(posedge check_done) begin

        // Correction logic: if the raw binary sum exceeds 9 (or binary carry occurred),
        // the BCD carry-out must be asserted
        correction_carry_check: assert (!(binary_sum > 4'd9 || binary_cout) || cout)
            else $error("[bcd_adder] Correction logic error: binary_sum=%0d binary_cout=%b cout=%b. cout must be 1 when raw sum exceeds 9. a=%0d b=%0d cin=%b",
                        binary_sum, binary_cout, cout, a, b, cin);

        // Final BCD sum must be a valid BCD digit (0-9)
        bcd_sum_valid: assert (sum <= 4'd9)
            else $error("[bcd_adder] Invalid BCD sum: sum=%0d exceeds maximum valid BCD digit of 9. a=%0d b=%0d cin=%b binary_sum=%0d cout=%b",
                        sum, a, b, cin, binary_sum, cout);

    end

endmodule
