module bcd_top #(parameter N = 4)(
    input  [4*N-1:0] A,
    input  [4*N-1:0] B,
    output           A_less_B,
    output           A_equal_B,
    output           A_greater_B
);
    // We'll reuse the multi_digit_bcd_add_sub in subtract mode (add_sub=0)
    // to compute A - B.
    wire [4*N-1:0] diff;
    wire           borrow;

    // Subtraction: add_sub = 0
    multi_digit_bcd_add_sub #(N) subtract_inst (
        .A           (A),
        .B           (B),
        .add_sub     (1'b0),  // 0 => subtract
        .result      (diff),
        .carry_borrow(borrow) // In subtract mode, this acts as "no-borrow" if ==1
    );

    // Check if difference is zero
    // (i.e., if all bits of diff are zero, then A == B)
    wire is_zero = (diff == {4*N{1'b0}});

    // For BCD subtraction with 9's complement + 1:
    //   borrow=1 => no borrow actually occurred => A >= B
    //   borrow=0 => we did "borrow" => A < B
    assign A_less_B    = ~borrow;
    assign A_equal_B   =  borrow & is_zero;
    assign A_greater_B =  borrow & ~is_zero;

    // check_done: pulses high after combinational outputs have settled.
    // Resets to 0 on any input change, then rises to 1 after #1 propagation delay.
    reg check_done;
    always @(*) begin
        check_done = 1'b0;
        #1 check_done = 1'b1;
    end

    // SVA: evaluate only after outputs have stabilized
    always @(posedge check_done) begin

        // Mutual exclusivity: exactly one comparison output must be asserted
        mutual_exclusivity: assert ((A_less_B + A_equal_B + A_greater_B) == 1)
            else $error("[bcd_top] Mutual exclusivity violated: A_less_B=%b A_equal_B=%b A_greater_B=%b. Exactly one must be asserted at a time. A=0x%0h B=0x%0h",
                        A_less_B, A_equal_B, A_greater_B, A, B);

        // A == B: only A_equal_B asserted
        equal_check: assert (!(A == B) || (A_equal_B && !A_less_B && !A_greater_B))
            else $error("[bcd_top] Equal comparison failed: when A==B only A_equal_B should be high. A_less_B=%b A_equal_B=%b A_greater_B=%b. A=0x%0h B=0x%0h",
                        A_less_B, A_equal_B, A_greater_B, A, B);

        // A < B: only A_less_B asserted
        less_check: assert (!(A < B) || (A_less_B && !A_equal_B && !A_greater_B))
            else $error("[bcd_top] Less-than comparison failed: when A<B only A_less_B should be high. A_less_B=%b A_equal_B=%b A_greater_B=%b. A=0x%0h B=0x%0h",
                        A_less_B, A_equal_B, A_greater_B, A, B);

        // A > B: only A_greater_B asserted
        greater_check: assert (!(A > B) || (A_greater_B && !A_equal_B && !A_less_B))
            else $error("[bcd_top] Greater-than comparison failed: when A>B only A_greater_B should be high. A_less_B=%b A_equal_B=%b A_greater_B=%b. A=0x%0h B=0x%0h",
                        A_less_B, A_equal_B, A_greater_B, A, B);

    end

endmodule
