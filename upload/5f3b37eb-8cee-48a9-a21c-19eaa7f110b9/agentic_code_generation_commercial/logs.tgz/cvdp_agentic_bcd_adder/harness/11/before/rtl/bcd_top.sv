module bcd_top #(parameter N = 4)(
    input  [4*N-1:0] A,
    input  [4*N-1:0] B,
    output           A_less_B,
    output           A_equal_B,
    output           A_greater_B
);
    // We'll reuse the multi_digit_bcd_add_sub in subtract mode (add_sub=0)
    // to compute A - B.
    wire [4*N-1:0] diff;
    wire           borrow;

    // Subtraction: add_sub = 0
    multi_digit_bcd_add_sub #(N) subtract_inst (
        .A           (A),
        .B           (B),
        .add_sub     (1'b0),  // 0 => subtract
        .result      (diff),
        .carry_borrow(borrow) // In subtract mode, this acts as "no-borrow" if ==1
    );

    // Check if difference is zero
    // (i.e., if all bits of diff are zero, then A == B)
    wire is_zero = (diff == {4*N{1'b0}});

    // For BCD subtraction with 9's complement + 1:
    //   borrow=1 => no borrow actually occurred => A >= B
    //   borrow=0 => we did "borrow" => A < B
    assign A_less_B    = ~borrow; 
    assign A_equal_B   =  borrow & is_zero;
    assign A_greater_B =  borrow & ~is_zero;

endmodule