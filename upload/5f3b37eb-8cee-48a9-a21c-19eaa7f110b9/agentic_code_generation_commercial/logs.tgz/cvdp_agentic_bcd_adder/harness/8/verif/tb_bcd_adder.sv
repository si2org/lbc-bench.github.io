module tb_bcd_adder();

    // Inputs
    reg [3:0] a;
    reg [3:0] b;

    // Outputs
    wire [3:0] sum;
    wire cout;
    wire invalid;

    // Coverage counters
    integer total_tests;
    integer passed_tests;
    integer failed_tests;

    // Instantiate the BCD adder
    bcd_adder uut (
        .a(a),
        .b(b),
        .sum(sum),
        .cout(cout),
        .invalid(invalid)
    );

    // Task to validate the BCD addition
    task bcd_addition(
        input [3:0] in_a,
        input [3:0] in_b,
        input string testcase_name
    );
        reg [3:0] eff_a, eff_b;
        reg [4:0] raw_sum;
        reg [3:0] exp_sum;
        reg       exp_cout;
        reg       exp_invalid;
        reg       pass;
    begin
        a = in_a;
        b = in_b;
        #10;

        // Compute expected values per spec:
        // Clamp invalid inputs to 9, assert invalid flag
        eff_a       = (in_a > 4'd9) ? 4'd9 : in_a;
        eff_b       = (in_b > 4'd9) ? 4'd9 : in_b;
        raw_sum     = eff_a + eff_b;
        exp_invalid = (in_a > 4'd9) | (in_b > 4'd9);
        exp_cout    = (raw_sum >= 5'd10);
        exp_sum     = exp_cout ? (raw_sum - 5'd10) : raw_sum[3:0];

        pass = (sum === exp_sum) && (cout === exp_cout) && (invalid === exp_invalid);

        total_tests = total_tests + 1;
        if (pass) begin
            passed_tests = passed_tests + 1;
            $display("PASS [%s] a=%0d b=%0d | sum=%0d cout=%b invalid=%b",
                     testcase_name, in_a, in_b, sum, cout, invalid);
        end else begin
            failed_tests = failed_tests + 1;
            $display("FAIL [%s] a=%0d b=%0d | got sum=%0d cout=%b invalid=%b | exp sum=%0d cout=%b invalid=%b",
                     testcase_name, in_a, in_b,
                     sum, cout, invalid,
                     exp_sum, exp_cout, exp_invalid);
        end
    end
    endtask

    // Task to run all test cases
    task run_tests;
    begin
        $display("Starting BCD Adder Tests...");

        for (integer i = 0; i < 16; i = i + 1) begin
            for (integer j = 0; j < 16; j = j + 1) begin
                bcd_addition(i, j, $sformatf("Test %0d + %0d", i, j));
            end
        end
    end
    endtask

    // Initial block to run tests
    initial begin
        total_tests  = 0;
        passed_tests = 0;
        failed_tests = 0;

        run_tests();

        $display("----------------------------------------------------");
        $display("TEST SUMMARY");
        $display("  Total  : %0d", total_tests);
        $display("  Passed : %0d", passed_tests);
        $display("  Failed : %0d", failed_tests);
        $display("----------------------------------------------------");
        if (failed_tests == 0)
            $display("RESULT: ALL TESTS PASSED");
        else
            $display("RESULT: %0d TEST(S) FAILED", failed_tests);
        $display("----------------------------------------------------");

        #50;
        $finish;
    end

    // Generate VCD waveform file
    initial begin
        $dumpfile("bcd_adder.vcd");
        $dumpvars(0, tb_bcd_adder);
    end

endmodule
