module tb_bcd_adder();

    // Inputs
    reg [3:0] a;
    reg [3:0] b;

    // Outputs
    wire [3:0] sum;
    wire cout;
    wire invalid;

    // Instantiate the BCD adder
    bcd_adder uut (
        .a(a),
        .b(b),
        .sum(sum),
        .cout(cout),
        .invalid(invalid)
    );

    // Task to validate the BCD addition
    task bcd_addition(
        input [3:0] in_a,
        input [3:0] in_b,
        input string testcase_name
    );
        
    begin
        a = in_a;
        b = in_b;
        #10;
        $display("Input : a=%d , b=%d Output: sum=%d , cout=%b, invalid=%b ", a, b, sum, cout,invalid);
    end
    endtask

    // Task to run all test cases
    task run_tests;
    begin
        $display("Starting BCD Adder Tests...");

        for (integer i = 0; i < 16; i = i + 1) begin
            for (integer j = 0; j < 16; j = j + 1) begin
                bcd_addition(i, j, $sformatf("Test %0d + %0d", i, j));
            end
        end
    end
    endtask

    // Initial block to run tests
    initial begin
        run_tests();
        #50;
        $finish;
    end

    // Generate VCD waveform file
    initial begin
        $dumpfile("bcd_adder.vcd");
        $dumpvars(0, tb_bcd_adder);
    end

endmodule