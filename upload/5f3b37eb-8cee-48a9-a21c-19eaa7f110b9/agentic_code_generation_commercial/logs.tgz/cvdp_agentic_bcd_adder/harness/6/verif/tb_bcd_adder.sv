`timescale 1ns/1ps

module tb_bcd_adder;

    // DUT signals
    logic [3:0] a;
    logic [3:0] b;
    logic [3:0] sum;
    logic       cout;
    logic       invalid;

    // Instantiate DUT
    bcd_adder uut (
        .a      (a),
        .b      (b),
        .sum    (sum),
        .cout   (cout),
        .invalid(invalid)
    );

    // ----------------------------------------------------------------
    // Task: drive one input combination and display the result
    // ----------------------------------------------------------------
    task automatic bcd_addition(input logic [3:0] ta, input logic [3:0] tb);
        a = ta;
        b = tb;
        #10;
        $display("a=%0d (0x%h)  b=%0d (0x%h)  |  sum=%0d (0x%h)  cout=%0b  invalid=%0b  %s",
                 ta, ta, tb, tb,
                 sum, sum, cout, invalid,
                 (invalid ? "  [INVALID INPUT]" : ""));
    endtask

    // ----------------------------------------------------------------
    // Task: iterate over all 256 input combinations
    // ----------------------------------------------------------------
    task automatic run_all_combinations();
        integer ai, bi;
        $display("");
        $display("============================================================");
        $display("  BCD ADDER - FULL STIMULUS SWEEP (a: 0-15, b: 0-15)");
        $display("============================================================");
        $display("%-26s %-26s | %-20s %-6s %-10s",
                 "  a (dec/hex)", "  b (dec/hex)",
                 "sum (dec/hex)", "cout", "invalid");
        $display("------------------------------------------------------------");

        for (ai = 0; ai <= 15; ai = ai + 1) begin
            for (bi = 0; bi <= 15; bi = bi + 1) begin
                bcd_addition(4'(ai), 4'(bi));
            end
        end

        $display("------------------------------------------------------------");
        $display("  Sweep complete: %0d test vectors applied.", 16 * 16);
        $display("============================================================");
        $display("");
    endtask

    // ----------------------------------------------------------------
    // Main stimulus
    // ----------------------------------------------------------------
    initial begin
        // Waveform capture
        $dumpfile("tb_bcd_adder.vcd");
        $dumpvars(0, tb_bcd_adder);

        // Initialise inputs
        a = 4'h0;
        b = 4'h0;
        #5;

        // ---- Section 1: valid BCD pairs (0–9 x 0–9) ----
        $display("");
        $display("============================================================");
        $display("  SECTION 1 — Valid BCD inputs only (a: 0-9, b: 0-9)");
        $display("============================================================");
        $display("%-26s %-26s | %-20s %-6s %-10s",
                 "  a (dec/hex)", "  b (dec/hex)",
                 "sum (dec/hex)", "cout", "invalid");
        $display("------------------------------------------------------------");
        begin
            integer ai, bi;
            for (ai = 0; ai <= 9; ai = ai + 1) begin
                for (bi = 0; bi <= 9; bi = bi + 1) begin
                    bcd_addition(4'(ai), 4'(bi));
                end
            end
        end
        $display("------------------------------------------------------------");
        $display("  Valid-BCD section complete: %0d vectors.", 10 * 10);
        $display("============================================================");

        // ---- Section 2: invalid BCD inputs (a or b >= 10) ----
        $display("");
        $display("============================================================");
        $display("  SECTION 2 — Invalid BCD inputs (a or b in range 10-15)");
        $display("============================================================");
        $display("%-26s %-26s | %-20s %-6s %-10s",
                 "  a (dec/hex)", "  b (dec/hex)",
                 "sum (dec/hex)", "cout", "invalid");
        $display("------------------------------------------------------------");
        begin
            integer ai, bi;
            // a is invalid, b is valid
            for (ai = 10; ai <= 15; ai = ai + 1) begin
                for (bi = 0; bi <= 9; bi = bi + 1) begin
                    bcd_addition(4'(ai), 4'(bi));
                end
            end
            // a is valid, b is invalid
            for (ai = 0; ai <= 9; ai = ai + 1) begin
                for (bi = 10; bi <= 15; bi = bi + 1) begin
                    bcd_addition(4'(ai), 4'(bi));
                end
            end
            // both a and b are invalid
            for (ai = 10; ai <= 15; ai = ai + 1) begin
                for (bi = 10; bi <= 15; bi = bi + 1) begin
                    bcd_addition(4'(ai), 4'(bi));
                end
            end
        end
        $display("------------------------------------------------------------");
        $display("  Invalid-BCD section complete.");
        $display("============================================================");

        // ---- Section 3: full exhaustive sweep for coverage ----
        run_all_combinations();

        $display("All test scenarios completed successfully.");
        $finish;
    end

endmodule
