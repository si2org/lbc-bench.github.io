# BCD Adder Module (bcd_adder)

This module adds two 4-bit BCD numbers and ensures the result remains in valid BCD form (0–9 per digit). It first detects invalid inputs (values above 9) and clamps them to 9 before performing the addition. If the intermediate result exceeds 9, the module applies BCD correction, producing a properly formatted two-digit result and asserting the carry-out signal to indicate overflow. The underlying addition logic is handled by the four_bit_adder and full_adder submodules, providing a clear, hierarchical design that is easy to extend and maintain.

## Parameterization

This module is designed as a fixed 4-bit adder with no configurable parameters.

## Interfaces

### Data Inputs

- **[3:0] a**: 4-bit input representing a binary value. (range: 0 to 15).
  
- **[3:0] b**: 4-bit input representing a binary value (range: 0 to 15).

### Data Outputs

- **[3:0] sum**: 4-bit output representing the BCD-corrected sum of a and b.
  
- **cout**: Single-bit output indicating if a carry is generated during the BCD addition.  

- **invalid**: Single-bit output Flag set when an invalid input is detected (although in a 4-bit design, this is usually redundant).

## Detailed Functionality

### Input Validation

- The module checks if `a` or `b` is greater than 9.
- If either input is invalid (≥ 10), the `invalid` signal is asserted.

### Addition Process

- When both inputs are valid (0–9), the module performs 4-bit binary addition.
- The 4-bit sum is produced based on the arithmetic result.
- If the sum is 10 or more, `cout` will be set to indicate overflow in the context of a single decimal digit.

### Overflow and Invalid Handling

- If the sum is between 10 and 18 (since the highest valid input pair is 9 + 9 = 18), the carry-out (`cout`) indicates the sum has exceeded one decimal digit.
- If `invalid` is asserted, the sum and carry-out may not be meaningful, as the inputs are outside the supported digit range.

## Submodules Explanation

### 1. `four_bit_adder`

- Accepts two 4-bit inputs and a carry-in (which is typically 0 for this design).
- Produces a 4-bit sum and a carry-out.
- Used here to add the clamped or validated inputs (0–9), though its internal capacity allows for inputs in the range of 0–15.

### 2. `full_adder`

- Forms the core of each bit's addition.
- Handles single-bit addition and produces a sum bit and a carry-out bit.
- Chained four times in `four_bit_adder` to handle all 4 bits.

## Example Usage

### Valid Input Example

- `a = 5` (0101 in BCD)  
- `b = 6` (0110 in BCD)

The binary sum of 5 and 6 is 11, which exceeds the single-digit BCD range of 0–9.  
The adder applies a BCD correction, resulting in two BCD digits `1` and `1` (i.e., 11 in decimal).  
The final output is `0001 0001`, with `cout` asserted to show overflow beyond a single BCD digit.  
The `invalid` signal remains low, since both inputs are valid (≤ 9).

### Invalid Input Example (Clamping to 9)

- `a = 12` (1100 in binary)  
- `b = 8` (1000 in binary)

Because `a` exceeds 9, the adder sets `invalid` to `1` and clamps `a` to 9 (`1001` in binary) internally.  
It then performs the addition using 9 + 8 = 17.  
Since 17 is above 9 in BCD terms, the result is represented as two BCD digits, typically shown as `0001 0111` (indicating `1` and `7`).  
The `cout` is asserted to indicate that the result is larger than a single decimal digit.  
Even though the final sum is computed, the `invalid` signal remains high to show that the original input (`a=12`) was out of valid range.

## Summary

### Functionality:
- The `bcd_adder` module performs 4-bit binary addition and manages carry propagation.

### Carry Handling:
- The carry-out (`cout`) is generated when the sum exceeds the 4-bit limit.

### Invalid Input Handling:
- The `invalid` flag is used to detect unintended input values.

### Modular Design:
- The module is structured hierarchically using `four_bit_adder` and `full_adder`, making it efficient, reusable, and easy to extend.