`timescale 1ns/1ps

module dramcntrl_tb;

  // --------------------------------------------------------------------------
  // Parameters matching DUT defaults (typical 16MB SDRAM at 100 MHz)
  // --------------------------------------------------------------------------
  parameter del               = 14;   // 2^14=16384 covers 100us at 100MHz
  parameter len_auto_ref      = 3;    // saturating counter: max 7 pending refreshes
  parameter len_small         = 4;    // small timing counter width
  parameter addr_bits_to_dram = 13;   // SDRAM row/col address width
  parameter addr_bits_from_up = 24;   // 16MB upstream address space
  parameter ba_bits           = 2;    // 4 banks

  // --------------------------------------------------------------------------
  // DUT port declarations
  // --------------------------------------------------------------------------
  logic                          clk_in;
  logic                          reset;
  logic [addr_bits_from_up-1:0]  addr_from_up;
  logic                          rd_n_from_up;
  logic                          wr_n_from_up;
  logic                          bus_term_from_up;

  wire  [addr_bits_to_dram-1:0]  addr;
  wire  [ba_bits-1:0]            ba;
  wire                           clk;
  wire                           cke;
  wire                           cs_n;
  wire                           ras_n;
  wire                           cas_n;
  wire                           we_n;
  wire  [1:0]                    dqm;
  wire                           dram_init_done;
  wire                           dram_busy;

  // --------------------------------------------------------------------------
  // DUT instantiation
  // --------------------------------------------------------------------------
  dramcntrl #(
    .del              (del),
    .len_auto_ref     (len_auto_ref),
    .len_small        (len_small),
    .addr_bits_to_dram(addr_bits_to_dram),
    .addr_bits_from_up(addr_bits_from_up),
    .ba_bits          (ba_bits)
  ) dut (
    .clk_in          (clk_in),
    .reset           (reset),
    .addr_from_up    (addr_from_up),
    .rd_n_from_up    (rd_n_from_up),
    .wr_n_from_up    (wr_n_from_up),
    .bus_term_from_up(bus_term_from_up),
    .addr            (addr),
    .ba              (ba),
    .clk             (clk),
    .cke             (cke),
    .cs_n            (cs_n),
    .ras_n           (ras_n),
    .cas_n           (cas_n),
    .we_n            (we_n),
    .dqm             (dqm),
    .dram_init_done  (dram_init_done),
    .dram_busy       (dram_busy)
  );

  // --------------------------------------------------------------------------
  // Clock generation: 100 MHz => 10 ns period
  // --------------------------------------------------------------------------
  initial clk_in = 1'b0;
  always #5 clk_in = ~clk_in;

  // --------------------------------------------------------------------------
  // apply_reset: assert synchronous reset for 10 cycles then deassert
  // --------------------------------------------------------------------------
  task automatic apply_reset();
    begin
      reset            = 1'b1;
      rd_n_from_up     = 1'b1;
      wr_n_from_up     = 1'b1;
      bus_term_from_up = 1'b0;
      addr_from_up     = '0;
      repeat (10) @(posedge clk_in);
      @(negedge clk_in);
      reset = 1'b0;
      $display("[%0t ns] apply_reset: reset deasserted", $time);
    end
  endtask

  // --------------------------------------------------------------------------
  // wait_for_init: spin until dram_init_done rises
  // --------------------------------------------------------------------------
  task automatic wait_for_init();
    begin
      $display("[%0t ns] wait_for_init: waiting for dram_init_done...", $time);
      wait (dram_init_done === 1'b1);
      @(posedge clk_in);
      $display("[%0t ns] wait_for_init: initialization complete", $time);
    end
  endtask

  // --------------------------------------------------------------------------
  // do_write: drive a valid write sequence to the given address
  // --------------------------------------------------------------------------
  task automatic do_write(input logic [addr_bits_from_up-1:0] addr_in);
    begin
      @(negedge clk_in);
      addr_from_up = addr_in;
      wr_n_from_up = 1'b0;
      rd_n_from_up = 1'b1;
      @(posedge clk_in);
      @(negedge clk_in);
      wr_n_from_up = 1'b1;
      @(posedge clk_in);
      $display("[%0t ns] do_write  addr=0x%06h", $time, addr_in);
    end
  endtask

  // --------------------------------------------------------------------------
  // do_read: apply a read transaction at the given address
  // --------------------------------------------------------------------------
  task automatic do_read(input logic [addr_bits_from_up-1:0] addr_in);
    begin
      @(negedge clk_in);
      addr_from_up = addr_in;
      rd_n_from_up = 1'b0;
      wr_n_from_up = 1'b1;
      @(posedge clk_in);
      @(negedge clk_in);
      rd_n_from_up = 1'b1;
      @(posedge clk_in);
      $display("[%0t ns] do_read   addr=0x%06h", $time, addr_in);
    end
  endtask

  // --------------------------------------------------------------------------
  // do_concurrent_rd_wr: simultaneously assert rd and wr, then switch address
  //   mid-transfer to stress arbitration and mux logic
  // --------------------------------------------------------------------------
  task automatic do_concurrent_rd_wr(
    input logic [addr_bits_from_up-1:0] addr_a,
    input logic [addr_bits_from_up-1:0] addr_b
  );
    begin
      @(negedge clk_in);
      addr_from_up = addr_a;
      rd_n_from_up = 1'b0;
      wr_n_from_up = 1'b0;
      repeat (2) @(posedge clk_in);
      @(negedge clk_in);
      addr_from_up = addr_b;          // mid-transfer address switch
      repeat (2) @(posedge clk_in);
      @(negedge clk_in);
      rd_n_from_up = 1'b1;
      wr_n_from_up = 1'b1;
      @(posedge clk_in);
      $display("[%0t ns] do_concurrent_rd_wr  addr_a=0x%06h  addr_b=0x%06h",
               $time, addr_a, addr_b);
    end
  endtask

  // --------------------------------------------------------------------------
  // random_traffic: mix of random writes and reads with random idle gaps
  // --------------------------------------------------------------------------
  task automatic random_traffic(input int unsigned num_ops);
    logic [addr_bits_from_up-1:0] raddr;
    int unsigned                  idle_cycles;
    begin
      for (int i = 0; i < num_ops; i++) begin
        raddr       = $urandom();
        idle_cycles = $urandom_range(1, 6);
        if ($urandom_range(0, 1))
          do_write(raddr);
        else
          do_read(raddr);
        repeat (idle_cycles) @(posedge clk_in);
      end
    end
  endtask

  // --------------------------------------------------------------------------
  // saturate_no_of_refs: idle long enough to let the saturating auto-refresh
  //   counter (no_of_refs_needed) reach its maximum value (2^len_auto_ref - 1)
  // --------------------------------------------------------------------------
  task automatic saturate_no_of_refs();
    begin
      $display("[%0t ns] saturate_no_of_refs: holding idle to saturate counter", $time);
      // 10 000 cycles >> 8 × 781-cycle refresh intervals needed to saturate
      repeat (10000) @(posedge clk_in);
      $display("[%0t ns] saturate_no_of_refs: done", $time);
    end
  endtask

  // --------------------------------------------------------------------------
  // toggle_bus_term_during_write: write while toggling bus_term_from_up each
  //   cycle to activate toggle paths and TB vector logic in the control FSM
  // --------------------------------------------------------------------------
  task automatic toggle_bus_term_during_write(
    input logic [addr_bits_from_up-1:0] addr_in
  );
    begin
      @(negedge clk_in);
      addr_from_up = addr_in;
      wr_n_from_up = 1'b0;
      rd_n_from_up = 1'b1;
      for (int i = 0; i < 8; i++) begin
        @(posedge clk_in);
        @(negedge clk_in);
        bus_term_from_up = ~bus_term_from_up;
      end
      wr_n_from_up     = 1'b1;
      bus_term_from_up = 1'b0;
      @(posedge clk_in);
      $display("[%0t ns] toggle_bus_term_during_write  addr=0x%06h", $time, addr_in);
    end
  endtask

  // --------------------------------------------------------------------------
  // inject_short_wr_pulse: 1-cycle write pulse to hit delayed-signal paths
  // --------------------------------------------------------------------------
  task automatic inject_short_wr_pulse(
    input logic [addr_bits_from_up-1:0] addr_in
  );
    begin
      @(negedge clk_in);
      addr_from_up = addr_in;
      wr_n_from_up = 1'b0;
      rd_n_from_up = 1'b1;
      @(posedge clk_in);
      @(negedge clk_in);
      wr_n_from_up = 1'b1;
      $display("[%0t ns] inject_short_wr_pulse  addr=0x%06h", $time, addr_in);
    end
  endtask

  // --------------------------------------------------------------------------
  // inject_short_rd_pulse: 1-cycle read pulse to hit delayed-signal paths
  // --------------------------------------------------------------------------
  task automatic inject_short_rd_pulse(
    input logic [addr_bits_from_up-1:0] addr_in
  );
    begin
      @(negedge clk_in);
      addr_from_up = addr_in;
      rd_n_from_up = 1'b0;
      wr_n_from_up = 1'b1;
      @(posedge clk_in);
      @(negedge clk_in);
      rd_n_from_up = 1'b1;
      $display("[%0t ns] inject_short_rd_pulse  addr=0x%06h", $time, addr_in);
    end
  endtask

  // --------------------------------------------------------------------------
  // reset_mid_transaction: start a write, then assert reset mid-way to
  //   exercise FSM recovery paths
  // --------------------------------------------------------------------------
  task automatic reset_mid_transaction(
    input logic [addr_bits_from_up-1:0] addr_in
  );
    begin
      @(negedge clk_in);
      addr_from_up = addr_in;
      wr_n_from_up = 1'b0;
      rd_n_from_up = 1'b1;
      repeat (3) @(posedge clk_in);
      $display("[%0t ns] reset_mid_transaction: injecting reset", $time);
      reset = 1'b1;
      repeat (5) @(posedge clk_in);
      @(negedge clk_in);
      reset        = 1'b0;
      wr_n_from_up = 1'b1;
      @(posedge clk_in);
      $display("[%0t ns] reset_mid_transaction: FSM recovery complete", $time);
    end
  endtask

  // ==========================================================================
  // Main stimulus
  // ==========================================================================
  initial begin
    $display("[%0t ns] *** dramcntrl_tb starting ***", $time);

    // ------------------------------------------------------------------
    // Power-on state
    // ------------------------------------------------------------------
    reset            = 1'b1;
    rd_n_from_up     = 1'b1;
    wr_n_from_up     = 1'b1;
    bus_term_from_up = 1'b0;
    addr_from_up     = '0;

    apply_reset();
    wait_for_init();

    // ------------------------------------------------------------------
    // 1. Known address sequences — deterministic behaviour verification
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 1: known address sequences ==", $time);
    do_write(24'h000001);
    do_read (24'h000001);
    do_write(24'h000002);
    do_read (24'h000002);
    do_write(24'h0000FF);
    do_read (24'h0000FF);
    do_write(24'h001234);
    do_read (24'h001234);
    do_write(24'hABCDEF);
    do_read (24'hABCDEF);

    // ------------------------------------------------------------------
    // 2. Back-to-back WR→RD transitions — arbitration stress
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 2: back-to-back WR->RD ==", $time);
    repeat (8) begin
      do_write(24'h001000);
      do_read (24'h001000);
    end

    // ------------------------------------------------------------------
    // 3. Edge / extreme address ranges — decoder coverage
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 3: edge address ranges ==", $time);
    do_write(24'h000000);
    do_read (24'h000000);
    do_write(24'hFFFFFF);
    do_read (24'hFFFFFF);
    do_write(24'h800000);
    do_read (24'h800000);
    do_write(24'h7FFFFF);
    do_read (24'h7FFFFF);

    // ------------------------------------------------------------------
    // 4. Randomized traffic
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 4: random traffic (30 ops) ==", $time);
    random_traffic(30);

    // ------------------------------------------------------------------
    // 5. Long idle — let auto-refresh fire naturally
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 5: long idle (auto-refresh) ==", $time);
    repeat (2000) @(posedge clk_in);

    // ------------------------------------------------------------------
    // 6. Saturate no_of_refs_needed to maximum value
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 6: saturate no_of_refs ==", $time);
    saturate_no_of_refs();

    // Drain pending refreshes with a burst of operations
    repeat (5) begin
      do_write($urandom() & 24'hFFFFFF);
      do_read ($urandom() & 24'hFFFFFF);
    end

    // ------------------------------------------------------------------
    // 7. Toggle bus_term_from_up during transactions
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 7: bus_term_from_up toggling ==", $time);
    toggle_bus_term_during_write(24'h010101);
    toggle_bus_term_during_write(24'h0ABCDE);
    toggle_bus_term_during_write(24'hFEDCBA);

    // Freestanding rapid bus_term_from_up toggles between transactions
    repeat (8) begin
      @(negedge clk_in);
      bus_term_from_up = ~bus_term_from_up;
      @(posedge clk_in);
    end
    bus_term_from_up = 1'b0;

    // ------------------------------------------------------------------
    // 8. 1-cycle WR and RD pulses — delayed signal / edge detection paths
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 8: short WR/RD pulses ==", $time);
    inject_short_wr_pulse(24'h001234);
    inject_short_rd_pulse(24'h001234);
    inject_short_wr_pulse(24'h000000);
    inject_short_rd_pulse(24'hFFFFFF);
    inject_short_wr_pulse(24'hAAAAAA);
    inject_short_rd_pulse(24'h555555);
    inject_short_wr_pulse(24'h800001);
    inject_short_rd_pulse(24'h7FFFFE);

    // ------------------------------------------------------------------
    // 9. Transactions during refresh / busy periods — FSM edge paths
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 9: transactions during busy ==", $time);
    repeat (8) begin
      @(posedge clk_in);
      addr_from_up = $urandom();
      wr_n_from_up = 1'b0;
      rd_n_from_up = 1'b1;
      @(posedge clk_in);
      wr_n_from_up = 1'b1;
      @(posedge clk_in);
      addr_from_up = $urandom();
      rd_n_from_up = 1'b0;
      wr_n_from_up = 1'b1;
      @(posedge clk_in);
      rd_n_from_up = 1'b1;
    end

    // ------------------------------------------------------------------
    // 10. Reset mid-transaction — FSM recovery
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 10: reset mid-transaction ==", $time);
    reset_mid_transaction(24'h005678);
    reset_mid_transaction(24'hAA5555);

    // ------------------------------------------------------------------
    // 11. Re-apply reset, re-initialize, force FSM re-entry
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 11: re-apply reset and re-initialize ==", $time);
    apply_reset();
    wait_for_init();

    do_write(24'h000001);
    do_read (24'h000001);
    do_write(24'hFFFFFF);
    do_read (24'hFFFFFF);
    do_write(24'h123456);
    do_read (24'h654321);
    random_traffic(10);

    // Second full re-initialization
    apply_reset();
    wait_for_init();

    // ------------------------------------------------------------------
    // 12. Boundary and cross-bank address transitions
    //     (ba_bits=2 → 4 banks; bank bits are upper 2 bits of addr_from_up)
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 12: bank boundary / cross-bank ==", $time);
    do_write(24'h000000); // bank 0 start
    do_write(24'h400000); // bank 1 start
    do_write(24'h800000); // bank 2 start
    do_write(24'hC00000); // bank 3 start
    do_read (24'h3FFFFF); // bank 0 end
    do_read (24'h7FFFFF); // bank 1 end
    do_read (24'hBFFFFF); // bank 2 end
    do_read (24'hFFFFFF); // bank 3 end

    // Sequential cross-bank walk
    do_write(24'h3FFFFE);
    do_write(24'h3FFFFF);
    do_write(24'h400000); // crosses bank 0 → bank 1
    do_read (24'h3FFFFE);
    do_read (24'h3FFFFF);
    do_read (24'h400000);

    do_write(24'h7FFFFE);
    do_write(24'h7FFFFF);
    do_write(24'h800000); // crosses bank 1 → bank 2
    do_read (24'h7FFFFE);
    do_read (24'h7FFFFF);
    do_read (24'h800000);

    do_write(24'hBFFFFE);
    do_write(24'hBFFFFF);
    do_write(24'hC00000); // crosses bank 2 → bank 3
    do_read (24'hBFFFFE);
    do_read (24'hBFFFFF);
    do_read (24'hC00000);

    // ------------------------------------------------------------------
    // 13. Random WR/RD with varied idle gaps — slow paths and timeouts
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 13: random WR/RD with varied idle ==", $time);
    repeat (15) begin
      do_write($urandom() & 24'hFFFFFF);
      repeat ($urandom_range(3, 25)) @(posedge clk_in);
      do_read ($urandom() & 24'hFFFFFF);
      repeat ($urandom_range(3, 25)) @(posedge clk_in);
    end

    // ------------------------------------------------------------------
    // 14. Concurrent access with varied spacing — toggle/block coverage
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 14: concurrent accesses with varied spacing ==", $time);
    repeat (6) begin
      do_write(24'h012345);
      repeat (2) @(posedge clk_in);
      do_read (24'h012345);
      repeat (5) @(posedge clk_in);
      do_concurrent_rd_wr(24'h001000, 24'h002000);
      repeat (3) @(posedge clk_in);
      do_concurrent_rd_wr(24'h000000, 24'hFFFFFF);
      repeat (10) @(posedge clk_in);
      do_concurrent_rd_wr(24'h400000, 24'hC00000); // cross-bank concurrent
      repeat (4) @(posedge clk_in);
    end

    // ------------------------------------------------------------------
    // 15. Counter and delay-register toggle coverage
    //     Alternating patterns 0xAA/0x55 maximize bit-level toggle
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 15: counter/delay toggle coverage ==", $time);
    repeat (6) begin
      do_write(24'hAAAAAA);
      @(posedge clk_in);
      do_read (24'h555555);
      @(posedge clk_in);
      do_write(24'h555555);
      @(posedge clk_in);
      do_read (24'hAAAAAA);
      @(posedge clk_in);
    end
    repeat (300) @(posedge clk_in); // let counters roll through their ranges

    // ------------------------------------------------------------------
    // 16. Additional auto-refresh triggering after sustained activity
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 16: additional auto-refresh triggers ==", $time);
    repeat (4000) @(posedge clk_in);
    random_traffic(20);
    repeat (1000) @(posedge clk_in);

    // ------------------------------------------------------------------
    // 17. Final mixed sequences — WR/RD/idle/concurrent to close coverage
    // ------------------------------------------------------------------
    $display("[%0t ns] == PHASE 17: final mixed sequences ==", $time);
    repeat (4) begin
      do_write($urandom() & 24'hFFFFFF);
      do_read ($urandom() & 24'hFFFFFF);
      repeat ($urandom_range(1, 10)) @(posedge clk_in);
      do_concurrent_rd_wr(
        $urandom() & 24'hFFFFFF,
        $urandom() & 24'hFFFFFF
      );
      repeat ($urandom_range(1, 15)) @(posedge clk_in);
    end

    // Short burst of 1-cycle pulses to re-exercise edge detection
    repeat (4) begin
      inject_short_wr_pulse($urandom() & 24'hFFFFFF);
      inject_short_rd_pulse($urandom() & 24'hFFFFFF);
      @(posedge clk_in);
    end

    // Final idle
    repeat (200) @(posedge clk_in);

    $display("[%0t ns] *** dramcntrl_tb complete ***", $time);
    $finish;
  end

endmodule
