`timescale 1ns/1ps

// Stimulus-only testbench for hdbn_top.
// Drives encoder and decoder inputs to maximise UUT coverage across:
//   - HDB3 (encoder_type=3) and HDB2/B3ZS (encoder_type=2) modes
//   - PRBS-7 pseudo-random data, long zero runs, alternating bits, constant 1/0
//   - Clock-enable gating and output-gate control
//   - pulse_active_state inversion
//   - Post-startup error injection (inject_error flag → pulse errors to decoder)
//   - Optional P/N polarity inversion between encoder and decoder outputs
//   - Mid-operation asynchronous resets
//   - Encoder-type boundary / undefined values

module tb_hdbn_top;

    //=========================================================================
    // Parameters
    //=========================================================================
    localparam CLK_PERIOD    = 10;   // ns  (100 MHz)
    localparam STARTUP_DELAY = 64;   // steady-state cycles before error injection

    localparam [1:0] ENC_HDB3 = 2'd3;
    localparam [1:0] ENC_HDB2 = 2'd2;

    //=========================================================================
    // DUT interface
    //=========================================================================
    logic        clk_in;
    logic        reset_in;
    logic [1:0]  encoder_type;
    logic        pulse_active_state;
    logic        clk_enable_in;
    logic        data_in;
    logic        output_gate_in;
    logic        p_out;
    logic        n_out;
    logic        p_in;
    logic        n_in;
    logic        data_out;
    logic        code_error_out;

    //=========================================================================
    // Testbench control signals
    //=========================================================================
    logic        inject_error;    // force p_in=n_in=1 → pulse error in decoder
    logic        invert_polarity; // swap p_out/n_out before feeding decoder
    logic [6:0]  prbs_reg;        // PRBS-7 shift register state

    //=========================================================================
    // DUT instantiation
    //=========================================================================
    hdbn_top uut (
        .reset_in           (reset_in),
        .clk_in             (clk_in),
        .encoder_type       (encoder_type),
        .pulse_active_state (pulse_active_state),
        .clk_enable_in      (clk_enable_in),
        .data_in            (data_in),
        .output_gate_in     (output_gate_in),
        .p_out              (p_out),
        .n_out              (n_out),
        .p_in               (p_in),
        .n_in               (n_in),
        .data_out           (data_out),
        .code_error_out     (code_error_out)
    );

    //=========================================================================
    // Clock generation – 100 MHz
    //=========================================================================
    initial clk_in = 1'b0;
    always #(CLK_PERIOD / 2) clk_in = ~clk_in;

    //=========================================================================
    // Decoder-input routing
    //
    //   inject_error=1   : both p_in and n_in forced high
    //                      → triggers decoder pulse-error detection
    //   invert_polarity=1: p/n swapped → feeds AMI violations to decoder
    //                      → exercises violation-error and zero-count paths
    //   default          : direct loopback from encoder outputs
    //=========================================================================
    always_comb begin
        if (inject_error) begin
            p_in = 1'b1;
            n_in = 1'b1;
        end else if (invert_polarity) begin
            p_in = n_out;
            n_in = p_out;
        end else begin
            p_in = p_out;
            n_in = n_out;
        end
    end

    //=========================================================================
    // PRBS-7  (polynomial x^7 + x^6 + 1, taps at bits [6] and [5])
    // Advances the module-level prbs_reg in place; returns the output bit.
    //=========================================================================
    task automatic prbs7_next(output logic bit_out);
        logic fb;
        fb       = prbs_reg[6] ^ prbs_reg[5];
        bit_out  = prbs_reg[6];
        prbs_reg = {prbs_reg[5:0], fb};
    endtask

    //=========================================================================
    // Stimulus helper tasks
    // All data changes occur on negedge clk to provide setup-time margin.
    //=========================================================================

    // Assert asynchronous reset for n posedge-aligned cycles then release.
    task automatic do_reset(input int n);
        reset_in = 1'b1;
        repeat (n) @(posedge clk_in);
        @(negedge clk_in);
        reset_in = 1'b0;
    endtask

    // Drive n bits of PRBS-7 pseudo-random data.
    task automatic drive_prbs(input int n);
        logic b;
        for (int i = 0; i < n; i++) begin
            @(negedge clk_in);
            prbs7_next(b);
            data_in = b;
        end
    endtask

    // Drive a constant value for n cycles.
    task automatic drive_const(input logic val, input int n);
        for (int i = 0; i < n; i++) begin
            @(negedge clk_in);
            data_in = val;
        end
    endtask

    // Drive alternating 0/1 pattern for n cycles (LSB of cycle index).
    task automatic drive_alternating(input int n);
        for (int i = 0; i < n; i++) begin
            @(negedge clk_in);
            data_in = i[0];
        end
    endtask

    // Drive 'ones' consecutive 1-bits followed by 'zeros' consecutive 0-bits.
    task automatic drive_burst(input int ones, input int zeros);
        for (int i = 0; i < ones;  i++) begin @(negedge clk_in); data_in = 1'b1; end
        for (int i = 0; i < zeros; i++) begin @(negedge clk_in); data_in = 1'b0; end
    endtask

    // Gate clk_enable_in low for off_cycles posedges, then re-enable.
    task automatic gate_clk_enable(input int off_cycles);
        @(negedge clk_in);
        clk_enable_in = 1'b0;
        repeat (off_cycles) @(posedge clk_in);
        @(negedge clk_in);
        clk_enable_in = 1'b1;
    endtask

    //=========================================================================
    // Main test sequence
    //=========================================================================
    initial begin
        // Safe initial state
        reset_in           = 1'b0;
        encoder_type       = ENC_HDB3;
        pulse_active_state = 1'b0;
        clk_enable_in      = 1'b1;
        data_in            = 1'b0;
        output_gate_in     = 1'b1;
        inject_error       = 1'b0;
        invert_polarity    = 1'b0;
        prbs_reg           = 7'h7F;  // non-zero PRBS seed

        //---------------------------------------------------------------------
        // Phase 1 – Power-on reset
        //---------------------------------------------------------------------
        do_reset(8);

        //---------------------------------------------------------------------
        // Phase 2 – HDB3: pseudo-random baseline
        //---------------------------------------------------------------------
        encoder_type       = ENC_HDB3;
        pulse_active_state = 1'b0;
        drive_prbs(256);

        //---------------------------------------------------------------------
        // Phase 3 – HDB3: deterministic zero-burst edge cases
        // Each burst triggers an exact number of B00V / 000V substitutions.
        //---------------------------------------------------------------------
        drive_burst(2, 4);   // 4 zeros → one substitution
        drive_burst(2, 8);   // 8 zeros → two substitutions
        drive_burst(2, 12);
        drive_burst(2, 16);
        drive_burst(1, 32);  // 32 zeros → eight substitutions

        //---------------------------------------------------------------------
        // Phase 4 – HDB3: alternating bits and all-ones
        //---------------------------------------------------------------------
        drive_alternating(128);
        drive_const(1'b1, 64);

        //---------------------------------------------------------------------
        // Phase 5 – HDB3: all-zeros stress (maximum substitution rate)
        //---------------------------------------------------------------------
        drive_const(1'b0, 128);

        //---------------------------------------------------------------------
        // Phase 6 – HDB3: clock-enable gating during active data
        // fork/join: PRBS data thread and periodic gating thread run together.
        //---------------------------------------------------------------------
        fork
            drive_prbs(128);
            begin : clk_gate_thread
                repeat (4) begin
                    repeat (16) @(posedge clk_in);
                    gate_clk_enable(4);
                end
            end
        join

        //---------------------------------------------------------------------
        // Phase 7 – HDB3: output-gate disable / enable
        //---------------------------------------------------------------------
        @(negedge clk_in); output_gate_in = 1'b0;
        drive_prbs(32);
        @(negedge clk_in); output_gate_in = 1'b1;
        drive_prbs(32);

        //---------------------------------------------------------------------
        // Phase 8 – HDB3: inverted pulse_active_state
        //---------------------------------------------------------------------
        pulse_active_state = 1'b1;
        drive_prbs(128);
        drive_const(1'b0, 32);
        drive_alternating(64);
        pulse_active_state = 1'b0;

        //---------------------------------------------------------------------
        // Phase 9 – HDB2/B3ZS: pseudo-random and deterministic patterns
        // Substitution boundary is every 3 zeros.
        //---------------------------------------------------------------------
        encoder_type = ENC_HDB2;
        do_reset(4);
        drive_prbs(256);
        drive_burst(2, 3);   // 3 zeros → one B0V substitution
        drive_burst(2, 6);
        drive_burst(2, 9);
        drive_burst(1, 24);
        drive_burst(1, 48);
        drive_alternating(128);
        drive_const(1'b1, 64);
        drive_const(1'b0, 128);

        //---------------------------------------------------------------------
        // Phase 10 – HDB2: inverted pulse_active_state
        //---------------------------------------------------------------------
        pulse_active_state = 1'b1;
        drive_prbs(128);
        drive_const(1'b0, 48);
        pulse_active_state = 1'b0;

        //---------------------------------------------------------------------
        // Phase 11 – Error injection: HDB3
        // Run STARTUP_DELAY cycles in clean loopback so both encoder and
        // decoder reach steady state, then raise inject_error to force
        // simultaneous p_in=n_in=1 (pulse error) into the decoder.
        //---------------------------------------------------------------------
        encoder_type = ENC_HDB3;
        do_reset(4);
        drive_prbs(STARTUP_DELAY);   // steady-state run
        inject_error = 1'b1;
        drive_prbs(32);              // decoder receives pulse errors
        inject_error = 1'b0;
        drive_prbs(64);              // recovery

        //---------------------------------------------------------------------
        // Phase 12 – Polarity inversion: encoder outputs P/N swapped
        // Exercises decoder violation-error and zero-count-error paths.
        //---------------------------------------------------------------------
        invert_polarity = 1'b1;
        drive_prbs(128);
        drive_const(1'b0, 32);
        drive_burst(2, 4);
        invert_polarity = 1'b0;

        //---------------------------------------------------------------------
        // Phase 13 – Error injection: HDB2
        //---------------------------------------------------------------------
        encoder_type = ENC_HDB2;
        do_reset(4);
        drive_prbs(STARTUP_DELAY);
        inject_error = 1'b1;
        drive_prbs(32);
        inject_error = 1'b0;
        drive_prbs(64);

        //---------------------------------------------------------------------
        // Phase 14 – Mid-operation asynchronous resets
        // Verifies that each sub-module resets cleanly and restarts correctly.
        //---------------------------------------------------------------------
        encoder_type = ENC_HDB3;
        drive_prbs(32);
        do_reset(2);
        drive_prbs(32);
        do_reset(2);
        drive_const(1'b0, 32);
        do_reset(2);
        drive_alternating(32);

        //---------------------------------------------------------------------
        // Phase 15 – Clock enable fully gated then resumed
        //---------------------------------------------------------------------
        clk_enable_in = 1'b0;
        repeat (16) @(posedge clk_in);
        clk_enable_in = 1'b1;
        drive_prbs(64);

        //---------------------------------------------------------------------
        // Phase 16 – encoder_type boundary / undefined values
        //---------------------------------------------------------------------
        encoder_type = 2'd0;
        drive_prbs(32);
        encoder_type = 2'd1;
        drive_prbs(32);

        //---------------------------------------------------------------------
        // Phase 17 – Combined stress: inject_error and invert_polarity
        // Exercises overlapping error conditions with active substitution.
        //---------------------------------------------------------------------
        encoder_type       = ENC_HDB3;
        pulse_active_state = 1'b0;
        output_gate_in     = 1'b1;
        do_reset(4);
        drive_prbs(STARTUP_DELAY);
        inject_error = 1'b1;
        drive_burst(1, 4);           // pulse error while zero burst is active
        inject_error = 1'b0;
        invert_polarity = 1'b1;
        drive_prbs(64);
        invert_polarity = 1'b0;
        drive_prbs(64);

        //---------------------------------------------------------------------
        // Phase 18 – Final long PRBS run with alternative seed
        // Second pass through the full PRBS-7 state space.
        //---------------------------------------------------------------------
        encoder_type       = ENC_HDB3;
        pulse_active_state = 1'b0;
        do_reset(4);
        prbs_reg = 7'h55;            // different seed → different sequence
        drive_prbs(512);

        // Allow pipeline to flush (encoder + decoder = 12 cycle latency)
        repeat (20) @(posedge clk_in);
        $finish;
    end

endmodule
