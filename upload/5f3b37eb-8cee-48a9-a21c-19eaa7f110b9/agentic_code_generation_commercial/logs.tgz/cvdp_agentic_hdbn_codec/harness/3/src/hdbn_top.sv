module hdbn_top
(
    input  logic reset_in,                      // Active high async reset
    input  logic clk_in,                        // Rising edge clock
    input  logic pulse_active_state,                        // Rising edge clock
    input  logic [1:0] encoder_type,                        // Rising edge clock
    input  logic clk_enable_in,                 // Active high clock enable
    input  logic data_in,                       // Active high data input
    input  logic output_gate_in,                // '0' forces p and n to not pulse_active_state
    output logic p_out,                         // Encoded +ve pulse output
    output logic n_out,                         // Encoded -ve pulse output
    input  logic p_in,                          // +ve pulse input
    input  logic n_in,                          // -ve pulse input
    output logic data_out,                      // Active high data output
    output logic code_error_out                 // Active high error indicator
);

    // Instantiate the HDB3/HDB2 encoder
    hdbn_encoder 
     encoder_uut (
        .reset_in(reset_in),
        .clk_in(clk_in),
        .pulse_active_state(pulse_active_state),
        .encoder_type(encoder_type),
        .clk_enable_in(clk_enable_in),
        .data_in(data_in),
        .output_gate_in(output_gate_in),
        .p_out(p_out),
        .n_out(n_out)
    );

    // Instantiate the HDB3/HDB2 decoder
    hdbn_decoder 
     decoder_uut (
        .reset_in(reset_in),
        .clk_in(clk_in),
        .encoder_type(encoder_type),
        .pulse_active_state(pulse_active_state),
        .p_in(p_in),
        .n_in(n_in),
        .data_out(data_out),
        .code_error_out(code_error_out)
    );

endmodule
