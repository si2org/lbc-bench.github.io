module hdbn_decoder
(
    input  logic reset_in,                      // Active high async reset
    input  logic clk_in,                        // Rising edge clock
    input  logic pulse_active_state,                        // Rising edge clock
    input  logic [1:0] encoder_type,                        // Rising edge clock
    input  logic p_in,                          // +ve pulse input
    input  logic n_in,                          // -ve pulse input
    output logic data_out,                      // Active high data output
    output logic code_error_out                 // Active high error indicator
);

    logic pin_raw, nin_raw;                     // Registered p and n inputs
    logic pin, nin;                             // Polarity-corrected p and n inputs
    logic violation;                            // Pulse violation detected
    logic last_pulse_polarity;                  // Last pulse sense (1=p, 0=n)
    logic last_violation_polarity;              // Last violation sense
    logic q1, q2, q3;                           // Shift register for aligning data
    logic violation_error;                      // Indicates bad violation
    logic [1:0] zero_count;                     // Counts 0s in input (0 to 3)
    logic too_many_zeros;                       // Indicates 4 consecutive zeros
    logic pulse_error;                          // Indicates simultaneous p and n pulse

    // register_input: DFF to register p and n inputs
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) begin
            pin_raw <= 1'b0;
            nin_raw <= 1'b0;
        end
        else  begin
            pin_raw <= p_in;
            nin_raw <= n_in;
        end
    end

    // restore_active_low: Convert pulse inputs to active high for internal use
    assign pin = pin_raw ^ ~pulse_active_state;
    assign nin = nin_raw ^ ~pulse_active_state;

    // decode_violation: Detect pulse violations and remember last pulse polarity
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            last_pulse_polarity <= 1'b0;
        else begin
            case ({pin, nin})
                2'b00: last_pulse_polarity <= last_pulse_polarity; // Hold
                2'b10: last_pulse_polarity <= 1'b1;                // Set
                2'b01: last_pulse_polarity <= 1'b0;                // Reset
                default: last_pulse_polarity <= 1'b0;              // Don't care
            endcase
        end
    end

    assign violation = (pin & last_pulse_polarity) | (nin & ~last_pulse_polarity);

    // delay_data: Delay data input to align with violation signal
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) begin
            q1 <= 1'b0;
            q2 <= 1'b0;
            q3 <= 1'b0;
        end
        else  begin
            q1 <= (pin | nin) & ~violation;     // Delete V bit
            q2 <= q1;
            if (encoder_type == 3) 
                q3 <= q2;                       // HDB3: Delay by 3 clocks
            else 
                q3 <= q1;                       // HDB2: Delay by 2 clocks
        end
    end

    // decode_data: Remove B bits from data and register output
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            data_out <= 1'b0;
        else  
            data_out <= q3 & ~violation;        // Delete B bit
    end

    // count_zeros: Count number of contiguous zeros in input (mod 3 or 4)
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            zero_count <= 2'b00;
        else if ((encoder_type == 2'd2 || encoder_type == 2'd3)) begin
            if (pin | nin) 
                zero_count <= 2'b00;            // Reset count if '1' is seen
            else if (zero_count >= encoder_type) 
                zero_count <= encoder_type;     // Hold
            else 
                zero_count <= zero_count + 1;   // Increment
        end
    end

    // decode_violation_error: Remember polarity of this violation
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            last_violation_polarity <= 1'b0;
        else begin
            if (violation) 
                last_violation_polarity <= last_pulse_polarity;
            else 
                last_violation_polarity <= last_violation_polarity; // Latch
        end
    end

    // error_detection: Combine all error conditions
    assign violation_error = violation & ~(pin ^ last_violation_polarity);
    assign pulse_error = pin & nin;
    assign too_many_zeros = ~(pin | nin) & (zero_count == encoder_type && (encoder_type == 2'd2 || encoder_type == 2'd3));

    // register_code_error: Combine all error signals and register the output
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            code_error_out <= 1'b0;
        else  
            code_error_out <= violation_error | pulse_error | too_many_zeros;
    end

endmodule
