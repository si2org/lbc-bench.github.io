module hdbn_encoder
(
    input  logic reset_in,                      // Active high async reset
    input  logic clk_in,                        // Rising edge clock
    input  logic pulse_active_state,                        // Rising edge clock
    input  logic [1:0] encoder_type,                        // Rising edge clock
    input  logic clk_enable_in,                 // Active high clock enable
    input  logic data_in,                       // Active high data input
    input  logic output_gate_in,                // '0' forces p and n to not pulse_active_state
    output logic p_out,                         // Encoded +ve pulse output
    output logic n_out                          // Encoded -ve pulse output
);

    logic q1, q2, q3, q4, q5;                  // Shift register for aligning data
    logic ami;                                  // Sense of pulse (p or n)
    logic violation_type;                       // Sense of violation
    logic [1:0] zero_count;                     // Counts 0s in input (0 to 3)
    logic zero_string;                          // Goes to '1' when 3 or 4 0s seen
    logic zero_string_delayed;                  // zero_string delayed by 1 clock

    // register_input: DFF to register input data
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            q1 <= 1'b0;
        else if (clk_enable_in) 
            q1 <= data_in;
    end

    // count_zeros: Count number of contiguous zeros in input (mod 3 or 4)
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            zero_count <= 2'b00;
        else if (clk_enable_in && (encoder_type == 2'd2 || encoder_type == 2'd3)) begin
            if (q1) 
                zero_count <= 2'b00;            // Reset count if '1' is seen
            else if (zero_count >= encoder_type) 
                zero_count <= 2'b00;            // Modulo reset
            else 
                zero_count <= zero_count + 1;   // Increment
        end
    end

    // decode_count: Combinatorial logic to detect zero_string
    assign zero_string = (zero_count == encoder_type && (encoder_type == 2'd2 || encoder_type == 2'd3)) && !q1;

    // register_zero_string: DFF to register zero_string
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            zero_string_delayed <= 1'b0;
        else if (clk_enable_in) 
            zero_string_delayed <= zero_string;
    end

    // delay_data: Insert 1 if needed for violation, and delay data
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) begin
            q2 <= 1'b0;
            q3 <= 1'b0;
            q4 <= 1'b0;
        end
        else if (clk_enable_in) begin
            q2 <= q1 | zero_string;            // Insert Violation bit
            q3 <= q2;
            if (encoder_type == 3) 
                q4 <= q3;                      // HDB3: Delay by 3 clocks
            else 
                q4 <= q2;                      // HDB2: Delay by 2 clocks
        end
    end

    // insert_b_bit: Delay q4 by one clock, and insert B bit if needed
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            q5 <= 1'b0;
        else if (clk_enable_in) 
            q5 <= q4 | (zero_string & ~violation_type);
    end

    // toggle_violation_type: Toggle violation_type whenever q5 is 1
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            violation_type <= 1'b0;
        else if (clk_enable_in) 
            violation_type <= violation_type ^ q5;
    end

    // ami_flip_flop: Toggle ami to alternate p and n pulses
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) 
            ami <= 1'b0;
        else if (clk_enable_in) 
            ami <= ami ^ (q5 & ~(violation_type & (zero_string | zero_string_delayed)));
    end

    // make_p_and_n_pulses: Gate q5 with ami to produce p and n outputs
    always_ff @(posedge clk_in or posedge reset_in) begin
        if (reset_in) begin
            p_out <= ~pulse_active_state;
            n_out <= ~pulse_active_state;
        end
        else if (clk_enable_in || !output_gate_in) begin
            if (!output_gate_in) begin
                p_out <= ~pulse_active_state;
                n_out <= ~pulse_active_state;
            end
            else if (q5) begin
                if (ami) begin
                    p_out <= pulse_active_state;
                    n_out <= ~pulse_active_state;
                end
                else begin
                    p_out <= ~pulse_active_state;
                    n_out <= pulse_active_state;
                end
            end
            else begin
                p_out <= ~pulse_active_state;
                n_out <= ~pulse_active_state;
            end
        end
    end

endmodule
