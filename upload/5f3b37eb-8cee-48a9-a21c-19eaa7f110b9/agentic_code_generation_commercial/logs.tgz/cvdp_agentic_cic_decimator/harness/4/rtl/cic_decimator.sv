module cic_decimator #(
    parameter int WIDTH     = 16,
    parameter int RMAX      = 2,
    parameter int M         = 1,
    parameter int N         = 2,
    parameter int REG_WIDTH = WIDTH + $clog2((RMAX * M)**N)
) (
    input  logic                      clk,
    input  logic                      rst,
    input  logic [WIDTH-1:0]          input_tdata,
    input  logic                      input_tvalid,
    input  logic                      output_tready,
    input  logic [$clog2(RMAX+1)-1:0] rate,
    output logic                      input_tready,
    output logic [REG_WIDTH-1:0]      output_tdata,
    output logic                      output_tvalid
);

    
    logic [$clog2(RMAX+1)-1:0] cycle_reg;
    logic [REG_WIDTH-1:0] int_reg [0:N-1];
    logic [REG_WIDTH-1:0] comb_reg [0:N-1];

    
    logic [REG_WIDTH-1:0] int_reg_0 = int_reg[0];
    logic [REG_WIDTH-1:0] int_reg_1 = int_reg[1];
    logic [REG_WIDTH-1:0] comb_reg_0 = comb_reg[0];
    logic [REG_WIDTH-1:0] comb_reg_1 = comb_reg[1];

    assign input_tready  = output_tready || (cycle_reg != 0);
    assign output_tdata  = comb_reg[N-1];
    assign output_tvalid = input_tvalid && (cycle_reg == 0);

    
    initial begin
        cycle_reg = 0;
        for (int i = 0; i < N; i++) begin
            int_reg[i]  = 0;
            comb_reg[i] = 0;
        end
    end

    
    genvar k;
    generate
        for (k = 0; k < N; k++) begin : integrator
            always_ff @(posedge clk) begin
                if (rst) begin
                    int_reg[k] <= 0;
                end else begin
                    if (input_tready && input_tvalid) begin
                        if (k == 0) begin
                            int_reg[k] <= $signed(int_reg[k]) + $signed(input_tdata);
                        end else begin
                            int_reg[k] <= $signed(int_reg[k]) + $signed(int_reg[k-1]);
                        end
                    end
                end
            end
        end
    endgenerate

    
    generate
        for (k = 0; k < N; k++) begin : comb
            logic [REG_WIDTH-1:0] delay_reg [0:M-1];

            
            initial begin
                for (int i = 0; i < M; i++) begin
                    delay_reg[i] = 0;
                end
            end

            always_ff @(posedge clk) begin
                if (rst) begin
                    for (int i = 0; i < M; i++) begin
                        delay_reg[i] <= 0;
                    end
                    comb_reg[k] <= 0;
                end else begin
                    if (output_tready && output_tvalid) begin
                        if (k == 0) begin
                            delay_reg[0] <= $signed(int_reg[N-1]);
                            comb_reg[k] <= $signed(int_reg[N-1]) - $signed(delay_reg[M-1]);
                        end else begin
                            delay_reg[0] <= $signed(comb_reg[k-1]);
                            comb_reg[k] <= $signed(comb_reg[k-1]) - $signed(delay_reg[M-1]);
                        end
                        for (int i = 0; i < M-1; i++) begin
                            delay_reg[i+1] <= delay_reg[i];
                        end
                    end
                end
            end
        end
    endgenerate


    always_ff @(posedge clk) begin
        if (rst) begin
            cycle_reg <= 0;
        end else begin
            if (input_tready && input_tvalid) begin
                if ((cycle_reg < RMAX - 1) && (cycle_reg < rate - 1)) begin
                    cycle_reg <= cycle_reg + 1;
                end else begin
                    cycle_reg <= 0;
                end
            end
        end
    end

    // =========================================================================
    // SystemVerilog Assertions (SVA)
    // =========================================================================

    // Reset Cycle Register: synchronous rst must zero cycle_reg on the next edge
    a_rst_cycle_reg: assert property (
        @(posedge clk) rst |=> (cycle_reg == 0)
    ) else $error("ASSERT FAIL [a_rst_cycle_reg]: cycle_reg not reset to 0 when rst asserted");

    // Reset Integrator Register 0
    a_rst_int_reg_0: assert property (
        @(posedge clk) rst |=> (int_reg[0] == 0)
    ) else $error("ASSERT FAIL [a_rst_int_reg_0]: int_reg[0] not reset to 0 when rst asserted");

    // Reset Integrator Register 1
    a_rst_int_reg_1: assert property (
        @(posedge clk) rst |=> (int_reg[1] == 0)
    ) else $error("ASSERT FAIL [a_rst_int_reg_1]: int_reg[1] not reset to 0 when rst asserted");

    // Reset Comb Register 0
    a_rst_comb_reg_0: assert property (
        @(posedge clk) rst |=> (comb_reg[0] == 0)
    ) else $error("ASSERT FAIL [a_rst_comb_reg_0]: comb_reg[0] not reset to 0 when rst asserted");

    // Reset Comb Register 1
    a_rst_comb_reg_1: assert property (
        @(posedge clk) rst |=> (comb_reg[1] == 0)
    ) else $error("ASSERT FAIL [a_rst_comb_reg_1]: comb_reg[1] not reset to 0 when rst asserted");

    // Output Valid Signal Constraint: output_tvalid may only be high when cycle_reg == 0
    a_output_valid: assert property (
        @(posedge clk) disable iff (rst)
        output_tvalid |-> (cycle_reg == 0)
    ) else $error("ASSERT FAIL [a_output_valid]: output_tvalid asserted when cycle_reg != 0");

    // Input Ready Signal Relation: input_tready == (output_tready || (cycle_reg != 0))
    a_input_ready: assert property (
        @(posedge clk) disable iff (rst)
        (input_tready == (output_tready || (cycle_reg != 0)))
    ) else $error("ASSERT FAIL [a_input_ready]: input_tready incorrectly driven");

    // Cycle Counter Behavior: check increment-or-wrap on valid input transfer
    a_cycle_counter: assert property (
        @(posedge clk) disable iff (rst)
        (input_tvalid && input_tready) |=>
        ((($past(cycle_reg) < (RMAX - 1)) && ($past(cycle_reg) < ($past(rate) - 1))) ?
         (cycle_reg == $past(cycle_reg) + 1) : (cycle_reg == 0))
    ) else $error("ASSERT FAIL [a_cycle_counter]: cycle_reg not correctly updated on valid input transfer");

    // Integrator Stage 0 Update: int_reg[0] += input_tdata on valid input transfer
    a_int_reg_0_update: assert property (
        @(posedge clk) disable iff (rst)
        (input_tvalid && input_tready) |=>
        (int_reg[0] == $signed($past(int_reg[0])) + $signed($past(input_tdata)))
    ) else $error("ASSERT FAIL [a_int_reg_0_update]: int_reg[0] not correctly updated on valid input transfer");

    // Integrator Stage 1 Update: int_reg[1] += int_reg[0] on valid input transfer
    a_int_reg_1_update: assert property (
        @(posedge clk) disable iff (rst)
        (input_tvalid && input_tready) |=>
        (int_reg[1] == $signed($past(int_reg[1])) + $signed($past(int_reg[0])))
    ) else $error("ASSERT FAIL [a_int_reg_1_update]: int_reg[1] not correctly updated on valid input transfer");

    // Comb Stage 0 Update: comb_reg[0] = int_reg[N-1] - comb[0].delay_reg[M-1] on valid output transfer
    a_comb_reg_0_update: assert property (
        @(posedge clk) disable iff (rst)
        (output_tvalid && output_tready) |=>
        (comb_reg[0] == $signed($past(int_reg[N-1])) - $signed($past(comb[0].delay_reg[M-1])))
    ) else $error("ASSERT FAIL [a_comb_reg_0_update]: comb_reg[0] not correctly updated on valid output transfer");

    // Comb Stage 1 Update: comb_reg[1] = comb_reg[0] - comb[1].delay_reg[M-1] on valid output transfer
    a_comb_reg_1_update: assert property (
        @(posedge clk) disable iff (rst)
        (output_tvalid && output_tready) |=>
        (comb_reg[1] == $signed($past(comb_reg[0])) - $signed($past(comb[1].delay_reg[M-1])))
    ) else $error("ASSERT FAIL [a_comb_reg_1_update]: comb_reg[1] not correctly updated on valid output transfer");

endmodule
