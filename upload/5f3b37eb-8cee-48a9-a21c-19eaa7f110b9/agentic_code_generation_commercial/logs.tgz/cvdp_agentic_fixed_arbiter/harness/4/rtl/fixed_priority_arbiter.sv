`timescale 1ns / 1ps
module fixed_priority_arbiter(
    input clk,                      // Clock signal
    input reset,                    // Active high reset signal
    input [7:0] req,                // 8-bit request signal; each bit represents a request from a different source
    input [7:0] priority_override,  // External priority override signal

    output reg [7:0] grant,         // 8-bit grant signal; only one bit will be set high based on priority
    output reg valid,               // Indicates if a request is granted
    output reg [2:0] grant_index    // Outputs the granted request index in binary format
); 

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            grant <= 8'b00000000;
            valid <= 1'b0;
            grant_index <= 3'b000;
        end 
        else begin
            if (priority_override != 8'b00000000) begin
                grant <= priority_override; 
                valid <= 1'b1;
                grant_index <= (priority_override[0] ? 3'd0 :
                                priority_override[1] ? 3'd1 :
                                priority_override[2] ? 3'd2 :
                                priority_override[3] ? 3'd3 :
                                priority_override[4] ? 3'd4 :
                                priority_override[5] ? 3'd5 :
                                priority_override[6] ? 3'd6 :
                                priority_override[7] ? 3'd7 : 3'd0);
            end
            else if (req[0]) begin
                grant <= 8'b00000001;
                grant_index <= 3'd0;
                valid <= 1'b1;
            end 
            else if (req[1]) begin
                grant <= 8'b00000010;
                grant_index <= 3'd1;
                valid <= 1'b1;
            end 
            else if (req[2]) begin
                grant <= 8'b00000100;
                grant_index <= 3'd2;
                valid <= 1'b1;
            end 
            else if (req[3]) begin
                grant <= 8'b00001000;
                grant_index <= 3'd3;
                valid <= 1'b1;
            end 
            else if (req[4]) begin
                grant <= 8'b00010000;
                grant_index <= 3'd4;
                valid <= 1'b1;
            end 
            else if (req[5]) begin
                grant <= 8'b00100000;
                grant_index <= 3'd5;
                valid <= 1'b1;
            end 
            else if (req[6]) begin
                grant <= 8'b01000000;
                grant_index <= 3'd6;
                valid <= 1'b1;
            end 
            else if (req[7]) begin
                grant <= 8'b10000000;
                grant_index <= 3'd7;
                valid <= 1'b1;
            end 
            else begin
                grant <= 8'b00000000;
                grant_index <= 3'd0;
                valid <= 1'b0;
            end
        end
    end

    // -------------------------------------------------------------------------
    // SystemVerilog Assertions
    //
    // Outputs are registered: at posedge clk[N] the preponed-region sample of
    // grant/valid/grant_index reflects inputs captured at posedge clk[N-1].
    // $past(signal) inside a clocked property returns the value at the previous
    // clock tick, so it matches the inputs that produced the current output.
    // -------------------------------------------------------------------------

    // Assertion 1 — Single Grant Validity (one-hot when valid)
    property p_single_grant;
        @(posedge clk) disable iff (reset)
        valid |-> $onehot(grant);
    endproperty
    a_single_grant: assert property (p_single_grant)
        else $error("Assertion Failed: More than one grant active when valid = 1.");

    // Assertion 2 — Priority-Based Arbitration (no override)
    property p_fixed_priority;
        @(posedge clk) disable iff (reset)
        (!$past(reset) && $past(priority_override) == 8'b0 && valid) |->
            ($past(req[0]) ? grant == 8'b00000001 :
             $past(req[1]) ? grant == 8'b00000010 :
             $past(req[2]) ? grant == 8'b00000100 :
             $past(req[3]) ? grant == 8'b00001000 :
             $past(req[4]) ? grant == 8'b00010000 :
             $past(req[5]) ? grant == 8'b00100000 :
             $past(req[6]) ? grant == 8'b01000000 :
             $past(req[7]) ? grant == 8'b10000000 : 1'b1);
    endproperty
    a_fixed_priority: assert property (p_fixed_priority)
        else $error("Assertion Failed: Grant does not match request with no override.");

    // Assertion 3 — Priority Override Enforcement
    property p_override;
        @(posedge clk) disable iff (reset)
        (!$past(reset) && $past(priority_override) != 8'b0) |->
            (grant == $past(priority_override));
    endproperty
    a_override: assert property (p_override)
        else $error("Assertion Failed: Priority override is asserted but grant does not match.");

    // Assertion 4 — Correct Grant Index Encoding
    property p_grant_index;
        @(posedge clk) disable iff (reset)
        valid |->
            (grant[0] ? grant_index == 3'd0 :
             grant[1] ? grant_index == 3'd1 :
             grant[2] ? grant_index == 3'd2 :
             grant[3] ? grant_index == 3'd3 :
             grant[4] ? grant_index == 3'd4 :
             grant[5] ? grant_index == 3'd5 :
             grant[6] ? grant_index == 3'd6 :
             grant[7] ? grant_index == 3'd7 : 1'b1);
    endproperty
    a_grant_index: assert property (p_grant_index)
        else $error("Assertion Failed: grant_index does not match the granted bit.");

endmodule