`timescale 1ns / 1ps

module fixed_priority_arbiter_tb;

    // Parameters
    localparam CLK_PERIOD = 10;

    // Signals
    reg clk;
    reg reset;
    reg [7:0] req;
    reg [7:0] priority_override;
    wire [7:0] grant;
    wire       valid;
    wire [2:0] grant_index;

    // Instantiate DUT
    fixed_priority_arbiter dut (
        .clk(clk),
        .reset(reset),
        .req(req),
        .priority_override(priority_override),
        .grant(grant),
        .valid(valid),
        .grant_index(grant_index)
    );

    // Clock generation
    always #(CLK_PERIOD / 2) clk = ~clk;

    // Task: Apply reset
    task apply_reset;
        begin
            reset = 1;
            #(2 * CLK_PERIOD);
            reset = 0;
        end
    endtask

    // Task: Apply request and priority override, wait one cycle, and display result
    task drive_input(input [7:0] request, input [7:0] override);
        begin
            req               = request;
            priority_override = override;
            #(CLK_PERIOD);

            $display("Time=%0t | reset=%b | req=%b | priority_override=%b | grant=%b | valid=%b | grant_index=%0d",
                     $time, reset, req, priority_override, grant, valid, grant_index);
        end
    endtask

    // Main test sequence
    initial begin
        // Initialize signals
        clk               = 0;
        req               = 8'b00000000;
        priority_override = 8'b00000000;

        // Apply reset
        apply_reset;
        $display("Test: Reset complete\n");

        // Test Case 1: Single request (each bit)
        drive_input(8'b00000001, 8'b00000000);  
        drive_input(8'b00000010, 8'b00000000);  
        drive_input(8'b00000100, 8'b00000000);  
        drive_input(8'b00001000, 8'b00000000);  
        drive_input(8'b00010000, 8'b00000000);  
        drive_input(8'b00100000, 8'b00000000);  
        drive_input(8'b01000000, 8'b00000000);  
        drive_input(8'b10000000, 8'b00000000);  
        drive_input(8'b00000000, 8'b00000000);  

        // Test Case 2: Multiple requests, no override
        drive_input(8'b00111000, 8'b00000000);  
        drive_input(8'b00000000, 8'b00000000); 
        drive_input(8'b10000000, 8'b00000000);  

        // Test Case 3: Priority override only
        drive_input(8'b11111111, 8'b00000001);  
        drive_input(8'b11111111, 8'b00000010);  
        drive_input(8'b11111111, 8'b00000100);  
        drive_input(8'b11111111, 8'b00001000);  
        drive_input(8'b11111111, 8'b10000000);  
        drive_input(8'b00000000, 8'b00000000); 

        // Test Case 4: No requests or overrides
        drive_input(8'b00000000, 8'b00000000); 

        // Test Case 5: Override wins over req
        drive_input(8'b00000000, 8'b11111111);  

        apply_reset;

        // Test Case 6: Fluctuating requests
        drive_input(8'b00000001, 8'b00000000);  
        drive_input(8'b00000010, 8'b00000000); 
        drive_input(8'b00000001, 8'b00000000);  

        $display("All test cases completed.");
        $finish;
    end

  
endmodule