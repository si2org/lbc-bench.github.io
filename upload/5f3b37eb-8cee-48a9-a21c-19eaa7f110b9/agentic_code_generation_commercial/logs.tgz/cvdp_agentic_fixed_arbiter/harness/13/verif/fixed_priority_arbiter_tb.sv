`timescale 1ns / 1ps

module fixed_priority_arbiter_tb;

    // Parameters
    localparam CLK_PERIOD = 10;

    // Signals
    reg clk;
    reg reset;
    reg [7:0] req;
    reg [7:0] priority_override;
    wire [7:0] grant;
    wire       valid;
    wire [2:0] grant_index;

    // Instantiate DUT
    fixed_priority_arbiter dut (
        .clk(clk),
        .reset(reset),
        .req(req),
        .priority_override(priority_override),
        .grant(grant),
        .valid(valid),
        .grant_index(grant_index)
    );

    // Clock generation
    always #(CLK_PERIOD / 2) clk = ~clk;

    // Task: Apply reset
    task apply_reset;
        begin
            reset = 1;
            #(2 * CLK_PERIOD);
            reset = 0;
        end
    endtask

    // Task: Validate that all outputs are cleared after reset
    task check_reset_outputs;
        begin
            if (grant !== 8'b0 || grant_index !== 3'b0 || valid !== 1'b0) begin
                $display("FAIL: After reset | grant=%b | valid=%b | grant_index=%0d | Expected all zeros",
                         grant, valid, grant_index);
                $error("Reset validation failed: outputs not cleared after reset");
                $finish(1);
            end else begin
                $display("PASS: Reset validated | grant=%b | valid=%b | grant_index=%0d",
                         grant, valid, grant_index);
            end
        end
    endtask

    // Task: Apply request and priority override, verify outputs against expected values
    task run_test;
        input [7:0] request;
        input [7:0] override;

        reg [7:0] exp_grant;
        reg [2:0] exp_grant_index;
        reg       exp_valid;
        integer   i;
        integer   pass;

        begin
            req               = request;
            priority_override = override;
            #(CLK_PERIOD);

            // Compute expected outputs:
            // If priority_override is non-zero, grant lowest-index active bit in override.
            // Otherwise, if req is non-zero, grant lowest-index active bit in req.
            exp_grant       = 8'b0;
            exp_grant_index = 3'b0;
            exp_valid       = 1'b0;

            if (override != 8'b0) begin
                for (i = 0; i < 8; i = i + 1) begin
                    if (override[i] && !exp_valid) begin
                        exp_grant       = 8'b1 << i;
                        exp_grant_index = i[2:0];
                        exp_valid       = 1'b1;
                    end
                end
            end else if (request != 8'b0) begin
                for (i = 0; i < 8; i = i + 1) begin
                    if (request[i] && !exp_valid) begin
                        exp_grant       = 8'b1 << i;
                        exp_grant_index = i[2:0];
                        exp_valid       = 1'b1;
                    end
                end
            end

            pass = 1;

            // Validate that valid is asserted only when a request or override is active
            if (valid !== exp_valid) begin
                $display("FAIL: Time=%0t | req=%b | override=%b | Expected valid=%b, Got valid=%b",
                         $time, request, override, exp_valid, valid);
                pass = 0;
            end

            // Verify grant output matches expected
            if (grant !== exp_grant) begin
                $display("FAIL: Time=%0t | req=%b | override=%b | Expected grant=%b, Got grant=%b",
                         $time, request, override, exp_grant, grant);
                pass = 0;
            end

            // Check that grant is one-hot encoded when a grant is issued
            if (valid && !$onehot(grant)) begin
                $display("FAIL: Time=%0t | req=%b | override=%b | grant=%b is not one-hot encoded",
                         $time, request, override, grant);
                pass = 0;
            end

            // Verify grant_index matches the position of the granted bit
            if (grant_index !== exp_grant_index) begin
                $display("FAIL: Time=%0t | req=%b | override=%b | Expected grant_index=%0d, Got grant_index=%0d",
                         $time, request, override, exp_grant_index, grant_index);
                pass = 0;
            end

            if (pass) begin
                $display("PASS: Time=%0t | req=%b | override=%b | grant=%b | valid=%b | grant_index=%0d",
                         $time, request, override, grant, valid, grant_index);
            end else begin
                $error("Test FAILED at Time=%0t: req=%b, override=%b | grant=%b | valid=%b | grant_index=%0d",
                       $time, request, override, grant, valid, grant_index);
                $finish(1);
            end
        end
    endtask

    // Main test sequence
    initial begin
        // Initialize signals
        clk               = 0;
        req               = 8'b00000000;
        priority_override = 8'b00000000;

        // Apply reset and validate outputs are cleared
        apply_reset;
        check_reset_outputs;
        $display("Test: Reset complete\n");

        // Test Case 1: Single request (each bit)
        run_test(8'b00000001, 8'b00000000);
        run_test(8'b00000010, 8'b00000000);
        run_test(8'b00000100, 8'b00000000);
        run_test(8'b00001000, 8'b00000000);
        run_test(8'b00010000, 8'b00000000);
        run_test(8'b00100000, 8'b00000000);
        run_test(8'b01000000, 8'b00000000);
        run_test(8'b10000000, 8'b00000000);
        run_test(8'b00000000, 8'b00000000);

        // Test Case 2: Multiple requests, no override
        run_test(8'b00111000, 8'b00000000);
        run_test(8'b00000000, 8'b00000000);
        run_test(8'b10000000, 8'b00000000);

        // Test Case 3: Priority override only
        run_test(8'b11111111, 8'b00000001);
        run_test(8'b11111111, 8'b00000010);
        run_test(8'b11111111, 8'b00000100);
        run_test(8'b11111111, 8'b00001000);
        run_test(8'b11111111, 8'b10000000);
        run_test(8'b00000000, 8'b00000000);

        // Test Case 4: No requests or overrides
        run_test(8'b00000000, 8'b00000000);

        // Test Case 5: Override wins over req
        run_test(8'b00000000, 8'b11111111);

        // Apply second reset and validate outputs are cleared
        apply_reset;
        check_reset_outputs;

        // Test Case 6: Fluctuating requests
        run_test(8'b00000001, 8'b00000000);
        run_test(8'b00000010, 8'b00000000);
        run_test(8'b00000001, 8'b00000000);

        $display("All test cases completed.");
        $finish;
    end


endmodule
