import cocotb
from cocotb.utils import get_sim_time
from cocotb.triggers import RisingEdge, Timer
from cocotb.clock import Clock

CLK_PERIOD = 10  # 100 MHz clock period

@cocotb.test()
async def axi4lite_test(dut):
    """Test AXI4-Lite to PCIe Configuration Bridge"""
    await Timer(1, unit='us')  # Increase delay to allow setup
    # Generate Clock
    cocotb.start_soon(Clock(dut.aclk, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())

    # Reset sequence
    dut.aresetn.value = 0
    dut.awvalid.value = 0
    dut.wvalid.value = 0
    dut.bready.value = 0
    dut.arvalid.value = 0
    dut.rready.value = 0
    await Timer(50, unit="ns")  # Hold reset
    dut.aresetn.value = 1
    await Timer(10, unit="ns")  # Wait after reset

    cocotb.log.info("Reset complete. Starting AXI4-Lite test.")

    # ============================================
    # WRITE TRANSACTION: Check awready and wready
    # ============================================
    cocotb.log.info("Starting AXI4-Lite write transaction...")

    dut.awvalid.value = 1
    dut.awaddr.value = 0x10
    dut.wvalid.value = 1
    dut.wdata.value = 0xDEADBEEF
    dut.wstrb.value = 0xF  # Enable all bytes

    # Wait for `awready` within 5 cycles
    for _ in range(5):  
        await RisingEdge(dut.aclk)
        if dut.awready.value == 1:
            break
    else:
        assert ("ERROR: awready not asserted within 5 cycles after awvalid")

    assert dut.wready.value == 1, "ERROR: wready not asserted after wvalid"

    # Deassert valid signals
    dut.awvalid.value = 0
    dut.wvalid.value = 0
    await RisingEdge(dut.aclk)

    # Check `bvalid` within 5 cycles
    for _ in range(5):
        await RisingEdge(dut.aclk)
        if dut.bvalid.value == 1:
            break
    else:
        assert ("ERROR: bvalid not asserted within 5 cycles after wvalid")

    # Acknowledge response
    dut.bready.value = 1
    await RisingEdge(dut.aclk)  # Give RTL time to respond
    await RisingEdge(dut.aclk)  # Extra cycle to ensure `bvalid` is cleared

    assert dut.bvalid.value == 0, "ERROR: bvalid not deasserted after bready"

    dut.bready.value = 0
    cocotb.log.info("Write transaction passed.")

    # ================================
    # Assertion: Check bvalid Timing
    # ================================
    for cycle in range(10):  
        await RisingEdge(dut.aclk)
        if dut.bvalid.value == 1:
            break
        else:
            assert ("ERROR: bvalid not asserted within 10 cycles after write transaction")

    # Acknowledge response
    dut.bready.value = 1
    await RisingEdge(dut.aclk)
    await RisingEdge(dut.aclk)  # Extra cycle to ensure bvalid is cleared

    assert dut.bvalid.value == 0, "ERROR: bvalid not deasserted after bready"
    dut.bready.value = 0
    cocotb.log.info("Write transaction passed.")

    # ============================================
    # READ TRANSACTION: Check arready and rvalid
    # ============================================
    cocotb.log.info("Starting AXI4-Lite read transaction...")

    # Initiate read request
    dut.arvalid.value = 1
    dut.araddr.value = 0x10

    await RisingEdge(dut.aclk)

    # Wait for `arready` to assert within 10 cycles
    for cycle in range(10):
        await RisingEdge(dut.aclk)
        cocotb.log.info(f"Cycle {cycle}: arready = {int(dut.arready.value)}")
        if dut.arready.value == 1:
            break
        else:
            assert ("ERROR: arready not asserted within 10 cycles after arvalid")

    dut.arvalid.value = 0  # Deassert `arvalid` after `arready` is seen

    # Wait for `rvalid` to assert within 15 cycles
    for cycle in range(15):  # Extended timeout
        await RisingEdge(dut.aclk)
        cocotb.log.info(f"Cycle {cycle}: rvalid = {int(dut.rvalid.value)}")
        if dut.rvalid.value == 1:
            break
        else:
            assert ("ERROR: rvalid not asserted within 15 cycles after read transaction")

    # Acknowledge read data
    dut.rready.value = 1
    await RisingEdge(dut.aclk)

    # Ensure `rvalid` is deasserted after `rready`
    for cycle in range(5):  # Wait for up to 5 cycles for `rvalid` to go low
        await RisingEdge(dut.aclk)
        if dut.rvalid.value == 0:
            break
    else:
        assert ("ERROR: rvalid not deasserted after rready")

    dut.rready.value = 0
    cocotb.log.info("Read transaction passed. Test complete!")

    @cocotb.test()
    async def check_arready_assertion(dut):
        """Test that arready asserts within 2 cycles after arvalid"""
    
    dut.arvalid.value = 1  # Set arvalid to initiate a read request
    await RisingEdge(dut.aclk)

    # Wait up to 2 clock cycles for arready to assert
    for _ in range(2):
        await RisingEdge(dut.aclk)
        if dut.arready.value == 1:
            break
    else:
        raise AssertionError("ERROR: arready not asserted within 2 cycles after arvalid")
    
    dut._log.info("PASS: arready asserted within 2 cycles after arvalid")

    @cocotb.test()
    async def test_rvalid_deassertion(dut):
        """Test if rvalid deasserts after rready is high."""
    
    # Generate Clock
    cocotb.start_soon(Clock(dut.aclk, CLK_PERIOD, unit="ns", period_high=(CLK_PERIOD+1)//2 if CLK_PERIOD%2 else CLK_PERIOD//2).start())

    # Reset sequence
    dut.aresetn.value = 0
    dut.awvalid.value = 0
    dut.wvalid.value = 0
    dut.bready.value = 0
    dut.arvalid.value = 0
    dut.rready.value = 0
    await Timer(50, unit="ns")  # Hold reset
    dut.aresetn.value = 1
    await Timer(10, unit="ns")  # Wait after reset

    # Initial conditions
    dut.arvalid.value = 0
    dut.araddr.value = 0x20  # Example address
    dut.rready.value = 0

    # Wait for a clock cycle before starting
    await RisingEdge(dut.aclk)

    # Step 1: Initiate a read transaction
    dut.arvalid.value = 1
    await RisingEdge(dut.aclk)

    # Step 2: Wait for `arready` to assert
    while dut.arready.value == 0:
        await RisingEdge(dut.aclk)

    dut._log.info("arready asserted, read address handshake complete.")

    # Step 3: Wait for `rvalid` to assert
    while dut.rvalid.value == 0:
        await RisingEdge(dut.aclk)

    dut._log.info("rvalid asserted, read data available.")

    # Step 4: Assert `rready` and check if `rvalid` deasserts
    dut.rready.value = 1
    await RisingEdge(dut.aclk)  # Wait one cycle
    await Timer(1, unit="ns") 
    if dut.rvalid.value == 0:
        dut._log.info("rvalid correctly deasserted after rready.")
    else:
        dut._log.error("❌ ERROR: rvalid did NOT deassert after rready was asserted.")
        assert ("rvalid did not deassert after rready.")

    @cocotb.test()
    async def check_arready_deassertion(dut):
        """Check that arready deasserts within 5 cycles after arvalid handshake"""

    max_cycles = 1000  # Prevent infinite loops
    cycles_waited = 0

    await RisingEdge(dut.aclk)  # Wait for the first clock edge
    
    while cycles_waited < max_cycles:
        await RisingEdge(dut.aclk)
        cycles_waited += 1  # Track how many cycles we waited

        if dut.arvalid.value and dut.arready.value:
            handshake_time = get_sim_time('ns')
            #dut._log.info(f"arvalid & arready handshake at {handshake_time} ns")

            # Check for deassertion within 5 cycles
            for cycle in range(1, 5):  # 1 to 5 cycles
                await RisingEdge(dut.aclk)
                if not dut.arready.value:
                    dut._log.info(f"arready deasserted at {get_sim_time('ns')} ns (within {cycle} cycles)")
                    return  # Test passes
            assert ("❌ ERROR: Timeout! `arvalid` and `arready` handshake never occurred.")