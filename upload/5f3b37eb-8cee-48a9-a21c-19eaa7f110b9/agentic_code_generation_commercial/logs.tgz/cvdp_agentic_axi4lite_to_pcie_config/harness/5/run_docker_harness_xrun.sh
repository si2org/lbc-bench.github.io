#!/bin/bash

# Auto-generated script to run harness Docker container
# Usage: run_docker_harness_xrun.sh [-d] (where -d enables debug mode with bash entrypoint)
set -e

# Parse command line arguments
DEBUG_MODE=false
while getopts 'd' flag; do
  case "${flag}" in
    d) DEBUG_MODE=true ;;
  esac
done

# Use shared bridge network: cvdp-bridge-pr38-v110-agentic-commercial-t4
NETWORK_CREATED=0

# Check if network exists, create if needed
if ! docker network inspect cvdp-bridge-pr38-v110-agentic-commercial-t4 &>/dev/null; then
  echo "Creating Docker network cvdp-bridge-pr38-v110-agentic-commercial-t4..."
  docker network create --driver bridge cvdp-bridge-pr38-v110-agentic-commercial-t4
  NETWORK_CREATED=1
fi

# Function to clean up resources
cleanup() {
  echo "Cleaning up Docker resources..."
  docker compose -f /tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/docker-compose.yml -p cvdp_agentic_axi4lite_to_pcie_config_5_1778608641 kill xrun 2>/dev/null || true
  docker rmi cvdp_agentic_axi4lite_to_pcie_config_5_1778608641-xrun 2>/dev/null || true
  if [ $NETWORK_CREATED -eq 1 ]; then
    echo "Removing Docker network cvdp-bridge-pr38-v110-agentic-commercial-t4..."
    docker network rm cvdp-bridge-pr38-v110-agentic-commercial-t4 2>/dev/null || true
  fi
}

# Set up cleanup trap
trap cleanup EXIT

# Run the harness container
echo "Running harness with project name: cvdp_agentic_axi4lite_to_pcie_config_5_1778608641"
# Get current user and group IDs
USER_ID=$(id -u)
GROUP_ID=$(id -g)

if [ "$DEBUG_MODE" = true ]; then
  echo "DEBUG MODE: Starting container with bash entrypoint"
  docker compose -f /tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/docker-compose.yml -p cvdp_agentic_axi4lite_to_pcie_config_5_1778608641 run --rm --user $USER_ID:$GROUP_ID -e HOME=/code/rundir -e XDG_CACHE_HOME=/code/rundir/.cache --entrypoint bash -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/docs:/code/docs" -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/rundir:/code/rundir" -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/rtl:/code/rtl" -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/verif:/code/verif" -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/src:/code/src" -v "<home>/for_github/cvdp_benchmark/src/llm_lib:/pysubj" --rm -w /code/rundir xrun
else
  docker compose -f /tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/docker-compose.yml -p cvdp_agentic_axi4lite_to_pcie_config_5_1778608641 run --rm --user $USER_ID:$GROUP_ID -e HOME=/code/rundir -e XDG_CACHE_HOME=/code/rundir/.cache -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/docs:/code/docs" -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/rundir:/code/rundir" -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/rtl:/code/rtl" -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/verif:/code/verif" -v "/tmp/cvdp_pr38_v110_agentic_commercial_t4/cvdp_agentic_axi4lite_to_pcie_config/harness/5/src:/code/src" -v "<home>/for_github/cvdp_benchmark/src/llm_lib:/pysubj" --rm -w /code/rundir xrun
fi
exit_code=$?

# Exit with the same code as the docker command
exit $exit_code
