`timescale 1ns/1ps

module axi4lite_to_pcie_cfg_bridge #(
    parameter ADDR_WIDTH = 8,
    parameter DATA_WIDTH = 32  
)(
    // AXI4-Lite Interface
    input  logic        aclk,           
    input  logic        aresetn,        
    input  logic [ADDR_WIDTH-1:0] awaddr,         
    input  logic        awvalid,        
    output logic        awready,        
    input  logic [DATA_WIDTH-1:0] wdata,          
    input  logic [DATA_WIDTH/8-1:0]  wstrb,          
    input  logic        wvalid,         
    output logic        wready,         
    output logic [1:0]  bresp,          
    output logic        bvalid,         
    input  logic        bready,         

    
    // Read Address Channel
    input  logic [ADDR_WIDTH-1:0] araddr,
    input  logic        arvalid,
    output logic        arready,
    
    // Read Data Channel
    output logic [DATA_WIDTH-1:0] rdata,
    output logic        rvalid,
    output logic [1:0]  rresp,
    input  logic        rready,

    // PCIe Configuration Space Interface
    output logic [ADDR_WIDTH/4-1:0]  pcie_cfg_addr,  
    output logic [DATA_WIDTH-1:0] pcie_cfg_wdata, 
    output logic        pcie_cfg_wr_en, 
    input  logic [DATA_WIDTH-1:0] pcie_cfg_rdata, 
    output logic        pcie_cfg_rd_en
);

    // FSM States
    typedef enum logic [2:0] {
        IDLE,                // 000
        WRITE_ADDR_DATA,     // 001
        PCIE_WRITE,          // 010 
        SEND_RESPONSE,       // 011 
        READ_ADDR,           // 100
        PCIE_READ,           // 101
        SEND_READ_RESPONSE   // 110
    } state_t;

    state_t current_state, next_state;

    // Internal registers
    logic [ADDR_WIDTH-1:0] awaddr_reg;  
    logic [DATA_WIDTH-1:0] wdata_reg;   
    logic [DATA_WIDTH/8-1:0]  wstrb_reg;   
    logic [ADDR_WIDTH-1:0] araddr_reg;

    //==========================================
    // FSM Implementation
    //==========================================

    // FSM State Transition
    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            current_state <= IDLE;
        end else begin
            current_state <= next_state;
        end
    end

    // FSM Next State Logic
    always_comb begin
        next_state = current_state;
        case (current_state)
            IDLE: begin
                if (awvalid && !arvalid) begin
                    next_state = WRITE_ADDR_DATA;
                end 
                else if (arvalid && !awvalid) begin
                    next_state = READ_ADDR;
                end
                else if (awvalid && arvalid) begin
                    next_state = IDLE;  // Stay in IDLE to prevent illegal transition
                end
            end

            WRITE_ADDR_DATA: begin
                if (awvalid && wvalid && awready && wready) begin
                    next_state = PCIE_WRITE;
                end
            end

            PCIE_WRITE: next_state = SEND_RESPONSE;
            
            SEND_RESPONSE: begin
                if (bready)
                if (bready)
                    next_state = IDLE;
                else
                    next_state = SEND_RESPONSE;
            end
            
            READ_ADDR: begin
                if (arvalid) begin
                    next_state = PCIE_READ;
                end
            end

            PCIE_READ: next_state = SEND_READ_RESPONSE;
            
            SEND_READ_RESPONSE: begin
                if (rvalid && rready) begin
                    next_state = IDLE;
                end else begin
                    next_state = SEND_READ_RESPONSE;
                end
            end
            
            default: next_state = IDLE;
        endcase
    end

    // FSM Output Logic
    always_ff @(posedge aclk or negedge aresetn) begin
        if (!aresetn) begin
            awready <= 1'b0;
            wready <= 1'b0;
            bvalid <= 1'b0;
            bresp <= 2'b00;
            bresp <= 2'b00;
            pcie_cfg_wr_en <= 1'b0;
            pcie_cfg_wdata <= 32'h0;
            pcie_cfg_addr <= 8'h0;
            awaddr_reg <= 32'h0;
            wdata_reg <= 32'h0;
            wstrb_reg <= 4'h0;
       
            arready <= 1'b0;
            rvalid <= 1'b0;
            rresp <= 2'b00;
            rdata <= 32'h0;
            pcie_cfg_rd_en <= 1'b0;
            araddr_reg <= 32'h0;
       
            arready <= 1'b0;
            rvalid <= 1'b0;
            rresp <= 2'b00;
            rdata <= 32'h0;
            pcie_cfg_rd_en <= 1'b0;
            araddr_reg <= 32'h0;
        end else begin
            case (current_state)
                IDLE: begin
                    awready <= 1'b0;
                    wready <= 1'b0;
                    bvalid <= 1'b0;  // <- ENSURES CLEAN RESET
                    pcie_cfg_wr_en <= 1'b0;
                    arready <= 1'b0;
                    rvalid <= 1'b0;
                    pcie_cfg_rd_en <= 1'b0;
                    arready <= 1'b0;
                    rvalid <= 1'b0;
                    pcie_cfg_rd_en <= 1'b0;
                end
    
                WRITE_ADDR_DATA: begin
                    if (awvalid && !awready) begin
                        awready <= 1'b1;  
                    end
                    if (wvalid && !wready) begin
                        wready <= 1'b1;    
                    end
                end
                                           
    
                PCIE_WRITE: begin
                    awready <= 1'b0;
                    wready <= 1'b0;
                    pcie_cfg_wr_en <= 1'b1;
                    pcie_cfg_addr <= awaddr_reg[7:0];
                    pcie_cfg_addr <= awaddr_reg[7:0];
                    for (int i = 0; i < (DATA_WIDTH/8); i++) begin
                        pcie_cfg_wdata[(i*8)+:8] <= (wstrb_reg[i]) ? wdata_reg[(i*8)+:8] : pcie_cfg_rdata[(i*8)+:8];
                    end
                end

                READ_ADDR: begin
                    if (arvalid && !arready) begin
                        arready <= 1'b1;
                        araddr_reg <= araddr;
                    end else if (arready) begin
                        arready <= 1'b0; // Ensure it deasserts after 1 cycle
                    end
                end             
                
                PCIE_READ: begin
                    pcie_cfg_rd_en <= 1'b1; 
                end
    
                SEND_RESPONSE: begin
                    pcie_cfg_wr_en <= 1'b0;
                    bvalid <= 1'b1;
                    bresp <= 2'b00;
                
                    if (bvalid && bready) begin
                        bvalid <= 1'b0; 
                    end
                end   
                
                SEND_READ_RESPONSE: begin
                    if (!rvalid && pcie_cfg_rd_en) begin
                        rvalid <= 1'b1;  
                        rdata  <= pcie_cfg_rdata;
                        rresp  <= 2'b00;
                    end
                    
                    if (rvalid && rready) begin
                        rvalid <= 1'b0;  
                        pcie_cfg_rd_en <= 1'b0;
                    end
                end                
    
                default: begin
                    awready <= 1'b0;
                    wready <= 1'b0;
                    bvalid <= 1'b0;
                    pcie_cfg_wr_en <= 1'b0;
                    arready <= 1'b0;
                    rvalid <= 1'b0;
                    pcie_cfg_rd_en <= 1'b0;
                end
            endcase
        end
    end

    //==========================================
    // SystemVerilog Assertions (SVA)
    //==========================================

    // awready asserts within 2 cycles after awvalid is asserted
    property awready_prop;
        @(posedge aclk) disable iff (!aresetn)
        $rose(awvalid) |-> ##[1:2] awready;
    endproperty
    awready_assertion: assert property (awready_prop)
        else $error("ASSERTION FAILED [awready_assertion]: awready did not assert within 2 cycles after awvalid");

    // wready asserts within 2 cycles after wvalid is asserted
    property wready_prop;
        @(posedge aclk) disable iff (!aresetn)
        $rose(wvalid) |-> ##[1:2] wready;
    endproperty
    wready_assertion: assert property (wready_prop)
        else $error("ASSERTION FAILED [wready_assertion]: wready did not assert within 2 cycles after wvalid");

    // bvalid asserts within 5 cycles after both awvalid and wvalid handshake
    property bvalid_prop;
        @(posedge aclk) disable iff (!aresetn)
        (awvalid && wvalid) |-> ##[1:5] bvalid;
    endproperty
    bvalid_assertion: assert property (bvalid_prop)
        else $error("ASSERTION FAILED [bvalid_assertion]: bvalid did not assert within 5 cycles after awvalid and wvalid handshake");

    // rvalid asserts within 10 cycles after arvalid and arready handshake
    property rvalid_prop;
        @(posedge aclk) disable iff (!aresetn)
        (arvalid && arready) |-> ##[1:10] rvalid;
    endproperty
    rvalid_assertion: assert property (rvalid_prop)
        else $error("ASSERTION FAILED [rvalid_assertion]: rvalid did not assert within 10 cycles after arvalid and arready handshake");

    // arready asserts within 2 cycles after arvalid is asserted
    property arready_prop;
        @(posedge aclk) disable iff (!aresetn)
        $rose(arvalid) |-> ##[1:2] arready;
    endproperty
    arready_assertion: assert property (arready_prop)
        else $error("ASSERTION FAILED [arready_assertion]: arready did not assert within 2 cycles after arvalid");

    // rvalid deasserts within 3 cycles after rready is asserted
    property rvalid_deassertion_prop;
        @(posedge aclk) disable iff (!aresetn)
        (rvalid && rready) |-> ##[1:3] !rvalid;
    endproperty
    rvalid_deassertion: assert property (rvalid_deassertion_prop)
        else $error("ASSERTION FAILED [rvalid_deassertion]: rvalid did not deassert within 3 cycles after rready");

    // bvalid deasserts within 3 cycles after bready is asserted
    property bvalid_deassertion_prop;
        @(posedge aclk) disable iff (!aresetn)
        (bvalid && bready) |-> ##[1:3] !bvalid;
    endproperty
    bvalid_deassertion: assert property (bvalid_deassertion_prop)
        else $error("ASSERTION FAILED [bvalid_deassertion]: bvalid did not deassert within 3 cycles after bready");

    // arready deasserts within 5 cycles after arvalid and arready handshake
    property arready_deassertion_prop;
        @(posedge aclk) disable iff (!aresetn)
        (arvalid && arready) |-> ##[1:5] !arready;
    endproperty
    arready_deassertion: assert property (arready_deassertion_prop)
        else $error("ASSERTION FAILED [arready_deassertion]: arready did not deassert within 5 cycles after arvalid and arready handshake");

endmodule