`timescale 1ns/1ps

module continuous_adder #(
    parameter integer DATA_WIDTH       = 32,
    parameter integer ENABLE_THRESHOLD = 0,
    parameter integer THRESHOLD        = 16,
    parameter integer REGISTER_OUTPUT  = 0
)(
    input  wire clk,
    input  wire rst_n,
    input  wire valid_in,
    input  wire [DATA_WIDTH-1:0] data_in,
    input  wire accumulate_enable,
    input  wire flush,
    output reg  [DATA_WIDTH-1:0] sum_out,
    output reg  sum_valid
);

reg [DATA_WIDTH-1:0] sum_reg;
wire threshold_reached = (ENABLE_THRESHOLD != 0) && (sum_reg >= THRESHOLD);

always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        sum_reg <= '0;
    else begin
        if (flush)
            sum_reg <= '0;
        else if (valid_in && accumulate_enable)
            sum_reg <= sum_reg + data_in;
    end
end

generate
    if (REGISTER_OUTPUT != 0) begin
        always @(posedge clk or negedge rst_n) begin
            if (!rst_n) begin
                sum_out   <= '0;
                sum_valid <= 1'b0;
            end else begin
                if (flush || threshold_reached) begin
                    sum_out   <= sum_reg;
                    sum_valid <= 1'b1;
                end else begin
                    sum_valid <= 1'b0;
                end
            end
        end
    end else begin
        always @* begin
            sum_out   = (flush || threshold_reached) ? sum_reg : sum_out;
            sum_valid = (flush || threshold_reached) ? 1'b1     : 1'b0;
        end
    end
endgenerate


// ============================================================
// SystemVerilog Assertions
// ============================================================

// Flush behavior: sum_reg must be cleared to 0 on the cycle after flush is asserted
property p_flush_resets_sum;
    @(posedge clk) disable iff (!rst_n)
    flush |=> (sum_reg == '0);
endproperty
AST_flush_resets_sum: assert property (p_flush_resets_sum)
    else $error("ASSERTION FAILED [AST_flush_resets_sum]: sum_reg was not reset to 0 the cycle after flush was asserted");

// Accumulate behavior: sum_reg must increment by data_in when valid_in and accumulate_enable are high and no flush
property p_accumulate_correct;
    @(posedge clk) disable iff (!rst_n)
    (valid_in && accumulate_enable && !flush) |=>
        (sum_reg == ($past(sum_reg) + $past(data_in)));
endproperty
AST_accumulate_correct: assert property (p_accumulate_correct)
    else $error("ASSERTION FAILED [AST_accumulate_correct]: sum_reg not correctly incremented by data_in during a valid accumulate cycle");

// Accumulate stability: sum_reg must not change when no valid accumulation occurs and no flush
property p_sum_stable_when_idle;
    @(posedge clk) disable iff (!rst_n)
    ((!valid_in || !accumulate_enable) && !flush) |=> (sum_reg == $past(sum_reg));
endproperty
AST_sum_stable_when_idle: assert property (p_sum_stable_when_idle)
    else $error("ASSERTION FAILED [AST_sum_stable_when_idle]: sum_reg changed unexpectedly without an active accumulate_enable or flush");

// Threshold detection assertions (only applicable when ENABLE_THRESHOLD is set)
generate
    if (ENABLE_THRESHOLD != 0) begin : gen_threshold_assertions
        // threshold_reached must be high whenever sum_reg meets or exceeds THRESHOLD
        property p_threshold_reached_hi;
            @(posedge clk) disable iff (!rst_n)
            (sum_reg >= THRESHOLD) |-> threshold_reached;
        endproperty
        AST_threshold_reached_hi: assert property (p_threshold_reached_hi)
            else $error("ASSERTION FAILED [AST_threshold_reached_hi]: threshold_reached not asserted when sum_reg >= THRESHOLD");

        // threshold_reached must be low whenever sum_reg is below THRESHOLD
        property p_threshold_reached_lo;
            @(posedge clk) disable iff (!rst_n)
            (sum_reg < THRESHOLD) |-> !threshold_reached;
        endproperty
        AST_threshold_reached_lo: assert property (p_threshold_reached_lo)
            else $error("ASSERTION FAILED [AST_threshold_reached_lo]: threshold_reached incorrectly asserted when sum_reg < THRESHOLD");
    end
endgenerate

// Output registration assertions (only applicable when REGISTER_OUTPUT is set)
generate
    if (REGISTER_OUTPUT != 0) begin : gen_reg_output_assertions
        // sum_valid must be registered high exactly one cycle after flush or threshold_reached
        property p_reg_sum_valid_asserted;
            @(posedge clk) disable iff (!rst_n)
            (flush || threshold_reached) |=> (sum_valid == 1'b1);
        endproperty
        AST_reg_sum_valid_asserted: assert property (p_reg_sum_valid_asserted)
            else $error("ASSERTION FAILED [AST_reg_sum_valid_asserted]: sum_valid not registered high one cycle after flush or threshold_reached");

        // sum_valid must be registered low one cycle after neither flush nor threshold_reached
        property p_reg_sum_valid_cleared;
            @(posedge clk) disable iff (!rst_n)
            (!flush && !threshold_reached) |=> (sum_valid == 1'b0);
        endproperty
        AST_reg_sum_valid_cleared: assert property (p_reg_sum_valid_cleared)
            else $error("ASSERTION FAILED [AST_reg_sum_valid_cleared]: sum_valid not registered low one cycle after no flush or threshold_reached");

        // sum_out must capture the pre-event value of sum_reg exactly one cycle after flush or threshold_reached
        property p_reg_sum_out_captured;
            @(posedge clk) disable iff (!rst_n)
            (flush || threshold_reached) |=> (sum_out == $past(sum_reg));
        endproperty
        AST_reg_sum_out_captured: assert property (p_reg_sum_out_captured)
            else $error("ASSERTION FAILED [AST_reg_sum_out_captured]: sum_out not correctly registered from sum_reg one cycle after flush or threshold_reached");
    end
endgenerate

endmodule