module caesar_cipher #(
    parameter PHRASE_WIDTH = 8,
    parameter PHRASE_LEN   = PHRASE_WIDTH / 8
)(
    input  wire [PHRASE_WIDTH-1:0]             input_char,
    input  wire [(PHRASE_LEN * 5) - 1:0]       key,
    input  wire                                decrypt,
    output reg  [PHRASE_WIDTH-1:0]             output_char
);

    integer idx;
    reg [7:0]  curr_char;
    reg [4:0]  shift_val;

    always @(*) begin
        // Initialize output
        output_char = {PHRASE_WIDTH{1'b0}};

        if (PHRASE_LEN > 0) begin
            for (idx = 0; idx < PHRASE_LEN; idx = idx + 1) begin
                // Extract the current character and shift key
                curr_char  = input_char[(idx * 8) +: 8];
                shift_val  = key[(idx * 5) +: 5];

                // Assertion 1: Shift key range check — shift_val must fit in 5 bits (<= 31)
                assert (shift_val <= 5'h1F)
                    else $error("Character[%0d]: shift_val %0d exceeds 5-bit maximum of 31",
                                idx, shift_val);

                // Assert input character is within valid ASCII range (0x00–0x7F)
                assert (curr_char <= 8'h7F)
                    else $error("Character[%0d]: input_char 0x%02X is outside valid ASCII range (0x00-0x7F)",
                                idx, curr_char);

                if (decrypt) begin
                    // Decryption logic
                    if (curr_char >= "A" && curr_char <= "Z") begin
                        output_char[(idx * 8) +: 8]
                            = ((curr_char - "A" - shift_val + 26) % 26) + "A";
                    end
                    else if (curr_char >= "a" && curr_char <= "z") begin
                        output_char[(idx * 8) +: 8]
                            = ((curr_char - "a" - shift_val + 26) % 26) + "a";
                    end
                    else begin
                        output_char[(idx * 8) +: 8]
                            = curr_char - shift_val;
                    end
                end
                else begin
                    // Encryption logic
                    if (curr_char >= "A" && curr_char <= "Z") begin
                        output_char[(idx * 8) +: 8]
                            = ((curr_char - "A" + shift_val) % 26) + "A";
                    end
                    else if (curr_char >= "a" && curr_char <= "z") begin
                        output_char[(idx * 8) +: 8]
                            = ((curr_char - "a" + shift_val) % 26) + "a";
                    end
                    else begin
                        output_char[(idx * 8) +: 8]
                            = curr_char + shift_val;
                    end
                end

                // Assertion 2: Alphabetic character output range check
                if (!decrypt) begin
                    // Uppercase encryption must stay within A–Z
                    if (curr_char >= "A" && curr_char <= "Z") begin
                        assert (output_char[(idx * 8) +: 8] >= "A" &&
                                output_char[(idx * 8) +: 8] <= "Z")
                            else $error("Character[%0d]: encrypted uppercase 0x%02X falls outside A-Z range",
                                        idx, output_char[(idx * 8) +: 8]);
                    end
                    // Lowercase encryption must stay within a–z
                    if (curr_char >= "a" && curr_char <= "z") begin
                        assert (output_char[(idx * 8) +: 8] >= "a" &&
                                output_char[(idx * 8) +: 8] <= "z")
                            else $error("Character[%0d]: encrypted lowercase 0x%02X falls outside a-z range",
                                        idx, output_char[(idx * 8) +: 8]);
                    end
                    // Assertion 3: Non-alphabetic encryption must not exceed 0x7F
                    if (!(curr_char >= "A" && curr_char <= "Z") &&
                        !(curr_char >= "a" && curr_char <= "z")) begin
                        assert (output_char[(idx * 8) +: 8] <= 8'h7F)
                            else $error("Character[%0d]: non-alphabetic 0x%02X + shift %0d = 0x%02X exceeds printable ASCII range",
                                        idx, curr_char, shift_val, output_char[(idx * 8) +: 8]);
                    end
                end else begin
                    // Uppercase decryption must stay within A–Z
                    if (curr_char >= "A" && curr_char <= "Z") begin
                        assert (output_char[(idx * 8) +: 8] >= "A" &&
                                output_char[(idx * 8) +: 8] <= "Z")
                            else $error("Character[%0d]: decrypted uppercase 0x%02X falls outside A-Z range",
                                        idx, output_char[(idx * 8) +: 8]);
                    end
                    // Lowercase decryption must stay within a–z
                    if (curr_char >= "a" && curr_char <= "z") begin
                        assert (output_char[(idx * 8) +: 8] >= "a" &&
                                output_char[(idx * 8) +: 8] <= "z")
                            else $error("Character[%0d]: decrypted lowercase 0x%02X falls outside a-z range",
                                        idx, output_char[(idx * 8) +: 8]);
                    end
                    // Assertion 3: Non-alphabetic decryption must not wrap below 0x00 or above 0x7F
                    if (!(curr_char >= "A" && curr_char <= "Z") &&
                        !(curr_char >= "a" && curr_char <= "z")) begin
                        assert (output_char[(idx * 8) +: 8] <= 8'h7F)
                            else $error("Character[%0d]: non-alphabetic 0x%02X - shift %0d = 0x%02X out of printable ASCII range",
                                        idx, curr_char, shift_val, output_char[(idx * 8) +: 8]);
                    end
                end

                // Assertion 4: Zero shift identity — output must equal input when shift is zero
                if (shift_val == 5'b0) begin
                    assert (output_char[(idx * 8) +: 8] == curr_char)
                        else $error("Character[%0d]: zero shift must leave 0x%02X unchanged, got 0x%02X",
                                    idx, curr_char, output_char[(idx * 8) +: 8]);
                end
            end
        end
    end
endmodule
