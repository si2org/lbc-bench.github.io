module caesar_cipher #(
    parameter PHRASE_WIDTH = 8,
    parameter PHRASE_LEN   = PHRASE_WIDTH / 8
)(
    input  wire [PHRASE_WIDTH-1:0]             input_char,
    input  wire [(PHRASE_LEN * 5) - 1:0]       key,
    input  wire                                decrypt,
    output reg  [PHRASE_WIDTH-1:0]             output_char
);

    integer idx;
    reg [7:0]  curr_char;
    reg [4:0]  shift_val;

    always @(*) begin
        // Initialize output
        output_char = {PHRASE_WIDTH{1'b0}};

        if (PHRASE_LEN > 0) begin
            for (idx = 0; idx < PHRASE_LEN; idx = idx + 1) begin
                // Extract the current character and shift key
                curr_char  = input_char[(idx * 8) +: 8];
                shift_val  = key[(idx * 5) +: 5];

                if (decrypt) begin
                    // Decryption logic
                    if (curr_char >= "A" && curr_char <= "Z") begin
                        output_char[(idx * 8) +: 8] 
                            = ((curr_char - "A" - shift_val + 26) % 26) + "A";
                    end
                    else if (curr_char >= "a" && curr_char <= "z") begin
                        output_char[(idx * 8) +: 8] 
                            = ((curr_char - "a" - shift_val + 26) % 26) + "a";
                    end
                    else begin
                        output_char[(idx * 8) +: 8] 
                            = curr_char - shift_val;
                    end
                end
                else begin
                    // Encryption logic
                    if (curr_char >= "A" && curr_char <= "Z") begin
                        output_char[(idx * 8) +: 8] 
                            = ((curr_char - "A" + shift_val) % 26) + "A";
                    end
                    else if (curr_char >= "a" && curr_char <= "z") begin
                        output_char[(idx * 8) +: 8] 
                            = ((curr_char - "a" + shift_val) % 26) + "a";
                    end
                    else begin
                        output_char[(idx * 8) +: 8] 
                            = curr_char + shift_val;
                    end
                end
            end
        end
    end
endmodule