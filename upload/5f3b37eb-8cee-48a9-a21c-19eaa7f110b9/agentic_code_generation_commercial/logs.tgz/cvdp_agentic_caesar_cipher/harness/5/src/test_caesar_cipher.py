import cocotb
from cocotb.triggers import Timer
import random
import string

# Helper: Pack an 8-character string into a 64-bit little-endian integer.
def pack_string_le(s):
    # s must be exactly 8 characters.
    return int.from_bytes(s.encode('ascii'), 'little')

# Helper: Pack a list of eight 5-bit shift values into an integer (little-endian order).
def pack_shifts_le(shifts):
    key_int = 0
    for i, s in enumerate(shifts):
        key_int |= (s & 0x1F) << (i * 5)
    return key_int

# Helper: Unpack a 64-bit integer (little-endian) into an 8-character string.
def unpack_string_le(val):
    return val.to_bytes(8, 'little').decode('ascii', errors='ignore')

@cocotb.test()
async def test_basic(dut):
    """
    BASIC TESTCASE:
    - Encrypt and then decrypt the fixed string "HelloZz!" using a fixed shift = 3.
    - Uses exactly 8 characters.
    """
    await Timer(1, unit="ns")
    shift = 3
    s = "HelloZz!"  # exactly 8 characters

    input_int = pack_string_le(s)
    shifts = [shift] * 8
    key_int = pack_shifts_le(shifts)

    dut.input_char.value = input_int
    dut.key.value        = key_int
    dut.decrypt.value    = 0  # encryption mode

    await Timer(10, unit="ns")
    encrypted_int = int(dut.output_char.value)

    # Now decrypt by feeding the encrypted output back.
    dut.input_char.value = encrypted_int
    dut.decrypt.value    = 1
    await Timer(10, unit="ns")
    decrypted_int = int(dut.output_char.value)
    decrypted_str = unpack_string_le(decrypted_int)

    assert decrypted_str == s, f"Basic test failed: got '{decrypted_str}', expected '{s}'"
    dut._log.info(f"PASS (basic): '{s}' correctly decrypted with shift={shift}")

@cocotb.test()
async def test_random(dut):
    """
    RANDOM TESTCASE:
    - Generate a random 8-character string.
    - For each character, choose a random shift from 1 to 25.
    - Encrypt then decrypt and verify the decrypted string matches the original.
    """
    await Timer(1, unit="ns")
    num_chars = 8
    s = ''.join(random.choices(string.ascii_letters, k=num_chars))
    shifts = [random.randint(1, 25) for _ in range(num_chars)]

    input_int = pack_string_le(s)
    key_int = pack_shifts_le(shifts)

    dut.input_char.value = input_int
    dut.key.value        = key_int
    dut.decrypt.value    = 0  # encryption mode

    await Timer(10, unit="ns")
    encrypted_int = int(dut.output_char.value)

    dut.input_char.value = encrypted_int
    dut.decrypt.value    = 1
    await Timer(10, unit="ns")
    decrypted_int = int(dut.output_char.value)
    decrypted_str = unpack_string_le(decrypted_int)

    assert decrypted_str == s, (
        f"Random test failed: original '{s}', decrypted '{decrypted_str}' with shifts {shifts}"
    )
    dut._log.info(f"PASS (random): '{s}' correctly decrypted with shifts {shifts}")

@cocotb.test()
async def test_shift_zero(dut):
    """
    EDGE TESTCASE (Shift = 0):
    - With a shift of 0, encryption should leave the input unchanged.
    """
    await Timer(1, unit="ns")
    shift = 0
    s = "ZeroTest"  # exactly 8 characters

    input_int = pack_string_le(s)
    shifts = [shift] * 8
    key_int = pack_shifts_le(shifts)

    dut.input_char.value = input_int
    dut.key.value        = key_int
    dut.decrypt.value    = 0

    await Timer(10, unit="ns")
    out_int = int(dut.output_char.value)
    out_str = unpack_string_le(out_int)

    assert out_str == s, f"Shift zero test failed: got '{out_str}', expected '{s}'"
    dut._log.info(f"PASS (shift zero): shift=0 yields '{out_str}'")
