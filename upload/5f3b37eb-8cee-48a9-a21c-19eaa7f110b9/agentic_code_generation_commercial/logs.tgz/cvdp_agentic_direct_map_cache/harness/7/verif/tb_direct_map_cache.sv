`timescale 1ns/1ps

module tb_direct_map_cache;

    parameter CACHE_SIZE   = 256; // Number of cache lines
    parameter DATA_WIDTH   = 16;  // Width of data
    parameter TAG_WIDTH    = 5;   // Width of the tag
    parameter OFFSET_WIDTH = 3;   // Width of the offset
    localparam INDEX_WIDTH = $clog2(CACHE_SIZE); // Width of the index

    reg enable;
    reg [INDEX_WIDTH-1:0] index;
    reg [OFFSET_WIDTH-1:0] offset;
    reg comp;
    reg write;
    reg [TAG_WIDTH-1:0] tag_in;
    reg [DATA_WIDTH-1:0] data_in;
    reg valid_in;
    reg clk;
    reg rst;

    wire hit;
    wire dirty;
    wire [TAG_WIDTH-1:0] tag_out;
    wire [DATA_WIDTH-1:0] data_out;
    wire valid;
    wire error;

    direct_map_cache #(
        .CACHE_SIZE(CACHE_SIZE),
        .DATA_WIDTH(DATA_WIDTH),
        .TAG_WIDTH(TAG_WIDTH),
        .OFFSET_WIDTH(OFFSET_WIDTH)
    ) uut (
        .enable(enable),
        .index(index),
        .offset(offset),
        .comp(comp),
        .write(write),
        .tag_in(tag_in),
        .data_in(data_in),
        .valid_in(valid_in),
        .clk(clk),
        .rst(rst),
        .hit(hit),
        .dirty(dirty),
        .tag_out(tag_out),
        .data_out(data_out),
        .valid(valid),
        .error(error)
    );

    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    reg [INDEX_WIDTH-1:0] stored_index;
    reg [OFFSET_WIDTH-1:0] stored_offset;
    reg [TAG_WIDTH-1:0]    stored_tag;
    reg [DATA_WIDTH-1:0]   stored_data;

    integer error_count;

    initial begin
        error_count = 0;
        reset();
    repeat(10) begin
        write_comp0();
        @(negedge clk);

        read_comp1();
        @(negedge clk);

        write_comp1();
        @(negedge clk);

        read_comp1();
        @(negedge clk);

        miss_test();
        @(negedge clk);

        write_comp1();
        @(negedge clk);

        read_comp0();
        @(negedge clk);
    end
        force_offset_error();
        @(negedge clk);

        write_comp0();
        @(negedge clk);

        reset();
        @(negedge clk);

        cache_hit_condition_scenarios();

        $display("\n[SUMMARY] Test completed at time %0t. Total checker failures: %0d", $time, error_count);
        if (error_count == 0)
            $display("[SUMMARY] ALL CHECKS PASSED.");
        else
            $display("[SUMMARY] SOME CHECKS FAILED.");

        // Wait a bit and finish
        #50;
        $finish;
    end

    task reset();
        begin
            rst     = 1;
            enable  = 0;
            comp    = 0;
            write   = 0;
            index   = 0;
            offset  = 0;
            tag_in  = 0;
            data_in = 0;
            valid_in= 0;

            @(negedge clk);
            rst = 0;
            @(negedge clk);
            $display("\n[RESET] Completed at time %0t", $time);
        end
    endtask

    task write_comp0();
        begin
            enable   = 1;
            comp     = 0;
            write    = 1;
            valid_in = 1'b1;

            stored_index = $random % CACHE_SIZE;
            stored_offset = ($random % (1<<OFFSET_WIDTH)) & ~1;
            stored_tag    = $random % (1<<TAG_WIDTH);
            stored_data   = $random % (1<<DATA_WIDTH);

            index   = stored_index;
            offset  = stored_offset;
            tag_in  = stored_tag;
            data_in = stored_data;

            @(negedge clk);
            $display("\n[WRITE_COMP0] @time %0t", $time);
            $display("  -> index=%0d, offset=%0d, tag_in=%b, data_in=%0h",
                      index, offset, tag_in, data_in);
            $display("  -> comp=%b, write=%b, valid_in=%b", comp, write, valid_in);

            // Checker 1: Write Without Compare
            // Valid aligned write must not assert error
            if (error !== 1'b0) begin
                $display("  FAIL [WRITE_COMP0]: error asserted during valid aligned write at time %0t", $time);
                error_count = error_count + 1;
            end else
                $display("  PASS [WRITE_COMP0]: no error during valid aligned write.");
        end
    endtask

    task read_comp1();
        begin
            comp  = 1;
            write = 0;
            index   = stored_index;
            offset  = stored_offset;
            tag_in  = stored_tag;

            @(negedge clk);
            $display("\n[READ_COMP1] @time %0t", $time);
            $display("  -> index=%0d, offset=%0d, tag_in=%b, data_out=%0h, valid=%b, hit=%b",
                     index, offset, tag_in, data_out, valid, hit);

            // Checker 2: Read With Compare
            // Cache line was written with valid_in=1 and same tag, so hit must be asserted
            if (!hit) begin
                $display("  FAIL [READ_COMP1]: hit not asserted (valid=%b, hit=%b) at time %0t",
                         valid, hit, $time);
                error_count = error_count + 1;
            end
            // On a hit, data_out must match the last written value
            if (hit && (data_out !== stored_data)) begin
                $display("  FAIL [READ_COMP1]: data mismatch - expected %0h, got %0h at time %0t",
                         stored_data, data_out, $time);
                error_count = error_count + 1;
            end
            if (error !== 1'b0) begin
                $display("  FAIL [READ_COMP1]: error asserted unexpectedly at time %0t", $time);
                error_count = error_count + 1;
            end
            if (hit && (data_out === stored_data) && (error === 1'b0))
                $display("  PASS [READ_COMP1]: hit=%b, data_out=%0h matches stored_data, error=0.",
                         hit, data_out);
        end
    endtask

    task write_comp1();
        begin
            comp   = 1;
            write  = 1;
            enable = 1;
            valid_in = 1'b1;

            index   = stored_index;
            offset  = stored_offset;
            tag_in  = stored_tag;
            stored_data = $random % (1<<DATA_WIDTH);
            data_in = stored_data;

            @(negedge clk);
            $display("\n[WRITE_COMP1] @time %0t", $time);
            $display("  -> index=%0d, offset=%0d, tag_in=%b, data_in=%0h, comp=%b, write=%b",
                     index, offset, tag_in, data_in, comp, write);

            // Checker 3: Write With Compare
            // Line is valid with matching tag, so this must be a hit
            if (!hit) begin
                $display("  FAIL [WRITE_COMP1]: expected hit not asserted (valid=%b, hit=%b) at time %0t",
                         valid, hit, $time);
                error_count = error_count + 1;
            end
            // A compare-write hit must assert dirty
            if (hit && !dirty) begin
                $display("  FAIL [WRITE_COMP1]: dirty not asserted after compare-write hit at time %0t",
                         $time);
                error_count = error_count + 1;
            end
            // A miss/invalid must not falsely assert dirty
            if (!hit && dirty) begin
                $display("  FAIL [WRITE_COMP1]: dirty falsely asserted on miss/invalid at time %0t",
                         $time);
                error_count = error_count + 1;
            end
            if (error !== 1'b0) begin
                $display("  FAIL [WRITE_COMP1]: error asserted unexpectedly at time %0t", $time);
                error_count = error_count + 1;
            end
            if (hit && dirty && (error === 1'b0))
                $display("  PASS [WRITE_COMP1]: hit=%b, dirty=%b after compare-write hit, error=0.",
                         hit, dirty);
        end
    endtask

    task read_comp0();
        begin
            comp  = 0;
            write = 0;
            index   = stored_index;
            offset  = stored_offset;
            tag_in  = stored_tag;

            @(negedge clk);
            $display("\n[READ_COMP0] @time %0t", $time);
            $display("  -> index=%0d, offset=%0d, tag_in=%b, data_out=%0h, valid=%b, hit=%b",
                     index, offset, tag_in, data_out, valid, hit);

            // Checker 4: Read Without Compare
            // No data validity expectations; only error must remain deasserted
            if (error !== 1'b0) begin
                $display("  FAIL [READ_COMP0]: error asserted during read without compare at time %0t",
                         $time);
                error_count = error_count + 1;
            end else
                $display("  PASS [READ_COMP0]: no error during read without compare.");
        end
    endtask

    task miss_test();
        reg [INDEX_WIDTH-1:0] new_index;
        begin
            comp  = 1;
            write = 0;
            enable = 1;

            // Access a different index that was never written → invalid → guaranteed miss
            new_index = (stored_index + 1) % CACHE_SIZE;
            index = new_index;
            offset = ($random % (1<<OFFSET_WIDTH)) & ~1;
            tag_in = $random % (1<<TAG_WIDTH);

            @(negedge clk);
            $display("\n[MISS_TEST] @time %0t", $time);
            $display("  -> new_index=%0d, offset=%0d, tag_in=%b, data_out=%0h, valid=%b, hit=%b",
                     new_index, offset, tag_in, data_out, valid, hit);

            // Checker 5: Miss Detection
            // Different (never-written) index must produce a miss
            if (hit) begin
                $display("  FAIL [MISS_TEST]: expected miss but hit asserted at time %0t", $time);
                error_count = error_count + 1;
            end
            if (error !== 1'b0) begin
                $display("  FAIL [MISS_TEST]: error asserted unexpectedly at time %0t", $time);
                error_count = error_count + 1;
            end
            if (!hit && (error === 1'b0))
                $display("  PASS [MISS_TEST]: miss correctly detected (hit=0, error=0).");
        end
    endtask

    task force_offset_error();
        begin
            $display("\n[OFFSET_ERROR_TEST] Forcing offset LSB=1, expecting 'error=1'.");
            offset = 3'b001; // LSB=1 → misaligned
            comp   = 0;
            write  = 0;
            index  = 0;
            tag_in = 0;
            data_in= 0;
            @(negedge clk);

            // Checker 6: Misaligned Offset Error
            // offset[0]=1 must trigger the error signal
            if (error !== 1'b1) begin
                $display("  FAIL [OFFSET_ERROR]: error not asserted for misaligned offset (error=%b) at time %0t",
                         error, $time);
                error_count = error_count + 1;
            end else
                $display("  PASS [OFFSET_ERROR]: error correctly asserted for misaligned offset.");
        end
    endtask

 task cache_hit_condition_scenarios();
        reg [INDEX_WIDTH-1:0] cov_index;
        reg [OFFSET_WIDTH-1:0] cov_offset;
        reg [TAG_WIDTH-1:0]    cov_tag, cov_mismatch_tag;
        reg [DATA_WIDTH-1:0]   cov_data;

        begin
            $display("\n[COVER_CACHE_HIT_CONDITION] Forcing scenarios to cover 'hit' condition sub-cases:");
            $display("  Condition A = (tags[index] == tag_in)");
            $display("  Condition B = valid_bits[index]");

            enable   = 1;
            comp     = 0;
            write    = 1;
            valid_in = 1'b1;

            cov_index = $random % CACHE_SIZE;
            cov_offset = ($random % (1 << OFFSET_WIDTH)) & ~1;
            cov_tag    = $random % (1 << TAG_WIDTH);
            cov_data   = $random % (1 << DATA_WIDTH);

            cov_mismatch_tag = cov_tag ^ 1;

            index   = cov_index;
            offset  = cov_offset;
            tag_in  = cov_tag;
            data_in = cov_data;

            // Step 1: Initial write (comp=0) to establish a valid cache line
            @(negedge clk);
            $display("  [Step 1] Initial write: made line valid. index=%0d, tag=%b",
                     cov_index, cov_tag);
            // Checker 7a: no-compare write must not cause error
            if (error !== 1'b0) begin
                $display("  FAIL [CACHE_HIT_COV Step1]: error asserted during initial write at time %0t",
                         $time);
                error_count = error_count + 1;
            end else
                $display("  PASS [CACHE_HIT_COV Step1]: no error during initial write.");

            // Step 2: Compare-write with mismatched tag → must miss, dirty must stay 0
            comp     = 1;
            write    = 1;
            valid_in = 1'b1;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_mismatch_tag; // mismatch
            data_in  = $random;

            @(negedge clk);
            $display("  [Step 2] Compare-write mismatch. index=%0d, tag=%b (expected miss)",
                     cov_index, cov_mismatch_tag);
            // Checker 7b: mismatched tag → hit=0, dirty=0, error=0
            if (hit) begin
                $display("  FAIL [CACHE_HIT_COV Step2]: hit asserted on tag mismatch at time %0t",
                         $time);
                error_count = error_count + 1;
            end
            if (dirty) begin
                $display("  FAIL [CACHE_HIT_COV Step2]: dirty falsely asserted on tag mismatch at time %0t",
                         $time);
                error_count = error_count + 1;
            end
            if (error !== 1'b0) begin
                $display("  FAIL [CACHE_HIT_COV Step2]: error asserted unexpectedly at time %0t", $time);
                error_count = error_count + 1;
            end
            if (!hit && !dirty && (error === 1'b0))
                $display("  PASS [CACHE_HIT_COV Step2]: miss on tag mismatch, dirty=0, error=0.");

            // Step 3: Clear the valid bit
            comp     = 0;
            write    = 1;
            valid_in = 1'b0; // clears valid_bits[cov_index]
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag;
            data_in  = $random;

            @(negedge clk);
            $display("  [Step 3] Cleared valid bit. index=%0d", cov_index);
            // Checker 7c: clearing valid must not cause error
            if (error !== 1'b0) begin
                $display("  FAIL [CACHE_HIT_COV Step3]: error asserted during valid-clear at time %0t",
                         $time);
                error_count = error_count + 1;
            end else
                $display("  PASS [CACHE_HIT_COV Step3]: no error during valid-clear.");

            // Step 4: Compare-write on now-invalid line → must miss, dirty must not be set
            comp     = 1;
            write    = 1;
            valid_in = 1'b1;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag;
            data_in  = $random;

            @(negedge clk);
            $display("  [Step 4] Compare-write on invalid line. index=%0d, tag=%b (expected miss)",
                     cov_index, cov_tag);
            // Checker 7d: invalid line → hit=0, dirty must not be falsely set, error=0
            if (hit) begin
                $display("  FAIL [CACHE_HIT_COV Step4]: hit asserted on invalid line at time %0t", $time);
                error_count = error_count + 1;
            end
            if (!hit && dirty) begin
                $display("  FAIL [CACHE_HIT_COV Step4]: dirty falsely asserted on invalid-line miss at time %0t",
                         $time);
                error_count = error_count + 1;
            end
            if (error !== 1'b0) begin
                $display("  FAIL [CACHE_HIT_COV Step4]: error asserted unexpectedly at time %0t", $time);
                error_count = error_count + 1;
            end
            if (!hit && !dirty && (error === 1'b0))
                $display("  PASS [CACHE_HIT_COV Step4]: no hit on invalid line, dirty=0, error=0.");

            // Step 5: Re-validate with same tag (comp=0 write, valid_in=1)
            comp     = 0;
            write    = 1;
            valid_in = 1'b1;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag;
            data_in  = $random;

            @(negedge clk);
            $display("  [Step 5] Re-validate. index=%0d, tag=%b", cov_index, cov_tag);
            // Checker 7e: re-validate must not cause error
            if (error !== 1'b0) begin
                $display("  FAIL [CACHE_HIT_COV Step5]: error asserted during re-validate at time %0t",
                         $time);
                error_count = error_count + 1;
            end else
                $display("  PASS [CACHE_HIT_COV Step5]: no error during re-validate.");

            // Step 6: Compare-write with valid matching tag → must hit, dirty must be set
            comp     = 1;
            write    = 1;
            valid_in = 1'b1;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag; // matching tag, line is now valid
            data_in  = $random;

            @(negedge clk);
            $display("  [Step 6] Compare-write with valid tag match. index=%0d, tag=%b (expected hit)",
                     cov_index, cov_tag);
            // Checker 7f: valid tag match → hit=1, dirty=1, error=0
            if (!hit) begin
                $display("  FAIL [CACHE_HIT_COV Step6]: hit not asserted on valid tag match (valid=%b) at time %0t",
                         valid, $time);
                error_count = error_count + 1;
            end
            if (hit && !dirty) begin
                $display("  FAIL [CACHE_HIT_COV Step6]: dirty not asserted after compare-write hit at time %0t",
                         $time);
                error_count = error_count + 1;
            end
            if (!hit && dirty) begin
                $display("  FAIL [CACHE_HIT_COV Step6]: dirty falsely asserted on miss at time %0t", $time);
                error_count = error_count + 1;
            end
            if (error !== 1'b0) begin
                $display("  FAIL [CACHE_HIT_COV Step6]: error asserted unexpectedly at time %0t", $time);
                error_count = error_count + 1;
            end
            if (hit && dirty && (error === 1'b0))
                $display("  PASS [CACHE_HIT_COV Step6]: hit=1, dirty=1 on valid tag match, error=0.");

            // Step 7: Compare-read with mismatched tag → hit=0, error=0
            comp     = 1;
            write    = 0;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_mismatch_tag;  // mismatch

            @(negedge clk);
            $display("  [Step 7] Compare-read mismatch. index=%0d, tag=%b (expected miss)",
                     cov_index, cov_mismatch_tag);
            // Checker 7g: tag mismatch read → hit=0, error=0
            if (hit) begin
                $display("  FAIL [CACHE_HIT_COV Step7]: hit asserted on tag mismatch at time %0t", $time);
                error_count = error_count + 1;
            end
            if (error !== 1'b0) begin
                $display("  FAIL [CACHE_HIT_COV Step7]: error asserted unexpectedly at time %0t", $time);
                error_count = error_count + 1;
            end
            if (!hit && (error === 1'b0))
                $display("  PASS [CACHE_HIT_COV Step7]: miss on tag mismatch read, error=0.");

            // Step 8: Clear valid bit again
            comp     = 0;
            write    = 1;
            valid_in = 1'b0;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag;

            @(negedge clk);
            $display("  [Step 8] Clear valid bit again. index=%0d", cov_index);
            // Checker 7h: clearing valid must not cause error
            if (error !== 1'b0) begin
                $display("  FAIL [CACHE_HIT_COV Step8]: error asserted during valid-clear at time %0t",
                         $time);
                error_count = error_count + 1;
            end else
                $display("  PASS [CACHE_HIT_COV Step8]: no error during valid-clear.");

            // Step 9: Compare-read on invalid line → hit=0 (valid bit cleared), error=0
            comp     = 1;
            write    = 0;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag;

            @(negedge clk);
            $display("  [Step 9] Compare-read on invalid line. index=%0d, tag=%b (expected miss)",
                     cov_index, cov_tag);
            // Checker 7i: invalid line after clear → hit=0, error=0
            if (hit) begin
                $display("  FAIL [CACHE_HIT_COV Step9]: hit asserted on cleared (invalid) line at time %0t",
                         $time);
                error_count = error_count + 1;
            end
            if (error !== 1'b0) begin
                $display("  FAIL [CACHE_HIT_COV Step9]: error asserted unexpectedly at time %0t", $time);
                error_count = error_count + 1;
            end
            if (!hit && (error === 1'b0))
                $display("  PASS [CACHE_HIT_COV Step9]: no hit on cleared line, error=0.");
        end
    endtask

    initial begin
        $dumpfile("direct_map_cache.vcd");
        $dumpvars(0, tb_direct_map_cache);
    end

endmodule
