`timescale 1ns/1ps

module tb_direct_map_cache;

    parameter CACHE_SIZE   = 256; // Number of cache lines
    parameter DATA_WIDTH   = 16;  // Width of data
    parameter TAG_WIDTH    = 5;   // Width of the tag
    parameter OFFSET_WIDTH = 3;   // Width of the offset
    localparam INDEX_WIDTH = $clog2(CACHE_SIZE); // Width of the index

    reg enable;
    reg [INDEX_WIDTH-1:0] index;
    reg [OFFSET_WIDTH-1:0] offset;
    reg comp;
    reg write;
    reg [TAG_WIDTH-1:0] tag_in;
    reg [DATA_WIDTH-1:0] data_in;
    reg valid_in;
    reg clk;
    reg rst;

    wire hit;
    wire dirty;
    wire [TAG_WIDTH-1:0] tag_out;
    wire [DATA_WIDTH-1:0] data_out;
    wire valid;
    wire error;

    direct_map_cache #(
        .CACHE_SIZE(CACHE_SIZE),
        .DATA_WIDTH(DATA_WIDTH),
        .TAG_WIDTH(TAG_WIDTH),
        .OFFSET_WIDTH(OFFSET_WIDTH)
    ) uut (
        .enable(enable),
        .index(index),
        .offset(offset),
        .comp(comp),
        .write(write),
        .tag_in(tag_in),
        .data_in(data_in),
        .valid_in(valid_in),
        .clk(clk),
        .rst(rst),
        .hit(hit),
        .dirty(dirty),
        .tag_out(tag_out),
        .data_out(data_out),
        .valid(valid),
        .error(error)
    );

    initial begin
        clk = 0;
        forever #5 clk = ~clk; 
    end

    reg [INDEX_WIDTH-1:0] stored_index;
    reg [OFFSET_WIDTH-1:0] stored_offset;
    reg [TAG_WIDTH-1:0]    stored_tag;
    reg [DATA_WIDTH-1:0]   stored_data;

    initial begin
        reset();
    repeat(10) begin
        write_comp0();
        @(negedge clk);

        read_comp1();
        @(negedge clk);

        write_comp1();
        @(negedge clk);

        read_comp1();
        @(negedge clk);

        miss_test();
        @(negedge clk);

        write_comp1();
        @(negedge clk);

        read_comp0();
        @(negedge clk);
    end
        force_offset_error();
        @(negedge clk);

        write_comp0();
        @(negedge clk);

        reset();
        @(negedge clk);

        cache_hit_condition_scenarios(); 

        // Wait a bit and finish
        #50;
        $finish;
    end

    task reset();
        begin
            rst     = 1;
            enable  = 0;
            comp    = 0;
            write   = 0;
            index   = 0;
            offset  = 0;
            tag_in  = 0;
            data_in = 0;
            valid_in= 0;

            @(negedge clk);
            rst = 0;
            @(negedge clk);
            $display("\n[RESET] Completed at time %0t", $time);
        end
    endtask

    task write_comp0();
        begin
            enable   = 1;
            comp     = 0;
            write    = 1;
            valid_in = 1'b1;

            stored_index = $random % CACHE_SIZE;
            stored_offset = ($random % (1<<OFFSET_WIDTH)) & ~1;
            stored_tag    = $random % (1<<TAG_WIDTH);
            stored_data   = $random % (1<<DATA_WIDTH);

            index   = stored_index;
            offset  = stored_offset;
            tag_in  = stored_tag;
            data_in = stored_data;

            @(negedge clk);
            $display("\n[WRITE_COMP0] @time %0t", $time);
            $display("  -> index=%0d, offset=%0d, tag_in=%b, data_in=%0h", 
                      index, offset, tag_in, data_in);
            $display("  -> comp=%b, write=%b, valid_in=%b", comp, write, valid_in);

        end
    endtask

    task read_comp1();
        begin
            comp  = 1;
            write = 0;
            index   = stored_index;
            offset  = stored_offset;
            tag_in  = stored_tag;

            @(negedge clk);
            $display("\n[READ_COMP1] @time %0t", $time);
            $display("  -> index=%0d, offset=%0d, tag_in=%b, data_out=%0h, valid=%b, hit=%b",
                     index, offset, tag_in, data_out, valid, hit);

        end
    endtask

    task write_comp1();
        begin
            comp   = 1;
            write  = 1;
            enable = 1;
            valid_in = 1'b1;

            index   = stored_index;
            offset  = stored_offset;
            tag_in  = stored_tag;
            stored_data = $random % (1<<DATA_WIDTH);
            data_in = stored_data;

            @(negedge clk);
            $display("\n[WRITE_COMP1] @time %0t", $time);
            $display("  -> index=%0d, offset=%0d, tag_in=%b, data_in=%0h, comp=%b, write=%b",
                     index, offset, tag_in, data_in, comp, write);

        end
    endtask

    task read_comp0();
        begin
            comp  = 0;
            write = 0;
            index   = stored_index;
            offset  = stored_offset;
            tag_in  = stored_tag;

            @(negedge clk);
            $display("\n[READ_COMP0] @time %0t", $time);
            $display("  -> index=%0d, offset=%0d, tag_in=%b, data_out=%0h, valid=%b, hit=%b", 
                     index, offset, tag_in, data_out, valid, hit);

        end
    endtask

    task miss_test();
        reg [INDEX_WIDTH-1:0] new_index;
        begin
            comp  = 1;
            write = 0;
            enable = 1;

            new_index = (stored_index + 1) % CACHE_SIZE;
            index = new_index;
            offset = ($random % (1<<OFFSET_WIDTH)) & ~1;
            tag_in = $random % (1<<TAG_WIDTH);

            @(negedge clk);
            $display("\n[MISS_TEST] @time %0t", $time);
            $display("  -> new_index=%0d, offset=%0d, tag_in=%b, data_out=%0h, valid=%b, hit=%b",
                     new_index, offset, tag_in, data_out, valid, hit);

        end
    endtask

    task force_offset_error();
        begin
            $display("\n[OFFSET_ERROR_TEST] Forcing offset LSB=1, expecting 'error=1'.");
            offset = 3'b001; // LSB=1
            comp   = 0; 
            write  = 0;
            index  = 0;
            tag_in = 0;
            data_in= 0;
            @(negedge clk);

        end
    endtask

 task cache_hit_condition_scenarios();
        reg [INDEX_WIDTH-1:0] cov_index;
        reg [OFFSET_WIDTH-1:0] cov_offset;
        reg [TAG_WIDTH-1:0]    cov_tag, cov_mismatch_tag;
        reg [DATA_WIDTH-1:0]   cov_data;

        begin
            $display("\n[COVER_CACHE_HIT_CONDITION] Forcing scenarios to cover 'hit' condition sub-cases:");
            $display("  Condition A = (tags[index] == tag_in)");
            $display("  Condition B = valid_bits[index]");

            enable   = 1;
            comp     = 0; 
            write    = 1; 
            valid_in = 1'b1;  

            cov_index = $random % CACHE_SIZE;
            cov_offset = ($random % (1 << OFFSET_WIDTH)) & ~1; 
            cov_tag    = $random % (1 << TAG_WIDTH);
            cov_data   = $random % (1 << DATA_WIDTH);

            cov_mismatch_tag = cov_tag ^ 1;

            index   = cov_index;
            offset  = cov_offset;
            tag_in  = cov_tag;
            data_in = cov_data;

            @(negedge clk);
            $display("Made line valid -> tags[index] == tag_in is high , valid_bits[index]=1.  index=%0d, tag=%b", 
                     cov_index, cov_tag);

            comp     = 1;
            write    = 1;
            valid_in = 1'b1; // remains valid
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_mismatch_tag; // mismatch
            data_in  = $random;

            @(negedge clk);
            $display("Compare-Write mismatch. index=%0d", cov_index);

            comp     = 0;
            write    = 1;
            valid_in = 1'b0; // sets valid_bits=0
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag;
            data_in  = $random;

            @(negedge clk);
            $display("Clearing valid bit.  index=%0d", cov_index);

            comp     = 1;
            write    = 1;
            valid_in = 1'b1; 
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag; 
            data_in  = $random;

            @(negedge clk);
            $display("Compare-Write. index=%0d", cov_index);

            comp     = 0;
            write    = 1;
            valid_in = 1'b1;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag;
            data_in  = $random;
            @(negedge clk);
            $display("Re-validate.  index=%0d, tag=%b", cov_index, cov_tag);

            comp     = 1;
            write    = 0;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_mismatch_tag;  // mismatch
            @(negedge clk);
            $display("Compare-Read mismatch. index=%0d", cov_index);

            comp     = 0;
            write    = 1;
            valid_in = 1'b0;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag;
            @(negedge clk);

            comp     = 1;
            write    = 0;
            index    = cov_index;
            offset   = cov_offset;
            tag_in   = cov_tag;
            @(negedge clk);
            $display("Compare-Read. index=%0d", cov_index);
        end
    endtask

    initial begin
        $dumpfile("direct_map_cache.vcd");
        $dumpvars(0, tb_direct_map_cache);
    end

endmodule