`timescale 1ns/1ps

module tb_direct_map_cache;

    // Parameters matching UUT defaults
    localparam CACHE_SIZE   = 256;
    localparam DATA_WIDTH   = 16;
    localparam TAG_WIDTH    = 5;
    localparam OFFSET_WIDTH = 3;
    localparam INDEX_WIDTH  = $clog2(CACHE_SIZE); // 8

    // DUT signal declarations
    logic                    clk;
    logic                    rst;
    logic                    enable;
    logic [INDEX_WIDTH-1:0]  index;
    logic [OFFSET_WIDTH-1:0] offset;
    logic                    comp;
    logic                    write;
    logic [TAG_WIDTH-1:0]    tag_in;
    logic [DATA_WIDTH-1:0]   data_in;
    logic                    valid_in;

    logic                    hit;
    logic                    dirty;
    logic [TAG_WIDTH-1:0]    tag_out;
    logic [DATA_WIDTH-1:0]   data_out;
    logic                    valid;
    logic                    error;

    // Module-level loop variables
    integer li;
    integer lj;

    // -----------------------------------------------------------------------
    // UUT instantiation
    // -----------------------------------------------------------------------
    direct_map_cache #(
        .CACHE_SIZE   (CACHE_SIZE),
        .DATA_WIDTH   (DATA_WIDTH),
        .TAG_WIDTH    (TAG_WIDTH),
        .OFFSET_WIDTH (OFFSET_WIDTH)
    ) uut (
        .clk      (clk),
        .rst      (rst),
        .enable   (enable),
        .index    (index),
        .offset   (offset),
        .comp     (comp),
        .write    (write),
        .tag_in   (tag_in),
        .data_in  (data_in),
        .valid_in (valid_in),
        .hit      (hit),
        .dirty    (dirty),
        .tag_out  (tag_out),
        .data_out (data_out),
        .valid    (valid),
        .error    (error)
    );

    // Clock: 10 ns period
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // -----------------------------------------------------------------------
    // Task 1: Reset and Initialization
    // Drives reset high for several cycles then deasserts and enables the DUT.
    // -----------------------------------------------------------------------
    task task_reset;
        $display("\n=== TASK: Reset / Initialization ===");
        rst      = 1'b1;
        enable   = 1'b0;
        comp     = 1'b0;
        write    = 1'b0;
        index    = '0;
        offset   = '0;
        tag_in   = '0;
        data_in  = '0;
        valid_in = 1'b0;
        repeat(4) @(posedge clk);
        #1;
        rst    = 1'b0;
        enable = 1'b1;
        @(posedge clk);
        #1;
        $display("  [RESET] hit=%0b dirty=%0b valid=%0b error=%0b data_out=%04h",
                 hit, dirty, valid, error, data_out);
    endtask

    // -----------------------------------------------------------------------
    // Task 2: Write with Compare Disabled (comp=0, write=1)
    // Unconditionally writes tag, data, and valid state into the cache line.
    // dirty_bits is always cleared by this mode.
    // -----------------------------------------------------------------------
    task task_write_no_compare(
        input [INDEX_WIDTH-1:0]  t_idx,
        input [OFFSET_WIDTH-1:0] t_off,
        input [TAG_WIDTH-1:0]    t_tag,
        input [DATA_WIDTH-1:0]   t_dat,
        input                    t_vld
    );
        comp     = 1'b0;
        write    = 1'b1;
        index    = t_idx;
        offset   = t_off;
        tag_in   = t_tag;
        data_in  = t_dat;
        valid_in = t_vld;
        @(posedge clk);
        #1;
        $display("  [WR-NOCOMP] idx=%3d off=%3b tag=%2h data=%4h vld_in=%0b | hit=%0b dirty=%0b valid=%0b error=%0b",
                 t_idx, t_off, t_tag, t_dat, t_vld, hit, dirty, valid, error);
    endtask

    // -----------------------------------------------------------------------
    // Task 3: Read with Compare Enabled (comp=1, write=0)
    // Checks tag against stored value; hit=1 only when tag matches AND valid=1.
    // -----------------------------------------------------------------------
    task task_read_compare(
        input [INDEX_WIDTH-1:0]  t_idx,
        input [OFFSET_WIDTH-1:0] t_off,
        input [TAG_WIDTH-1:0]    t_tag
    );
        comp     = 1'b1;
        write    = 1'b0;
        index    = t_idx;
        offset   = t_off;
        tag_in   = t_tag;
        data_in  = '0;
        valid_in = 1'b0;
        @(posedge clk);
        #1;
        $display("  [RD-COMP]   idx=%3d off=%3b tag=%2h | hit=%0b dirty=%0b valid=%0b data_out=%4h tag_out=%2h error=%0b",
                 t_idx, t_off, t_tag, hit, dirty, valid, data_out, tag_out, error);
    endtask

    // -----------------------------------------------------------------------
    // Task 4: Write with Compare Enabled (comp=1, write=1)
    // Overwrites data and marks dirty on a tag+valid hit; on miss, evicts the
    // existing line and installs a fresh entry with dirty cleared.
    // -----------------------------------------------------------------------
    task task_write_compare(
        input [INDEX_WIDTH-1:0]  t_idx,
        input [OFFSET_WIDTH-1:0] t_off,
        input [TAG_WIDTH-1:0]    t_tag,
        input [DATA_WIDTH-1:0]   t_dat,
        input                    t_vld
    );
        comp     = 1'b1;
        write    = 1'b1;
        index    = t_idx;
        offset   = t_off;
        tag_in   = t_tag;
        data_in  = t_dat;
        valid_in = t_vld;
        @(posedge clk);
        #1;
        $display("  [WR-COMP]   idx=%3d off=%3b tag=%2h data=%4h vld_in=%0b | hit=%0b dirty=%0b valid=%0b error=%0b",
                 t_idx, t_off, t_tag, t_dat, t_vld, hit, dirty, valid, error);
    endtask

    // -----------------------------------------------------------------------
    // Task 5: Read with Compare Disabled (comp=0, write=0)
    // Returns tag/data/valid/dirty unconditionally; hit is always 0.
    // -----------------------------------------------------------------------
    task task_read_no_compare(
        input [INDEX_WIDTH-1:0]  t_idx,
        input [OFFSET_WIDTH-1:0] t_off
    );
        comp     = 1'b0;
        write    = 1'b0;
        index    = t_idx;
        offset   = t_off;
        tag_in   = '0;
        data_in  = '0;
        valid_in = 1'b0;
        @(posedge clk);
        #1;
        $display("  [RD-NOCOMP] idx=%3d off=%3b | hit=%0b dirty=%0b valid=%0b data_out=%4h tag_out=%2h error=%0b",
                 t_idx, t_off, hit, dirty, valid, data_out, tag_out, error);
    endtask

    // -----------------------------------------------------------------------
    // Task 6: Miss Scenario Generation
    // Populates a line with stored_tag then reads with miss_tag (different
    // value) to guarantee a compare miss.
    // -----------------------------------------------------------------------
    task task_miss_scenario(
        input [INDEX_WIDTH-1:0]  t_idx,
        input [OFFSET_WIDTH-1:0] t_off,
        input [TAG_WIDTH-1:0]    t_stored_tag,
        input [TAG_WIDTH-1:0]    t_miss_tag,
        input [DATA_WIDTH-1:0]   t_dat
    );
        $display("  [MISS-SETUP] Populate idx=%3d off=%3b tag=%2h data=%4h",
                 t_idx, t_off, t_stored_tag, t_dat);
        // Populate the cache line unconditionally
        comp     = 1'b0;
        write    = 1'b1;
        index    = t_idx;
        offset   = t_off;
        tag_in   = t_stored_tag;
        data_in  = t_dat;
        valid_in = 1'b1;
        @(posedge clk);
        #1;
        // Compare-read with a deliberately mismatched tag
        comp     = 1'b1;
        write    = 1'b0;
        index    = t_idx;
        offset   = t_off;
        tag_in   = t_miss_tag;
        data_in  = '0;
        valid_in = 1'b0;
        @(posedge clk);
        #1;
        $display("  [MISS-READ]  idx=%3d off=%3b stored=%2h vs lookup=%2h | hit=%0b error=%0b [expect hit=0]",
                 t_idx, t_off, t_stored_tag, t_miss_tag, hit, error);
    endtask

    // -----------------------------------------------------------------------
    // Task 7: Offset Error Injection
    // Applies an offset with LSB=1, which the DUT treats as an alignment error.
    // -----------------------------------------------------------------------
    task task_offset_error(
        input [INDEX_WIDTH-1:0]  t_idx,
        input [OFFSET_WIDTH-1:0] t_off,    // caller must set t_off[0] = 1
        input [TAG_WIDTH-1:0]    t_tag,
        input [DATA_WIDTH-1:0]   t_dat,
        input                    t_write
    );
        comp     = 1'b0;
        write    = t_write;
        index    = t_idx;
        offset   = t_off;
        tag_in   = t_tag;
        data_in  = t_dat;
        valid_in = 1'b1;
        @(posedge clk);
        #1;
        $display("  [OFF-ERROR]  idx=%3d off=%3b (LSB=%0b) write=%0b | hit=%0b dirty=%0b valid=%0b error=%0b [expect error=1]",
                 t_idx, t_off, t_off[0], t_write, hit, dirty, valid, error);
    endtask

    // -----------------------------------------------------------------------
    // Task 8: Coverage Corner Cases
    // Exercises the four combinations of (valid/invalid) × (tag match/mismatch)
    // at a given cache index to ensure the hit logic handles every case.
    // -----------------------------------------------------------------------
    task task_coverage_corners(
        input [INDEX_WIDTH-1:0]  t_idx,
        input [OFFSET_WIDTH-1:0] t_off,
        input [TAG_WIDTH-1:0]    t_tag,
        input [DATA_WIDTH-1:0]   t_dat
    );
        $display("  --- Coverage Corners: idx=%3d off=%3b tag=%2h ---", t_idx, t_off, t_tag);

        // Setup: install a valid line with known tag (no-compare write)
        comp     = 1'b0;
        write    = 1'b1;
        index    = t_idx;
        offset   = t_off;
        tag_in   = t_tag;
        data_in  = t_dat;
        valid_in = 1'b1;
        @(posedge clk);
        #1;

        // Corner 1: valid line + matching tag → hit=1, valid=1
        comp   = 1'b1;
        write  = 1'b0;
        tag_in = t_tag;
        @(posedge clk);
        #1;
        $display("  [CORNER-1] valid+match_tag    : hit=%0b valid=%0b [expect hit=1 valid=1]", hit, valid);

        // Corner 2: valid line + mismatching tag → hit=0
        comp   = 1'b1;
        write  = 1'b0;
        tag_in = ~t_tag;   // bitwise NOT guarantees a different 5-bit value
        @(posedge clk);
        #1;
        $display("  [CORNER-2] valid+mismatch_tag : hit=%0b valid=%0b [expect hit=0]", hit, valid);

        // Invalidate the line: no-compare write with valid_in=0
        comp     = 1'b0;
        write    = 1'b1;
        tag_in   = t_tag;
        data_in  = t_dat;
        valid_in = 1'b0;
        @(posedge clk);
        #1;

        // Corner 3: invalid line + matching tag → hit=0, valid=0
        comp   = 1'b1;
        write  = 1'b0;
        tag_in = t_tag;
        @(posedge clk);
        #1;
        $display("  [CORNER-3] invalid+match_tag  : hit=%0b valid=%0b [expect hit=0 valid=0]", hit, valid);

        // Corner 4: invalid line + mismatching tag → hit=0, valid=0
        comp   = 1'b1;
        write  = 1'b0;
        tag_in = ~t_tag;
        @(posedge clk);
        #1;
        $display("  [CORNER-4] invalid+mismatch_tag: hit=%0b valid=%0b [expect hit=0 valid=0]", hit, valid);
    endtask

    // -----------------------------------------------------------------------
    // Main stimulus sequence
    // -----------------------------------------------------------------------
    initial begin
        $timeformat(-9, 1, " ns", 10);
        $display("============================================");
        $display("  direct_map_cache Testbench Starting      ");
        $display("============================================");

        // Initialize all inputs before clock edges begin
        rst      = 1'b0;
        enable   = 1'b0;
        comp     = 1'b0;
        write    = 1'b0;
        index    = '0;
        offset   = '0;
        tag_in   = '0;
        data_in  = '0;
        valid_in = 1'b0;

        // ------------------------------------------------------------
        // Phase 1: Reset
        // ------------------------------------------------------------
        task_reset();

        // ------------------------------------------------------------
        // Phase 2: Write with Compare Disabled
        // Populate 8 lines and verify dirty is always 0 after this mode.
        // ------------------------------------------------------------
        $display("\n=== PHASE 2: Write with Compare Disabled ===");
        for (li = 0; li < 8; li++) begin
            task_write_no_compare(
                INDEX_WIDTH'(li),
                3'b000,
                TAG_WIDTH'(li + 1),        // tags 1..8
                DATA_WIDTH'(16'hAA00 + li),
                1'b1
            );
        end
        // Exercise all four valid (even) offsets on distinct indices
        task_write_no_compare(8'd10, 3'b000, 5'h0A, 16'h1111, 1'b1);
        task_write_no_compare(8'd11, 3'b010, 5'h0B, 16'h2222, 1'b1);
        task_write_no_compare(8'd12, 3'b100, 5'h0C, 16'h3333, 1'b1);
        task_write_no_compare(8'd13, 3'b110, 5'h0D, 16'h4444, 1'b1);

        // ------------------------------------------------------------
        // Phase 3: Read with Compare Enabled
        // Expect hits for the matching tags written in Phase 2;
        // expect misses when a wrong tag is supplied.
        // ------------------------------------------------------------
        $display("\n=== PHASE 3: Read with Compare Enabled ===");
        for (li = 0; li < 8; li++) begin
            task_read_compare(INDEX_WIDTH'(li), 3'b000, TAG_WIDTH'(li + 1)); // hit expected
        end
        for (li = 0; li < 4; li++) begin
            task_read_compare(INDEX_WIDTH'(li), 3'b000, 5'h1F); // tag mismatch: miss expected
        end
        // Verify offset-addressed data written in Phase 2
        task_read_compare(8'd11, 3'b010, 5'h0B);
        task_read_compare(8'd12, 3'b100, 5'h0C);
        task_read_compare(8'd13, 3'b110, 5'h0D);

        // ------------------------------------------------------------
        // Phase 4: Write with Compare Enabled
        // Hit path marks dirty; miss path evicts and clears dirty.
        // ------------------------------------------------------------
        $display("\n=== PHASE 4: Write with Compare Enabled ===");
        // Hit: tag matches → data updated, dirty_bit set
        task_write_compare(8'd0, 3'b000, 5'h01, 16'hDEAD, 1'b1);
        task_read_compare(8'd0, 3'b000, 5'h01);   // verify updated data and dirty=1

        // Miss: tag differs → eviction, new tag installed, dirty cleared
        task_write_compare(8'd1, 3'b000, 5'h1F, 16'hBEEF, 1'b1);
        task_read_compare(8'd1, 3'b000, 5'h1F);   // now a hit with new tag

        // Sweep: write-compare then read-compare across indices 20-23
        for (li = 0; li < 4; li++) begin
            task_write_compare(
                INDEX_WIDTH'(li + 20), 3'b000,
                TAG_WIDTH'(li + 10),
                DATA_WIDTH'(16'hF000 + li),
                1'b1
            );
        end
        for (li = 0; li < 4; li++) begin
            task_read_compare(INDEX_WIDTH'(li + 20), 3'b000, TAG_WIDTH'(li + 10));
        end

        // ------------------------------------------------------------
        // Phase 5: Read with Compare Disabled
        // Retrieves raw cache contents; hit is always 0 in this mode.
        // ------------------------------------------------------------
        $display("\n=== PHASE 5: Read with Compare Disabled ===");
        for (li = 0; li < 8; li++) begin
            task_read_no_compare(INDEX_WIDTH'(li), 3'b000);
        end
        task_read_no_compare(8'd10, 3'b000);
        task_read_no_compare(8'd11, 3'b010);
        task_read_no_compare(8'd12, 3'b100);
        task_read_no_compare(8'd13, 3'b110);

        // ------------------------------------------------------------
        // Phase 6: Miss Scenario Generation
        // Each call populates a line then reads with a different tag.
        // ------------------------------------------------------------
        $display("\n=== PHASE 6: Miss Scenario Generation ===");
        task_miss_scenario(8'd50, 3'b000, 5'h05, 5'h15, 16'hCAFE);
        task_miss_scenario(8'd60, 3'b010, 5'h0A, 5'h0B, 16'hFACE);
        task_miss_scenario(8'd70, 3'b100, 5'h1E, 5'h00, 16'hBABE);
        task_miss_scenario(8'd75, 3'b110, 5'h03, 5'h1C, 16'hD00D);
        for (li = 0; li < 4; li++) begin
            task_miss_scenario(
                INDEX_WIDTH'(100 + li),
                3'b000,
                TAG_WIDTH'(li + 1),
                TAG_WIDTH'(li + 16),   // offset by 15 guarantees no match
                DATA_WIDTH'(16'hCC00 + li)
            );
        end

        // ------------------------------------------------------------
        // Phase 7: Offset Error Injection
        // Any offset with LSB=1 must assert error and suppress normal output.
        // ------------------------------------------------------------
        $display("\n=== PHASE 7: Offset Error Injection ===");
        // Write operations with odd offsets
        task_offset_error(8'd5,  3'b001, 5'h01, 16'hFFFF, 1'b1);
        task_offset_error(8'd10, 3'b011, 5'h02, 16'hAAAA, 1'b1);
        task_offset_error(8'd15, 3'b101, 5'h03, 16'h5555, 1'b1);
        task_offset_error(8'd20, 3'b111, 5'h04, 16'h1234, 1'b0);
        // Read operations with odd offsets (compare mode)
        for (li = 0; li < 4; li++) begin
            comp     = 1'b1;
            write    = 1'b0;
            index    = INDEX_WIDTH'(30 + li);
            offset   = 3'b001;
            tag_in   = TAG_WIDTH'(li);
            data_in  = '0;
            valid_in = 1'b0;
            @(posedge clk);
            #1;
            $display("  [OFF-ERR-RD] idx=%3d off=001 | hit=%0b error=%0b [expect error=1]",
                     30 + li, hit, error);
        end

        // ------------------------------------------------------------
        // Phase 8: Coverage Corner Cases
        // Four (valid/invalid)×(match/mismatch) combinations per index.
        // ------------------------------------------------------------
        $display("\n=== PHASE 8: Coverage Corner Cases ===");
        task_coverage_corners(8'd80,  3'b000, 5'h1A, 16'hCCCC);
        task_coverage_corners(8'd90,  3'b010, 5'h0F, 16'h3333);
        task_coverage_corners(8'd100, 3'b100, 5'h05, 16'hAAAA);
        task_coverage_corners(8'd110, 3'b110, 5'h1F, 16'h7777);

        // ------------------------------------------------------------
        // Phase 9: Systematic Multi-Index Sweep (16 indices, spread across cache)
        // Write → read-hit → compare-write hit → read-hit again
        // ------------------------------------------------------------
        $display("\n=== PHASE 9: Systematic Multi-Index Sweep ===");
        for (li = 0; li < 16; li++) begin
            task_write_no_compare(
                INDEX_WIDTH'(li * 15),     // indices: 0, 15, 30, … 225
                3'b000,
                TAG_WIDTH'(li % 32),
                DATA_WIDTH'(16'hA000 + li),
                1'b1
            );
        end
        for (li = 0; li < 16; li++) begin
            task_read_compare(INDEX_WIDTH'(li * 15), 3'b000, TAG_WIDTH'(li % 32)); // all hit
        end
        // Overwrite first 8 entries via compare-write (hit path → dirty set)
        for (li = 0; li < 8; li++) begin
            task_write_compare(
                INDEX_WIDTH'(li * 15), 3'b000,
                TAG_WIDTH'(li % 32),
                DATA_WIDTH'(16'hB000 + li),
                1'b1
            );
        end
        // Read all 16 back: first 8 show new data and dirty=1, last 8 unchanged
        for (li = 0; li < 16; li++) begin
            task_read_compare(INDEX_WIDTH'(li * 15), 3'b000, TAG_WIDTH'(li % 32));
        end

        // ------------------------------------------------------------
        // Phase 10: Dirty Bit Tests
        // no-compare write always clears dirty; compare-write hit sets it.
        // ------------------------------------------------------------
        $display("\n=== PHASE 10: Dirty Bit Tests ===");
        task_write_no_compare(8'd200, 3'b000, 5'h1C, 16'hDDDD, 1'b1); // dirty_bit = 0
        task_read_no_compare(8'd200, 3'b000);              // check dirty=0
        task_write_compare(8'd200, 3'b000, 5'h1C, 16'hEEEE, 1'b1);    // hit → dirty_bit = 1
        task_read_compare(8'd200, 3'b000, 5'h1C);          // check dirty=1

        // Verify compare-write miss resets dirty on a previously dirty line
        task_write_compare(8'd200, 3'b000, 5'h00, 16'h1234, 1'b1);    // tag mismatch → evict, dirty cleared
        task_read_compare(8'd200, 3'b000, 5'h00);          // new tag, dirty=0

        // ------------------------------------------------------------
        // Phase 11: Enable De-assertion Test
        // Deasserting enable clears all valid/dirty bits.
        // ------------------------------------------------------------
        $display("\n=== PHASE 11: Enable De-assertion Test ===");
        task_write_no_compare(8'd250, 3'b000, 5'h1F, 16'hFFFF, 1'b1);
        enable = 1'b0;
        @(posedge clk);
        #1;
        $display("  [ENABLE=0] hit=%0b dirty=%0b valid=%0b data_out=%04h error=%0b [expect zeros]",
                 hit, dirty, valid, data_out, error);
        enable = 1'b1;
        // After re-enable, valid_bits were wiped so the previous entry is gone
        task_read_compare(8'd250, 3'b000, 5'h1F); // miss expected (valid=0)

        // ------------------------------------------------------------
        // Phase 12: Nested loop — all four valid offsets × four indices
        // Exercises offset[2:1] addressing across the data_mem sub-array.
        // ------------------------------------------------------------
        $display("\n=== PHASE 12: All Valid Offsets x Multiple Indices ===");
        for (li = 0; li < 4; li++) begin
            for (lj = 0; lj < 4; lj++) begin
                task_write_no_compare(
                    INDEX_WIDTH'(130 + li * 4 + lj),
                    OFFSET_WIDTH'(lj * 2),           // offsets 0, 2, 4, 6
                    TAG_WIDTH'(li * 4 + lj),
                    DATA_WIDTH'(16'hE000 + li * 4 + lj),
                    1'b1
                );
            end
        end
        for (li = 0; li < 4; li++) begin
            for (lj = 0; lj < 4; lj++) begin
                task_read_compare(
                    INDEX_WIDTH'(130 + li * 4 + lj),
                    OFFSET_WIDTH'(lj * 2),
                    TAG_WIDTH'(li * 4 + lj)
                );
            end
        end

        // ------------------------------------------------------------
        // Phase 13: Valid_in toggling during compare-write
        // Verifies that valid_in drives valid_bits correctly on both
        // hit and miss paths of the compare-write mode.
        // ------------------------------------------------------------
        $display("\n=== PHASE 13: valid_in Toggling via Compare-Write ===");
        // Populate with valid=1
        task_write_no_compare(8'd160, 3'b000, 5'h0E, 16'h1234, 1'b1);
        // Compare-write hit with valid_in=0 — should clear valid after write
        task_write_compare(8'd160, 3'b000, 5'h0E, 16'h5678, 1'b0);
        task_read_compare(8'd160, 3'b000, 5'h0E);   // tag matches but valid=0 → miss

        // Compare-write miss with valid_in=1 — installs new entry as valid
        task_write_compare(8'd160, 3'b000, 5'h1B, 16'hABCD, 1'b1);
        task_read_compare(8'd160, 3'b000, 5'h1B);   // now hit

        // ------------------------------------------------------------
        // Phase 14: Repeated access to same index with rotating tags
        // ------------------------------------------------------------
        $display("\n=== PHASE 14: Rotating Tags on Same Index ===");
        for (li = 0; li < 8; li++) begin
            // Install tag = li+1
            task_write_no_compare(8'd170, 3'b000, TAG_WIDTH'(li + 1), DATA_WIDTH'(16'hFF00 + li), 1'b1);
            // Correct tag → hit
            task_read_compare(8'd170, 3'b000, TAG_WIDTH'(li + 1));
            // Previous tag → miss (also tests eviction visibility)
            if (li > 0)
                task_read_compare(8'd170, 3'b000, TAG_WIDTH'(li)); // prior tag no longer stored
        end

        $display("\n============================================");
        $display("  All Tests Complete                        ");
        $display("============================================");
        $finish;
    end

endmodule
