import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, FallingEdge, ReadOnly , Timer

import harness_library as hrs_lb
import random

# ---------------------------------------
# Helper: Hamming Distance Function
# ---------------------------------------
def compute_hamming(a, b, width):
    return bin(a ^ b).count('1')

# ---------------------------------------
# Helper: Reference Data Packer
# ---------------------------------------
def pack_refs_and_labels(refs, labels, bit_width, label_width):
    ref_data = 0
    label_data = 0
    for i, (ref, label) in enumerate(zip(refs, labels)):
        ref_data   |= (ref   << (i * bit_width))
        label_data |= (label << (i * label_width))
    return ref_data, label_data


def assert_outputs(dut, query, refs, labels, bit_width):
    # Compute expected values
    best_dist = bit_width + 1
    best_idx  = 0
    for i, ref in enumerate(refs):
        d = compute_hamming(query, ref, bit_width)
        if d < best_dist:
            best_dist = d
            best_idx = i

    expected_label = labels[best_idx]

    assert dut.min_distance.value == best_dist, f"[FAIL] Expected min_distance={best_dist}, got={dut.min_distance.value}"
    assert dut.match_index.value == best_idx, f"[FAIL] Expected match_index={best_idx}, got={dut.match_index.value}"
    assert dut.predicted_label.value == expected_label, f"[FAIL] Expected predicted_label={expected_label}, got={dut.predicted_label.value}"

    cocotb.log.info(f"[ASSERTION PASS] Outputs validated: match_index={best_idx}, min_distance={best_dist}, label={expected_label}")

# ---------------------------------------
# Corner Case Runner
# ---------------------------------------
async def run_corner_cases(dut, BIT_WIDTH, REFERENCE_COUNT, LABEL_WIDTH):
    cocotb.log.info("Running Corner Case Tests...")

    # All references match input_query
    query = int('1' * BIT_WIDTH, 2)
    refs  = [query] * REFERENCE_COUNT
    labels = list(range(REFERENCE_COUNT))
    ref_data, label_data = pack_refs_and_labels(refs, labels, BIT_WIDTH, LABEL_WIDTH)
    dut.input_query.value = query
    dut.reference_data.value = ref_data
    dut.reference_labels.value = label_data
    await Timer(1, unit='ns')
    assert_outputs(dut, query, refs, labels, BIT_WIDTH)

    # One exact match among others
    query = int('11001100', 2) & ((1 << BIT_WIDTH) - 1)
    refs = [int('11110000', 2) & ((1 << BIT_WIDTH) - 1),
            int('10101010', 2) & ((1 << BIT_WIDTH) - 1),
            query,
            0]
    while len(refs) < REFERENCE_COUNT:
        refs.append(random.getrandbits(BIT_WIDTH))
    labels = list(range(REFERENCE_COUNT))
    ref_data, label_data = pack_refs_and_labels(refs, labels, BIT_WIDTH, LABEL_WIDTH)
    dut.input_query.value = query
    dut.reference_data.value = ref_data
    dut.reference_labels.value = label_data
    await Timer(1, unit='ns')
    assert_outputs(dut, query, refs, labels, BIT_WIDTH)

    # Tied distances case
    query = int('00001111', 2) & ((1 << BIT_WIDTH) - 1)
    ref_tie = int('00011111', 2) & ((1 << BIT_WIDTH) - 1)
    refs = [ref_tie, ref_tie] + [random.getrandbits(BIT_WIDTH) for _ in range(REFERENCE_COUNT - 2)]
    labels = list(range(REFERENCE_COUNT))
    ref_data, label_data = pack_refs_and_labels(refs, labels, BIT_WIDTH, LABEL_WIDTH)
    dut.input_query.value = query
    dut.reference_data.value = ref_data
    dut.reference_labels.value = label_data
    await Timer(1, unit='ns')
    assert_outputs(dut, query, refs, labels, BIT_WIDTH)

    # One-hot refs and all-zero input
    query = 0
    refs = [1 << i for i in range(min(REFERENCE_COUNT, BIT_WIDTH))]
    while len(refs) < REFERENCE_COUNT:
        refs.append(random.getrandbits(BIT_WIDTH))
    labels = list(range(REFERENCE_COUNT))
    ref_data, label_data = pack_refs_and_labels(refs, labels, BIT_WIDTH, LABEL_WIDTH)
    dut.input_query.value = query
    dut.reference_data.value = ref_data
    dut.reference_labels.value = label_data
    await Timer(1, unit='ns')
    assert_outputs(dut, query, refs, labels, BIT_WIDTH)

    # Alternating bits input
    query = int('10' * (BIT_WIDTH // 2), 2)
    refs = [query, ~query & ((1 << BIT_WIDTH) - 1)] + [0xFF, 0x00]
    refs = refs[:REFERENCE_COUNT]
    labels = list(range(REFERENCE_COUNT))
    ref_data, label_data = pack_refs_and_labels(refs, labels, BIT_WIDTH, LABEL_WIDTH)
    dut.input_query.value = query
    dut.reference_data.value = ref_data
    dut.reference_labels.value = label_data
    await Timer(1, unit='ns')
    assert_outputs(dut, query, refs, labels, BIT_WIDTH)

# ---------------------------------------
# Cocotb Main Test
# ---------------------------------------
@cocotb.test()
async def adaptive_parameterized_test(dut):
    # Read parameters from the DUT
    BIT_WIDTH        = int(dut.BIT_WIDTH.value)
    REFERENCE_COUNT  = int(dut.REFERENCE_COUNT.value)
    LABEL_WIDTH      = int(dut.LABEL_WIDTH.value)

    cocotb.log.info(f"Detected DUT Parameters: BIT_WIDTH={BIT_WIDTH}, REFERENCE_COUNT={REFERENCE_COUNT}, LABEL_WIDTH={LABEL_WIDTH}")
    
    await run_corner_cases(dut, BIT_WIDTH, REFERENCE_COUNT, LABEL_WIDTH)

    # Setup constants for signal widths
    ref_width   = REFERENCE_COUNT * BIT_WIDTH
    label_width = REFERENCE_COUNT * LABEL_WIDTH

    # --- CORNER TEST 1: All references match input ---
    query = int('1' * BIT_WIDTH, 2)
    refs  = [query] * REFERENCE_COUNT
    labels = list(range(REFERENCE_COUNT))
    ref_data, label_data = pack_refs_and_labels(refs, labels, BIT_WIDTH, LABEL_WIDTH)
    dut.input_query.value = query
    dut.reference_data.value = ref_data & ((1 << ref_width) - 1)
    dut.reference_labels.value = label_data & ((1 << label_width) - 1)
    await Timer(1, unit='ns')
    assert_outputs(dut, query, refs, labels, BIT_WIDTH)

    # --- CORNER TEST 2: All references different ---
    query = int('1' * BIT_WIDTH, 2)
    refs = [0x00] * REFERENCE_COUNT
    labels = list(range(REFERENCE_COUNT))
    ref_data, label_data = pack_refs_and_labels(refs, labels, BIT_WIDTH, LABEL_WIDTH)
    dut.input_query.value = query
    dut.reference_data.value = ref_data & ((1 << ref_width) - 1)
    dut.reference_labels.value = label_data & ((1 << label_width) - 1)
    await Timer(1, unit='ns')
    assert dut.min_distance.value == BIT_WIDTH, f"[FAIL] All references different: Expected min_distance = {BIT_WIDTH}"
    cocotb.log.info("[PASS] All references different")

    # --- CORNER TEST 3: is_input_uniform for all 1s ---
    dut.input_query.value = int('1' * BIT_WIDTH, 2)
    await Timer(1, unit='ns')
    assert int(dut.is_input_uniform.value) == 1, "[FAIL] is_input_uniform = 0 for all 1s input"
    cocotb.log.info("[PASS] is_input_uniform works for all 1s")


    # --- RANDOMIZED FUNCTIONAL TESTS ---
    for test_num in range(30):
        query = random.getrandbits(BIT_WIDTH)
        refs = [random.getrandbits(BIT_WIDTH) for _ in range(REFERENCE_COUNT)]
        labels = [random.randint(0, (1 << LABEL_WIDTH) - 1) for _ in range(REFERENCE_COUNT)]

        # Compute expected best match
        min_dist = BIT_WIDTH + 1
        match_idx = 0
        for i, ref in enumerate(refs):
            dist = compute_hamming(query, ref, BIT_WIDTH)
            if dist < min_dist:
                min_dist = dist
                match_idx = i

        ref_data, label_data = pack_refs_and_labels(refs, labels, BIT_WIDTH, LABEL_WIDTH)
        dut.input_query.value = query
        dut.reference_data.value = ref_data
        dut.reference_labels.value = label_data
        await Timer(1, unit='ns')

        assert dut.min_distance.value == min_dist, f"[FAIL] Random test #{test_num}: Wrong min_distance"
        assert dut.match_index.value == match_idx, f"[FAIL] Random test #{test_num}: Wrong match_index"
        assert dut.predicted_label.value == labels[match_idx], f"[FAIL] Random test #{test_num}: Wrong label"

        cocotb.log.info(f"[PASS] Random Test #{test_num} | Query={query:0{BIT_WIDTH}b} | Best Match Index={match_idx} | Distance={min_dist} | Label={labels[match_idx]}")

    cocotb.log.info(" All parameterized functional tests passed.")
