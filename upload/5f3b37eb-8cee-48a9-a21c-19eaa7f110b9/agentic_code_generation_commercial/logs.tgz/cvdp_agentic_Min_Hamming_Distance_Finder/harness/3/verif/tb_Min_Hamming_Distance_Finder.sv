`timescale 1ns / 1ps
module tb_Min_Hamming_Distance_Finder;

    // Testbench parameters
    parameter BIT_WIDTH       = 8;
    parameter REFERENCE_COUNT = 4;
    parameter LABEL_WIDTH     = 4;

    // DUT signal declarations
    reg  [BIT_WIDTH-1:0]                    input_query;
    reg  [REFERENCE_COUNT*BIT_WIDTH-1:0]    reference_data;
    reg  [REFERENCE_COUNT*LABEL_WIDTH-1:0]  reference_labels;
    wire [LABEL_WIDTH-1:0]                  predicted_label;
    wire [$clog2(BIT_WIDTH+1)-1:0]          min_distance;
    wire [$clog2(REFERENCE_COUNT)-1:0]      match_index;
    wire [BIT_WIDTH-1:0]                    bitwise_features;
    wire                                    is_input_uniform;

    // Instantiate the DUT
    Adaptive_Binary_Pattern_Classifier
    #(
        .BIT_WIDTH       (BIT_WIDTH),
        .REFERENCE_COUNT (REFERENCE_COUNT),
        .LABEL_WIDTH     (LABEL_WIDTH)
    )
    uut (
        .input_query      (input_query),
        .reference_data   (reference_data),
        .reference_labels (reference_labels),
        .predicted_label  (predicted_label),
        .min_distance     (min_distance),
        .match_index      (match_index),
        .bitwise_features (bitwise_features),
        .is_input_uniform (is_input_uniform)
    );

    // -------------------------------------------------------------------------
    // Task 4: Structured Input Application / Logging Task
    // Prints query, each reference with its label, and all DUT outputs.
    // -------------------------------------------------------------------------
    task print_test_details;
        integer k;
        begin
            $display("  Query            : %b (%0d)", input_query, input_query);
            for (k = 0; k < REFERENCE_COUNT; k = k + 1) begin
                $display("  Reference[%0d]     : %b  Label: %b",
                    k,
                    reference_data[k*BIT_WIDTH  +: BIT_WIDTH],
                    reference_labels[k*LABEL_WIDTH +: LABEL_WIDTH]);
            end
            $display("  Predicted Label  : %b", predicted_label);
            $display("  Match Index      : %0d", match_index);
            $display("  Min Distance     : %0d", min_distance);
            $display("  Bitwise Features : %b", bitwise_features);
            $display("  Is Uniform       : %b", is_input_uniform);
            $display("  ---");
        end
    endtask

    // -------------------------------------------------------------------------
    // Task 1: Corner Case Testing
    // -------------------------------------------------------------------------
    task corner_case_testing;
        begin
            $display("");
            $display("=== Corner Case Testing ===");

            // Scenario 1: All references identical to input query → min_distance = 0
            $display("Scenario 1: All references identical to input query");
            input_query      = 8'b10101010;
            reference_data   = {8'b10101010, 8'b10101010, 8'b10101010, 8'b10101010};
            reference_labels = {4'b0100, 4'b0011, 4'b0010, 4'b0001};
            #10;
            print_test_details;
            $display("  CHECK: min_distance == 0 → %s", (min_distance === 0) ? "PASS" : "FAIL");
            $display("");

            // Scenario 2: All references completely different (max Hamming distance)
            $display("Scenario 2: All references are the bitwise complement of input");
            input_query      = 8'b11110000;
            reference_data   = {8'b00001111, 8'b00001111, 8'b00001111, 8'b00001111};
            reference_labels = {4'b0100, 4'b0011, 4'b0010, 4'b0001};
            #10;
            print_test_details;
            $display("  CHECK: min_distance == %0d (max) → %s",
                BIT_WIDTH, (min_distance === BIT_WIDTH) ? "PASS" : "FAIL");
            $display("");

            // Scenario 3: Only one reference perfectly matches the input
            // reference_data[7:0] (index 0) = 8'b11001100 matches input exactly
            $display("Scenario 3: Only one reference perfectly matches input (index 0)");
            input_query      = 8'b11001100;
            reference_data   = {8'b10011001, 8'b11110000, 8'b10101010, 8'b11001100};
            reference_labels = {4'b0100, 4'b0011, 4'b0010, 4'b0001};
            #10;
            print_test_details;
            $display("  CHECK: min_distance == 0 → %s", (min_distance === 0) ? "PASS" : "FAIL");
            $display("  CHECK: match_index  == 0 → %s", (match_index  === 0) ? "PASS" : "FAIL");
            $display("  CHECK: predicted_label == 4'b0001 → %s",
                (predicted_label === 4'b0001) ? "PASS" : "FAIL");
            $display("");

            // Scenario 4: Two references tied for minimum Hamming distance
            // index 0: 8'b11001101 → distance 1 from 8'b11001100
            // index 1: 8'b11001110 → distance 1 from 8'b11001100
            // First tie (index 0) wins
            $display("Scenario 4: Two references tied at minimum Hamming distance");
            input_query      = 8'b11001100;
            reference_data   = {8'b10011001, 8'b11110000, 8'b11001110, 8'b11001101};
            reference_labels = {4'b0100, 4'b0011, 4'b0010, 4'b0001};
            #10;
            print_test_details;
            $display("  CHECK: min_distance == 1 → %s", (min_distance === 1) ? "PASS" : "FAIL");
            $display("  CHECK: match_index  == 0 (first tie wins) → %s",
                (match_index === 0) ? "PASS" : "FAIL");
            $display("");

            // Scenario 5: Input query is all zeros with nonzero reference patterns
            // index 0: 8'b00000001 → distance 1 (closest)
            $display("Scenario 5: Input is all zeros with nonzero references");
            input_query      = 8'b00000000;
            reference_data   = {8'b11001100, 8'b10101010, 8'b11110000, 8'b00000001};
            reference_labels = {4'b0100, 4'b0011, 4'b0010, 4'b0001};
            #10;
            print_test_details;
            $display("  CHECK: min_distance == 1 → %s", (min_distance === 1) ? "PASS" : "FAIL");
            $display("  CHECK: match_index  == 0 → %s", (match_index  === 0) ? "PASS" : "FAIL");
            $display("  CHECK: is_input_uniform == 0 → %s",
                (is_input_uniform === 1'b0) ? "PASS" : "FAIL");
            $display("");
        end
    endtask

    // -------------------------------------------------------------------------
    // Task 2: Feature Extraction & Uniformity Testing
    // -------------------------------------------------------------------------
    task feature_uniformity_testing;
        begin
            $display("=== Feature Extraction & Uniformity Testing ===");

            // Test 1: All 1s input → is_input_uniform must be HIGH
            $display("Test 1: Input is all 1s");
            input_query      = 8'hFF;
            reference_data   = {8'b11111000, 8'b11110000, 8'b11111100, 8'b11111110};
            reference_labels = {4'b0100, 4'b0011, 4'b0010, 4'b0001};
            #10;
            print_test_details;
            $display("  CHECK: is_input_uniform == 1 (all 1s) → %s",
                (is_input_uniform === 1'b1) ? "PASS" : "FAIL");
            // Gray code of all-1s: 11111111 XOR 01111111 = 10000000
            $display("  CHECK: bitwise_features == 10000000 → %s",
                (bitwise_features === 8'b10000000) ? "PASS" : "FAIL");
            $display("");

            // Test 2: All 0s input → bitwise_features = 0, is_input_uniform = 0 (AND of zeros)
            $display("Test 2: Input is all 0s");
            input_query      = 8'h00;
            reference_data   = {8'b11001100, 8'b10101010, 8'b11110000, 8'b00000001};
            reference_labels = {4'b0100, 4'b0011, 4'b0010, 4'b0001};
            #10;
            print_test_details;
            $display("  CHECK: bitwise_features == 0 → %s",
                (bitwise_features === 8'b0) ? "PASS" : "FAIL");
            $display("  CHECK: is_input_uniform == 0 (AND of zeros = 0) → %s",
                (is_input_uniform === 1'b0) ? "PASS" : "FAIL");
            $display("");
        end
    endtask

    // -------------------------------------------------------------------------
    // Task 3: Randomized Testing
    // -------------------------------------------------------------------------
    task randomized_testing;
        integer i, ref_idx;
        integer exp_min_dist, exp_match_idx, cur_dist, xor_bits, b;
        reg [BIT_WIDTH-1:0]   cur_ref;
        begin
            $display("=== Randomized Testing (50 cases) ===");

            for (i = 0; i < 50; i = i + 1) begin
                // Generate random stimulus
                input_query = $urandom;
                for (ref_idx = 0; ref_idx < REFERENCE_COUNT; ref_idx = ref_idx + 1) begin
                    reference_data[ref_idx*BIT_WIDTH  +: BIT_WIDTH]  = $urandom;
                    reference_labels[ref_idx*LABEL_WIDTH +: LABEL_WIDTH] = $urandom;
                end
                #10;

                // Software reference: compute expected min distance and match index
                exp_min_dist   = BIT_WIDTH + 1;
                exp_match_idx  = 0;
                for (ref_idx = 0; ref_idx < REFERENCE_COUNT; ref_idx = ref_idx + 1) begin
                    cur_ref  = reference_data[ref_idx*BIT_WIDTH +: BIT_WIDTH];
                    xor_bits = input_query ^ cur_ref;
                    cur_dist = 0;
                    for (b = 0; b < BIT_WIDTH; b = b + 1)
                        cur_dist = cur_dist + xor_bits[b];
                    if (cur_dist < exp_min_dist) begin
                        exp_min_dist  = cur_dist;
                        exp_match_idx = ref_idx;
                    end
                end

                $display("Random Test %0d:", i + 1);
                print_test_details;
                $display("  SW check: exp_min_dist=%0d dut_min_dist=%0d → %s",
                    exp_min_dist, min_distance,
                    (min_distance === exp_min_dist[($clog2(BIT_WIDTH+1)-1):0]) ? "PASS" : "FAIL");
                $display("  SW check: exp_match_idx=%0d dut_match_idx=%0d → %s",
                    exp_match_idx, match_index,
                    (match_index === exp_match_idx[($clog2(REFERENCE_COUNT)-1):0]) ? "PASS" : "FAIL");
                $display("");
            end
        end
    endtask

    // -------------------------------------------------------------------------
    // Main stimulus control
    // -------------------------------------------------------------------------
    initial begin
        $display("========================================");
        $display("  Adaptive Binary Pattern Classifier TB ");
        $display("========================================");

        // Initialize inputs
        input_query      = '0;
        reference_data   = '0;
        reference_labels = '0;
        #5;

        // Task 1: Corner cases
        corner_case_testing;

        // Task 2: Feature extraction & uniformity
        feature_uniformity_testing;

        // Task 3: Randomized testing (called once; loop is inside the task)
        randomized_testing;

        $display("========================================");
        $display("  Simulation Complete                   ");
        $display("========================================");
        $finish;
    end

endmodule
