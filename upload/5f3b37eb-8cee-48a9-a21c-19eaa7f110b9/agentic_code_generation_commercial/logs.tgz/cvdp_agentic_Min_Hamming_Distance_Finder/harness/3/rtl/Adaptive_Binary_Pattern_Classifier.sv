`timescale 1ns / 1ps
module Adaptive_Binary_Pattern_Classifier
#(
    parameter BIT_WIDTH       = 8,
    parameter REFERENCE_COUNT = 8,
    parameter LABEL_WIDTH     = 4
)
(
    input  wire [BIT_WIDTH-1:0]                   input_query,
    input  wire [REFERENCE_COUNT*BIT_WIDTH-1:0]   reference_data,
    input  wire [REFERENCE_COUNT*LABEL_WIDTH-1:0] reference_labels,
    output wire [LABEL_WIDTH-1:0]                 predicted_label,
    output wire [$clog2(BIT_WIDTH+1)-1:0]         min_distance,
    output wire [$clog2(REFERENCE_COUNT)-1:0]     match_index,
    output wire [BIT_WIDTH-1:0]                   bitwise_features,
    output wire                                   is_input_uniform
);

    // Best Match Identification via Hamming distance computation
    Min_Hamming_Distance_Finder
    #(
        .BIT_WIDTH       (BIT_WIDTH),
        .REFERENCE_COUNT (REFERENCE_COUNT)
    )
    hamming_finder (
        .input_query      (input_query),
        .references       (reference_data),
        .best_match_index (match_index),
        .min_distance     (min_distance)
    );

    // Label Prediction: select label at best match index
    assign predicted_label = reference_labels[match_index * LABEL_WIDTH +: LABEL_WIDTH];

    // Bitwise Feature Extraction: XOR input with its 1-bit right-shifted version (Gray-code)
    wire [BIT_WIDTH-1:0] shifted_query;
    assign shifted_query = input_query >> 1;

    Data_Reduction
    #(
        .REDUCTION_OP (3'b010),   // XOR operation
        .DATA_WIDTH   (BIT_WIDTH),
        .DATA_COUNT   (2)
    )
    feature_extractor (
        .data_in          ({input_query, shifted_query}),
        .reduced_data_out (bitwise_features)
    );

    // Uniformity Check: AND reduction over all input bits
    Bitwise_Reduction
    #(
        .REDUCTION_OP (3'b000),   // AND operation
        .BIT_COUNT    (BIT_WIDTH)
    )
    uniformity_checker (
        .input_bits  (input_query),
        .reduced_bit (is_input_uniform)
    );

endmodule
