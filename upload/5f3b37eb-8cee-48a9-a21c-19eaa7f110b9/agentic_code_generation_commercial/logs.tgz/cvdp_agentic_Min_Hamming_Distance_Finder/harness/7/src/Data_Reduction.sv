`timescale 1ns / 1ps
module Data_Reduction
#(
    parameter [2:0] REDUCTION_OP = 3'b000, // Default operation: AND
    parameter DATA_WIDTH         = 4,      // Width of each data element
    parameter DATA_COUNT         = 4,      // Number of data elements
    localparam TOTAL_INPUT_WIDTH = DATA_WIDTH * DATA_COUNT
)
(
    input  wire [TOTAL_INPUT_WIDTH-1:0] data_in,
    output reg  [DATA_WIDTH-1:0]        reduced_data_out
);

    generate
        genvar bit_index;

        for (bit_index = 0; bit_index < DATA_WIDTH; bit_index = bit_index + 1) begin : bit_processing
            wire [DATA_COUNT-1:0] extracted_bits;

            genvar data_index;
            for (data_index = 0; data_index < DATA_COUNT; data_index = data_index + 1) begin : bit_extraction
                `ifndef BUG_6
                    assign extracted_bits[data_index] = data_in[(data_index * DATA_WIDTH) + bit_index];
                `else
                    assign extracted_bits[data_index+1] = data_in[(data_index * DATA_WIDTH) + bit_index];
                `endif
            end

            Bitwise_Reduction
            #(
                .REDUCTION_OP (REDUCTION_OP),
                .BIT_COUNT    (DATA_COUNT)
            )
            reducer_instance
            (
                .input_bits  (extracted_bits),
                `ifndef BUG_3
                    .reduced_bit (reduced_data_out[bit_index])
                `else
                    .reduced_bit (DATA_WIDTH{1'b0})
                `endif
            );
        end
    endgenerate

endmodule