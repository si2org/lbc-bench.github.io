`timescale 1ns / 1ps
module Min_Hamming_Distance_Finder
#(
    parameter BIT_WIDTH      = 8,  // Width of each reference and the query
    parameter REFERENCE_COUNT = 4  // Number of reference vectors
)
(
    input  wire [BIT_WIDTH-1:0]                           input_query,
    input  wire [REFERENCE_COUNT*BIT_WIDTH-1:0]           references,
    output reg  [$clog2(REFERENCE_COUNT)-1:0]             best_match_index,
    output reg  [$clog2(BIT_WIDTH+1)-1:0]                 min_distance
);

    wire [$clog2(BIT_WIDTH+1)-1:0] distance [0:REFERENCE_COUNT-1];
    genvar i;
    
    generate 
        for (i = 0; i < REFERENCE_COUNT; i = i + 1) begin : calc_distance
            Bit_Difference_Counter
            #(
                .BIT_WIDTH (BIT_WIDTH)
            )
            distance_inst
            (
                `ifndef BUG_0
                    .input_A (input_query),
                `else
                    .input_A (input_query+1),  
                `endif 
                .input_B (references[i*BIT_WIDTH +: BIT_WIDTH]),
                .bit_difference_count (distance[i])
            );
        end
    endgenerate

    integer j;
    always @(*) begin
        min_distance     = {($clog2(BIT_WIDTH+1)){1'b1}}; // Start with max
        best_match_index = {($clog2(REFERENCE_COUNT)){1'b0}};
        for (j = 0; j < REFERENCE_COUNT; j = j + 1) begin
            if (distance[j] < min_distance) begin
                `ifndef BUG_1
                    min_distance     = distance[j];
                `else
                    min_distance     = distance[j-1]; 
                `endif
                `ifndef BUG_2
                    best_match_index = j[$clog2(REFERENCE_COUNT)-1:0];
                `else
                    best_match_index = j[$clog2(REFERENCE_COUNT-2)-1:0];
                `endif
            end
        end
    end

endmodule