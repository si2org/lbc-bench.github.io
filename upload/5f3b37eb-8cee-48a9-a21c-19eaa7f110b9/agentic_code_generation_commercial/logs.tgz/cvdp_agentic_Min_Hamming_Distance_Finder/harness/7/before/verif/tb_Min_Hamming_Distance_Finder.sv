`timescale 1ns / 1ps

module tb_Min_Hamming_Distance_Finder;

    // Parameters for the testbench
    parameter BIT_WIDTH = 8;
    parameter REFERENCE_COUNT = 4;

    // Testbench signals
    reg  [BIT_WIDTH-1:0]                      input_query;
    reg  [REFERENCE_COUNT*BIT_WIDTH-1:0]      references;
    wire [$clog2(REFERENCE_COUNT)-1:0]        best_match_index;
    wire [$clog2(BIT_WIDTH+1)-1:0]            min_distance;

    // Instantiate the DUT
    Min_Hamming_Distance_Finder #(
        .BIT_WIDTH(BIT_WIDTH),
        .REFERENCE_COUNT(REFERENCE_COUNT)
    ) uut (
        .input_query(input_query),
        .references(references),
        .best_match_index(best_match_index),
        .min_distance(min_distance)
    );

    
    // Task to validate the output of the Min_Hamming_Distance_Finder
    task data_in(
        input [BIT_WIDTH-1:0] test_query,
        input [REFERENCE_COUNT*BIT_WIDTH-1:0] test_references,
        input string testcase_name
    );
        begin
            input_query = test_query;
            references  = test_references;
            #10; 
            $display("%s: Query=%b, Refs=%b -> index=%0d, dist=%0d",
                         testcase_name, test_query, test_references, best_match_index, min_distance);
        end
    endtask

    // Task for testing specific edge cases
    task test_edge_cases;
        reg [BIT_WIDTH-1:0] ref_vector;
        reg [REFERENCE_COUNT*BIT_WIDTH-1:0] refs_temp;
        integer i;
        begin
            $display("Starting Edge Case Testing...");

            // Case 1: All references equal to input_query (zero distance)
            ref_vector = 8'b10101010;
            for (i = 0; i < REFERENCE_COUNT; i = i + 1) begin
                refs_temp[i*BIT_WIDTH +: BIT_WIDTH] = ref_vector;
            end
            data_in(ref_vector, refs_temp, "All references equal to query");

            // Case 2: One reference is an exact match and others are completely different.
            input_query = 8'b11110000;
            // Set reference 0 to be completely different, reference 1 slightly different, reference 2 exact match, reference 3 different.
            refs_temp = {8'b00000000, 8'b11100000, 8'b11110000, 8'b10101010};
            data_in(input_query, refs_temp, "Exact match among others");

            // Case 3: Test when the first reference is the closest
            input_query = 8'b01010101;
            refs_temp = {8'b01010100, 8'b10101010, 8'b11110000, 8'b00001111};
            data_in(input_query, refs_temp, "First reference is closest");

             //Case 4: All ones query vs. alternating pattern references
            input_query = 8'b11111111;
            refs_temp = {8'b10101010, 8'b01010101, 8'b11111110, 8'b00000000};
            data_in(input_query, refs_temp, "All ones vs alternating patterns");

            // Case 5: Identical non-matching references
            input_query = 8'b11001100;
            ref_vector = 8'b01010101;  
            for (i = 0; i < REFERENCE_COUNT; i = i + 1) begin
                refs_temp[i*BIT_WIDTH +: BIT_WIDTH] = ref_vector;
            end
            data_in(input_query, refs_temp, "Identical non-matching references");

            //Case 6: Multiple tie minimal distances (first minimal wins)
            input_query = 8'b00010001;
            refs_temp = {8'b00000000, 8'b00010000, 8'b00000001, 8'b00001001};
            data_in(input_query, refs_temp, "Multiple tie minimal distances");
        end
    endtask

    // Task for testing random inputs
    task test_random_inputs;
        integer i;
        reg [BIT_WIDTH-1:0] random_query;
        reg [REFERENCE_COUNT*BIT_WIDTH-1:0] random_refs;
        begin
            $display("Starting Randomized Testing...");
            for (i = 0; i < 100; i = i + 1) begin
                random_query = $urandom;
                random_refs  = $urandom;
                data_in(random_query, random_refs, $sformatf("Random Test %0d", i+1));
            end
        end
    endtask

    initial begin
        $display("Starting testbench for Min_Hamming_Distance_Finder...");
        test_edge_cases();
        test_random_inputs();
        $finish;
    end

endmodule