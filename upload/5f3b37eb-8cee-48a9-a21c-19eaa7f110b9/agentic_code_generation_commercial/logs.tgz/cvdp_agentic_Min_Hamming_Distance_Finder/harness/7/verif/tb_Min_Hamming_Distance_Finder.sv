`timescale 1ns / 1ps

module tb_Min_Hamming_Distance_Finder;

    // Parameters for the testbench
    parameter BIT_WIDTH = 8;
    parameter REFERENCE_COUNT = 4;

    // Testbench signals
    reg  [BIT_WIDTH-1:0]                      input_query;
    reg  [REFERENCE_COUNT*BIT_WIDTH-1:0]      references;
    wire [$clog2(REFERENCE_COUNT)-1:0]        best_match_index;
    wire [$clog2(BIT_WIDTH+1)-1:0]            min_distance;

    // Test counters
    integer tests_total;
    integer tests_passed;
    integer tests_failed;

    // Instantiate the DUT
    Min_Hamming_Distance_Finder #(
        .BIT_WIDTH(BIT_WIDTH),
        .REFERENCE_COUNT(REFERENCE_COUNT)
    ) uut (
        .input_query(input_query),
        .references(references),
        .best_match_index(best_match_index),
        .min_distance(min_distance)
    );

    // Compute Hamming distance between two BIT_WIDTH-bit values
    function automatic integer calc_hamming_distance;
        input [BIT_WIDTH-1:0] a;
        input [BIT_WIDTH-1:0] b;
        begin
            calc_hamming_distance = $countones(a ^ b);
        end
    endfunction

    // Compute expected best_match_index and min_distance for given query and references
    task automatic calc_expected;
        input  [BIT_WIDTH-1:0]               query;
        input  [REFERENCE_COUNT*BIT_WIDTH-1:0] refs;
        output [$clog2(REFERENCE_COUNT)-1:0] exp_index;
        output [$clog2(BIT_WIDTH+1)-1:0]     exp_dist;
        integer i;
        integer dist;
        integer min_dist;
        begin
            min_dist  = BIT_WIDTH + 1;
            exp_index = 0;
            for (i = 0; i < REFERENCE_COUNT; i = i + 1) begin
                dist = calc_hamming_distance(query, refs[i*BIT_WIDTH +: BIT_WIDTH]);
                if (dist < min_dist) begin
                    min_dist  = dist;
                    exp_index = i[$clog2(REFERENCE_COUNT)-1:0];
                end
            end
            exp_dist = min_dist[$clog2(BIT_WIDTH+1)-1:0];
        end
    endtask

    // Centralized checker: compares DUT outputs against reference model
    task automatic check_output;
        input string testcase_name;
        reg [$clog2(REFERENCE_COUNT)-1:0] exp_index;
        reg [$clog2(BIT_WIDTH+1)-1:0]     exp_dist;
        begin
            calc_expected(input_query, references, exp_index, exp_dist);
            tests_total = tests_total + 1;
            if (best_match_index === exp_index && min_distance === exp_dist) begin
                $display("PASS: %s | query=%b refs=%b | index=%0d dist=%0d",
                         testcase_name, input_query, references,
                         best_match_index, min_distance);
                tests_passed = tests_passed + 1;
            end else begin
                $display("FAIL: %s | query=%b refs=%b | expected index=%0d dist=%0d, got index=%0d dist=%0d",
                         testcase_name, input_query, references,
                         exp_index, exp_dist, best_match_index, min_distance);
                tests_failed = tests_failed + 1;
            end
        end
    endtask

    // Apply stimulus and invoke checker
    task data_in(
        input [BIT_WIDTH-1:0] test_query,
        input [REFERENCE_COUNT*BIT_WIDTH-1:0] test_references,
        input string testcase_name
    );
        begin
            input_query = test_query;
            references  = test_references;
            #10;
            check_output(testcase_name);
        end
    endtask

    // Task for testing specific edge cases
    task test_edge_cases;
        reg [BIT_WIDTH-1:0] ref_vector;
        reg [REFERENCE_COUNT*BIT_WIDTH-1:0] refs_temp;
        integer i;
        begin
            $display("Starting Edge Case Testing...");

            // Case 1: All references equal to input_query (zero distance)
            ref_vector = 8'b10101010;
            for (i = 0; i < REFERENCE_COUNT; i = i + 1) begin
                refs_temp[i*BIT_WIDTH +: BIT_WIDTH] = ref_vector;
            end
            data_in(ref_vector, refs_temp, "All references equal to query");

            // Case 2: One reference is an exact match and others are completely different.
            input_query = 8'b11110000;
            // Set reference 0 to be completely different, reference 1 slightly different, reference 2 exact match, reference 3 different.
            refs_temp = {8'b00000000, 8'b11100000, 8'b11110000, 8'b10101010};
            data_in(input_query, refs_temp, "Exact match among others");

            // Case 3: Test when the first reference is the closest
            input_query = 8'b01010101;
            refs_temp = {8'b01010100, 8'b10101010, 8'b11110000, 8'b00001111};
            data_in(input_query, refs_temp, "First reference is closest");

            //Case 4: All ones query vs. alternating pattern references
            input_query = 8'b11111111;
            refs_temp = {8'b10101010, 8'b01010101, 8'b11111110, 8'b00000000};
            data_in(input_query, refs_temp, "All ones vs alternating patterns");

            // Case 5: Identical non-matching references
            input_query = 8'b11001100;
            ref_vector = 8'b01010101;
            for (i = 0; i < REFERENCE_COUNT; i = i + 1) begin
                refs_temp[i*BIT_WIDTH +: BIT_WIDTH] = ref_vector;
            end
            data_in(input_query, refs_temp, "Identical non-matching references");

            //Case 6: Multiple tie minimal distances (first minimal wins)
            input_query = 8'b00010001;
            refs_temp = {8'b00000000, 8'b00010000, 8'b00000001, 8'b00001001};
            data_in(input_query, refs_temp, "Multiple tie minimal distances");
        end
    endtask

    // Task for testing random inputs
    task test_random_inputs;
        integer i;
        reg [BIT_WIDTH-1:0] random_query;
        reg [REFERENCE_COUNT*BIT_WIDTH-1:0] random_refs;
        begin
            $display("Starting Randomized Testing...");
            for (i = 0; i < 100; i = i + 1) begin
                random_query = $urandom;
                random_refs  = $urandom;
                data_in(random_query, random_refs, $sformatf("Random Test %0d", i+1));
            end
        end
    endtask

    initial begin
        tests_total  = 0;
        tests_passed = 0;
        tests_failed = 0;

        $display("Starting testbench for Min_Hamming_Distance_Finder...");
        test_edge_cases();
        test_random_inputs();

        $display("==========================================");
        $display("TEST SUMMARY: Total=%0d  Passed=%0d  Failed=%0d",
                 tests_total, tests_passed, tests_failed);
        if (tests_failed > 0)
            $display("ERROR: %0d test(s) failed. Review the FAIL messages above for details.", tests_failed);
        else
            $display("All tests passed successfully.");
        $display("==========================================");

        $finish;
    end

endmodule
