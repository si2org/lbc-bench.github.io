module tb_branch_control_unit;

    
    logic test_0;
    logic test_1;
    logic test_2;
    logic test_3;
    logic i_0;
    logic i_1;
    logic i_2;
    logic i_3;

    
    logic o_0;
    logic o_1;
    logic o_2;
    logic o_3;

    
    branch_control_unit uut (
        .test_0(test_0),
        .test_1(test_1),
        .test_2(test_2),
        .test_3(test_3),
        .i_0(i_0),
        .i_1(i_1),
        .i_2(i_2),
        .i_3(i_3),
        .o_0(o_0),
        .o_1(o_1),
        .o_2(o_2),
        .o_3(o_3)
    );

    
    initial begin
        $display("Case 1 : i[3:0] = 4'b0000 , test[3:0] = 4'bxxxx");
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 2 : i[3:0] = 4'b0001 , test[3:0] = 4'bxxx0");
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 2 : i[3:0] = 4'b0001 , test[3:0] = 4'bxxx1");
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 3 : i[3:0] = 4'b0010 , test[3:0] = 4'bxx0x");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 0; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 3 : i[3:0] = 4'b0010 , test[3:0] = 4'bxx1x");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 4 : i[3:0] = 4'b0011 , test[3:0] = 4'bxx00");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 4 : i[3:0] = 4'b0011 , test[3:0] = 4'bxx01");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 4 : i[3:0] = 4'b0011 , test[3:0] = 4'bxx10");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 4 : i[3:0] = 4'b0011 , test[3:0] = 4'bxx10");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 5 : i[3:0] = 4'b0100 , test[3:0] = 4'bx0xx");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1'bx; test_2 = 0; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 5 : i[3:0] = 4'b0100 , test[3:0] = 4'bx1xx");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1'bx; test_2 = 1; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 6 : i[3:0] = 4'b0101 , test[3:0] = 4'bx0x0");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 0; test_1 = 1'bx; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 6 : i[3:0] = 4'b0101 , test[3:0] = 4'bx0x1");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 0; test_1 = 1'bx; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 6 : i[3:0] = 4'b0101 , test[3:0] = 4'bx1x0");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1; test_1 = 1'bx; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 6 : i[3:0] = 4'b0101 , test[3:0] = 4'bx1x1");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1; test_1 = 1'bx; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 7 : i[3:0] = 4'b0110 , test[3:0] = 4'bx00x");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 0; test_1 = 0; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 7 : i[3:0] = 4'b0110 , test[3:0] = 4'bx01x");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 0; test_1 = 1; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 7 : i[3:0] = 4'b0110 , test[3:0] = 4'bx10x");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1; test_1 = 0; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 7 : i[3:0] = 4'b0110 , test[3:0] = 4'bx11x");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1; test_1 = 1; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx000");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx001");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx010");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx011");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx100");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx101");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx110");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx111");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 9 : i[3:0] = 4'b1000 , test[3:0] = 4'b0xxx"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 9 : i[3:0] = 4'b1000 , test[3:0] = 4'b1xxx"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 10 : i[3:0] = 4'b1001 , test[3:0] = 4'b0xx0"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1'bx; test_1 = 1'bx; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 10 : i[3:0] = 4'b1001 , test[3:0] = 4'b0xx1"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 10 : i[3:0] = 4'b1001 , test[3:0] = 4'b1xx0"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1'bx; test_1 = 1'bx; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 10 : i[3:0] = 4'b1001 , test[3:0] = 4'b1xx1"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1;
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 11 : i[3:0] = 4'b1010 , test[3:0] = 4'b0x0x"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1'bx; test_1 = 0; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 11 : i[3:0] = 4'b1010 , test[3:0] = 4'b0x1x"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1'bx; test_1 = 1; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 11 : i[3:0] = 4'b1010 , test[3:0] = 4'b1x0x"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1'bx; test_1 = 0; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 11 : i[3:0] = 4'b1010 , test[3:0] = 4'b1x1x"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1'bx; test_1 = 1; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b0x00"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1'bx; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b0x01"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1'bx; test_1 = 0; test_0 = 1;
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b0x10"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1'bx; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b0x11"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1'bx; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b1x00"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1'bx; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b1x01"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1'bx; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b1x10"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1'bx; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b1x11"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1'bx; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 13 : i[3:0] = 4'b1100 , test[3:0] = 4'b00xx"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 13 : i[3:0] = 4'b1100 , test[3:0] = 4'b01xx"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 13 : i[3:0] = 4'b1100 , test[3:0] = 4'b10xx"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 13 : i[3:0] = 4'b1100 , test[3:0] = 4'b11xx"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b00x0"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1'bx; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b00x1"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1'bx; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b01x0"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1'bx; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b01x1"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1'bx; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b10x0"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1'bx; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b10x1"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1'bx; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b11x0"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1'bx; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b11x1"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1'bx; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b000x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b001x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b010x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b011x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b100x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b101x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b110x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b111x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 16 : i[3:0] = 4'b1111");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 1 : i[3:0] = 4'b0000 , test[3:0] = 4'bxxxx");
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1;  
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1;  
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1;  
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0;  
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1;  
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0;  
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1;  
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0;  
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0;  
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
               
        $display("Case 2 : i[3:0] = 4'b0001 , test[3:0] = 4'bxxx0");
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        
        $display("Case 2 : i[3:0] = 4'b0001 , test[3:0] = 4'bxxx1");
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 3 : i[3:0] = 4'b0010 , test[3:0] = 4'bxx0x");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 3 : i[3:0] = 4'b0010 , test[3:0] = 4'bxx1x");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        
        $display("Case 4 : i[3:0] = 4'b0011 , test[3:0] = 4'bxx00");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 4 : i[3:0] = 4'b0011 , test[3:0] = 4'bxx01");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 4 : i[3:0] = 4'b0011 , test[3:0] = 4'bxx10");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 4 : i[3:0] = 4'b0011 , test[3:0] = 4'bxx11");
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
       
        $display("Case 5 : i[3:0] = 4'b0100 , test[3:0] = 4'bx0xx");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 5 : i[3:0] = 4'b0100 , test[3:0] = 4'bx1xx");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 6 : i[3:0] = 4'b0101 , test[3:0] = 4'bx0x0");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 6 : i[3:0] = 4'b0101 , test[3:0] = 4'bx0x1");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 6 : i[3:0] = 4'b0101 , test[3:0] = 4'bx1x0");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 6 : i[3:0] = 4'b0101 , test[3:0] = 4'bx1x1");
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 7 : i[3:0] = 4'b0110 , test[3:0] = 4'bx00x");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 7 : i[3:0] = 4'b0110 , test[3:0] = 4'bx01x");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 7 : i[3:0] = 4'b0110 , test[3:0] = 4'bx10x");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 7 : i[3:0] = 4'b0110 , test[3:0] = 4'bx11x"); // To Be Continued from Here
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0;
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
       
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx000");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx001");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx010");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx011");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx100");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx101");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8 : i[3:0] = 4'b0111 , test[3:0] = 4'bx110");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $display("Case 8: i[3:0] = 4'b0111 , test[3:0] = 4'bx111");
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 0; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
       
        $display("Case 9 : i[3:0] = 4'b1000 , test[3:0] = 4'b0xxx"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 9 : i[3:0] = 4'b1000 , test[3:0] = 4'b1xxx"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 10 : i[3:0] = 4'b1001 , test[3:0] = 4'b0xx0"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 10 : i[3:0] = 4'b1001 , test[3:0] = 4'b0xx1"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 10 : i[3:0] = 4'b1001 , test[3:0] = 4'b1xx0"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 10 : i[3:0] = 4'b1001 , test[3:0] = 4'b1xx1"); 
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 11 : i[3:0] = 4'b1010 , test[3:0] = 4'b0x0x"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
       
        $display("Case 11 : i[3:0] = 4'b1010 , test[3:0] = 4'b0x1x"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 11 : i[3:0] = 4'b1010 , test[3:0] = 4'b1x0x"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 11 : i[3:0] = 4'b1010 , test[3:0] = 4'b1x1x"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b0x00"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b0x01"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b0x10"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b0x11"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b1x00"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b1x01"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b1x10"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 12 : i[3:0] = 4'b1011 , test[3:0] = 4'b1x11"); 
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        i_3 = 1; i_2 = 0; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 13 : i[3:0] = 4'b1100 , test[3:0] = 4'b00xx"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 13 : i[3:0] = 4'b1100 , test[3:0] = 4'b01xx"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 13 : i[3:0] = 4'b1100 , test[3:0] = 4'b10xx"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 13 : i[3:0] = 4'b1100 , test[3:0] = 4'b11xx"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b00x0"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b00x1"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b01x0"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b01x1"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b10x0"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b10x1"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b11x0"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 14 : i[3:0] = 4'b1101 , test[3:0] = 4'b11x1"); 
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        i_3 = 1; i_2 = 1; i_1 = 0; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b000x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b001x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b010x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b011x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b100x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b101x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b110x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        
        $display("Case 15 : i[3:0] = 4'b1110 , test[3:0] = 4'b111x");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 0; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        $display("Case 16 : i[3:0] = 4'b1111");
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 0; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 0; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 0; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 0; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1; test_2 = 1; test_1 = 1; test_0 = 1; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        
        i_3 = 1; i_2 = 1; i_1 = 1; i_0 = 1; test_3 = 1'bx; test_2 = 1'bx; test_1 = 1'bx; test_0 = 1'bx; 
        #10;  
        $display("Computed Values o_3 = %0b , o_2 = %0b , o_1 = %0b , o_0 = %0b", o_3 , o_2 , o_1 , o_0);
        check_output;
        $finish;
    end

    task check_output;
        reg exp_o_3, exp_o_2, exp_o_1, exp_o_0;
        begin
            exp_o_3 = 0; exp_o_2 = 0; exp_o_1 = 0; exp_o_0 = 0;
            case ({i_3, i_2, i_1, i_0})
                4'b0000: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'bxxxx: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                    endcase
                end
                4'b0001: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'bxxx0: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'bxxx1: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                    endcase
                end
                4'b0010: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'bxx0x: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'bxx1x: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                    endcase
                end
                4'b0011: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'bxx00: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'bxx01: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'bxx10: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'bxx11: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b0100: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'bx0xx: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'bx1xx: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                    endcase
                end
                4'b0101: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'bx0x0: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'bx0x1: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'bx1x0: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'bx1x1: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b0110: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'bx00x: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'bx01x: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'bx10x: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'bx11x: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b0111: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'bx000: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'bx001: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'bx010: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'bx011: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                        4'bx100: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=0; end
                        4'bx101: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=1; end
                        4'bx110: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=0; end
                        4'bx111: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b1000: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'b0xxx: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'b1xxx: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                    endcase
                end
                4'b1001: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'b0xx0: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'b0xx1: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'b1xx0: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'b1xx1: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b1010: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'b0x0x: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'b0x1x: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'b1x0x: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'b1x1x: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b1011: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'b0x00: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'b0x01: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'b0x10: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'b0x11: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                        4'b1x00: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=0; end
                        4'b1x01: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=1; end
                        4'b1x10: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=0; end
                        4'b1x11: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b1100: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'b00xx: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'b01xx: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'b10xx: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'b11xx: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b1101: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'b00x0: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'b00x1: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'b01x0: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'b01x1: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                        4'b10x0: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=0; end
                        4'b10x1: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=1; end
                        4'b11x0: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=0; end
                        4'b11x1: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b1110: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'b000x: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'b001x: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'b010x: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'b011x: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                        4'b100x: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=0; end
                        4'b101x: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=1; end
                        4'b110x: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=0; end
                        4'b111x: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                4'b1111: begin
                    casex ({test_3, test_2, test_1, test_0})
                        4'b0000: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'b0001: begin exp_o_3=0; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'b0010: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'b0011: begin exp_o_3=0; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                        4'b0100: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=0; end
                        4'b0101: begin exp_o_3=0; exp_o_2=1; exp_o_1=0; exp_o_0=1; end
                        4'b0110: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=0; end
                        4'b0111: begin exp_o_3=0; exp_o_2=1; exp_o_1=1; exp_o_0=1; end
                        4'b1000: begin exp_o_3=1; exp_o_2=0; exp_o_1=0; exp_o_0=0; end
                        4'b1001: begin exp_o_3=1; exp_o_2=0; exp_o_1=0; exp_o_0=1; end
                        4'b1010: begin exp_o_3=1; exp_o_2=0; exp_o_1=1; exp_o_0=0; end
                        4'b1011: begin exp_o_3=1; exp_o_2=0; exp_o_1=1; exp_o_0=1; end
                        4'b1100: begin exp_o_3=1; exp_o_2=1; exp_o_1=0; exp_o_0=0; end
                        4'b1101: begin exp_o_3=1; exp_o_2=1; exp_o_1=0; exp_o_0=1; end
                        4'b1110: begin exp_o_3=1; exp_o_2=1; exp_o_1=1; exp_o_0=0; end
                        4'b1111: begin exp_o_3=1; exp_o_2=1; exp_o_1=1; exp_o_0=1; end
                    endcase
                end
                default: begin
                    exp_o_3 = 0; exp_o_2 = 0; exp_o_1 = 0; exp_o_0 = 0;
                end
            endcase

            if ({o_3, o_2, o_1, o_0} === {exp_o_3, exp_o_2, exp_o_1, exp_o_0}) begin
                $display("PASS at time %0t: i[3:0]=%0b%0b%0b%0b test[3:0]=%0b%0b%0b%0b o[3:0]=%0b%0b%0b%0b",
                    $time, i_3, i_2, i_1, i_0, test_3, test_2, test_1, test_0,
                    o_3, o_2, o_1, o_0);
            end else begin
                $display("ERROR at time %0t: i[3:0]=%0b%0b%0b%0b test[3:0]=%0b%0b%0b%0b expected o[3:0]=%0b%0b%0b%0b actual o[3:0]=%0b%0b%0b%0b",
                    $time, i_3, i_2, i_1, i_0, test_3, test_2, test_1, test_0,
                    exp_o_3, exp_o_2, exp_o_1, exp_o_0, o_3, o_2, o_1, o_0);
            end
        end
    endtask

endmodule