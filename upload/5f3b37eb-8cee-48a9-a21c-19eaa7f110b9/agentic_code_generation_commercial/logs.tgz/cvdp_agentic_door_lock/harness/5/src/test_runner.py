import os
from pathlib import Path
from cocotb_tools.runner import get_runner
import pytest
import random
import harness_library as hrs_lb

verilog_sources = os.getenv("VERILOG_SOURCES").split()
toplevel_lang   = os.getenv("TOPLEVEL_LANG")
sim             = os.getenv("SIM", "icarus")
toplevel        = os.getenv("TOPLEVEL")
module          = os.getenv("MODULE")
wave            = os.getenv("WAVE")

def call_runner(PASSWORD_LENGTH, MAX_TRIALS):
    parameter = {
    "PASSWORD_LENGTH": PASSWORD_LENGTH,
    "MAX_TRIALS": MAX_TRIALS,
    }
    # Debug information
    print(f"[DEBUG] Running simulation with PASSWORD_LENGTH={PASSWORD_LENGTH} and MAX_TRIALS={MAX_TRIALS}")
    print(f"[DEBUG] Parameters: {parameter}")
    plusargs = []
    try:
        args = []
        if sim == "xcelium":
            args = ("-coverage all", " -covoverwrite", "-sv", "-covtest test", "-svseed random")

        hrs_lb.runner(
            wave=wave,
            toplevel=toplevel,
            plusargs=plusargs,
            module=module,
            src=verilog_sources,
            sim=sim,
            args=args,
            parameter=parameter
        )
        hrs_lb.coverage_report("assertion")
        hrs_lb.covt_report_check()
    except SystemExit:
        # hrs_lb.save_vcd(wave, toplevel, new_name=f"waveform_test")
        raise SystemError("simulation failed due to assertion failed in your test")

# # Parametrize test for random parameters
@pytest.mark.parametrize("random_test", range(3))
def test_random_door_lock(random_test):
    PASSWORD_LENGTH = random.randint(4, 8)
    MAX_TRIALS = random.randint(4, 8)
    # Run the simulation with specified parameters
    call_runner(PASSWORD_LENGTH=PASSWORD_LENGTH, MAX_TRIALS=MAX_TRIALS)
