`timescale 1ns/1ps

module tb_door_lock;

    // =========================================================
    // Parameters
    // =========================================================
    localparam PASSWORD_LENGTH = 4;
    localparam MAX_TRIALS      = 3;
    localparam CLK_PERIOD      = 10; // 10 ns

    // =========================================================
    // DUT port signals
    // =========================================================
    logic                         clk;
    logic                         srst;
    logic [3:0]                   key_input;
    logic                         key_valid;
    logic                         confirm;
    logic                         admin_override;
    logic                         admin_set_mode;
    logic [PASSWORD_LENGTH*4-1:0] new_password;
    logic                         new_password_valid;
    logic                         door_unlock;
    logic                         lockout;

    // Software mirror of the current stored password (updated by testbench)
    logic [PASSWORD_LENGTH*4-1:0] current_password;

    // =========================================================
    // DUT instantiation
    // =========================================================
    door_lock #(
        .PASSWORD_LENGTH(PASSWORD_LENGTH),
        .MAX_TRIALS     (MAX_TRIALS)
    ) door_lock_inst (
        .clk               (clk),
        .srst              (srst),
        .key_input         (key_input),
        .key_valid         (key_valid),
        .confirm           (confirm),
        .admin_override    (admin_override),
        .admin_set_mode    (admin_set_mode),
        .new_password      (new_password),
        .new_password_valid(new_password_valid),
        .door_unlock       (door_unlock),
        .lockout           (lockout)
    );

    // =========================================================
    // Clock generation: 10 ns period
    // =========================================================
    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    // =========================================================
    // Task: Apply synchronous reset and initialise all inputs
    // =========================================================
    task automatic reset_dut();
        $display("\n[%0t] === Applying synchronous reset ===", $time);
        srst               = 1'b1;
        key_input          = 4'h0;
        key_valid          = 1'b0;
        confirm            = 1'b0;
        admin_override     = 1'b0;
        admin_set_mode     = 1'b0;
        new_password       = '0;
        new_password_valid = 1'b0;
        repeat(4) @(posedge clk);
        @(posedge clk); #1;
        srst = 1'b0;
        repeat(2) @(posedge clk);
        $display("[%0t] Reset deasserted – DUT in IDLE.", $time);
    endtask

    // =========================================================
    // Task: Enter a full-length password then assert confirm.
    //
    // Digits are entered MSB-first so that the packed bit-vector
    // pass[PASSWORD_LENGTH*4-1:0] maps intuitively:
    //   first key  = pass[(PASSWORD_LENGTH-1)*4 +: 4]  (MSB nibble)
    //   last  key  = pass[3:0]                          (LSB nibble)
    //
    // Example: pass = 16'h0001  →  keys 0,0,0,1
    //          pass = 16'h1234  →  keys 1,2,3,4
    // =========================================================
    task automatic enter_password(
        input logic [PASSWORD_LENGTH*4-1:0] pass,
        input string                        label
    );
        int         i;
        logic [3:0] digit;
        $display("[%0t] [enter_password:%s]  pass=0x%0h", $time, label, pass);
        for (i = PASSWORD_LENGTH - 1; i >= 0; i--) begin
            digit = pass[i*4 +: 4];
            @(posedge clk); #1;
            key_input = digit;
            key_valid = 1'b1;
            $display("[%0t]   key[%0d] = %0d", $time, PASSWORD_LENGTH - 1 - i, digit);
            @(posedge clk); #1;
            key_valid = 1'b0;
            key_input = 4'h0;
        end
        // Assert confirm for one clock cycle
        @(posedge clk); #1;
        confirm = 1'b1;
        @(posedge clk); #1;
        confirm = 1'b0;
        // Allow FSM and output logic to settle
        repeat(5) @(posedge clk);
        $display("[%0t]   -> door_unlock=%b  lockout=%b", $time, door_unlock, lockout);
    endtask

    // =========================================================
    // Task: Enter fewer than PASSWORD_LENGTH digits then confirm.
    // Tests the ENTER_PASS → PASSWORD_FAIL path for wrong count.
    // =========================================================
    task automatic enter_partial_password(
        input int                           num_digits,
        input logic [PASSWORD_LENGTH*4-1:0] pass,
        input string                        label
    );
        int         i;
        logic [3:0] digit;
        $display("[%0t] [enter_partial_password:%s]  num_digits=%0d  pass=0x%0h",
                 $time, label, num_digits, pass);
        for (i = 0; i < num_digits; i++) begin
            digit = pass[(PASSWORD_LENGTH - 1 - i)*4 +: 4];
            @(posedge clk); #1;
            key_input = digit;
            key_valid = 1'b1;
            $display("[%0t]   key[%0d] = %0d", $time, i, digit);
            @(posedge clk); #1;
            key_valid = 1'b0;
            key_input = 4'h0;
        end
        @(posedge clk); #1;
        confirm = 1'b1;
        @(posedge clk); #1;
        confirm = 1'b0;
        repeat(5) @(posedge clk);
        $display("[%0t]   -> door_unlock=%b  lockout=%b", $time, door_unlock, lockout);
    endtask

    // =========================================================
    // Task: Drive the admin override sequence (single-cycle pulse).
    // Works from both IDLE and LOCKED_OUT states.
    // =========================================================
    task automatic do_admin_override();
        $display("[%0t] [admin_override] Asserting admin_override", $time);
        @(posedge clk); #1;
        admin_override = 1'b1;
        @(posedge clk); #1;
        admin_override = 1'b0;
        repeat(5) @(posedge clk);
        $display("[%0t]   -> door_unlock=%b  lockout=%b", $time, door_unlock, lockout);
    endtask

    // =========================================================
    // Task: Enter admin mode from IDLE and store a new password.
    // Sequence: assert admin_override + admin_set_mode together
    // (IDLE → ADMIN_MODE), then provide new_password_valid.
    // Updates the software mirror current_password.
    // =========================================================
    task automatic change_password(input logic [PASSWORD_LENGTH*4-1:0] new_pass);
        $display("[%0t] [change_password]  new_pass=0x%0h", $time, new_pass);
        // Enter ADMIN_MODE: both admin_override and admin_set_mode asserted in same cycle
        @(posedge clk); #1;
        admin_override = 1'b1;
        admin_set_mode = 1'b1;
        @(posedge clk); #1;
        admin_override = 1'b0;
        admin_set_mode = 1'b0;
        repeat(2) @(posedge clk);
        // Provide the new password while in ADMIN_MODE
        @(posedge clk); #1;
        new_password       = new_pass;
        new_password_valid = 1'b1;
        @(posedge clk); #1;
        new_password_valid = 1'b0;
        new_password       = '0;
        repeat(5) @(posedge clk);
        $display("[%0t]   Password successfully changed to 0x%0h.", $time, new_pass);
        current_password = new_pass;
    endtask

    // =========================================================
    // Main stimulus
    // =========================================================
    initial begin
        $display("========================================================");
        $display("  door_lock Testbench – Stimulus Generation");
        $display("  PASSWORD_LENGTH = %0d   MAX_TRIALS = %0d", PASSWORD_LENGTH, MAX_TRIALS);
        $display("========================================================");

        // Default stored password after reset: right-aligned 1
        // e.g. PASSWORD_LENGTH=4 → 16'h0001 (digit sequence: 0,0,0,1)
        current_password = {{(PASSWORD_LENGTH-1)*4{1'b0}}, 4'h1};

        // Initialise all inputs before clock starts toggling
        srst               = 1'b0;
        key_input          = 4'h0;
        key_valid          = 1'b0;
        confirm            = 1'b0;
        admin_override     = 1'b0;
        admin_set_mode     = 1'b0;
        new_password       = '0;
        new_password_valid = 1'b0;

        reset_dut();

        // ======================================================
        // Scenario 1: Correct password entry (default password)
        // Expected: door_unlock asserts, fail_count resets to 0.
        // ======================================================
        $display("\n--- Scenario 1: Correct password entry (default 0x%0h) ---",
                 current_password);
        enter_password(current_password, "CORRECT");
        repeat(2) @(posedge clk);

        // ======================================================
        // Scenario 2: Single incorrect password entry
        // Expected: PASSWORD_FAIL, fail_count becomes 1.
        // ======================================================
        $display("\n--- Scenario 2: Incorrect password entry ---");
        enter_password(16'h1234, "WRONG_1234");
        repeat(2) @(posedge clk);

        // ======================================================
        // Scenario 3: Multiple incorrect attempts → lockout
        // fail_count is 1 from scenario 2; two more wrongs reach
        // MAX_TRIALS=3 and trigger LOCKED_OUT.
        // ======================================================
        $display("\n--- Scenario 3a: Second incorrect attempt (fail_count → 2) ---");
        enter_password(16'h5678, "WRONG_5678");
        repeat(2) @(posedge clk);

        $display("\n--- Scenario 3b: Third incorrect attempt (fail_count → 3, triggers lockout) ---");
        enter_password(16'h9999, "WRONG_9999");
        repeat(4) @(posedge clk);
        $display("[%0t]   After %0d wrong attempts: lockout=%b (expect 1)",
                 $time, MAX_TRIALS, lockout);

        // ======================================================
        // Scenario 4: Admin override from LOCKED_OUT state
        // Expected: door_unlock pulses, lockout deasserts, → IDLE.
        // ======================================================
        $display("\n--- Scenario 4: Admin override from lockout ---");
        do_admin_override();
        repeat(2) @(posedge clk);

        // ======================================================
        // Scenario 5: Change password via admin mode, then verify
        // DUT is in IDLE after scenario 4.
        // ======================================================
        $display("\n--- Scenario 5: Change password to 0x1357 ---");
        change_password(16'h1357);
        repeat(2) @(posedge clk);

        $display("\n--- Scenario 5b: Enter new (changed) password – expect unlock ---");
        enter_password(current_password, "NEW_CORRECT");
        repeat(2) @(posedge clk);

        $display("\n--- Scenario 5c: Enter old (default) password – expect fail ---");
        enter_password({{(PASSWORD_LENGTH-1)*4{1'b0}}, 4'h1}, "OLD_DEFAULT");
        repeat(2) @(posedge clk);

        // ======================================================
        // Scenario 6: Admin override from IDLE (no lockout)
        // Expected: door_unlock pulses once, FSM → PASSWORD_OK → IDLE.
        // ======================================================
        $display("\n--- Scenario 6: Admin override from IDLE (no lockout) ---");
        reset_dut();
        current_password = {{(PASSWORD_LENGTH-1)*4{1'b0}}, 4'h1};
        do_admin_override();
        repeat(2) @(posedge clk);

        // ======================================================
        // Scenario 7: Partial password entry (fewer digits than
        // PASSWORD_LENGTH before confirm)
        // Expected: ENTER_PASS → PASSWORD_FAIL (digit count mismatch).
        // ======================================================
        $display("\n--- Scenario 7: Partial password (2 of %0d digits) ---",
                 PASSWORD_LENGTH);
        enter_partial_password(2, current_password, "PARTIAL_2");
        repeat(2) @(posedge clk);

        $display("\n--- Scenario 7b: Zero digits then confirm ---");
        begin : scen7b
            @(posedge clk); #1;
            confirm = 1'b1;
            @(posedge clk); #1;
            confirm = 1'b0;
            repeat(5) @(posedge clk);
            $display("[%0t]   -> door_unlock=%b  lockout=%b", $time, door_unlock, lockout);
        end
        repeat(2) @(posedge clk);

        // ======================================================
        // Scenario 8: Key input with out-of-range digit values
        // (key_input > 9 should be ignored by the DUT)
        // ======================================================
        $display("\n--- Scenario 8: Out-of-range key values (A, F – should be ignored) ---");
        begin : scen8
            // Drive two invalid digits
            @(posedge clk); #1;
            key_input = 4'hA; key_valid = 1'b1;
            @(posedge clk); #1;
            key_valid = 1'b0; key_input = 4'h0;

            @(posedge clk); #1;
            key_input = 4'hF; key_valid = 1'b1;
            @(posedge clk); #1;
            key_valid = 1'b0; key_input = 4'h0;

            // Confirm – expect no unlock since no valid digits registered
            @(posedge clk); #1;
            confirm = 1'b1;
            @(posedge clk); #1;
            confirm = 1'b0;
            repeat(5) @(posedge clk);
            $display("[%0t]   -> door_unlock=%b  lockout=%b", $time, door_unlock, lockout);
        end
        repeat(2) @(posedge clk);

        // ======================================================
        // Scenario 9: Mix of valid and invalid digit values
        // Some valid digits followed by an invalid one, then confirm
        // ======================================================
        $display("\n--- Scenario 9: Mix valid/invalid digits then confirm ---");
        begin : scen9
            @(posedge clk); #1;
            key_input = 4'h0; key_valid = 1'b1;   // valid: 0
            @(posedge clk); #1; key_valid = 1'b0; key_input = 4'h0;

            @(posedge clk); #1;
            key_input = 4'hB; key_valid = 1'b1;   // invalid: 11
            @(posedge clk); #1; key_valid = 1'b0; key_input = 4'h0;

            @(posedge clk); #1;
            key_input = 4'h0; key_valid = 1'b1;   // valid: 0
            @(posedge clk); #1; key_valid = 1'b0; key_input = 4'h0;

            @(posedge clk); #1;
            key_input = 4'h1; key_valid = 1'b1;   // valid: 1
            @(posedge clk); #1; key_valid = 1'b0; key_input = 4'h0;

            @(posedge clk); #1;
            confirm = 1'b1;
            @(posedge clk); #1;
            confirm = 1'b0;
            repeat(5) @(posedge clk);
            $display("[%0t]   -> door_unlock=%b  lockout=%b", $time, door_unlock, lockout);
        end
        repeat(2) @(posedge clk);

        // ======================================================
        // Scenario 10: Stress test – random password sequences
        // Covers repeated correct/incorrect entries and lockout
        // recovery via admin override under randomised stimulus.
        // ======================================================
        $display("\n--- Scenario 10: Stress test (30 random password attempts) ---");
        reset_dut();
        current_password = {{(PASSWORD_LENGTH-1)*4{1'b0}}, 4'h1};

        begin : stress_test
            logic [PASSWORD_LENGTH*4-1:0] rand_pass;
            int sw_fail_count;
            sw_fail_count = 0;

            for (int iter = 0; iter < 30; iter++) begin
                // Build a random password using only valid digits (0–9) per nibble
                for (int j = 0; j < PASSWORD_LENGTH; j++)
                    rand_pass[j*4 +: 4] = 4'($urandom_range(9, 0));

                $display("[%0t] [stress] iter=%0d  rand=0x%0h  stored=0x%0h",
                         $time, iter, rand_pass, current_password);

                enter_password(rand_pass, "STRESS");

                if (rand_pass == current_password) begin
                    $display("[%0t]   (password matched – fail_count reset)", $time);
                    sw_fail_count = 0;
                end else begin
                    sw_fail_count++;
                    $display("[%0t]   (mismatch – sw_fail_count=%0d)", $time, sw_fail_count);
                end

                // After enough wrong attempts the DUT asserts lockout;
                // clear it with admin override so the test can continue.
                @(posedge clk);
                if (lockout) begin
                    $display("[%0t]   Lockout detected – issuing admin override.", $time);
                    do_admin_override();
                    sw_fail_count = 0;
                end

                repeat(2) @(posedge clk);
            end
        end

        // ======================================================
        // Scenario 11: Change password during stress, verify it,
        // then lock out again and use admin override to recover.
        // ======================================================
        $display("\n--- Scenario 11: Password change mid-run then new-password verification ---");
        // Ensure we are in IDLE (may need to override if locked)
        if (lockout) begin
            $display("[%0t]   Pre-scenario lockout clear via admin override.", $time);
            do_admin_override();
        end
        repeat(2) @(posedge clk);

        change_password(16'h2468);   // new password: 2,4,6,8

        $display("\n--- Scenario 11b: Verify changed password (0x2468) ---");
        enter_password(current_password, "POST_CHANGE_CORRECT");
        repeat(2) @(posedge clk);

        $display("\n--- Scenario 11c: Trigger lockout with new password in force ---");
        repeat(MAX_TRIALS) begin
            enter_password(16'h1111, "WRONG_1111");
            repeat(2) @(posedge clk);
        end
        $display("[%0t]   lockout=%b after %0d wrong attempts", $time, lockout, MAX_TRIALS);

        $display("\n--- Scenario 11d: Admin override to exit lockout ---");
        do_admin_override();
        repeat(2) @(posedge clk);

        // ======================================================
        // Scenario 12: Assert srst mid-sequence to verify reset
        // clears state and restores default password.
        // ======================================================
        $display("\n--- Scenario 12: Mid-sequence synchronous reset ---");
        // Start entering a password then reset before confirming
        @(posedge clk); #1;
        key_input = 4'h2; key_valid = 1'b1;
        @(posedge clk); #1; key_valid = 1'b0; key_input = 4'h0;

        @(posedge clk); #1;
        key_input = 4'h4; key_valid = 1'b1;
        @(posedge clk); #1; key_valid = 1'b0; key_input = 4'h0;

        $display("[%0t]   Asserting srst mid-entry...", $time);
        @(posedge clk); #1;
        srst = 1'b1;
        repeat(3) @(posedge clk); #1;
        srst = 1'b0;
        repeat(2) @(posedge clk);
        $display("[%0t]   Post-reset: door_unlock=%b  lockout=%b", $time, door_unlock, lockout);

        // Restore software mirror – reset returns to default password
        current_password = {{(PASSWORD_LENGTH-1)*4{1'b0}}, 4'h1};

        // Confirm correct password still works after reset
        $display("\n--- Scenario 12b: Default password after mid-sequence reset ---");
        enter_password(current_password, "DEFAULT_POST_RESET");
        repeat(2) @(posedge clk);

        // ======================================================
        // End of test
        // ======================================================
        $display("\n========================================================");
        $display("  All stimulus scenarios complete at time %0t", $time);
        $display("========================================================");
        repeat(10) @(posedge clk);
        $finish;
    end

endmodule
