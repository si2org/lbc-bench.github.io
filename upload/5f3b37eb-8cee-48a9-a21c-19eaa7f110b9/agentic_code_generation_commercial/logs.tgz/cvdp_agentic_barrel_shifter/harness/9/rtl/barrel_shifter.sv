module barrel_shifter (
    input  [7:0] data_in,
    input  [2:0] shift_bits,
    input        shift_mode,
    input        left_right,
    output reg [7:0] data_out
);

always @(*) begin
    if (shift_mode) begin
            if (left_right)
            data_out = data_in << shift_bits;
        else
            data_out = $signed(data_in) >>> shift_bits;
    end else begin
        if (left_right)
            data_out = data_in << shift_bits;
        else
            data_out = data_in >> shift_bits;
    end

    // SVA immediate assertion: validate data_out against the expected shift result
    assert (data_out == (left_right ? (data_in << shift_bits) :
                         (shift_mode ? (8'($signed(data_in) >>> shift_bits)) :
                                       (data_in >> shift_bits))))
        else $error("barrel_shifter: data_out validation FAILED! data_in=0x%0h shift_bits=%0d shift_mode=%0b left_right=%0b Expected=0x%0h Got=0x%0h",
                    data_in, shift_bits, shift_mode, left_right,
                    (left_right ? (data_in << shift_bits) :
                     (shift_mode ? (8'($signed(data_in) >>> shift_bits)) :
                                   (data_in >> shift_bits))),
                    data_out);
end

endmodule